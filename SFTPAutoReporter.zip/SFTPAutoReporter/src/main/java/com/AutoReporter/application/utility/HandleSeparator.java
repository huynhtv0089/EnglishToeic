package com.AutoReporter.application.utility;

import java.io.File;
import java.util.regex.Matcher;

public class HandleSeparator {
	
	public static String handlerStr(String value) {
		String strPath = value.replaceAll("/", Matcher.quoteReplacement(File.separator));
		
		int position = strPath.length()-1;
		String theEnd = String.valueOf(strPath.charAt(position));
		if(!File.separator.equalsIgnoreCase(theEnd)) {
			return strPath += File.separator;
		}
		
		return strPath;
	}
	
	public static String handleSeparatorTheEndSftp(String value) {
		int position = value.length()-1;
		String theEnd = String.valueOf(value.charAt(position));
		
		if(!"/".equalsIgnoreCase(theEnd)) {
			return value += "/";
		}
		
		return value;
	}
}
