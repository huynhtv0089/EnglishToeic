package com.AutoReporter.application;

import java.io.File;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.AutoReporter.application.utility.HandleSeparator;
import com.AutoReporter.services.SftpHandle;

@Component
public class Worker {
	
	@Autowired
	private SftpHandle stftHandler;
	
	@Value("${app.sftp.remoteDirectoryServer}")
	private String remoteDirectoryServer;//dirServer;
	
	@Value("${app.sftp.remoteDirectoryLocal}")
	private String remoteDirectoryLocal; //dirLocal;
	
	@EventListener(ApplicationReadyEvent.class)
	public void toDo() throws InterruptedException {
		String dirServer = HandleSeparator.handleSeparatorTheEndSftp(remoteDirectoryServer);
		String dirLocal = HandleSeparator.handlerStr(remoteDirectoryLocal);
		
		while(true) {
			TimeUnit.MILLISECONDS.sleep(250);
			Collection<File> files = FileUtils.listFiles(new File(dirLocal), null, true);
			Map<File, String[]> containerData = new HashMap<>();
			for(File file : files) {
				String arrOne = file.getPath().split(Matcher.quoteReplacement(dirLocal))[1];
				containerData.put(file, Arrays.stream(arrOne.split(Matcher.quoteReplacement(File.separator))).filter(element -> !"".equals(element)).toArray(String[]::new));
			}
			
			if(files.size() != 0) {
				stftHandler.uploadFilesFromlocal(dirLocal, dirServer, containerData);
				//stftHandler.checkIntegrityFile(dirLocal, dirServer);
				//stftHandler.downloadFilesFromRemote(dirLocal, dirServer);
				//stftHandler.deleteFilesFromLocal(dirLocal);
			}
		}
	}
}
