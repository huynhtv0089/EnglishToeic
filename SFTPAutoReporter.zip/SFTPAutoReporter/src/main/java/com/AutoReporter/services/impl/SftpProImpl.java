package com.AutoReporter.services.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AutoReporter.application.utility.EncryptDecryptUtils;
import com.AutoReporter.configuration.SftpProperties;
import com.AutoReporter.services.SftpHandle;
import com.enterprisedt.net.ftp.FTPException;
import com.enterprisedt.net.ftp.ssh.SSHFTPClient;
import com.enterprisedt.util.license.License;

@Service
public class SftpProImpl implements SftpHandle{
private static final Logger LOGGER = LoggerFactory.getLogger(SftpProImpl.class);

	@Autowired
	private SftpProperties sftpProtocal;
	
	private EncryptDecryptUtils encryptDecryptUtils;
	
	private SSHFTPClient remote;
	
	/*@PostConstruct
	public void startApp() {
        try {
        	encryptDecryptUtils = new EncryptDecryptUtils("DES");
        } catch (Exception e) {
        }
        //da#rZW33
        System.out.println("encrypt: " + encryptDecryptUtils.encrypt("F3Vd54$!aD"));
        System.out.println("decrypt: " + encryptDecryptUtils.decrypt("CXVjAhrXT0kaZs/n4coLNw=="));
	}*/
	
	@Override
	@SuppressWarnings("static-access")
	public void connection() {
		License.setLicenseDetails("GHPFarEastLtd", "348-7352-2340-1248");
		try {
			remote = new SSHFTPClient();
			remote.setRemoteHost(this.sftpProtocal.getHost());
			remote.setRemotePort(this.sftpProtocal.getPort());
			remote.setAuthentication(this.sftpProtocal.getUsername(), encryptDecryptUtils.decrypt(this.sftpProtocal.getPassword()));
			remote.getValidator().setHostValidationEnabled(false);
			remote.connect();
		} catch (FTPException | IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void disconnection() {
		try {
			this.remote.quit();
		} catch (IOException | FTPException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void uploadFilesFromlocal(String dirLocal, String dirServer, Map<File, String[]> containerData){
		this.connection();
		
		containerData.forEach((filePathLocal, containerDir) -> {
			double beforeSize = filePathLocal.length();
			while(true) {
				File thisFile = new File(String.valueOf(filePathLocal));
				double afterSize = thisFile.length();
				double sizeRemote= 0;
				if((afterSize - beforeSize) == 0) {
					LOGGER.info("Begin upload file with path local : '{}'", filePathLocal);
					try {
						if(containerDir.length > 1) {
							String[] arrDir = Arrays.stream(containerDir).filter(element -> element.indexOf(".") == -1).toArray(String[]::new);
							String storeDirectory = "";
							for(int i=0; i<arrDir.length; i++) {
								if(storeDirectory == null || storeDirectory.isEmpty()) {
									if(!remote.exists(dirServer + arrDir[i])) {
										remote.mkdir(dirServer + arrDir[i]);
									}
								} else {
									if(!remote.exists(dirServer + storeDirectory + arrDir[i])) {
										remote.mkdir(dirServer + storeDirectory + arrDir[i]);
									}
								}
								storeDirectory += arrDir[i] + "/";
								
								if(i == (arrDir.length-1)) {
									remote.put(String.valueOf(filePathLocal), (dirServer+storeDirectory));
									sizeRemote = remote.fileDetails((dirServer+storeDirectory)+filePathLocal.getName()).size();
								}
							}
						} else {
							remote.put(String.valueOf(filePathLocal), dirServer);
							sizeRemote = remote.fileDetails(dirServer+filePathLocal.getName()).size();
						}
						
						if(sizeRemote >= beforeSize) {
							deleteFilesFromLocal(String.valueOf(filePathLocal));
						} else {
							LOGGER.info("File not yet integrity, remove file on server : '{}'", dirServer+filePathLocal.getName());
							remote.delete(dirServer+filePathLocal.getName());
							break;
						}
					} catch (FTPException | IOException e) {
						LOGGER.error("ERROR UPLOAD FILE: Wrong Directory. Current Server haven't directory '{}' this", dirServer);
						e.printStackTrace();
					}
				    LOGGER.info("Finished uploaded file into path remote : '{}'", dirServer);
				    break;
				} else {
					break;
				}
			}
		});
		
		this.disconnection();
	}
	
	@Override
	public void downloadFilesFromRemote(String dirLocal, String dirServer) {
		this.connection();
		try {
			try {
				for(String fileName : remote.dir(dirServer)) {
					if(".".equals(fileName) || "..".equals(fileName)) {
						continue;
					}
					String filePathLocal = dirLocal + fileName;
					
					LOGGER.info("Begin download file with path remote : '{}'", dirServer + "/" + fileName);
					remote.get(new FileOutputStream(filePathLocal), dirServer + "/" + fileName);
					LOGGER.info("Finished download file into path local : '{}'", filePathLocal);
				}
			} catch (IOException e) {
				LOGGER.error("ERROR DOWNLOAD FILE: Wrong Directory. Current Server haven't directory '{}' this", dirServer);
			}
		} catch(FTPException e) {
			LOGGER.error("ERROR DOWNLOAD FILE: File Directory. Current local haven't directory '{}' this", dirLocal);
		}
		this.disconnection();
	}
	
	@Override
	public void deleteFilesFromLocal(String filePath) {
		Path fileToDeletePath = Paths.get(filePath);
		try {
			Files.delete(fileToDeletePath);
		} catch (IOException e) {
			LOGGER.info("Finished clean file in directory : '{}'", filePath);
		}
		
	}

	@Override
	public boolean checkIntegrityFile(String dirLocal, String dirServer) {
		try {
			for(String fileName : remote.dir(dirServer)) {
				if(".".equals(fileName) || "..".equals(fileName)) {
					continue;
				}
			}
		} catch (IOException | FTPException e) {
			e.printStackTrace();
			LOGGER.error("ERROR remote");
		}
		
		return false;
	}
}
