package com.AutoReporter.services;

import java.io.File;
import java.util.Map;

public interface SftpHandle {
	void connection();
	void uploadFilesFromlocal(String dirLocal, String dirServer, Map<File, String[]> containerData);
	void downloadFilesFromRemote(String dirLocal, String dirServer);
	void deleteFilesFromLocal(String dirLocal);
	boolean checkIntegrityFile(String dirLocal, String dirServer);
	void disconnection();
}
