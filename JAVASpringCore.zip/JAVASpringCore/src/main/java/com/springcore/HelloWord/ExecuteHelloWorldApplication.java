package com.springcore.HelloWord;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ExecuteHelloWorldApplication {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("HelloWorld_Beans.xml");
		
		//Just use 1 bean define in file xml
		//If have 2 same been then comment or remove 1 bean
		//Way different, use getBean(get id of been), Example like way below
		MyMessage app = (MyMessage)context.getBean(MyMessage.class);
		
		//getBean("singleMessage") will be mapping into file 'HelloWorldBeans.xml' 
		//and It will be find name which 'id' of any bean 
		//MyMessage app = (MyMessage)context.getBean("singleMessage");
		app.getMessage();
		
		context.close();
	}
}
