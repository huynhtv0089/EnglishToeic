package com.springcore.HelloWord;

public class MyMessage {
	private String message;
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void getMessage() {
		System.out.println(message + " spring core");
	}
}
