package com.springcore.DependencyInjection_01.services.impl;

import com.springcore.DependencyInjection_01.services.MessageService;

public class EmailService implements MessageService {

	public boolean sendMessage(String message, String recipient) {
		System.out.println("Email sent to " + message + " with Message=" + recipient);
		
		return true;
	}

}
