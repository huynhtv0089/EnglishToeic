package com.springcore.DependencyInjection_01.application;

import com.springcore.DependencyInjection_01.services.MessageService;

public class MyXMLApplication {
	private MessageService messageService;
	
	public void setService(MessageService messageService) {
		this.messageService = messageService;
	}
	
	public boolean processMessage(String message, String recipient) {
		return this.messageService.sendMessage(message, recipient);
	}
}
