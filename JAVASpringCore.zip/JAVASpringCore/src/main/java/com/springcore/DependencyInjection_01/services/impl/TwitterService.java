package com.springcore.DependencyInjection_01.services.impl;

import com.springcore.DependencyInjection_01.services.MessageService;

public class TwitterService implements MessageService {

	public boolean sendMessage(String message, String recipient) {
		System.out.println("Twitter message Sent to " + recipient + " with Message=" + message);
		
		return true;
	}

}
