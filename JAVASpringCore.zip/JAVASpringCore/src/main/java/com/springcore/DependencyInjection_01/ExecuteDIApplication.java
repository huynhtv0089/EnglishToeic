package com.springcore.DependencyInjection_01;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.DependencyInjection_01.application.MyApplication;
import com.springcore.DependencyInjection_01.application.MyXMLApplication;
import com.springcore.DependencyInjection_01.configuration.DIConfiguration;

public class ExecuteDIApplication {
	public static void main(String[] args) {
		/*AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DIConfiguration.class);
		MyApplication app = context.getBean(MyApplication.class);*/
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("Dependency_Injection_Beans01.xml");
		// can use both
		// MyXMLApplication app = context.getBean(MyXMLApplication.class);
		MyXMLApplication app = (MyXMLApplication)context.getBean("MyXMLApp");
		
		
		app.processMessage("Hi pankaj", "pankaj@gmail.com");
		
		context.close();
	}
}
