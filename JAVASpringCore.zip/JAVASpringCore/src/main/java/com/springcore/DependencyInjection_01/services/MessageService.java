package com.springcore.DependencyInjection_01.services;

public interface MessageService {
	boolean sendMessage(String message, String recipient);
}
