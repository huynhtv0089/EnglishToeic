package com.springcore.DependencyInjection_01.application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.springcore.DependencyInjection_01.services.MessageService;

@Component
public class MyApplication {
	private MessageService messagePrivate;
	
	@Autowired
	public void setService(MessageService messagePrivate) {
		this.messagePrivate = messagePrivate;
	}
	
	public boolean processMessage(String message, String recipient) {
		return messagePrivate.sendMessage(message, recipient);
	}
}
