package com.springcore.DependencyInjection_01.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.springcore.DependencyInjection_01.services.MessageService;
import com.springcore.DependencyInjection_01.services.impl.EmailService;

@Configuration
@ComponentScan(value={"com.springcore.DI.application"})
public class DIConfiguration {
	
	@Bean
	public MessageService getMessageEmailService() {
		return new EmailService();
	}
	
	/*@Bean
	public MessageService getMessageTwitterService() {
		return new TwitterService();
	}*/
	
}
