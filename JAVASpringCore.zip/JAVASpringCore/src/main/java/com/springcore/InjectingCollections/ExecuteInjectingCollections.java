package com.springcore.InjectingCollections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ExecuteInjectingCollections {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Injecting_Collections_Beans.xml");
		Collections collection = (Collections)context.getBean("javaCollection");
		
		collection.getAddressList();
		collection.getAddressSet();
		collection.getAddressMap();
		collection.getAddressProp();
	}
}
