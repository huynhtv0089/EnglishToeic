package com.springcore.Scope;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ExecuteScopeApplication {

	public static void main(String[] args) {
		//ApplicationContext context = new ClassPathXmlApplicationContext("ScopeBeans.xml");
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("Scope_Beans.xml");
		
		/*
		 * Just use 1 bean definde in file xml
		 * If have 2 same been then comment or remove 1 bean
		 * Way different, use getBean(get id of been)
		 */
		//MessageScope objA = context.getBean(MessageScope.class);
		
		
		MessageScope objA = (MessageScope) context.getBean("scopeMessageSingleton");
		/*
		 * If use been scopeMessagePrototype then comment line 13
		 * Because in bean injected value already
		 */
		objA.setMessage("I'm object A");
		
		objA.getMessage();
		
		MessageScope objB = (MessageScope) context.getBean("scopeMessageSingleton");
		objB.getMessage();
		
		context.close();
	}

}
