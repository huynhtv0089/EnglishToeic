package com.springcore.DefinitionInheritance;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ExecuteDefinitionInheritanceApp {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Definition_Inheritance_Beans.xml");
		
		MessageHello hello = (MessageHello) context.getBean("messageHello");
		hello.getMessage1();
		hello.getMessage2();
		
		System.out.println("");
		
		MessageHi hi = (MessageHi) context.getBean("messageHi");
		hi.getMessage1();
		hi.getMessage2();
		hi.getMessage3();
		
	}
}
