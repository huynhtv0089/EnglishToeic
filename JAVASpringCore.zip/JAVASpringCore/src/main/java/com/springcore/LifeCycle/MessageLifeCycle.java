package com.springcore.LifeCycle;

public class MessageLifeCycle {
	private String message;
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void getMessage() {
		System.out.println("Your message: " + message);
	}
	
	public void init123() {
		System.out.println("Bean is going through init.");
	}
	
	public void destroy123() {
		System.out.println("Bean will destroy now.");
	}
}	
