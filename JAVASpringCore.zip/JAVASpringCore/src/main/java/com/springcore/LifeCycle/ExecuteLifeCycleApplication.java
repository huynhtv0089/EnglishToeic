package com.springcore.LifeCycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ExecuteLifeCycleApplication {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("LifeCycle_Beans.xml");
		MessageLifeCycle messageLifeCycle = (MessageLifeCycle) context.getBean("lifeCycleMessage");
		messageLifeCycle.getMessage();
		
		context.registerShutdownHook();
		//context.close();
	}
}
