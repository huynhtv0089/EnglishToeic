package com.springcore.DependencyInjection_02;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ExecuteMainApplication {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Dependency_Injection_Beans02.xml");
		TextEditor textEditor = context.getBean(TextEditor.class);
		textEditor.spellCheck();

	}
}
