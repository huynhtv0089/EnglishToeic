package com.springcore.ConfigurationBeanAnnotations.examp2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ExecuteExamp2 {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(TextEditorConfig.class);
		
		TextEditor textEditor = context.getBean(TextEditor.class);
		textEditor.spellCheck();
	}
}
