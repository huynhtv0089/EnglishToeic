package com.springcore.ConfigurationBeanAnnotations.examp4;

public class Bar {
	private String message;
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void getMessage() {
		System.out.println("your message: " + message);
	}
}
