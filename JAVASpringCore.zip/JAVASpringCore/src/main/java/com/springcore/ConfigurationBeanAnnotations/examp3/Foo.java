package com.springcore.ConfigurationBeanAnnotations.examp3;

public class Foo {
	public void init() {
		System.out.println("Call method init() and inside method init()");
	}
	
	public void cleanUp() {
		System.out.println("Call method cleanUp() and inside method cleanUp()");
	}
}
