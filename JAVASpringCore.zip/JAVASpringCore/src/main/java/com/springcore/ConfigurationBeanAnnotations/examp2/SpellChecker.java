package com.springcore.ConfigurationBeanAnnotations.examp2;

public class SpellChecker {
	public SpellChecker() {
		System.out.println("Inside constructor of SpellChecker");
	}
	
	public void checkSpelling() {
		System.out.println("Get method checkSpelling");
	}
}
