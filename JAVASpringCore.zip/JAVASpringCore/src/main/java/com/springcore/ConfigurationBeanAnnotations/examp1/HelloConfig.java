package com.springcore.ConfigurationBeanAnnotations.examp1;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
//@ComponentScan(value={"com.springcore.ConfigurationBeanAnnotations.examp1"})
public class HelloConfig {
	
	@Bean
	public HelloWorld beanHelloWord() {
		return new HelloWorld();
	}
	
}
