package com.springcore.ConfigurationBeanAnnotations.examp3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ExecuteExamp3 {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(LifeCycleConfig.class);
		Foo foo = context.getBean(Foo.class);
		
		context.close();
	}
}
