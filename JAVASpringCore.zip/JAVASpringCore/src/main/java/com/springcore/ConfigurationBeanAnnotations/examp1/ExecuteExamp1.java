package com.springcore.ConfigurationBeanAnnotations.examp1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ExecuteExamp1 {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(HelloConfig.class);
		
		HelloWorld hello = context.getBean(HelloWorld.class);
		hello.setMessage("hello annotation");
		hello.getMessage();
	}

}
