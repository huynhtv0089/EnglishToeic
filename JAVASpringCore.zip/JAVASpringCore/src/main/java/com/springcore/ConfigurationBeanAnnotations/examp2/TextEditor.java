package com.springcore.ConfigurationBeanAnnotations.examp2;

public class TextEditor {
	private SpellChecker spellChecker;
	
	public TextEditor() {
		
	}
	
	public TextEditor(SpellChecker spellChecker) {
		System.out.println("Inject into constructor of TextEditor");
		this.spellChecker = spellChecker;
	}
	
	public void setSpellChecker(SpellChecker spellChecker) {
		System.out.println("Inject into method setSpellChecker of TextEditor");
		this.spellChecker = spellChecker;
	}
	
	public void spellCheck() {
		this.spellChecker.checkSpelling();
	}
}
