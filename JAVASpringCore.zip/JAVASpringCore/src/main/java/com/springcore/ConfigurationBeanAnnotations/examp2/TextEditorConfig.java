package com.springcore.ConfigurationBeanAnnotations.examp2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TextEditorConfig {
	
	@Bean
	public TextEditor beanTextEditor() {
		//Inject pass constructor
		//return new TextEditor(beanSpellChecker());
		
		//Inject pass method set
		TextEditor te = new TextEditor();
		te.setSpellChecker(beanSpellChecker());
		return te;
	}
	
	@Bean
	public SpellChecker beanSpellChecker() {
		return new SpellChecker();
	}
	
}
