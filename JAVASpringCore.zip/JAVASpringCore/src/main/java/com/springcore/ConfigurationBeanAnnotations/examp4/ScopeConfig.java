package com.springcore.ConfigurationBeanAnnotations.examp4;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class ScopeConfig {
	
	@Bean
	//@Scope("singleton")
	@Scope("prototype")
	public Bar beanBar() {
		return new Bar();
	}
	
}
