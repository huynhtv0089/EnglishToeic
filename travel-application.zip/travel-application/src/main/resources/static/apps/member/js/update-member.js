var app = angular.module("updateMember", []).controller("updateMemberCtrl", ['$scope', '$http', function($scope, $http) {
	$http({
        method : "GET",
        url : "/view-member"
    }).then(function mySuccess(response) {
    	console.log('response: ' + JSON.stringify(response.data));
        $scope.metaData = response.data;
    	
    	$scope.name = response.data.name;
    	$scope.sex = response.data.sex;
    	$scope.age = response.data.age;
		$scope.phone = response.data.phone;
		$scope.address = response.data.address;
    }, function myError(response) {
    });
}]);
