var app = angular.module("member", []).controller("memberCtrl", ['$scope', '$http', function($scope, $http) {
	$http({
        method : "GET",
        url : "/getListMember"
    }).then(function mySuccess(response) {
        console.log('response: ' + JSON.stringify(response.data));
        $scope.metaData = response.data;
    }, function myError(response) {
    });
	
	$scope.getId = function(id) {
		$http.post("/getIdMember", id);
	}
}]);