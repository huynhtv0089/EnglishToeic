var app = angular.module("updateTour", []).controller("updateTourCtrl", ['$scope', '$http', function($scope, $http) {
	$http({
        method : "GET",
        url : "/view-Member"
    }).then(function mySuccess(response) {
    	console.log('response: ' + JSON.stringify(response.data));
        $scope.metaData = response.data;
    	
    	$scope.name = response.data.name;
    	$scope.beginDate = response.data.beginDate;
    	$scope.endDate = response.data.endDate;
		$scope.price = response.data.price;
		$scope.quantityMember = response.data.quantityMember;
		$scope.attended = response.data.attended;
		$scope.status = response.data.status;
    }, function myError(response) {
    });
}]);
