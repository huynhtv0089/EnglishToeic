var app = angular.module("tour", []).controller("tourCtrl", ['$scope', '$http', function($scope, $http) {
	$http({
        method : "GET",
        url : "/getListTour"
    }).then(function mySuccess(response) {
        console.log('response: ' + JSON.stringify(response.data));
        $scope.metaData = response.data;
    }, function myError(response) {
    });
	
	$scope.getId = function(id) {
		$http.post("/getIdTour", id);
	}
}]);
