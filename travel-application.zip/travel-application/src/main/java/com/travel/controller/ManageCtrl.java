package com.travel.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.travel.persistence.entity.Member;
import com.travel.persistence.entity.Tour;
import com.travel.services.login.LoginService;
import com.travel.services.member.MemberService;
import com.travel.services.tour.TourService;

@Controller
public class ManageCtrl {
	
	@Autowired
	private LoginService loginService;
	
	@Autowired
	private TourService tourService;
	
	@Autowired
	private MemberService memberService;
		
	@RequestMapping(value="/", method=RequestMethod.GET) 
	public String login() {
		loginService.createAdmin();
		
		return "/apps/login/login.html";
	}
	
	@RequestMapping(value="/handleLogin", method=RequestMethod.POST) 
	public String handlelogin(@RequestParam("username") String username, @RequestParam("password") String password) {

		boolean result = loginService.checkLogin(username, password);
		if(result) {
			return "redirect:/dashboard";
		}
		
		return "redirect:/";
	}
	
	@RequestMapping(value="/dashboard", method=RequestMethod.GET) 
	public String viewDashboard() {
		return "apps/dashboard.html";
	}
	
	@RequestMapping(value="/tour", method=RequestMethod.GET) 
	public String viewTour() {
		return "apps/tour/tour.html";
	}
	
	@RequestMapping(value="/member", method=RequestMethod.GET) 
	public String viewMember() {
		return "apps/member/member.html";
	}
	
	@RequestMapping(value="/getListTour", method=RequestMethod.GET)
	public ResponseEntity<List<Tour>> listTour() {
		List<Tour> data = tourService.listTour();
		
		return new ResponseEntity<List<Tour>>(data, HttpStatus.OK);
	}
	
	@RequestMapping(value="/getListMember", method=RequestMethod.GET)
	public ResponseEntity<List<Member>> listMember() {
		List<Member> data = memberService.listMember();
		
		return new ResponseEntity<List<Member>>(data, HttpStatus.OK);
	}
	
	@RequestMapping(value="/create-tour", method=RequestMethod.GET) 
	public String viewCreateTour() {
		return "apps/tour/create-tour.html";
	}
	
	@RequestMapping(value="/create-member", method=RequestMethod.GET) 
	public String viewCreateMember() {
		return "apps/member/create-member.html";
	}
	
	@RequestMapping(value="/handle-create-tour", method=RequestMethod.POST) 
	public String handleCreateTour(@RequestParam("name") String name, 
			@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate,
			@RequestParam("quantityMember") String quantityMember,
			@RequestParam("price") String price) {		
		
		Tour tour = new Tour(name, Integer.parseInt(quantityMember), 
								Integer.parseInt(price), 
								LocalDate.parse(beginDate), 
								LocalDate.parse(endDate));
		boolean result = tourService.createTour(tour);
		if(result)
			return "redirect:/tour";
		else 
			return "redirect:/create-tour";
	}
	
	@RequestMapping(value="/handle-create-member", method=RequestMethod.POST) 
	public String handleCreateMember(@RequestParam("name") String name, 
			@RequestParam("sex") String sex, @RequestParam("age") String age,
			@RequestParam("phone") String phone, @RequestParam("address") String address) {		
		
		Member member = new Member(name, sex, Integer.parseInt(age), phone, address);
		boolean result = memberService.createMember(member);
		if(result)
			return "redirect:/member";
		else 
			return "redirect:/create-member";
	}
	
	@RequestMapping(value="/delete-tour/{id}", method=RequestMethod.GET) 
	public String deleteTour(@PathVariable String id) {		
		
		tourService.deleteTour(Integer.parseInt(id));
	
		return "redirect:/tour";
	}
	
	@RequestMapping(value="/delete-member/{id}", method=RequestMethod.GET) 
	public String deleteMember(@PathVariable String id) {		
		
		memberService.deleteMember(Integer.parseInt(id));
	
		return "redirect:/member";
	}
	
	@RequestMapping(value="/getIdTour", method=RequestMethod.POST) 
	public String getIdTour(@RequestBody String id) {
		tourService.updateId(Integer.parseInt(id));
		
		return "apps/tour/update-tour.html";
	}
	
	@RequestMapping(value="/getIdMember", method=RequestMethod.POST) 
	public String getIdMember(@RequestBody String id) {
		System.out.println("id: " + id);
		memberService.updateId(Integer.parseInt(id));
		
		return "apps/member/update-member.html";
	}
	
	@RequestMapping(value="/update-tour", method=RequestMethod.GET) 
	public String updateTour() {
		return "apps/tour/update-tour.html";
	}
	
	@RequestMapping(value="/update-member", method=RequestMethod.GET) 
	public String updateMember() {
		return "apps/member/update-member.html";
	}
	
	@RequestMapping(value="/handle-update-tour", method=RequestMethod.POST) 
	public String handleUpdateTour(@RequestParam("name") String name, 
			@RequestParam("beginDate") String beginDate,
			@RequestParam("endDate") String endDate,
			@RequestParam("quantityMember") String quantityMember,
			@RequestParam("price") String price) {		
		
		Tour tour = new Tour(name, Integer.parseInt(quantityMember), 
								Integer.parseInt(price), 
								LocalDate.parse(beginDate), 
								LocalDate.parse(endDate));
		tourService.updateTour(tour);
			
		return "redirect:/tour";
	}
	
	@RequestMapping(value="/handle-update-member", method=RequestMethod.POST) 
	public String handleUpdateMember(@RequestParam("name") String name, 
				@RequestParam("sex") String sex,
				@RequestParam("age") String age,
				@RequestParam("phone") String phone,
				@RequestParam("address") String address) {		
		
		Member member = new Member(name, sex, Integer.parseInt(age), phone, address);
		memberService.updateMember(member);
			
		return "redirect:/member";
	}

	@RequestMapping(value="/view-tour", method=RequestMethod.GET) 
	public ResponseEntity<Tour> viewInfoTour() {
		
		return new ResponseEntity<Tour>(tourService.infomationTour(), HttpStatus.OK);
	}
	
	@RequestMapping(value="/view-member", method=RequestMethod.GET) 
	public ResponseEntity<Member> viewInfoMember() {
		
		return new ResponseEntity<Member>(memberService.infomationMember(), HttpStatus.OK);
	}
	
}
