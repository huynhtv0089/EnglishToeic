package com.travel.services.member;

import java.util.List;

import com.travel.persistence.entity.Member;

public interface MemberService {
	public List<Member> listMember();
	public List<Member> listEmployee();
	public Member infomationMember();
	public void updateId(int id);
	public boolean createMember(Member member);
	public void updateMember(Member member);
	public void deleteMember(int id);
}
