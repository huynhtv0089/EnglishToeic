package com.travel.services.login.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.persistence.entity.Administrator;
import com.travel.persistence.repository.AdminRepo;
import com.travel.services.login.LoginService;

@Service
public class LoginImpl implements LoginService {
	
	@Autowired
	private AdminRepo adminRepo;
	
	@Override
	public void createAdmin() {
		Administrator admin = new Administrator();
		admin.setUsername("admin");
		admin.setPassword("admin");
		adminRepo.save(admin);
	}

	@Override
	public boolean checkLogin(String username, String password) {
		for(Administrator element : adminRepo.findAll()) {
			if(element.getUsername().equals(username) && element.getPassword().equals(password)) {
				return true;
			}
		}
		
		return false;
	}

}
