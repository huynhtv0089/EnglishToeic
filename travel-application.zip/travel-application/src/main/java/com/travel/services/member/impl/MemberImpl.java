package com.travel.services.member.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.persistence.entity.Member;
import com.travel.persistence.repository.MemberRepo;
import com.travel.services.member.MemberService;

@Service
public class MemberImpl implements MemberService{
	
	@Autowired
	private MemberRepo memberRepo;
	
	private int id;
	
	@Override
	public List<Member> listMember() {
		return (List<Member>) memberRepo.findAllMember();
	}
	
	@Override
	public List<Member> listEmployee() {
		return (List<Member>) memberRepo.findAllEmployee();
	}

	@Override
	public Member infomationMember() {
		Member member = memberRepo.findById(this.id).get();
		return member;
	}

	@Override
	public void updateId(int id) {
		this.id = id;
	}

	@Override
	public boolean createMember(Member member) {
		if(member != null) {
			memberRepo.save(member);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void updateMember(Member member) {
		member.setId(this.id);
		
		memberRepo.save(member);
	}

	@Override
	public void deleteMember(int id) {
		Member delete = memberRepo.findById(id).get();
		memberRepo.delete(delete);
	}

}
