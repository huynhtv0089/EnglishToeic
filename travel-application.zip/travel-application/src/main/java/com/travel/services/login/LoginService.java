package com.travel.services.login;

public interface LoginService {
	public void createAdmin();
	public boolean checkLogin(String username, String password);
}
