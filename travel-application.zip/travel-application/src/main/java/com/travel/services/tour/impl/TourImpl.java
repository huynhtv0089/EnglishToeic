package com.travel.services.tour.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.persistence.entity.Tour;
import com.travel.persistence.repository.TourRepo;
import com.travel.services.tour.TourService;

@Service
public class TourImpl implements TourService {

	@Autowired
	private TourRepo tourRepo;
	
	private int id;
	
	@Override
	public List<Tour> listTour() {
		return (List<Tour>)tourRepo.findAll();
	}
	
	@Override
	public Tour infomationTour() {
		Tour tour = tourRepo.findById(this.id).get();
		return tour;
	}

	@Override
	public boolean createTour(Tour tour) {
		if(tour != null) {
			tourRepo.save(tour);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void updateTour(Tour tour) {
		tour.setId(this.id);
		
		tourRepo.save(tour);
	}

	@Override
	public void deleteTour(int id) {
		Tour delete = tourRepo.findById(id).get();
		tourRepo.delete(delete);
	}

	@Override
	public void updateId(int id) {
		this.id = id;
	}

}
