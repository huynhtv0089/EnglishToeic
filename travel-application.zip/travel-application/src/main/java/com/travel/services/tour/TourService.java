package com.travel.services.tour;

import java.util.List;

import com.travel.persistence.entity.Tour;

public interface TourService {
	public List<Tour> listTour();
	public Tour infomationTour();
	public void updateId(int id);
	public boolean createTour(Tour tour);
	public void updateTour(Tour tour);
	public void deleteTour(int id);
	public List<Tour> listOptionTour();
}
