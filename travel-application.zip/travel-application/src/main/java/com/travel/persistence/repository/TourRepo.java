package com.travel.persistence.repository;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.travel.persistence.entity.Tour;

@Transactional
@Repository
public interface TourRepo extends CrudRepository<Tour, Integer> {

}
