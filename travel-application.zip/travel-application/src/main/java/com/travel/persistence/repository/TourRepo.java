package com.travel.persistence.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.travel.persistence.entity.Tour;

@Transactional
@Repository
public interface TourRepo extends CrudRepository<Tour, Integer> {
	
	@Query("SELECT t.id, t.name FROM Tour t")
	public List<Tour> listOptionTour(); 
	
}
