package com.travel.persistence.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Tour implements Serializable {
	private static final long serialVersionUID = 7029120042307136590L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="name", length=250, nullable=false)
	private String name;
	
	@Column(name="quantity_member", nullable=false)
	private int quantityMember;
	
	@Column(name="price")
	private int price;
	
	@Column(name="begin_date")
	private LocalDate beginDate;
	
	@Column(name="end_data")
	private LocalDate endDate;
	
	@Column(name="attended")
	private int attended;
	
	@Column(name="status")
	private String status;
	
	public Tour() {
		
	}
	
	public Tour(String name, int quantityMember, int price, LocalDate beginDate, LocalDate endDate) {
		this.name = name;
		this.quantityMember = quantityMember;
		this.price = price;
		this.beginDate = beginDate;
		this.endDate = endDate;
		this.status = "Trống";
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getQuantityMember() {
		return quantityMember;
	}
	public void setQuantityMember(int quantityMember) {
		this.quantityMember = quantityMember;
	}
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	public LocalDate getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(LocalDate beginDate) {
		this.beginDate = beginDate;
	}
	
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public int getAttended() {
		return attended;
	}
	public void setAttended(int attended) {
		this.attended = attended;
	}	
	
}
