package com.travel.persistence.repository;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.travel.persistence.entity.Administrator;

@Transactional
@Repository
public interface AdminRepo extends CrudRepository<Administrator, Integer>{

}
