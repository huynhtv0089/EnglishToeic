package com.travel.persistence.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

@Entity
public class Member implements Serializable {
	private static final long serialVersionUID = -7505598198829829899L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="name", length=20, nullable=false)
	private String name;
	
	@Column(name="sex", length=10)
	private String sex;
	
	@Column(name="age")
	private int age;
	
	@Column(name="phone", length=12)
	private String phone;
	
	@Column(name="address", length=50)
	private String address;
	
	@Column(name="option", length=1, nullable=false)
	private int option;
	
	@ManyToOne(fetch = FetchType.LAZY) 
	private Tour tourId;
	
	@Transient
	private List<Tour> listOptTour;
	
	public Member() {
		
	}
	
	public Member(String name, String sex, int age, String phone, String address) {
		this.name = name;
		this.sex = sex;
		this.age = age;
		this.phone = phone;
		this.address = address;
		this.option = 0;
	}

	public Member(String name, String sex, int age, String phone, String address, int option) {
		this.name = name;
		this.sex = sex;
		this.age = age;
		this.phone = phone;
		this.address = address;
		this.option = option;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getOption() {
		return option;
	}
	public void setOption(int option) {
		this.option = option;
	}
	public Tour getTourId() {
		return tourId;
	}
	public void setTourId(Tour tourId) {
		this.tourId = tourId;
	}

	public List<Tour> getListOptTour() {
		return listOptTour;
	}

	public void setListOptTour(List<Tour> listOptTour) {
		this.listOptTour = listOptTour;
	}
	
}
