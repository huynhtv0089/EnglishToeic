package com.travel.persistence.repository;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.travel.persistence.entity.Member;

@Transactional
@Repository
public interface MemberRepo extends CrudRepository<Member, Integer> {

}
