/**
 * Runnable does not return result, Callable returns result.
 * 
 * For implementing Runnable, the run() method needs to be implemented which does not return anything, 
 * while for a Callable, the call() method needs to be implemented which returns a result on completion
 * 
 * A thread can�t be created with a Callable, it can only be created with a Runnable
 * 
 * Another difference is that the call() method can throw an exception whereas run() cannot.
 */

/**
 * ExecutorService - A sub-interface of Executor that adds functionality to manage the lifecycle of the tasks.
 */

package thread.pool.excutor.service;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ExecutorsExample {
	public static void main(String[] args) {
		System.out.println("Inside: " + Thread.currentThread().getName());
		
		System.out.println("Creating Executor Service...");
		
		/**
		 * Parameter number in "newFixedThreadPool" be number thread executor
		 */
		ExecutorService executorService = Executors.newFixedThreadPool(2);
		System.out.println("Creating a Runnable...");
		Runnable task1 = () -> {
			System.out.println("Executing Task1 inside: " + Thread.currentThread().getName());
			try {
				TimeUnit.SECONDS.sleep(5);
			} catch(InterruptedException e) {
				throw new IllegalStateException(e);
			}
		};
		
		Runnable task2 = () -> {
			System.out.println("Executing Task2 inside: " + Thread.currentThread().getName());
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch(InterruptedException e) {
				throw new IllegalStateException(e);
			}
		};
		
		Runnable task3 = () -> {
			System.out.println("Executing Task3 inside: " + Thread.currentThread().getName());
			try {
				TimeUnit.SECONDS.sleep(7);
			} catch(InterruptedException e) {
				throw new IllegalStateException(e);
			}
		};
		
		Callable<Integer> task4 = () -> {
			System.out.println("Executing Task4 inside: " + Thread.currentThread().getName());
			try {
				TimeUnit.SECONDS.sleep(1);
			} catch(InterruptedException e) {
				throw new IllegalStateException(e);
			}
			
			return 3;
		};
		
		
		System.out.println("Submit the task for execution...");
		executorService.submit(task1);
		executorService.submit(task2);
		executorService.submit(task3);
		executorService.submit(task4);
		
		System.out.println("Shutting down the executor");
		/**
		 * when shutdown() method is called on an executor service, it stops accepting new tasks, 
		 * waits for previously submitted tasks to execute, and then terminates the executor
		 */
		executorService.shutdown();
		
		/**
		 * this method interrupts the running task and shuts down the executor immediately
		 */
		//executorService.shutdownNow();
	}
}
