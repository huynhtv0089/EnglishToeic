/**
 * A sub-interface of ExecutorService. It adds functionality to schedule the execution of the tasks.
 */

package thread.pool.excutor.service;

import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ScheduleExecutorsExample {
	public static void main(String[] args) {
		ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(2);
		
		Runnable task1 = () -> {
			System.out.println("Executing task1 At " + System.currentTimeMillis());
		};
		
		Callable<Integer> task2 = () -> {
			System.out.println("Executing task2 At " + System.currentTimeMillis());
			
			return -1;
		};
		
		System.out.println("Submitting task at " + System.currentTimeMillis() + " to be executed after 5 seconds.");
		scheduledExecutorService.schedule(task1, 5, TimeUnit.SECONDS);
		scheduledExecutorService.schedule(task2, 3, TimeUnit.SECONDS);
		
		scheduledExecutorService.shutdown();
	}
}
