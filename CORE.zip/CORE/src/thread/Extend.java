/**
 * When you extends Thread class, after that you can�t extend any other class which you required. 
 * (As you know, Java does not allow inheriting more than one class).
 */

package thread;

public class Extend extends Thread {

	private String name;
	
	public Extend(String name) {
		this.name = name;
	}
	
	public void run() {
		System.out.println("Start " + name);
		
		for(int i = 0; i < 5; i++) {
			
			try {
				System.out.println(name + " work " + i);
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
		
		System.out.println(name + " exiting.");
	}

	
	
	public static void main(String[] args) {
		Extend thread1 = new Extend("Thread 1 - ");					//Time 1: New thread 1		
		thread1.start();											//Time 2: Thread 1 run. Then for loop running (don't care anything)
		
		
		Extend thread2 = new Extend("Thread 2 - ");					//Time 3: New thread 2		
		thread2.start();											//Time 4: Thread 2 run. Then for loop running (don't care anything)
		
		
		
	}
}
