package thread;

class Chat {
	boolean flag = false;
	
	public synchronized void Question(String msg) {
		if(flag) {
			try {
				wait();
			} catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println(msg);
		flag = true;
		notify();
	}
	
	public synchronized void Answer(String msg) {
		if(!flag) {
			try {
				wait();
			} catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println(msg);
		flag = false;
		notify();
	}
}

class T1 implements Runnable {
	private Chat chat;
	String[] s1 = {"Hello", "How are you ?", "I'm also doing fine!"};
	
	public T1(Chat chat) {
		this.chat = chat;
		new Thread(this, "Question").start();
	}

	@Override
	public void run() {
		for(String s : s1) {
			chat.Question(s);
		}
	}
}

class T2 implements Runnable {
	private Chat chat;
	String[] s2 = {"Hi", "I'm fine, and you ?", "Great!"};
	
	public T2(Chat chat) {
		this.chat = chat;
		new Thread(this, "Answer").start();
	}
	
	@Override
	public void run() {
		for(String s : s2) {
			chat.Answer(s);
		}
	}
	
}

class ThreadsExchangeInfo {
	public static void main(String[] args) {
		Chat chat = new Chat();
		new T1(chat);
		new T2(chat);
	}
}
