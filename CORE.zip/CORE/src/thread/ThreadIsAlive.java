package thread;

import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.Robot;
import java.awt.event.InputEvent;

class MyRunnable implements Runnable {
	
	public void run() {
		System.out.println(Thread.currentThread().getName() + ": Start.");
		for(int i = 0; i < 5; i++) {
			System.out.println(Thread.currentThread().getName() + ": " + i);
		}
		System.out.println(Thread.currentThread().getName() + ": Exit.");
	}
	
}



public class ThreadIsAlive {
	
	public static void main(String[] args) {
		Thread runMe = new Thread(new MyRunnable());
		runMe.start();
		
		System.out.println("live, true or false: " + runMe.isAlive());
		while(runMe.isAlive()) {
			System.out.println("state: " + runMe.getState());
		}
		System.out.println("live, true or false: " + runMe.isAlive());
	}
	
	/*public static void main(String[] args) throws InterruptedException {
	    //For testing
	    Thread.sleep(1000);

	    PointerInfo a = MouseInfo.getPointerInfo();
	    Point b = a.getLocation();
	    int xOrig = (int) b.getX();
	    int yOrig = (int) b.getY();

	    try {
	        Robot r = new Robot();

	        r.mouseMove(1720, 1360);
	        // press the left mouse button
	        r.mousePress(InputEvent.BUTTON1_MASK);
	        // release the left mouse button
	        r.mouseRelease(InputEvent.BUTTON1_MASK);

	        // move the mouse back to the original position
	        r.mouseMove(xOrig, yOrig);

	        Thread.sleep(3000);
	    } catch (Exception e) {
	        System.out.println(e.toString());
	    }
	}*/
}
