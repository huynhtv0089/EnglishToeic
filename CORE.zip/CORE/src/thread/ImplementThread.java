package thread;

import java.util.ArrayList;
import java.util.List;

class ArrayListCollection {
	private List<Integer> data;
	
	public ArrayListCollection() {
		this.data = new ArrayList<>();
		for(int i = 100; i --> 0; ) {
			data.add(i);
		}
	}
	
	
}

public class ImplementThread {
	public static void main(String[] args) {
		
	}
}
