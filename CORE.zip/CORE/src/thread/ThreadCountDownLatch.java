package thread;

import java.util.concurrent.CountDownLatch;

class MyCountDownLatch implements Runnable {
	
	private CountDownLatch latch;

	public MyCountDownLatch(CountDownLatch latch) {
		this.latch = latch;
	}
	
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName());
		try {
			latch.await();
			for(int i = 0; i < 5; i++) {
				System.out.println(i);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}

public class ThreadCountDownLatch {
	public static void main(String[] args) {
		CountDownLatch latch = new CountDownLatch(2);
		new Thread(new MyCountDownLatch(latch)).start();
		new Thread(new MyCountDownLatch(latch)).start();
		
		latch.countDown();
	}
}
