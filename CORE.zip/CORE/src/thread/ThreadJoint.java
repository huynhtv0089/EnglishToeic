/* The join() method allows one thread to wait for the completion of another. */

/**
 * The main thread creates and starts the t1 and t2 threads. The two threads start running in parallel.
 
 * The main thread calls t1.join() to wait for the t1 thread to finish.
 
 * The t1 thread completes and the t1.join() method returns in the main thread. Note that t1 could already have finished before the join() 
   call is made in which case the join() call will return immediately.
   
 * The main thread calls t2.join() to wait for the t2 thread to finish.
 
 * The t2 thread completes (or it might have completed before the t1 thread did) and the t2.join() method returns in the main thread.
 */

package thread;

class MethodJoin implements Runnable {
	
	public void run() {
		System.out.println(Thread.currentThread().getName() + " start.");
		
		for(int i = 0; i < 5; i++) {
			try {
				Thread.sleep(250);
				System.out.println(Thread.currentThread().getName() + ": " + i);
			} catch(Exception e) {
				System.out.println("Exception has been caught" + e);
			}
		}
		
		System.out.println(Thread.currentThread().getName() + " exit.\n");
	}
	
}

public class ThreadJoint {
	
	public static void main(String[] args) {
		Thread t0 = new Thread(new MethodJoin());
		Thread t1 = new Thread(new MethodJoin());
		Thread t2 = new Thread(new MethodJoin());
		
		t0.start();
		try {
			// Waits for a thread to die.
			t0.join();								// To wait for the t1 thread to finish.
		} catch(Exception e) { }
		
		
		t1.start();
		try {
			// Parameter, when executes code at line 54, then will be wait 1000 (parameter, miliseconds), if done 1000 milisecond then The 3rd start.
			// Waits for a thread to die for the specified miliseconds.
			t1.join(15000);							// To wait for the t2 thread to finish.
		} catch(Exception e) { }
		
		t2.start();
	}
	
}
