/**
 * Runnable does not return result, Callable returns result.
 * 
 * For implementing Runnable, the run() method needs to be implemented which does not return anything, 
 * while for a Callable, the call() method needs to be implemented which returns a result on completion
 * 
 * A thread can�t be created with a Callable, it can only be created with a Runnable
 * 
 * Another difference is that the call() method can throw an exception whereas run() cannot.
 */

package thread;

import java.util.concurrent.Callable;

public class CallableAndRunnable {
	static class MRunable implements Runnable{
		
		@Override
		public void run() {
			System.out.println("Start: " + Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("End: " + Thread.currentThread().getName());
		}
	}
	
	static class MCallable implements Callable<String> {
		
		
		@Override
		public String call() throws Exception {
			System.out.println("Start: " + Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("End: " + Thread.currentThread().getName());
			return Thread.currentThread().getName(); 
		}
	}
	
	public static void main(String[] args) {
		Thread thread1 = new Thread(new MRunable());
		
		//But thread can't accept Callable
		//Thread thread2 = new Thread(new MRunbale); => error
	}
}
