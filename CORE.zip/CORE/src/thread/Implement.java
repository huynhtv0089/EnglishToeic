/**
 * When you implements Runnable, you can save a space for your class to extend any other class in future or now.
 */

package thread; 

public class Implement implements Runnable {
	
	private String name;
	
	public Implement() { }
	
	public Implement(String name) {
		this.name = name;
	}
	
	@Override
	public void  run() {
		synchronized(this) {
			this.name = Thread.currentThread().getName();
			System.out.println(name + " START.");
			
			for(int i = 0; i < 5; i++) {
				
				try {
					System.out.println(Thread.currentThread().getName() + " work " + i + " isAlive: " + Thread.currentThread().isAlive());
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
			
			System.out.println(name + " EXITING.");
		}
	}

	
	public static void main(String[] args) {
		Thread thread1 = new Thread(new Implement());							//Time 1: Create new thread 1
		Thread thread2 = new Thread(new Implement());							//Time 2: Create new thread 2
		
		thread1.start();														//Time 3: Thread 1 run. Then for loop running (don't care anything)
		try {
			thread1.join();	
			thread2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		thread2.start();														//Time 4: Thread 2 run.Then for loop running (don't care anything)
		
		
		
		/*Thread t3 = new Thread(() -> {											//Time 5: Create new thread 3
			System.out.println("*Thread 3");
		});
		t3.start();																//Time 6: Thread 3 run
		
		Runnable t4 = () -> {
			System.out.println("**Thread 4");
			
		};
		new Thread(t4).start();
		
		Thread t5 = new Thread(() -> { 
			System.out.println("**Thread 5");
		});
		t5.start();*/
	}
}
