package stream;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

public class StreamJava8 {
	public static void main(String[] args) throws IOException {
	    Stream<Integer> streamOfCollection = Arrays.asList(1, 4, 6, 42).stream();
	    streamOfCollection.forEach(e -> System.out.println(e));
	    
	    System.out.println("====================================================");
	    
	    String[] arr = {"A", "B", "C", "A"};
	    Stream<String> streamOfArray = Arrays.stream(arr);
	    streamOfArray.filter(e -> "A".equals(e)).forEach(e -> System.out.println(e));
	    
	    System.out.println("====================================================");
	    
	    Stream<String> streamBuilder = Stream.<String>builder().add("1").add("2").add("3").build();
	    streamBuilder.forEach(e -> System.out.println(e));
	    
	    System.out.println("====================================================");
	    
	    Stream<String> streamGenerated = Stream.generate(() -> "java").limit(10);
	    streamGenerated.forEach(e -> System.out.println(e));
	    
	    System.out.println("====================================================");
	    
	    Stream<String> streamIterated = Stream.iterate("Java", n -> n.concat("|")).limit(5);
	    List<String> listIterated = streamIterated.collect(Collectors.toList());
	    System.out.println(listIterated);
	    
	    System.out.println("====================================================");
	    
	    Stream<Integer> isStream = Stream.of(1, 2, 3, 4, 5);
	    Map<Integer, Integer> isMap = isStream.collect(Collectors.toMap(i-> i, i-> i+5));
	    System.out.println(isMap);
	    
	    System.out.println("====================================================");
	    
	    List<Integer> llist = Arrays.asList(3, 1, 5);
	    // True: nếu predicate thõa với tất cả các phần tử || False: predicate không thõa với bất kỳ 1 phần tử nào.
	    System.out.println("allMatch: " + llist.stream().allMatch(e -> e % 2 != 0));
	    
	    // True: nếu predicate thõa với chỉ 1 phần tử || False: predicate không thõa với bất kỳ phần tử nào.
	    System.out.println("anyMatch: " + llist.stream().anyMatch(e -> e > 10));
	    
	    // True: nếu predicate không thõa với tất cả phần tử || False: predicate thõa với tất cả phần tử nào.
	    System.out.println("anyMatch: " + llist.stream().noneMatch(e -> e < 10));
	    
	    System.out.println("====================================================");
	    List<String> lStr = Arrays.asList("G","B","F","E");
	    System.out.println("findAny: " + lStr.stream().findAny().get());
	    System.out.println("findFirst: " + lStr.stream().findFirst().get());
	    
	    System.out.println("====================================================");
	    List<Integer> list = Arrays.asList(3, 4, 6, 6, 4);
	    System.out.println("Dictinct element: ");
	    list.stream().distinct().forEach(p -> System.out.println(p));
	    
	    System.out.println("====================================================");
	    Stream<String> names = Stream.of("j", "a", "v", "a");
	    List<String> streamMaptoList = names.map(s -> { return s.toUpperCase();}).collect(Collectors.toList());
	    System.out.println("streamMapToList: " + streamMaptoList);
	    
	    System.out.println("====================================================");
	    List<Integer> listMinMax = Arrays.asList(1, 5, 60, 2, 10, 45);
	    int max = listMinMax.stream().max(Comparator.comparing(String::valueOf)).get();
	    System.out.println("max: " + max);
	    
	    int min = listMinMax.stream().min(Comparator.comparing(String::valueOf)).get();
	    System.out.println("min: " + min);
	    
	    
	    System.out.println("====================================================");
	    Map<Integer, String> mmap = new HashMap<>();
	    mmap.put(1, "value");
	    List<String> llst = new ArrayList<>();
	    llst.add("e");
	    
	    System.out.println(StringUtils.repeat("abc ", 5));
	    System.out.println(StringUtils.join(new String[] {"A", "B", "C"}, ", "));
	    
	    Stream<String> strStream = Pattern.compile(", ").splitAsStream("f, g, h");
	    strStream.forEach(e -> System.out.println(e));
	    
	    System.out.println("====================================================");
	    
	    Path path = Paths.get("C:\\workspace\\backup\\db-rk-phy-build-directory\\unzip\\beleg_20190213.csv");
		Stream<String> streamOfStrings = Files.lines(path);
		List<String> lstData = streamOfStrings.collect(Collectors.toList());
		//Stream<String> streamWithCharset = Files.lines(path, Charset.forName("UTF-8"));
		
		System.out.println("====================================================");
		
		Stream<String> namesStr = Stream.of("java", "stream");
		namesStr.forEach(p -> System.out.print(p + " ")); 
		
		namesStr = Stream.of("java", "stream");
		namesStr.forEach(p -> System.out.print(p + " ")); // print: stack java stackjava.com
		
		Supplier<Stream<String>> streamSupplier = () -> Stream.of("java", "stream");
		streamSupplier.get().forEach(p -> System.out.print(p + " ")); // print: stack java stackjava.com
		streamSupplier.get().forEach(p -> System.out.print(p + " ")); // print: stack java stackjava.com
		
		
		System.out.println("====================================================");
		
		List<String> data = Arrays.asList("Java", "C#", "C++", "PHP", "Javascript");
        data.stream().skip(1).limit(3).forEach(System.out::println);
        
        System.out.println("====================================================");
        
        List<Integer> dataInteger = Arrays.asList(1, 10, 15, 30, 5);
        dataInteger.stream().sorted().forEach(System.out::println);
        System.out.println("-----");
        dataInteger.stream().sorted((s1, s2) -> s2 - s1).forEach(System.out::println);
        
        System.out.println("====================================================");
        
        List<Integer> dataCount = Arrays.asList(2, 3, 5, 4, 6);
        long count = dataCount.stream().filter(num -> num % 3 == 0).count();
        System.out.println("Count = " + count);		//output: 2
        
        System.out.println("====================================================");
        
        List<Integer> primes = Arrays.asList(2, 3, 5, 7, 10);
        IntSummaryStatistics stats = primes.stream().mapToInt((x) -> x).summaryStatistics();
        System.out.println("Count: " + stats.getCount());
        System.out.println("Max: " + stats.getMax());
        System.out.println("Min: " + stats.getMin());
        System.out.println("Sum: " + stats.getSum());
        System.out.println("Average: " + stats.getAverage());
        
        UUID uuid = UUID.randomUUID();
        System.out.println(uuid);
        
        System.out.println("====================================================");
        
        Stream<String> namesLambda = Stream.of("j", "a", "v", "a");
		List<String> streamMaptoListLambda = namesLambda.map(s -> { String result = s.toUpperCase(); return result;}).collect(Collectors.toList());
		System.out.println(streamMaptoListLambda);	//output: [J, A, V, A]
	}
	
}
