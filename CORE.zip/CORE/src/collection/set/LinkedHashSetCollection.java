package collection.set;

import java.util.Iterator;
import java.util.LinkedHashSet;

class Book {
	private int id, quantity;
	private String name, author, publisher;
	
	public Book(int id, String name, String author, String publisher, int quantity) {
		this.id = id;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "id= " + this.id + ", name= " + this.name + ", author= " + this.author + ", publisher= " + this.publisher + ", quantity= " + this.quantity;
	}
}

public class LinkedHashSetCollection {
	public static void main(String[] args) {
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
		linkedHashSet.add("Ravi");
		linkedHashSet.add("Vijay");
		linkedHashSet.add("Ravi");
		linkedHashSet.add("Ajay");
		
		Iterator<String> itr = linkedHashSet.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		/*-------------------------------------------------------------------------------------------*/
		Book book1 = new Book(101,"Let us C","Yashwant Kanetkar","BPB",8);
		Book book2 = new Book(102,"Data Communications & Networking","Forouzan","Mc Graw Hill",4);
		Book book3 = new Book(103,"Operating System","Galvin","Wiley",6);
		
		LinkedHashSet<Book> linkedBook = new LinkedHashSet<>();
		linkedBook.add(book1);
		linkedBook.add(book2);
		linkedBook.add(book3);
		linkedBook.add(book1);
		
		
		Iterator<Book> itrBook = linkedBook.iterator();
		while(itrBook.hasNext()) {
			System.out.println(itrBook.next().toString());
		}
	}
}
