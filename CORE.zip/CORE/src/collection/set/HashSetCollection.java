package collection.set;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetCollection {
	public static void main(String[] args) {
		HashSet<String> hashSet = new HashSet<>();
		hashSet.add("Ravi");
		hashSet.add("Vijay");
		hashSet.add("Ravi");
		hashSet.add("Ajay");
		
		System.out.println("Traversing elements (Not duplicate)");
		Iterator<String> itr = hashSet.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
