package collection.enums;

import java.util.EnumMap;
import java.util.Map;

enum DayMap {
	Monday, Tuesday, Wednesday, Thursday 
};

public class EnumMapCollection {
	
	public static void main(String[] args) {
		//Create and populate enum map
		EnumMap<DayMap, String> map = new EnumMap<>(DayMap.class);
		map.put(DayMap.Monday, "1");
		map.put(DayMap.Tuesday, "2");
		map.put(DayMap.Wednesday, "3");
		map.put(DayMap.Thursday, "4");
		
		//print the map
		for(Map.Entry<DayMap, String> m : map.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}
	
}
