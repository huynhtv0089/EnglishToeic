package collection.enums;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.Set;

enum DaySet {
	SUNDAY,
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY
}

public class EnumSetCollection {
	public static void main(String[] args) {
		Set<DaySet> set = EnumSet.of(DaySet.TUESDAY, DaySet.WEDNESDAY);
		
		//Traversing elements
		Iterator<DaySet> itr = set.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		Set<DaySet> set1 = EnumSet.allOf(DaySet.class);
		System.out.println("Week Days: " + set1);
		
		Set<DaySet> set2 = EnumSet.noneOf(DaySet.class);
		System.out.println("Week Days: " + set2);
	}
}
