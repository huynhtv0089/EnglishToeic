/**
 * Java ArrayList class extends AbstractList class which implements List Interface
 * List Interface extends Collection and Iterable Interfaces
 */

package collection.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListCollection {
	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<>();
		al.add("Ravi");
		al.add("Vijay");
		al.add("Ajay");
		
		ArrayList<String> al2 = new ArrayList<>();
		al2.add("Ravi");
		al2.add("Hanumat");
		
		
		al.retainAll(al2);
		
		System.out.println("Iterating the elements after retaining the elements of al2");
		
		Iterator<String> itr = al.iterator();
		while(itr.hasNext()) {
			System.out.println("==> " + itr.next());
		}
		
		
		//Can contain duplicate data.
		List<String> arrayList = new ArrayList<>();
		arrayList.add("1");
		arrayList.add("2");
		arrayList.add("3");
		arrayList.add("1");
		System.out.println(arrayList.toString());
	}
}
