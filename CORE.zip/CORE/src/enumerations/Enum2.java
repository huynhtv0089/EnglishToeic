package enumerations;


/**
 * Enum + Instance field
 * Obligate: must have constructor
 * Param of constructor that, will be mapping to Field.
 */
enum WhoisRIR {
	ARIN("whois.arin.net"),
	RIPE("whois.ripe.net"),
	APNIC("whois.apnic.net"),
	AFRINIC("whois.afrinic.net"),
	LACNIC("whois.lacnic.net"),
	JPNIC("whois.jpnic.net"),
	KRNIC("whois.nic.ad.jp"),
	UNNIC("ipwhois.cnnic.cn"),
	UNKNOW("");
	
	private String url;
	
	//Obligate
	private WhoisRIR(String value) {
		System.out.println(this.toString());
		
		url = value;
	}
	
	public String getUrl() {
		return url;
	}
}

/**
 * Enum + method + some logic
 */
enum Operation {
	PLUS, MINUS, TIMES, DIVIDE;
	
	public double calculate(double x, double y) {
		switch (this) {
			case PLUS:
				return x + y;
			case MINUS:
				return x - y;
			case TIMES:
				return x * y;
			case DIVIDE:
				return x / y;
			default:
				throw new AssertionError("Unknown operations: " + this);
		}
	}
}

public class Enum2 {
	
	public static void main(String[] args) {
		System.out.println("1: " + WhoisRIR.ARIN);
		
		//Get value from constructor method
		System.out.println("2: " + WhoisRIR.ARIN.getUrl());
		
		System.out.println("3: " + WhoisRIR.valueOf("AFRINIC").getUrl());
		
		System.out.println();
		
	
		// Way 3
		Operation operation = Operation.MINUS;
		System.out.println("10 + 3 = " + operation.calculate(10, 3));
		
		// Way 2
		operation = Operation.TIMES;
		System.out.println("10 x 3 = " + operation.calculate(10, 3));
		
		// Way 3
		try {
			operation = Operation.valueOf("divide".toUpperCase());
			System.out.println("10 / 3 = " + operation.calculate(10, 3));
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}

		
		System.out.println();
		

		/**
		 * Have two type compare both Enum.
		 */
		Operation operA = Operation.MINUS;
		Operation operB = Operation.PLUS;
		
		System.out.println("Compare both enum: " + (operA == operB)); 					// Output: false
		System.out.println("Compare both enum: " + (Operation.PLUS.equals(operB))); 	// Output: true
	} 
	
}
