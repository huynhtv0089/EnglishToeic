package enumerations;

enum ColorHex {
	RED_HEX("red") {
		@Override
		public String getHexCode() {
			return "#ff0000";
		}
	},
	GREEN_HEX("green") {
		@Override
		public String getHexCode() {
			return "#00ff00";
		}
	},
	BLUE_HEX("blue") {
		@Override
		public String getHexCode() {
			return "#0000ff";
		}
	};
	
	private String name;
	
	ColorHex(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public abstract String getHexCode();
}

public class AbstractEnum {
	public static void main(String[] args) {
		for(ColorHex colorHex : ColorHex.values()) {
			System.out.println(colorHex.getName() + " = " + colorHex.getHexCode());
		}
	}
}
