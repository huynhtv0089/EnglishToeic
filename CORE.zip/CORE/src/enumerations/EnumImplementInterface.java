package enumerations;

import java.util.Arrays;

interface Option {
    int getValue();
 
    String getLabel();
}

enum Gender implements Option {
    MALE(1, "Male"), FEMALE(2, "Female");
 
    private int value;
    private String label;
 
    private Gender(int value, String label) {
        this.value = value;
        this.label = label;
    }
 
    @Override
    public int getValue() {
        return value;
    }
 
    @Override
    public String getLabel() {
        return label;
    }
}

public class EnumImplementInterface {
	public static void main(String[] args) {
        Option[] genders = Gender.values();
 
        System.out.println(Arrays.asList(genders));
    }
}
