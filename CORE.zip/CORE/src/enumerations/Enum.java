/**
 * Enumerations are used when we know all possible values at compile time, such as choices on a menu, rounding modes, command line flags, etc.
 * It isn't necessary that the set of constants in an enum type stay fixed for all time
 */

package enumerations;

//Enum declaration can be done outside a Class or inside Class, but not inside a method.
enum Color {
	RED, 
	GREEN, 
	BLUE;
	
	//constructor called separately for each
	// Modifier default is private
	private Color() {
		System.out.println("Constructor called for: " + this.toString());
	}
	
	public void infoColor() {
		System.out.println("Universal color");
	}
}

public class Enum {
	
	// Defaut ENUM is always public static
	// Since it is static, we can access it by using enum Name.
	enum Day {
		MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
		
		/*private Day() {
			System.out.println("For each");
		}*/
	}
	
	
	public static void main(String[] args) {
		
		{
			Day day = Day.TUESDAY;
			switch(day) {
				case MONDAY:
					System.out.println("Monday is boring");
					break;
				case FRIDAY:
					System.out.println("Friday is better");
					break;
				case SATURDAY:
				case SUNDAY:
					System.out.println("Weeken is best");
					break;
				default:
					System.out.println("Midweek days are so-so.");
					break;
			}
		}
		
		System.out.println();
		

		Color color = Color.RED;
		System.out.println("1. color: " + color);
		System.out.println("2. color: " + Color.GREEN);
		System.out.println("3. At index: " + color.ordinal());
		
		color.infoColor();

	
		System.out.println();
		
	
		/** Enum Iteration */
		// values() method can be return all values present inside enum.
		// ordinal() method can be return index of each enum, just like array index
		Color arrColor[] = Color.values();
		for (Color colorEnum : arrColor) {
			System.out.println(colorEnum + " at index " + colorEnum.ordinal());
		}
		
		
		/** Case check exists */
		// valueOf() method return The enum constant of the specified string value, if exists.
		try {
			//Color c1 = Color.valueOf("RED");
			System.out.println(Color.valueOf("RED"));
		} catch (IllegalArgumentException e) {
			System.out.println("Error: Not value exists.");
		}

	}
}
