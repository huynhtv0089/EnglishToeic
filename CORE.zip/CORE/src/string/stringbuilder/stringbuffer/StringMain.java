/**
 * Both is mutable and String is immutable
 *
 * StringBuilder is faster than StringBuffer
 *      Because:
 *          StringBuilder doesn't synchronize and StringBuffer isn't
 *
 * However, If the thread safety is necessary, the best option is StringBuffer objects
 */

package string.stringbuilder.stringbuffer;

public class StringMain {
	
	public static void main(String[] args) {
		/*for (int i = 10; i-->0; ) {
	        System.out.println(i);
	    }*/

	    long t;
	    {
	        StringBuffer sb = new StringBuffer();
	        t = System.currentTimeMillis();
	        for (int i = 100000; i-->0;) {
	            sb.append("Java");
	        }
	        System.out.println("StringBuffer: " + (System.currentTimeMillis() - t));             //Output: 6
	    }
	
	    {
	        StringBuilder sb = new StringBuilder();
	        t = System.currentTimeMillis();
	        for (int i = 100000; i-->0;) {
	            sb.append("Java");
	        }
	        System.out.println("StringBuilder: " + (System.currentTimeMillis() - t));             //Output: 1
	    }
	}
}
