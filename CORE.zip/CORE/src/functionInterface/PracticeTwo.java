package functionInterface;

import java.util.concurrent.ExecutionException;

public class PracticeTwo {
	
	public boolean checkPrimeNumber(int num) {
		if(num == 1 || num < 1) return false;

		for(int i = 2; i<=Math.sqrt(num); i++) {
			if(num % i == 0) {
				return false;
			}
		}
		
		return true;
	}
	
	public int totalPrimeNumber(int n) {
		int total = 0;
		for(int i = 2; i<=n; i++) {
			if(this.checkPrimeNumber(i)) {
				total += i;
			}
		}
		
		return total;
	}
	
	public void abs(int a) {
		if(a < 0) System.out.println("1: " + -a);
		else System.out.println("2: " + a);
    }
	
	public int uscln(int a, int b) {
		a = Math.abs(a);
		b = Math.abs(b);
			
		while(a != b) {
			if(a < b)
				b = b - a;
			else 
				a = a - b;
		}				
		
		return a; //or return b
	}
		
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		PracticeTwo p = new PracticeTwo();
		int numCheck = 4;
		String result = "";
		if(p.checkPrimeNumber(numCheck)) System.out.println(numCheck + " is The prime number.");
		else System.out.println(numCheck + " isn't prime number."); 
		
		int num = 11;
		System.out.println("total prime number, from 2 to " + num + ": " + p.totalPrimeNumber(num));
		
		System.out.println("USCLN: 18, 84: " + p.uscln(18, 84));
	}
}
