package functionInterface;

import java.util.Arrays;

public class PracticeOne {
	
	private int partition(int arr[], int left, int right) {
		int pivot = arr[right], i = (left - 1);
		
		for(int j = left; j < right; j++) {
			if(arr[j] < pivot) {
				i++;
				
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
		
		int temp = arr[right];
		arr[right] = arr[i+1];
		arr[i+1] = temp;
		
		return (i+1);
	}
	
	public void quicksort(int arr[], int left, int right) {
		if(left < right) {
			int posPivot = partition(arr, left, right);
			quicksort(arr, left, posPivot-1);
			quicksort(arr, posPivot+1, right);
		}
	}
	
	public void linearSearch(int arr[], int x, int index) {
		if(index < arr.length) {
			if(arr[index] == x) System.out.println("[linear search] Find out inside array: " + x);
				
			linearSearch(arr, x, index+1);
		}
	}
	
	public void binarySearch(int a[], int x) {
		int left = 0, right = a.length-1;
		
		while(left <= right) {
			int mid = (left + right) / 2;
			if(a[mid] == x) {
				System.out.println("[binary search] Find out inside array: " + x);
				break;
			}
			
			if(x < a[mid])	right = mid - 1;
			else left = mid + 1;
		}
	}
	
	public static void main(String[] args) {
		int[] arr = new int[] {25, 64, 3, 6, 204, 30, 90};
		PracticeOne p = new PracticeOne();
		p.quicksort(arr, 0, arr.length-1);
		System.out.println("arr after sorted: " + Arrays.toString(arr));
		
		p.linearSearch(arr, 3, 0);
		p.binarySearch(arr, 6);
	}
}