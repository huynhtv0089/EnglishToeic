var http = require('http');
var express = require('express');
var bodyParser = require('body-parser');
var searchAPI = require('./search');
var counter = require('./counter');
var common = require('./common');
var md5 = require('md5');
var app = express();

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

app.get('/vae/lookup/search', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            took: data.took,
            total: data.hits.total,
            hits: data.hits.hits
        };
        response.send(returnData);
    }
    // End of handler function
    var params = request.query.objectSearch;
   
    //Log request information
    searchAPI.log().log({
        from: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
        console.log('The normal step');
        /* for (var property in params) {
            console.log('PROPERTY: ' + property + '>>: ' + params[property]);
        } */
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }

    searchAPI.search(params).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/lookup/search/first', function (request, response) {
     // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            took: data.took,
            total: data.hits.total,
            hits: data.hits.hits
        };
        response.send(returnData);
    }

    // End of handler function
    var params = request.query.objectSearch;
    console.log('THE 1st SEARCH');
    
    //Log request information
    searchAPI.log().log({
        from: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
        /* for (var property in params) {
           console.log('PROPERTY: ' + property + '>>: ' + params[property]);
        } */
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }

    searchAPI.search_first(params).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/lookup_qc/search', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            took: data.took,
            total: data.hits.total,
            hits: data.hits.hits
        };
        response.send(returnData);
    }
    // End of handler function
    var params = request.query.objectSearch;

    //Log request information
    searchAPI.log().log({
        from: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }

    searchAPI.search_qc(params).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/lookup_qc/:kdpid', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            took: data.took,
            total: data.hits.total,
            hits: data.hits.hits
        };
        response.send(returnData);
    }

    var kdpId = request.params.kdpid;
    if (kdpId == undefined || kdpId == null || kdpId.length == 0) {
        return response.send("Missing kdpId");
    }

    //Log request information
    searchAPI.log().log({
        from: request.ip,
        param: request.params
    });

    searchAPI.searchKdpid(kdpId).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

/**
 * ABA-77: Firmen-Plz
 */
app.get('/vae/search_qc/firmenplz', function (request, response) {
   var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    };
    searchAPI.log().log({
        host: request.ip,
        param: request.params
    });
    var plz = request.query.plz;
    var search_plz_state = function (data) {
        var hits = data.hits;
        var returnData = {};
        var arrayReturnData = [];
        var errorResponse = function (error) {
            searchAPI.log().log({
                'error': error.message
            });
            response.status(500).send(error.message);
        };
        if (hits.total > 0) {
            var plzs = hits.hits;
            plzs.forEach(function (item, index) {
                plz = item._source;
                returnData.plz_plz = plz.plz_plz;
                returnData.plz_typ = plz.plz_typ;
                returnData.plz_logtyp = plz.plz_logtyp;
                returnData.ort = null;
                arrayReturnData.push(returnData);
                returnData = {};
            });
            if (plzs.length === 1) {
                var plz_6_digits = plzs[0]._source.plz_plz;
                searchAPI.searchOrtZubofi(plz_6_digits).then(function (zubofi_data) {
                    successResponse(zubofi_data, arrayReturnData);
                }, errorResponse);
            } else {
                 response.send(arrayReturnData);
            }
        } else {
            response.send(arrayReturnData);
        }
    };
    var successResponse = function (zubofi_data, arrayReturnData) {
        var zubofi_hits = zubofi_data.hits;
        if (zubofi_hits.total > 0) {
            var arrayZubofiData = zubofi_hits.hits;
            var ort = "";
            arrayZubofiData.forEach(function (item, index) {
                ort += item._source.ort + ";";
            })
            arrayReturnData[0].ort = ort;
        }
        response.send(arrayReturnData);
    };
    searchAPI.searchFirmenPLZ(plz).then(function (data) {
        search_plz_state(data);
    }, errorResponse)
});

app.get('/vae/lookup/lookupExtra', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            took: data.took,
            total: data.hits.total,
            hits: data.hits.hits
        };
        response.send(returnData);
    }
    // End of handler function
    var params = request.query.lookupExtra;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }

    searchAPI.lookup_extra(params).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/lookup/hauskey/:kdpid', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var hits = data.hits;
        var returnData = {};
        if (hits.total > 0) {
            doc = hits.hits[0]._source;
            // Do not retrun hauskey if it is null or zero.
            var hauskey = doc.hauskey;
            if (hauskey != null && hauskey != 'undefined' && hauskey > 0) {
                returnData.hauskey = hauskey;
            }
        }
        response.send(returnData);
    }
    // End of handler function
    var kdpid = request.params.kdpid;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: request.params
    });

    searchAPI.find_hauskey_by_kdpid(kdpid).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/lookup/hauskey', function (request, response) {

    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var hits = data.hits;
        var returnData = {};
        var returnData = {};
        if (hits.total > 0) {
            doc = hits.hits[0]._source;
            // Do not retrun hauskey if it is null or zero.
            var hauskey = doc.hauskey;
            if (hauskey != null && hauskey != 'undefined' && hauskey > 0) {
                returnData.hauskey = hauskey;
            }
        }
        response.send(returnData);
    }
    // End of handler function
    var kdp = JSON.parse(request.query.kdp);

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: kdp
    });

    searchAPI.find_hauskey_by_kdp_object(kdp).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/lookup/duplication/count', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            count: 0
        };
        var hits = data.hits;
        if (hits.total > 1) {
            returnData.count = 2;
        } else {
            returnData.count = 0;
        }
        response.send(returnData);
    }
    // End of handler function
    var kdp = request.query.kdp;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: kdp
    });

    try {
        kdp = JSON.parse(kdp);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }
    searchAPI.count_duplicate_kdp(kdp).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/zubofi/addressid', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var hits = data.hits;
        var kdp = null;
        var returnData = {};
        if (hits.total > 0) {
            doc = hits.hits[0]._source;
            returnData.adr_id = doc.adr_id;
            returnData.plz = doc.plz;
            returnData.ort = doc.ort;
            returnData.strasse = doc.strasse;
            returnData.hauskey = doc.hauskey;
            returnData.streetnumber = doc.streetnumber;
            returnData.hausnr = doc.hausnr;
            returnData.hausnrzusatz = doc.hausnrzusatz;
        }
        response.send(returnData);
    }
    // End of handler function
    var params = request.query.address;
    try {
        params = JSON.parse(params);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    searchAPI.search_zubofi_addrid(params).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

/**
 * Find parcel_hauskey in zubofi for normal
 */
app.get('/vae/zubofi/hauskey', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var hits = data.hits;
        var kdp = null;
        var returnData = {};
        if (hits.total > 0) {
            doc = hits.hits[0]._source;
            returnData.adr_id = doc.adr_id;
            returnData.plz = doc.plz;
            returnData.ort = doc.ort;
            returnData.strasse = doc.strasse;
            returnData.hauskey = doc.hauskey;
            returnData.streetnumber = doc.streetnumber;
            returnData.hausnr = doc.hausnr;
            returnData.hausnrzusatz = doc.hausnrzusatz;
        }
        response.send(returnData);
    }
    // End of handler function
    var params = request.query.address;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }

    searchAPI.search_zubofi_hauskey(params).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/zubofi/streetnumber/:parcel_hauskey', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var hits = data.hits;
        var kdp = null;
        var returnData = {};
        if (hits.total > 0) {
            doc = hits.hits[0]._source;
            returnData.streetnumber = doc.streetnumber;
        }
        response.send(returnData);
    }
    // End of handler function
    var parcelHauskey = request.params.parcel_hauskey;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: request.params
    });

    searchAPI.find_streetnumber_by_parcel_hauskey(parcelHauskey).then(function (data) {
        console.log('data:= ' + data);
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/zubofi/special/search', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data, _case) {
        var hits = data.hits;
        var kdp = null;
        var returnData = {};
        if (hits.total > 0) {
            kdp = hits.hits[0]._source;
            returnData.plz = kdp.plz;
            returnData.ort = kdp.ort;
            // pvgiang_1 -27/07/2016- Use hauskey for adr_id
            returnData.adr_id = kdp.hauskey;
            returnData.hauskey = kdp.hauskey;
            returnData.by_rule = _case;
        }
        response.send(returnData);
    }
    // End of handler function
    var params = request.query.address;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }

    searchAPI.searchZubofiSpecial(params).then(function (data) {
        if (data.hits.total == 0) {// retry case 2
            searchAPI.searchZubofiSpecial(params, 1).then(function (data) {
                successResponse(data, 2);
            });
        } else {// response case 1
            successResponse(data, 1);
        }
    }, errorResponse);
});

/**
 * Find parcel_hauskey for Domizil special address by plz.
 */
app.get('/vae/zubofi/special/search/:plz', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    };
    var successResponse = function (data) {
        var hits = data.hits;
        var kdp = null;
        var returnData = {};
        if (hits.total > 0) {
            kdp = hits.hits[0]._source;
            returnData.plz = kdp.plz;
            returnData.ort = kdp.ort;
            returnData.adr_id = kdp.hauskey;
            returnData.hauskey = kdp.hauskey;
        }
        response.send(returnData);
    };
    var plz = request.params.plz;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: request.params
    });

    searchAPI.searchASDPPLZ(plz).then(function (data) {
        var hits = data.hits;
        if (hits.total > 0) {
            var param = {
                plz: plz,
                type: 1
            };
            searchAPI.searchZubofiSpecial(param).then(function (result) {
                successResponse(result);
            }, errorResponse);
        } else {
            var returnData = {};
            response.send(returnData);
        }
    }, errorResponse);
});

/**
 * ABA-175: Firmen-Plz
 */
app.get('/vae/lookup/asdpplz', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    };
    searchAPI.log().log({
        host: request.ip,
        param: request.params
    });

    var plz = request.query.plz;
    var ort = request.query.ort;
    
    var searchPlzAndOrt = function (data, opt) {
        var hits = data.hits;
        
        var errorResponse = function (error) {
            searchAPI.log().log({
                'error': error.message
            });
            response.status(500).send(error.message);
        };
        if(opt === 'prefix') {
            var returnData = {};
            var arrayReturnData = [];
            var results = hits.hits;
            var arrayPlz = [];
            results.forEach(function (item, index) {
                result = item._source;
                arrayPlz.push(result.plz);  
            });
            //Check PLZ 6 digit
            if(arrayPlz.length > 0) {
                for(var i=0; i<arrayPlz.length; i++) {
                    if(arrayPlz[0] === arrayPlz[i])
                        flag = 1; //Same PLZ 6 digit => go to step 2
                    else 
                        flag = 0; // Theses Plz 6 digit is different => get out
                }
                // Go to next step 2
                if(flag === 1) {                 
                    var plz_6_digits = arrayPlz[0];
                    searchAPI.searchFirmenPlzASDP(plz_6_digits).then(function (data) {
                        checkFirmenPLZ(data);
                    }, errorResponse);
                    return;
                }else {
                    response.send(arrayReturnData);
                    return;
                }
            }else {
                console.log('not record step prefix');
                response.send(arrayReturnData);
                return;
            }
        }

        if(hits.hits.length > 0) {
            if(hits.total === 1) {
                // If there's 6digit-PLZ, => step 2
                var plz_6_digits = hits.hits[0]._source.plz;
                searchAPI.searchFirmenPlzASDP(plz_6_digits).then(function (data) {
                    checkFirmenPLZ(data);
                }, errorResponse);
            }else {
                searchAPI.searchPlzOrtZubofi(plz, ort, 2).then(function (dataSearchPrefix) {
                    searchPlzAndOrt(dataSearchPrefix, 'prefix');
                }, errorResponse);
            }
        }else {
            searchAPI.searchPlzOrtZubofi(plz, ort, 2).then(function (dataSearchPrefix) {
                searchPlzAndOrt(dataSearchPrefix, 'prefix');
            }, errorResponse);
        }
    };

    var checkFirmenPLZ = function(data) {
        var hits = data.hits;
        if(hits.total === 1) {
            result = hits.hits[0]._source;
            if(result.plz_typ === 40 && (result.plz_logtyp === 0 || result.plz_logtyp === 1)) {
                searchAPI.searchPlzOrtZubofi(result.plz_plz, ort, 3).then(function (data) {
                    successResponse(data, result.plz_plz);
                }, errorResponse);
            }else {
                response.send([]);
            }
        }else {
            response.send([]);
        }
    }

    var successResponse = function (data, plz_plz, plz_typ, plz_logtyp) {
        var hits = data.hits;
        var returnData = {};
        var arrayReturnData = [];
        returnData.plz_plz = plz_plz;
        returnData.ort = hits.hits[0]._source.ort;
        arrayReturnData.push(returnData);
        console.log('param firmen plz: ' + JSON.stringify(arrayReturnData));

        response.send(arrayReturnData);
    };

    searchAPI.searchPlzOrtZubofi(plz ,ort, 1).then(function (data) {
        searchPlzAndOrt(data, 'match');
    }, errorResponse);
});

app.get('/vae/zubofi/special/same-check', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var hits = data.hits;
        var returnData = [];
        var keys = [];
        if (hits.total > 0) {
            hits.hits.forEach(function (item) {
                var kdp = item._source;
                var key = md5(kdp.dl_zusatz + kdp.strasse + kdp.hausnr + kdp.hausnrzusatz + kdp.plz + kdp.ort);
                if (keys.indexOf(key) == -1) {
                    keys.push(key);
                    returnData.push({
                        plz: kdp.plz,
                        ort: kdp.ort,
                        strasse: kdp.strasse,
                        hausnr: kdp.hausnr,
                        hausnrzusatz: kdp.hausnrzusatz,
                        // pvgiang_1 -27/07/2016- Use hauskey for adr_id
                        adr_id: kdp.hauskey,
                        hauskey: kdp.hauskey
                    });
                }
            });
        }

        response.send(returnData);
    }
    // End of handler function
    var params = request.query.address;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }

    searchAPI.searchZubofiSpecialPickpostSameCheck(params).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

/**
 * Find parcel_hauskey in asdp/(zubofi special) for pickpost or mypost24
 */
app.get('/vae/zubofi/special/pickpost/hauskey', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var hits = data.hits;
        var returnData = {};
        if (hits.total > 0) {
            var kdp = hits.hits[0]._source;
            returnData = {
                plz: kdp.plz,
                ort: kdp.ort,
                strasse: kdp.strasse,
                hausnr: kdp.hausnr,
                hausnrzusatz: kdp.hausnrzusatz,
                // pvgiang_1 -27/07/2016- Use hauskey for adr_id
                adr_id: kdp.hauskey,
                hauskey: kdp.hauskey
            };
        }
        response.send(returnData);
    }
    // End of handler function
    var params = request.query.address;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }

    searchAPI.searchZubofiSpecialPickpostOrMypost24(params).then(function (data) {
        successResponse(data);
    }, errorResponse);
});


/**
 * Request #10890(update 30/09/2016): search parcelhauskey for postfach address with plz, ort, name2 = Poststellen und Verkauf
 * 
 * Find parcel_hauskey in asdp/(zubofi special) for postfach 
 */
app.get('/vae/zubofi/special/postfach/hauskey', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var hits = data.hits;
        var returnData = {};
        if (hits.total > 0) {
            var kdp = hits.hits[0]._source;
            returnData = {
                plz: kdp.plz,
                ort: kdp.ort,
                strasse: kdp.strasse,
                hausnr: kdp.hausnr,
                hausnrzusatz: kdp.hausnrzusatz,
                // pvgiang_1 -27/07/2016- Use hauskey for adr_id
                adr_id: kdp.hauskey,
                hauskey: kdp.hauskey
            };
        }
        response.send(returnData);
    }
    // End of handler function
    var params = request.query.address;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }

    searchAPI.searchZubofiSpecialPostfach(params, 2).then(function (data) {
        var hits = data.hits;
        if (hits.total == 1) {
            successResponse(data);
        } else {
            var returnData = {};
            response.send(returnData);
        }
    }, errorResponse);
});

app.get('/vae/zubofi/special/postlagernd/hauskey', function (request, response) {
     var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }

    var successResponse = function (data) {
        var hits = data.hits;
        var kdp = null;
        var returnData = {};
        if (hits.total > 0) {
            kdp = hits.hits[0]._source;
            returnData.plz = kdp.plz;
            returnData.ort = kdp.ort;
            returnData.hauskey = kdp.hauskey;
        }
        response.send(returnData);
    }

    var emptyResponse = function (data) {
        var returnData = {};
        response.send(returnData);
    }

     // End of handler function
    var params = request.query.address;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

     try {
        params = JSON.parse(params);
        console.log(params);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }
    searchAPI.searchZubofiSpecialPostlagernd(params, 1).then(function (data) {
          if (data.hits.total === 1) { // response case 1
            successResponse(data);
        } else { // retry case 2
              searchAPI.searchZubofiSpecialPostlagernd(params, 2).then(function (data) {
                if (data.hits.total !== 0) {
                    successResponse(data);
                } else {
                    searchAPI.searchZubofiSpecialPostlagernd(params, 3).then(function (data) {
                        if (data.hits.total === 1) {             
                            successResponse(data);
                        } else {
                            searchAPI.searchZubofiSpecialPostlagernd(params, 4).then(function (data) {
                                if (data.hits.total === 1) {
                                    successResponse(data);
                                }else {
                                    emptyResponse(data);
                                }
                            }, errorResponse);
                        }
                    }, errorResponse);
                }
            }, errorResponse);
        }
    }, errorResponse);
});

app.get('/vae/zubofi/special/check', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var hits = data.hits;
        var returnData = {};
        if (hits.total > 0) {
            var kdp = hits.hits[0]._source;
            returnData = {
                plz: kdp.plz,
                ort: kdp.ort,
                strasse: kdp.strasse,
                hausnr: kdp.hausnr,
                hausnrzusatz: kdp.hausnrzusatz,
                // pvgiang_1 -27/07/2016- Use hauskey for adr_id
                adr_id: kdp.hauskey,
                hauskey: kdp.hauskey
            };
        }
        response.send(returnData);
    }
    // End of handler function
    var params = request.query.address;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
    } catch (error) {
        response.status(500).send(error.message);
        return;
    }
    searchAPI.searchZubofiSpecialPickpostCheck(params).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/ocr/strasse/count', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            count: data.count
        };
        response.send(returnData);
    }
    var params = request.query.value;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
        counter.countOCRStrasse(params).then(function (data) {
            successResponse(data);
        }, errorResponse);
    } catch (error) {
        response.status(500).send(error.message);
    }
});

app.get('/vae/ocr/ort/count', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            count: data.count
        };
        response.send(returnData);
    }
    var params = request.query.value;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
        counter.countOCROrt(params).then(function (data) {
            successResponse(data);
        }, errorResponse);
    } catch (error) {
        response.status(500).send(error.message);
    }
});

app.get('/vae/ocr/plz/count', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            count: data.count
        };
        response.send(returnData);
    }
    var params = request.query.value;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
        counter.countOCRPlz(params).then(function (data) {
            successResponse(data);
        }, errorResponse);
    } catch (error) {
        response.status(500).send(error.message);
    }
});

app.get('/vae/ocr/kdp/count', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            count: data.count
        };
        response.send(returnData);
    }
    var params = request.query.value;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
        counter.countOCRName(params).then(function (data) {
            successResponse(data);
        }, errorResponse);
    } catch (error) {
        response.status(500).send(error.message);
    }
});

app.get('/vae/ocr/firmasign/search', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = {
            took: data.took,
            total: data.hits.total,
            hits: data.hits.hits
        };
        response.send(returnData);
    }
    try {
        counter.countFirmaSign(null).then(function (data) {
            var max = 10000;
            if (data.count > 0) {
                max = data.count;
            }
            searchAPI.getAllOCRFirmaSign(0, max).then(function (data) {
                successResponse(data);
            }, errorResponse);
        });
    } catch (error) {
        response.status(500).send(error.message);
    }
});

app.get('/vae/util/normalize', function (request, response) {
    var params = request.query.string;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: params
    });

    try {
        params = JSON.parse(params);
        response.send(common.normalize(params));
    } catch (error) {
        response.status(500).send(error.message);
    }
});

app.get('/vae/suggestion/kdp', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var hits = data.hits;
        var returnData = [];
        if (hits.total > 0) {
            hits.hits.forEach(function (item) {
                var kdp = item._source;
                returnData.push(kdp);
            });
        }
        response.send(returnData);
    }
    // End of handler function
    var term = request.query.term;
    var fieldName = request.query.fieldName;
    var type = request.query.type;// index type

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: request.query
    });

    searchAPI.suggestionKdp(type, fieldName, term).then(function (data) {
        successResponse(data);
    }, errorResponse);
});

app.get('/vae/checkswapcondition', function (request, response) {
    // Handler function
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        if (data === false) {
            response.send(false);
        } else if (typeof data == 'object') {
            if (data.count > 0) {
                response.send(true);
            } else {
                response.send(false);
            }
        }
    }
    // End of handler function
    var strVN = request.query.strVN;
    var strNN = request.query.strNN;
    var iPercent = request.query.iPercent;

    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: request.query
    });

    if ((strVN == undefined || strVN == "")
            && (strNN == undefined || strNN == "")) {
        return successResponse(false);
    }
    if (strVN != "" && strNN != "") {
        searchAPI.checkConditionSwap(strNN, 2, iPercent).then(
                function (data) {
                    if (typeof data == 'object' && data.count > 0) {
                        searchAPI.checkConditionSwap(strVN, 1, iPercent).then(
                                function (data) {
                                    successResponse(data);
                                }, errorResponse);
                    } else {
                        successResponse(data);
                    }
                }, errorResponse);
    } else if (strVN != "" && strNN == "") {
        searchAPI.checkConditionSwap(strVN, 1, iPercent).then(function (data) {
            successResponse(data);
        }, errorResponse);
    } else if (strVN == "" && strNN != "") {
        searchAPI.checkConditionSwap(strNN, 2, iPercent).then(function (data) {
            successResponse(data);
        }, errorResponse);
    }
});

app.get('/vae/word-suggestion/suggest', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = [];
        if (data.suggester.length > 0)
        {
            var options = data.suggester[0].options;
            for (var i = 0; i < options.length; i++)
            {
                var searchItem = {
                    key: options[i].payload.id,
                    value: options[i].text,
                    numberOfSuggestion: options[i].score
                };
                returnData.push(searchItem);
            }
        }
        response.send(returnData);
    }
    try {
        var word = request.query.word;
        //Log request information
        searchAPI.log().log({
            host: request.ip,
            param: request.query
        });
        
        searchAPI.suggestWord(word).then(function (data) {
            successResponse(data);
        }, errorResponse);
    } catch (error) {
        errorResponse(error);
    }
});

app.get('/vae/word-suggestion/search', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = [];
        var hits = data.hits;
        if (hits.total > 0)
        {
            var options = hits.hits;
            for (var i = 0; i < options.length; i++)
            {
                var searchItem = {
                    key: options[i]._source.suggest.payload.id,
                    value: options[i]._source.name,
                    numberOfSuggestion: options[i]._source.suggest.weight
                };
                returnData.push(searchItem);
            }
            returnData.sort(function (a, b) {
                var result = (a.numberOfSuggestion - a.numberOfSuggestion);
                if (result === 0)
                    result = (a.value.length - b.value.length);
                return result;
            });

        }
        response.send(returnData);
    }
    try {
        var word = request.query.word;
        //Log request information
        searchAPI.log().log({
            host: request.ip,
            param: request.query
        });
        
        searchAPI.searchSuggestWord(word).then(function (data) {
            successResponse(data);
        }, errorResponse);
    } catch (error) {
        response.status(500).send(error.message);
    }
});


app.post('/vae/word-suggestion/weight/:id/:weight', function (request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = data;
        response.send(returnData);
    }
    try {
        searchAPI.updateWeightSuggest(request.params.id, request.params.weight).then(function (data) {
            successResponse(data);
        }, errorResponse);
    } catch (error) {
        response.status(500).send(error.message);
    }
});

app.get('/vae/alias/:index/:alias_name', function(request, response) {
    var errorResponse = function (error) {
        searchAPI.log().log({
            'error': error.message
        });
        response.status(500).send(error.message);
    }
    var successResponse = function (data) {
        var returnData = data;
        response.send(returnData);
    }
    
    //Log request information
    searchAPI.log().log({
        host: request.ip,
        param: request.query
    });
    
    try {
        searchAPI.setAlias(request.params.alias_name, request.params.index, successResponse, errorResponse);
    } catch (error) {
        errorResponse(error);
    }
});

app.get('/vae/lookup/searchES', function (request, response) {
    // Handler function
   var errorResponse = function (error) {
       searchAPI.log().log({
           'error': error.message
       });
       response.status(500).send(error.message);
   }
   var successResponse = function (data) {
       var returnData = {
           took: data.took,
           total: data.hits.total,
           hits: data.hits.hits
       };

       console.log('-> ' + JSON.stringify(returnData.hits[0]));

       response.send(returnData);
   }

   // End of handler function
   var params = request.query.searchES;
   console.log('THE 1st SEARCH');
   
   //Log request information
   searchAPI.log().log({
       from: request.ip,
       param: params
   });

   try {
       params = JSON.parse(params);
   } catch (error) {
       response.status(500).send(error.message);
       return;
   }

   searchAPI.searchMatch100Percent(params).then(function (data) {
       successResponse(data);
   }, errorResponse);
});


/**
 * Set PORT from terminated.Ex:PORT=8523 node server.js If PORT is undefined ,
 * 8888 is used as default
 */
app.set('port', process.env.PORT || 8888)
app.listen(app.get('port'), function () {
    console.log('Listening on port ' + app.get('port'));
});
