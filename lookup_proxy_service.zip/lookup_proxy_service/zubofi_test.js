//nodeunit zubofi_test.js
var searchAPI = require('./search'); 

if(typeof ZubofiTest == 'undefined') {
	ZubofiTest = [];
}
module.exports.testCase1 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes-près-Renens",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase2 = function(test) {
	var params = {
		type : 1,
		ort : "abc",
		plz : "1022",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase3 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes-près-Renens",
		plz : "1111",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase4 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes-près-Renens",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase5 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes-près-Renens",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase6 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase7 = function(test) {
	var params = {
		type : 1,
		ort : "Près-Renens",
		plz : "1022",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase8 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes-près-Renens111",
		plz : "1022",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase9 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes-pres-Renens 111",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase10 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes-près-Renens-111",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase11 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes-pres-Renens",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase12 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes pres Renens",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase13 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes pres-Renens",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase14 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes-pres-Renens 1",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase15 = function(test) {
	var params = {
		type : 1,
		ort : "Chavannes-près-Renens 2",
		plz : "1022",
	};
	var expect = {
		ort : "Chavannes-près-Renens",
		plz : "102200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase16 = function(test) {
	var params = {
		type : 1,
		ort : "Forel (Lavaux)",
		plz : "1072",
	};
	var expect = {
		ort : "Forel (Lavaux)",
		plz : "107200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase17 = function(test) {
	var params = {
		type : 1,
		ort : "Forel Lavaux",
		plz : "1072",
	};
	var expect = {
		ort : "Forel (Lavaux)",
		plz : "107200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase18 = function(test) {
	var params = {
		type : 1,
		ort : "Forel",
		plz : "1072",
	};
	var expect = {
		ort : "Forel (Lavaux)",
		plz : "107200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase19 = function(test) {
	var params = {
		type : 1,
		ort : "(Lavaux)",
		plz : "1072",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase20 = function(test) {
	var params = {
		type : 1,
		ort : "Forel 1",
		plz : "1072",
	};
	var expect = {
		ort : "Forel (Lavaux)",
		plz : "107200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase21 = function(test) {
	var params = {
		type : 1,
		ort : "Château-d'Oex",
		plz : "1660",
	};
	var expect = {
		ort : "Château-d'Oex",
		plz : "166000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase22 = function(test) {
	var params = {
		type : 1,
		ort : "Chateau-d'Oex",
		plz : "1660",
	};
	var expect = {
		ort : "Château-d'Oex",
		plz : "166000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase23 = function(test) {
	var params = {
		type : 1,
		ort : "Château-dOex",
		plz : "1660",
	};
	var expect = {
		ort : "Château-d'Oex",
		plz : "166000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase24 = function(test) {
	var params = {
		type : 1,
		ort : "Chateau d'Oex",
		plz : "1660",
	};
	var expect = {
		ort : "Château-d'Oex",
		plz : "166000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase25 = function(test) {
	var params = {
		type : 1,
		ort : "d'Oex",
		plz : "1660",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase26 = function(test) {
	var params = {
		type : 1,
		ort : "L'Auberson",
		plz : "1454",
	};
	var expect = {
		ort : "L'Auberson",
		plz : "145400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase27 = function(test) {
	var params = {
		type : 1,
		ort : "Lauberson",
		plz : "1454",
	};
	var expect = {
		ort : "L'Auberson",
		plz : "145400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase28 = function(test) {
	var params = {
		type : 1,
		ort : "L-auberson",
		plz : "1454",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase29 = function(test) {
	var params = {
		type : 1,
		ort : "L auberson",
		plz : "1454",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase30 = function(test) {
	var params = {
		type : 1,
		ort : "Diessbach b. Büren",
		plz : "3264",
	};
	var expect = {
		ort : "Diessbach b. Büren",
		plz : "326400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase31 = function(test) {
	var params = {
		type : 1,
		ort : "Diessbach b. Buren",
		plz : "3264",
	};
	var expect = {
		ort : "Diessbach b. Büren",
		plz : "326400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase32 = function(test) {
	var params = {
		type : 1,
		ort : "Diessbach b Buren",
		plz : "3264",
	};
	var expect = {
		ort : "Diessbach b. Büren",
		plz : "326400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase33 = function(test) {
	var params = {
		type : 1,
		ort : "Diessbach b.",
		plz : "3264",
	};
	var expect = {
		ort : "Diessbach b. Büren",
		plz : "326400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase34 = function(test) {
	var params = {
		type : 1,
		ort : "Diessbach",
		plz : "3264",
	};
	var expect = {
		ort : "Diessbach b. Büren",
		plz : "326400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase35 = function(test) {
	var params = {
		type : 1,
		ort : "Diessbach 111",
		plz : "3264",
	};
	var expect = {
		ort : "Diessbach b. Büren",
		plz : "326400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase36 = function(test) {
	var params = {
		type : 1,
		ort : "b.",
		plz : "3264",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase37 = function(test) {
	var params = {
		type : 1,
		ort : "Büren",
		plz : "3264",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase38 = function(test) {
	var params = {
		type : 1,
		ort : "Neuchâtel 4 Ecluse",
		plz : "2004",
	};
	var expect = {
		ort : "Neuchâtel 4 Ecluse",
		plz : "200400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase39 = function(test) {
	var params = {
		type : 1,
		ort : "Neuchatel 4 Ecluse",
		plz : "2004",
	};
	var expect = {
		ort : "Neuchâtel 4 Ecluse",
		plz : "200400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase40 = function(test) {
	var params = {
		type : 1,
		ort : "Neuchatel 4",
		plz : "2004",
	};
	var expect = {
		ort : "Neuchâtel 4 Ecluse",
		plz : "200400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase41 = function(test) {
	var params = {
		type : 1,
		ort : "Neuchatel",
		plz : "2004",
	};
	var expect = {
		ort : "Neuchâtel 4 Ecluse",
		plz : "200400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase42 = function(test) {
	var params = {
		type : 1,
		ort : "Ecluse",
		plz : "2004",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase43 = function(test) {
	var params = {
		type : 1,
		ort : "Neuchatel 5 Ecluse",
		plz : "2004",
	};
	var expect = {
		ort : "Neuchâtel 4 Ecluse",
		plz : "200400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase44 = function(test) {
	var params = {
		type : 1,
		ort : "Biel/Bienne 1 Fächer",
		plz : "2501",
	};
	var expect = {
		ort : "Biel/Bienne 1 Fächer",
		plz : "250100"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase45 = function(test) {
	var params = {
		type : 1,
		ort : "Biel/Bienne",
		plz : "2501",
	};
	var expect = {
		ort : "Biel/Bienne 1 Fächer",
		plz : "250100"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase46 = function(test) {
	var params = {
		type : 1,
		ort : "Biel",
		plz : "2501",
	};
	var expect = {
		ort : "Biel/Bienne 1 Fächer",
		plz : "250100"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase47 = function(test) {
	var params = {
		type : 1,
		ort : "Bienne",
		plz : "2501",
	};
	var expect = {
		ort : "Biel/Bienne 1 Fächer",
		plz : "250100"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase48 = function(test) {
	var params = {
		type : 1,
		ort : "Biel/Bienne 2 Fächer",
		plz : "2501",
	};
	var expect = {
		ort : "Biel/Bienne 1 Fächer",
		plz : "250100"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase49 = function(test) {
	var params = {
		type : 1,
		ort : "BielBienne 1 Fächer",
		plz : "2501",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase50 = function(test) {
	var params = {
		type : 1,
		ort : "Fächer",
		plz : "2501",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase51 = function(test) {
	var params = {
		type : 1,
		ort : "Biel Bienne 1 Fächer",
		plz : "2501",
	};
	var expect = {
		ort : "Biel/Bienne 1 Fächer",
		plz : "250100"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase52 = function(test) {
	var params = {
		type : 1,
		ort : "Biel-Bienne 1 Fächer",
		plz : "2501",
	};
	var expect = {
		ort : "Biel/Bienne 1 Fächer",
		plz : "250100"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase53 = function(test) {
	var params = {
		type : 1,
		ort : "Biel Bienne-1-Fächer",
		plz : "2501",
	};
	var expect = {
		ort : "Biel/Bienne 1 Fächer",
		plz : "250100"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase54 = function(test) {
	var params = {
		type : 1,
		ort : "Disentis/Mustér",
		plz : "7180",
	};
	var expect = {
		ort : "Disentis/Mustér",
		plz : "718000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase55 = function(test) {
	var params = {
		type : 1,
		ort : "Disentis-Mustér",
		plz : "7180",
	};
	var expect = {
		ort : "Disentis/Mustér",
		plz : "718000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase56 = function(test) {
	var params = {
		type : 1,
		ort : "Disentis Mustér",
		plz : "7180",
	};
	var expect = {
		ort : "Disentis/Mustér",
		plz : "718000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase57 = function(test) {
	var params = {
		type : 1,
		ort : "Disentis 4",
		plz : "7180",
	};
	var expect = {
		ort : "Disentis/Mustér",
		plz : "718000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase58 = function(test) {
	var params = {
		type : 1,
		ort : "Muster 8",
		plz : "7180",
	};
	var expect = {
		ort : "Disentis/Mustér",
		plz : "718000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase59 = function(test) {
	var params = {
		type : 1,
		ort : "Sils",
		plz : "7514",
	};
	var expect = {
		ort : "Sils/Segl Maria",
		plz : "751400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase60 = function(test) {
	var params = {
		type : 1,
		ort : "Segl Maria",
		plz : "7514",
	};
	var expect = {
		ort : "Sils/Segl Maria",
		plz : "751400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase61 = function(test) {
	var params = {
		type : 1,
		ort : "Sils Segl",
		plz : "7514",
	};
	var expect = {
		ort : "Sils/Segl Maria",
		plz : "751400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase62 = function(test) {
	var params = {
		type : 1,
		ort : "Sils Segl Maria",
		plz : "7514",
	};
	var expect = {
		ort : "Sils/Segl Maria",
		plz : "751400"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase63 = function(test) {
	var params = {
		type : 1,
		ort : "Aire",
		plz : "1219",
	};
	var expect = {
		ort : "Aïre",
		plz : "121910"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase64 = function(test) {
	var params = {
		type : 1,
		ort : "Aïre",
		plz : "1219",
	};
	var expect = {
		ort : "Aïre",
		plz : "121910"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase65 = function(test) {
	var params = {
		type : 1,
		ort : "Aïre Abc",
		plz : "1219",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase66 = function(test) {
	var params = {
		type : 1,
		ort : "Renens VD 1",
		plz : "1020",
	};
	var expect = {
		ort : "Renens VD 1",
		plz : "102001"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase67 = function(test) {
	var params = {
		type : 1,
		ort : "Renens",
		plz : "1020",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase68 = function(test) {
	var params = {
		type : 1,
		ort : "Renens VD 3",
		plz : "1020",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase69 = function(test) {
	var params = {
		type : 1,
		ort : "Renens VD",
		plz : "1020",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase70 = function(test) {
	var params = {
		type : 1,
		ort : "Renens 1",
		plz : "1020",
	};
	var expect = {
		ort : "Renens VD 1",
		plz : "102001"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase71 = function(test) {
	var params = {
		type : 1,
		ort : "Renens VD",
		plz : "1020",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase72 = function(test) {
	var params = {
		type : 1,
		ort : "Renens VD 2",
		plz : "1020",
	};
	var expect = {
		ort : "Renens VD 2 Village",
		plz : "102002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase73 = function(test) {
	var params = {
		type : 1,
		ort : "Renens 2",
		plz : "1020",
	};
	var expect = {
		ort : "Renens VD 2 Village",
		plz : "102002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase74 = function(test) {
	var params = {
		type : 1,
		ort : "Dübendorf 2 Flugfeld",
		plz : "8600",
	};
	var expect = {
		ort : "Dübendorf 2 Flugfeld",
		plz : "860002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase75 = function(test) {
	var params = {
		type : 1,
		ort : "Dubendorf 2 Flugfeld",
		plz : "8600",
	};
	var expect = {
		ort : "Dübendorf 2 Flugfeld",
		plz : "860002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase76 = function(test) {
	var params = {
		type : 1,
		ort : "Dübendorf 2",
		plz : "8600",
	};
	var expect = {
		ort : "Dübendorf 2 Flugfeld",
		plz : "860002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase77 = function(test) {
	var params = {
		type : 1,
		ort : "Dubendorf 2 Flug",
		plz : "8600",
	};
	var expect = {
		ort : "Dübendorf 2 Flugfeld",
		plz : "860002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase78 = function(test) {
	var params = {
		type : 1,
		ort : "Poliez",
		plz : "1041",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase79 = function(test) {
	var params = {
		type : 1,
		ort : "Poliez le",
		plz : "1041",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase80 = function(test) {
	var params = {
		type : 1,
		ort : "Poliez-le",
		plz : "1041",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase81 = function(test) {
	var params = {
		type : 1,
		ort : "Poliez-le Grand",
		plz : "1041",
	};
	var expect = {
		ort : "Poliez-le-Grand",
		plz : "104131"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase82 = function(test) {
	var params = {
		type : 1,
		ort : "St.George",
		plz : "1188",
	};
	var expect = {
		ort : "St-George",
		plz : "118802"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase83 = function(test) {
	var params = {
		type : 1,
		ort : "St George",
		plz : "1188",
	};
	var expect = {
		ort : "St-George",
		plz : "118802"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase84 = function(test) {
	var params = {
		type : 1,
		ort : "St-George",
		plz : "1188",
	};
	var expect = {
		ort : "St-George",
		plz : "118802"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase85 = function(test) {
	var params = {
		type : 1,
		ort : "Nyon",
		plz : "1260",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase86 = function(test) {
	var params = {
		type : 1,
		ort : "Nyon 2",
		plz : "1260",
	};
	var expect = {
		ort : "Nyon 2 Champ-Colin",
		plz : "126002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase87 = function(test) {
	var params = {
		type : 1,
		ort : "Nyon 2 Champ",
		plz : "1260",
	};
	var expect = {
		ort : "Nyon 2 Champ-Colin",
		plz : "126002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase88 = function(test) {
	var params = {
		type : 1,
		ort : "Nyon 2 Champ-Colin",
		plz : "1260",
	};
	var expect = {
		ort : "Nyon 2 Champ-Colin",
		plz : "126002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase89 = function(test) {
	var params = {
		type : 1,
		ort : "Nyon 2 Champ Colin",
		plz : "1260",
	};
	var expect = {
		ort : "Nyon 2 Champ-Colin",
		plz : "126002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase90 = function(test) {
	var params = {
		type : 1,
		ort : "Bichelsee",
		plz : "8362",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase91 = function(test) {
	var params = {
		type : 1,
		ort : "Bichelsee Balterswil",
		plz : "8362",
	};
	var expect = {
		ort : "Bichelsee-Balterswil",
		plz : "836201"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase92 = function(test) {
	var params = {
		type : 1,
		ort : "Bichelsee-Balterswil",
		plz : "8362",
	};
	var expect = {
		ort : "Bichelsee-Balterswil",
		plz : "836201"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase93 = function(test) {
	var params = {
		type : 1,
		ort : "St.",
		plz : "3942",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase94 = function(test) {
	var params = {
		type : 1,
		ort : "St German",
		plz : "3942",
	};
	var expect = {
		ort : "St. German",
		plz : "394203"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase95 = function(test) {
	var params = {
		type : 1,
		ort : "St-German",
		plz : "3942",
	};
	var expect = {
		ort : "St. German",
		plz : "394203"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase96 = function(test) {
	var params = {
		type : 1,
		ort : "St. Moritz",
		plz : "7500",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase97 = function(test) {
	var params = {
		type : 1,
		ort : "St.",
		plz : "7500",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase98 = function(test) {
	var params = {
		type : 1,
		ort : "Biel 3",
		plz : "2500",
	};
	var expect = {
		ort : "Biel/Bienne 3 Neumarkt/Marché-Neuf",
		plz : "250003"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase99 = function(test) {
	var params = {
		type : 1,
		ort : "Bienne 3",
		plz : "2500",
	};
	var expect = {
		ort : "Biel/Bienne 3 Neumarkt/Marché-Neuf",
		plz : "250003"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase100 = function(test) {
	var params = {
		type : 1,
		ort : "Biel Bienne 3",
		plz : "2500",
	};
	var expect = {
		ort : "Biel/Bienne 3 Neumarkt/Marché-Neuf",
		plz : "250003"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase101 = function(test) {
	var params = {
		type : 1,
		ort : "Biel 3 Neumarkt-Neuf",
		plz : "2500",
	};
	var expect = {
		ort : "Biel/Bienne 3 Neumarkt/Marché-Neuf",
		plz : "250003"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase102 = function(test) {
	var params = {
		type : 1,
		ort : "Bienne 3 Marché-Neuf",
		plz : "2500",
	};
	var expect = {
		ort : "Biel/Bienne 3 Neumarkt/Marché-Neuf",
		plz : "250003"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase103 = function(test) {
	var params = {
		type : 1,
		ort : "Biel(Bienne) 3 Neumarkt",
		plz : "2500",
	};
	var expect = {
		ort : "Biel/Bienne 3 Neumarkt/Marché-Neuf",
		plz : "250003"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase104 = function(test) {
	var params = {
		type : 1,
		ort : "Biel-Bienne 3 Marché",
		plz : "2500",
	};
	var expect = {
		ort : "Biel/Bienne 3 Neumarkt/Marché-Neuf",
		plz : "250003"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase105 = function(test) {
	var params = {
		type : 1,
		ort : "BielBienne 3 Neuf",
		plz : "2500",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase106 = function(test) {
	var params = {
		type : 1,
		ort : "Biel/Bienne 3 Neuf",
		plz : "2500",
	};
	var expect = {
		ort : "Biel/Bienne 3 Neumarkt/Marché-Neuf",
		plz : "250003"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase107 = function(test) {
	var params = {
		type : 1,
		ort : "BielBienne 3 NeumarktMarché-Neuf",
		plz : "2500",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase108 = function(test) {
	var params = {
		type : 1,
		ort : "BielBienne 3 Neumarkt/Marché-Neuf",
		plz : "2500",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase109 = function(test) {
	var params = {
		type : 1,
		ort : "Villars-sur-Glane 2",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase110 = function(test) {
	var params = {
		type : 1,
		ort : "Villars-sur-Glane 2 Les Dailles",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase111 = function(test) {
	var params = {
		type : 1,
		ort : "Villars-sur-Glâne 2",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase112 = function(test) {
	var params = {
		type : 1,
		ort : "Villars-sur-Glâne 2 Les-Dailles",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase113 = function(test) {
	var params = {
		type : 1,
		ort : "Villars-sur-Glâne 2 Les",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase114 = function(test) {
	var params = {
		type : 1,
		ort : "Villars sur Glâne 2 Les Dailles",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase115 = function(test) {
	var params = {
		type : 1,
		ort : "Villars sur Glâne 2 Les",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase116 = function(test) {
	var params = {
		type : 1,
		ort : "Villars-sur Glâne 2 Les Dailles",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase117 = function(test) {
	var params = {
		type : 1,
		ort : "Villars sur-Glâne 2 Les Dailles",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase118 = function(test) {
	var params = {
		type : 1,
		ort : "Villars 2 Les Dailles",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase119 = function(test) {
	var params = {
		type : 1,
		ort : "Villars-sur 2 Les Dailles",
		plz : "1752",
	};
	var expect = {
		ort : "Villars-sur-Glâne 2 Les Dailles",
		plz : "175202"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase120 = function(test) {
	var params = {
		type : 1,
		ort : "Geneve",
		plz : "1215",
	};
	var expect = {
		ort : "Genève 15 Aéroport",
		plz : "121500"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase121 = function(test) {
	var params = {
		type : 1,
		ort : "Geneve 15",
		plz : "1215",
	};
	var expect = {
		ort : "Genève 15 Aéroport",
		plz : "121500"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase122 = function(test) {
	var params = {
		type : 1,
		ort : "Genève 1",
		plz : "1215",
	};
	var expect = {
		ort : "Genève 15 Aéroport",
		plz : "121500"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase123 = function(test) {
	var params = {
		type : 1,
		ort : "Genève 15 Aéroport",
		plz : "1215",
	};
	var expect = {
		ort : "Genève 15 Aéroport",
		plz : "121500"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase124 = function(test) {
	var params = {
		type : 1,
		ort : "Genève 15 Aeroport",
		plz : "1215",
	};
	var expect = {
		ort : "Genève 15 Aéroport",
		plz : "121500"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase125 = function(test) {
	var params = {
		type : 1,
		ort : "Genève 15 Aéroport Dépôt",
		plz : "1215",
	};
	var expect = {
		ort : "Genève 15 Aéroport Dépôt",
		plz : "121568"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase126 = function(test) {
	var params = {
		type : 1,
		ort : "Biasca 1",
		plz : "6710",
	};
	var expect = {
		ort : "Biasca",
		plz : "671000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase127 = function(test) {
	var params = {
		type : 1,
		ort : "Biasca",
		plz : "6710",
	};
	var expect = {
		ort : "Biasca",
		plz : "671000"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase128 = function(test) {
	var params = {
		type : 1,
		ort : "Biasca Stazione",
		plz : "6710",
	};
	var expect = {
		ort : "Biasca Stazione",
		plz : "671001"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase129 = function(test) {
	var params = {
		type : 1,
		ort : "Bulle",
		plz : "1630",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase130 = function(test) {
	var params = {
		type : 1,
		ort : "Bulle 1",
		plz : "1630",
	};
	var expect = {
		ort : "Bulle 1",
		plz : "163001"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase131 = function(test) {
	var params = {
		type : 1,
		ort : "Bulle 2",
		plz : "1630",
	};
	var expect = {
		ort : "Bulle 2",
		plz : "163002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase132 = function(test) {
	var params = {
		type : 1,
		ort : "Bulle 3",
		plz : "1630",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase133 = function(test) {
	var params = {
		type : 1,
		ort : "Sion 2",
		plz : "1950",
	};
	var expect = {
		ort : "Sion 2 Nord",
		plz : "195002"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase134 = function(test) {
	var params = {
		type : 1,
		ort : "Sion 4",
		plz : "1950",
	};
	var expect = {
		ort : "Sion 4 Champsec",
		plz : "195004"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase135 = function(test) {
	var params = {
		type : 1,
		ort : "Döttingen",
		plz : "5312",
	};
	var expect = {
		ort : "Döttingen",
		plz : "531200"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase136 = function(test) {
	var params = {
		type : 1,
		ort : "Döttingen Klingnau",
		plz : "5312",
	};
	var expect = {
		ort : "Döttingen-Klingnau",
		plz : "531201"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase137 = function(test) {
	var params = {
		type : 1,
		ort : "Döttingen-Klingnau",
		plz : "5312",
	};
	var expect = {
		ort : "Döttingen-Klingnau",
		plz : "531201"
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
module.exports.testCase138 = function(test) {
	var params = {
		type : 1,
		ort : "Mendrisio",
		plz : "6850",
	};
	var expect = {
		ort : "",
		plz : ""
	}
	searchAPI.searchZubofiSpecial(params).then(function(data) {
		if (data.hits.total == 0) {// retry time 1
			searchAPI.searchZubofiSpecial(params, 1).then(function(data) {
				if (data.hits.total == 0) {
					test.ok(expect.plz == '' && expect.ort == '');
				} else {
					var resp = data.hits.hits[0];
					test.ok(resp._source.plz == expect.plz && resp._source.ort == expect.ort);
				}
				test.done();
			});
		} else {
			var resp = data.hits.hits[0];
			test.ok(resp._source != undefined && resp._source.plz == expect.plz && resp._source.ort == expect.ort);
			test.done();
		}
		
	}, function() {
		test.ok(false);
		test.done();
	});
}
