if (typeof Common == 'undefined') {
    var Common = {};
}

Common.countWords = function (text) {
    return text.split(/\s+/).length;
}

Common.normalize = function (s) {
    if (s != undefined) {
        var r = s.toString().toLowerCase();

        var aRegExp = new RegExp("[àáâãäå]", 'g');
        var cRegExp = new RegExp("ç", 'g');
        var eRegExp = new RegExp("[èéêë]", 'g');
        var iRegExp = new RegExp("[ìíîï]", 'g');
        var nRegExp = new RegExp("ñ", 'g');
        var oRegExp = new RegExp("[òóôõö]", 'g');
        var uRegExp = new RegExp("[ùúûü]", 'g');
        var yRegExp = new RegExp("[ýÿ]", 'g');
        var a1RegExp = new RegExp("æ", 'g');
        var o1RegExp = new RegExp("œ", 'g');
        var a2RegExp = new RegExp("ae", 'g');
        var o2RegExp = new RegExp("oe", 'g');
        var u1RegExp = new RegExp("ue", 'g');
        var bRegExp = new RegExp("ß", 'g');
        var sRegExp = new RegExp("š", 'g');

        r = r.replace(aRegExp, "a");
        r = r.replace(cRegExp, "c");
        r = r.replace(eRegExp, "e");
        r = r.replace(iRegExp, "i");
        r = r.replace(nRegExp, "n");
        r = r.replace(oRegExp, "o");
        r = r.replace(uRegExp, "u");
        r = r.replace(yRegExp, "y");
        r = r.replace(a1RegExp, "ae");
        r = r.replace(o1RegExp, "oe");
        r = r.replace(a2RegExp, "a");
        r = r.replace(o2RegExp, "o");
        r = r.replace(u1RegExp, "u");
        r = r.replace(bRegExp, "ss");
        r = r.replace(sRegExp, "s");

        //Looup replace
        if (aRegExp.test(r) || cRegExp.test(r) || eRegExp.test(r) || iRegExp.test(r) || nRegExp.test(r)
                || oRegExp.test(r) || uRegExp.test(r) || yRegExp.test(r) || a1RegExp.test(r) || o1RegExp.test(r)
                || a2RegExp.test(r) || o2RegExp.test(r) || u1RegExp.test(r) || bRegExp.test(r) || sRegExp.test(r)) {

            r = this.normalize(r);
        }

        return r;
    }
    return '';
}

Common.stripAccents = function (s) {
    var r = Common.normalize(s);
    r = r.replace(new RegExp("[^0-9a-z%*?]+", 'g'), " ");
    return r;
}

Common.normalizeForMatch = function (s) {
    var r = Common.normalize(s);
    r = r.replace("'", "");
    r = r.replace(new RegExp("[^0-9a-z]+", 'g'), " ");
    r = r.trim();
    return r;
}

Common.normalizeForWildcard = function (s) {
    var r = Common.normalize(s);
    r = r.replace(new RegExp("[^0-9a-z\'%*?]+", 'g'), '');
    return r;
}

Common.escapeWildcard = function (s) {
    s = s.replace(new RegExp("%", 'g'), "*");
    s = s.replace(new RegExp("_", 'g'), "?");
    return s;
}

Common.normalizeOrtForSpecialZubofiSearch = function (s) {
    var r = s.replace("'", "");
    r = Common.normalize(r);
    r = r.replace(new RegExp("[^0-9a-z/]+", 'g'), " ");
    return r;
}

Common.normalizeOrtForSpecialZubofiPickpost = function (s) {
    var r = s.replace('-', ' ').replace('/', ' ');
    r = Common.normalize(r);
    return r;
}

Common.checkValid = function (value) {
    if (typeof value != 'undefined' && value.toString().trim().length > 0) {
        return true;
    }
    return false;
}

Common.existsFilter = function (fieldName) {
    return {
        exists: {
            field: fieldName
        }
    }
}

Common.missingFilter = function (fieldName) {
    return {
        missing: {
            field: fieldName
        }
    }
}

Common.buildQueryStringQuery = function (fieldName, value, boost) {
    value = value.toString().replace(
            /(\+|-|&&|=|\|\||>|<|!|\(|\)|{|}|\[|\]|\^|\"|~|:|\\|\/)/g, ' ');
    value = value.trim().replace(/( )+/g, "* ") + "*";
    value = value.replace(/(%)+/g, " *").toLowerCase();

    if (boost == undefined) {
        boost = 1;
    }
    var query = {}
    query.query_string = {};
    query.query_string.default_field = fieldName;
    query.query_string.query = value

    if (typeof boost != 'undefined') {
        query.query_string.boost = boost
    }
    return query;
}

Common.buildQueryStringQueryWithoutWildcard = function (fieldName, value, boost, default_operator) {
    var query = {
        query_string: {
            default_field: '',
            query: '',
            default_operator: 'OR',
            boost: 1
        }
    };
    if (fieldName != undefined && fieldName != null) {
        query.query_string.default_field = fieldName;

        if (value != undefined && value != null) {
            query.query_string.query = value;
        } else {
            query.query_string.query = '_null_';
        }

        if (boost != undefined && boost != null) {
            query.query_string.boost = boost;
        }

        if (default_operator != undefined && default_operator != null) {
            query.query_string.default_operator = default_operator;
        }
    } else {
        return null;
    }

    return query;
}

Common.buildMatchQuery = function (fieldName, value, boost, fuzziness, operator, isMatchDefaultField) {
    var query = {}
    query.match = {};
     if (isMatchDefaultField == true) {
        query.match[fieldName] = value;
    } else {
         if (boost == undefined) {
             boost = 1;
         };
         query.match[fieldName] = {};
         query.match[fieldName].query = value
         if (fuzziness == true) {
             query.match[fieldName].fuzziness = 'AUTO';
         }
         if (typeof boost != 'undefined' && boost != null) {
             query.match[fieldName].boost = boost
         }
         if (typeof operator != 'undefined'
             && (operator.toLowerCase() == "and" || operator.toLowerCase() == "or")) {
             query.match[fieldName].operator = operator;
         }
    }
    return query;
}

Common.buildMatchPhraseQuery = function (fieldName, value) {
    var query = {}

    query.match_phrase = {};
    query.match_phrase[fieldName] = value;

    return query;
}

Common.buildPhrasePrefixQuery = function (fieldName, value) {
    var query = {};
    query.match_phrase_prefix = {};
    query.match_phrase_prefix[fieldName] = value;
    return query;
}

Common.buildMultiMatchQuery = function (fieldNameList, value, boost, fuzziness) {
    var query = {}
    query.multi_match = {
        fields: fieldNameList,
        query: value
    };
    if (fuzziness == true) {
        query.multi_match.fuzziness = 'AUTO'
    }
    if (typeof boost != 'undefined') {
        query.multi_match.boost = boost
    }
    query.multi_match.tie_breaker = 1
    return query;
}

Common.buildWildcard = function (fieldNameList, lookup, fuzziness, operator) {

    var fieldNames = []
    if (fieldNameList instanceof Array) {
        fieldNames = fieldNameList;
    } else {
        fieldNames.push(fieldNameList);
    }
    var query = {}
    query.query_string = {}
    lookup = lookup.replace(
            /(\+|-|&&|=|\|\||>|<|!|\(|\)|{|}|\[|\]|\^|\"|~|:|\\|\/)/g, ' ');
    if (fuzziness == true) {
        lookup = lookup.trim().replace(/( )+/g, "~ ");
        if (lookup.trim().match('~$') != "~") {
            lookup = lookup.trim() + "~";
        }

    } else {
        lookup = lookup.trim().replace(/( )+/g, "* ") + "*";
        lookup = lookup.replace(/(%)+/g, " *");
    }
    query.query_string.fields = fieldNames;
    query.query_string.query = lookup;
    if (typeof operator != 'undefined'
            && (operator.toLowerCase() == "and" || operator.toLowerCase() == "or")) {
        query.query_string.default_operator = operator;
    }

    return query;
}

Common.buildBoolQuery = function (clauseQuery) {
    var query = {
        query: {
            bool: {
                minimum_should_match: typeof clauseQuery.msm == 'undefined' ? 1
                        : clauseQuery.msm
            }
        }
    };

    if (typeof clauseQuery.shouldQueryList != 'undefined'
            && clauseQuery.shouldQueryList.length > 0) {
        query.query.bool.should = clauseQuery.shouldQueryList;
    }

    if (typeof clauseQuery.filter != 'undefined') {
        query.filter = clauseQuery.filter;
    }

    if (typeof clauseQuery.mustQueryList != 'undefined'
            && clauseQuery.mustQueryList.length > 0) {
        query.query.bool.must = clauseQuery.mustQueryList;
    }
    if (typeof clauseQuery.mustNotQueryList != 'undefined'
            && clauseQuery.mustNotQueryList.length > 0) {
        query.query.bool.must_not = clauseQuery.mustNotQueryList;
    }
    return query;
}

Common.buildSortingQuery = function (fieldName, order) {
    var sort = {}
    sort[fieldName] = order;
    return sort;
}

Common.buildStandardWildcardQuery = function (fieldName, _value) {
    var query = {
        wildcard: {}
    }
    query.wildcard[fieldName] = {
        value: _value
    }
    return query;
}

Common.buildSuggestQuery = function (fieldName, _value, size) {
    var query = {
        suggester: {}
    };
    query.suggester = {
        text: _value,
        completion: {
            field: fieldName,
            size: size
        }
    };
    return query;
}

Common.buildSearchSuggestQuery = function (_value) {
    var query = {
        query_string: {}
    };
    query.query_string = {
        query: _value
    };
    return query;
}

Common.buildUpdateWeightSuggestQuery = function (fieldName, weight) {
    var query = {
        doc: {
            suggest: {
            }
        }
    };
    query.doc.suggest[fieldName] = weight;
    return query;
}

/*
 * make it visible for use when using require operator to include
 */
module.exports = {
    stripAccents: function (rawText) {
        return Common.stripAccents(rawText);
    },
    normalizeOrtForSpecialZubofiSearch: function (rawText) {
        return Common.normalizeOrtForSpecialZubofiSearch(rawText);
    },
    buildMatchQuery: function (fieldName, value, boost, fuzziness, operator, isMatchDefaultField) {
        return Common.buildMatchQuery(fieldName, value, boost, fuzziness,
                operator, isMatchDefaultField);
    },
    buildBoolQuery: function (clauseQuery) {
        return Common.buildBoolQuery(clauseQuery);
    },
    buildWildcard: function (fieldNameList, lookup, fuzziness, operator) {
        return Common.buildWildcard(fieldNameList, lookup, fuzziness, operator);
    },
    buildQueryStringQuery: function (fieldName, value, boost) {
        return Common.buildQueryStringQuery(fieldName, value, boost);
    },
    buildQueryStringQueryWithoutWildcard: function (fieldName, value, boost, default_operator) {
        return Common.buildQueryStringQueryWithoutWildcard(fieldName, value, boost, default_operator);
    },
    buildMatchPhraseQuery: function (fieldName, value) {
        return Common.buildMatchPhraseQuery(fieldName, value);
    },
    buildMultiMatchQuery: function (fieldNameList, value, boost, fuzziness) {
        return Common.buildMultiMatchQuery(fieldNameList, value, boost,
                fuzziness);
    },
    buildPhrasePrefixQuery: function (fieldName, value) {
        return Common.buildPhrasePrefixQuery(fieldName, value);
    },
    buildStandardWildcardQuery: function (fieldName, value) {
        return Common.buildStandardWildcardQuery(fieldName, value);
    },
    missingFilter: function (fieldName) {
        return Common.missingFilter(fieldName);
    },
    existsFilter: function (fieldName) {
        return Common.existsFilter(fieldName);
    },
    checkValid: function (value) {
        return Common.checkValid(value);
    },
    countWords: function (text) {
        return Common.countWords(text);
    },
    buildSortingQuery: function (fieldName, order) {
        return Common.buildSortingQuery(fieldName, order);
    },
    normalizeOrtForSpecialZubofiPickpost: function (rawText) {
        return Common.normalizeOrtForSpecialZubofiPickpost(rawText);
    },
    normalize: function (rawText) {
        return Common.normalize(rawText);
    },
    escapeWildcard: function (s) {
        return Common.escapeWildcard(s);
    },
    normalizeForMatch: function (rawtext) {
        return Common.normalizeForMatch(rawtext);
    },
    normalizeForWildcard: function (rawtext) {
        return Common.normalizeForWildcard(rawtext);
    },
    buildSuggestQuery: function (fieldName, value, size)
    {
        return Common.buildSuggestQuery(fieldName, value, size);
    },
    buildSearchSuggestQuery: function (value, size)
    {
        return Common.buildSearchSuggestQuery(value, size);
    },
    buildUpdateWeightSuggestQuery: function (fieldName, weight)
    {
        return Common.buildUpdateWeightSuggestQuery(fieldName, weight);
    }

}