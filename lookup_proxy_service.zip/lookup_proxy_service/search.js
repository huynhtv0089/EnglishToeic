var elasticsearch = require('elasticsearch');
var fs = require('fs');
var zubofiSpecial = require('./zubofi/special');
var zubofiNormal = require('./zubofi/normal');
var lookupExtra = require('./zubofi/lookupExtra');
var lookup = require('./kdp/lookup');
var lookupQC = require('./kdp/lookupQC');
var ocrFirmaSign = require('./ocr/firmaSign');
var suggestion = require('./suggestion/suggestion');
var wordSuggestion = require('./word-suggestion/word_suggestion');

var graylog2 = require("graylog2");
var logger = null;

if (typeof Search == 'undefined') {
    var Search = {};
}

Search.initialize = function () {
    var self = this;
    if (self.config == undefined) {
        var data = fs.readFileSync(__dirname + '/config/properties.json', 'utf8');
        self.config = JSON.parse(data);
    }

    self.client = elasticsearch.Client({
        hosts: self.config.ES_hosts,
        log: [{
                type: 'file',
                level: (typeof self.config.logLevel === 'undefined') ? info : self.config.logLevel, // change these options: trace, info, warning, error
                path: 'logs/elasticsearch.log'
            }]
    });

    // Init graylog2 for logger
    logger = new graylog2.graylog({
        servers: [{
                host: self.config.graylog.host,
                port: self.config.graylog.port
            }]
    });
};

Search.getIndexTypeFromFieldName = function (text_type) {
    var type = "";
    switch (text_type) {
        case suggestion.getFIRMA_TYPE():
            type = Search.config.VAE_suggestion_data_firma_type;
            break;
        case suggestion.getVORNAME_TYPE() :
            type = Search.config.VAE_suggestion_data_vorname_type;
            break;
        case suggestion.getNACHNAME_TYPE() :
            type = Search.config.VAE_suggestion_data_nachname_type;
            break;
        case suggestion.getZUSAT_TYPE() :
            type = Search.config.VAE_suggestion_data_zusat_type;
            break;
        case suggestion.getANREDE_TYPE() :
            type = Search.config.VAE_suggestion_data_anrede_type;
            break;
        case suggestion.getVORNAMEMORE_TYPE() :
            type = Search.config.VAE_suggestion_data_vornamemore_type;
            break;
        case suggestion.getNACHNAMEMORE_TYPE():
            type = Search.config.VAE_suggestion_data_nachnamemore_type;
            break;
        case suggestion.getFIRMENAMEMORE_TYPE():
            type = Search.config.VAE_suggestion_data_firmenamemore_type;
            break;
    }

    return type;
}

module.exports = {
    /*
     * { took: total: hits: { } }
     */
    search: function (searchParam, retryCount) {
        var query = lookup.buildDefaultQuery(searchParam, false);
        if (retryCount != undefined && retryCount == 1) {
            query = lookup.buildDefaultQuery(searchParam, true);
        } else if (retryCount != undefined && retryCount == 2) {
            query = lookup.buildNachNameFuzzyQuery(searchParam);
        }

        console.log(JSON.stringify(query));

        query.size = Search.config.searchSize;
        var searchParamObj = {
            index: Search.config.VAE_index,
            type: Search.config.VAE_type,
            body: query
        };

        logger.log({
            query: searchParamObj,
            objSearch: searchParam
        });
        return Search.client.search(searchParamObj);
    },
    search_first: function(searchParam) {
        var query = lookup.buildMustQuery(searchParam);
         console.log(JSON.stringify(query));

        query.size = Search.config.searchSize;
        var searchParamObj = {
            index: Search.config.VAE_index,
            type: Search.config.VAE_type,
            body: query
        };

        logger.log({
            query: searchParamObj,
            objSearch: searchParam
        });

        return Search.client.search(searchParamObj);
    },
    search_qc: function (searchParam) {
        var query = lookupQC.buildQCQuery(searchParam);
        query.size = Search.config.QC_searchSize;
        var searchParamObj = {
            index: Search.config.VAE_QC_index,
            type: Search.config.VAE_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    searchKdpid: function (kdpId) {
        var searchParam = {
            "query": {
                "match": {
                    "kdp_id": kdpId
                }
            }
        };
        return Search.client.search({
            index: Search.config.VAE_QC_index,
            type: Search.config.VAE_type,
            body: searchParam
        });
    },
    find_hauskey_by_kdpid: function (kdpid) {
        var query = lookup.find_hauskey_by_kdpid(kdpid);
        query.size = 1;
        var searchParamObj = {
            index: Search.config.VAE_index,
            type: Search.config.VAE_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    find_hauskey_by_kdp_object: function (kdp) {
        var query = lookup.buildFindHauskeyByKdpObjectQuery(kdp);
        query.size = 1;
        var searchParamObj = {
            index: Search.config.VAE_index,
            type: Search.config.VAE_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    count_duplicate_kdp: function (kdp) {
        var query = lookup.count_duplicate_kdp(kdp);
        var searchParamObj = {
            index: Search.config.VAE_index,
            type: Search.config.VAE_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    lookup_extra: function (plookupExtra) {
        var query = lookupExtra.build_LookupExtra_Query(plookupExtra);
        query.size = Search.config.lookupExtraSize;
        var searchParamObj = {
            index: Search.config.VAE_zubofi_index,
            type: Search.config.VAE_lookupExtra_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    find_streetnumber_by_parcel_hauskey: function (addressid) {
        var query = zubofiNormal.find_street_number_by_parcel_hauskey(addressid);
        query.size = 1;
        var searchParamObj = {
            index: Search.config.VAE_zubofi_index,
            type: Search.config.VAE_zubofi_normal_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    search_zubofi_addrid: function (zubofiAddr) {
        var query = zubofiNormal
                .search_zubofi_addrid(zubofiAddr);
        query.size = 1;
        var searchParamObj = {
            index: Search.config.VAE_zubofi_index,
            type: Search.config.VAE_zubofi_normal_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    search_zubofi_hauskey: function (zubofiAddr) {
        var query = zubofiNormal
                .search_zubofi_hauskey(zubofiAddr);
        query.size = 1;
        var searchParamObj = {
            index: Search.config.VAE_zubofi_index,
            type: Search.config.VAE_zubofi_normal_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    searchZubofiSpecial: function (searchParam, retryCount) {
        var squery = {};
        if (retryCount == undefined) {
            squery = zubofiSpecial.makeSearchVGDLFirstTryParams(searchParam);
        } else {// second retry
            squery = zubofiSpecial.makeSearchVGDLSecondTryParams(searchParam);
        }
        var query = {};
        query.query = squery;
        query.sort = zubofiSpecial.makeSearchVGDLSorting();
        query.size = 1;
        var searchParamObj = {
            index: Search.config.VAE_zubofi_special_index,
            type: Search.config.VAE_zubofi_special_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    searchZubofiSpecialPickpostSameCheck: function (searchParam) {
        var query = {};
        var squery = zubofiSpecial.makeSearchVGDLPickpostSpecialSameCheckParam(searchParam);
        var sorting = zubofiSpecial.makeSearchVGDLPickPostSpecialSameCheckSorting();
        query.query = squery;
        query.sort = sorting;
        query.size = 2;
        var searchParamObj = {
            index: Search.config.VAE_zubofi_special_index,
            type: Search.config.VAE_zubofi_special_type,
            body: query
        };

        return Search.client.search(searchParamObj);
    },
    searchZubofiSpecialPickpostOrMypost24: function (searchParam) {
        var query = {};
        var squery = zubofiSpecial.makeSearchPickpostOrMypost24(searchParam);
        var sorting = zubofiSpecial.makeSearchVGDLPickPostSpecialSameCheckSorting();
        query.query = squery;
        query.sort = sorting;
        query.size = 2;
        var searchParamObj = {
            index: Search.config.VAE_zubofi_special_index,
            type: Search.config.VAE_zubofi_special_type,
            body: query
        };

        return Search.client.search(searchParamObj);
    },
    searchZubofiSpecialPickpostCheck: function (searchParam) {
        var query = {};
        var squery = zubofiSpecial.makeSearchVGDLPickpostSpecialCheckParam(searchParam);
        var sorting = zubofiSpecial.makeSearchVGDLSorting();
        query.query = squery;
        query.sort = sorting;
        query.size = 1;
        var searchParamObj = {
            index: Search.config.VAE_zubofi_special_index,
            type: Search.config.VAE_zubofi_special_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    searchZubofiSpecialPostfach: function (searchParam, times) {
        var query = {};
        if (times > 1) {
            var squery = zubofiSpecial.makeSearchASDPPostfachWithoutOrt(searchParam);
        } else {
            var squery = zubofiSpecial.makeSearchASDPPostfachWithOrt(searchParam);
        }

        query.query = squery;
        query.size = 2;
        var searchParamObj = {
            index: Search.config.VAE_zubofi_special_index,
            type: Search.config.VAE_zubofi_special_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    searchZubofiSpecialPostlagernd: function (searchParam, retryTimes) {
        var query = {};
        query.query = zubofiSpecial.makeSearchASDPPostlagernd(searchParam, retryTimes);
        if (retryTimes === 2) {
            query.sort = zubofiSpecial.makeSearchVGDLSorting();
        }

        var searchParamObj = {
            index: Search.config.VAE_zubofi_special_index,
            type: Search.config.VAE_zubofi_special_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    searchASDPPLZ: function (searchParam) {
        var query = {};
        query.query = {
            "bool": {
                "must": [
                    {
                        "match": {
                            "plz_typ": "30"
                        }
                    },
                    {
                        "query_string": {
                            "default_field": "plz_plz",
                            "query": searchParam + "*"
                        }
                    }
                ]
            }
        };
        query.size = 1;

        var searchParamObj = {
            index: Search.config.VAE_zubofi_special_index,
            type: Search.config.VAE_asdp_plz_type,
            body: query
        };
        return Search.client.search(searchParamObj);
    },
    /**
     * ABA-175: Firmen-Plz
     */
    searchPlzOrtZubofi: function (plz, ort, opt) {
        params = {};
        params.plz = plz;
        params.ort = ort;
        var query;

        if(opt !== 3) {
            if(opt === 1) {
                query = lookupExtra.build_Match_PlzAndOrt_LookupExtra_Query(params);
            }else if(opt === 2) {
                query = lookupExtra.build_MatchPlz_PrefixOrt_LookupExtra_Query(params);
            }
            query.query.bool.must[2].match.type = 'ort';
        }else {
            query = {
                "query": {
                    "bool": {
                      "must": [
                        {
                          "match" : {
                            "plz": plz
                          }
                        },
                        {
                          "match": {
                            "type": "plz"
                          }
                        }
                      ]
                    }
                },
                "sort": [
                    {
                      "ort_search_not_analyzed": "asc"
                    }
                ]
            }
        }

        var searchParamObj = {
            index: Search.config.VAE_zubofi_index,
            type: Search.config.VAE_lookupExtra_type,
            body: query
        }
        return Search.client.search(searchParamObj);
    },
    /**
     * ABA-175: Firmen-Plz
     */
    searchFirmenPlzASDP: function (plz) {
        var query = {};
        query = {
            "query" : {
                "query_string": {
                    "default_field": "plz_plz",
                    "query": plz
                }
            }
        }
        var searchParamObj = {
            index: Search.config.VAE_zubofi_special_index,
            type: Search.config.VAE_asdp_plz_type,
            body: query
        }
        return Search.client.search(searchParamObj);
    },
    getAllOCRFirmaSign: function (index, max) {
        var searchParamObj = {
            index: Search.config.index_ocr,
            type: Search.config.index_ocr_firmasign,
            body: {
                from: index,
                size: max
            }
        };
        return Search.client.search(searchParamObj);
    },
    suggestionKdp: function (textType, fieldName, term) {//Suggestion for KDP auto complete
        var type = Search.getIndexTypeFromFieldName(textType);
        var query = suggestion.makeKdpAutocomplete(textType, term);
        if (query != undefined) {
            query.size = Search.config.suggestion_kdp_size;
            query.sort = suggestion.makeKdpAutocompleteSorting(textType);
            var searchParamObj = {
                index: Search.config.VAE_suggestion_data_index,
                type: type,
                body: query
            };

            return Search.client.search(searchParamObj);
        }
    },
    checkConditionSwap: function (name, typeName, iPercent) {//Check if swappable
        var type = suggestion.getINDEX_TYPE_NAME();
        var query = suggestion.checkName(name, typeName, iPercent);
        if (query != undefined) {
            var searchParamObj = {
                index: Search.config.VAE_suggestion_data_index,
                type: type,
                body: query
            };

            return Search.client.count(searchParamObj);
        }
    },
    suggestWord: function (value)
    {
        var query = wordSuggestion.buildSuggest(value, Search.config.word_suggestion_size);
        if (query !== undefined) {
            var suggest = {
                index: Search.config.VAE_word_suggestion_index,
                body: query
            };
            return Search.client.suggest(suggest);
        }
    },
    searchSuggestWord: function (value)
    {
        var query = {
            query: wordSuggestion.buildSearchSuggest(value),
            size: Search.config.word_suggestion_size
        };
        var searchObject = {
            index: Search.config.VAE_word_suggestion_index,
            type: Search.config.VAE_word_suggestion_type,
            body: query
        };
        return Search.client.search(searchObject);
    },
    updateWeightSuggest: function (id, weight)
    {
        var updateObject = {
            index: Search.config.VAE_word_suggestion_index,
            type: Search.config.VAE_word_suggestion_type,
            id: id,
            body: wordSuggestion.buildUpdateWeightSuggest(weight)
        };
        return Search.client.update(updateObject);
    },
    setAlias: function (aliasName, indexName, onSuccess, onError) {
        // Get all alias by name from ES, and delete them
        Search.client.indices.getAlias({name: aliasName}, function (err, response, status) {
            if (status == 200) {
                var indexs = [];
                for (var index in response) {
                    indexs.push(index);
                }

                Search.client.indices.deleteAlias({index: indexs, name: aliasName}, function (err, response, status) {
                    // Check index is exist by name, if exist add alias for the index.
                    if (status == 200) {
                        Search.client.indices.exists({index: indexName}, function (err, response, status) {
                            if (status == 200) {
                                Search.client.indices.putAlias({index: indexName, name: aliasName}, function (err, response, status) {
                                    if (status == 200) {
                                        onSuccess("OK");
                                    } else {
                                        onError({message: "Could not put alias: " + aliasName + " to index: " + indexName});
                                    }
                                });
                            } else {
                                onError({message: "Index " + indexName + " is not exist!."});
                            }
                        });
                    } else {
                        onError({message: "Could not delete alias: " + aliasName + " in indexs: " + indexs});
                    }
                });
            } else {
                // Check index is exist by name, if exist add alias for the index.
                Search.client.indices.exists({index: indexName}, function (err, response, status) {
                    if (status == 200) {
                        Search.client.indices.putAlias({index: indexName, name: aliasName}, function (err, response, status) {
                            if (status == 200) {
                                onSuccess("OK");
                            } else {
                                onError({message: "Could not put alias!"});
                            }
                        });
                    } else {
                        onError({message: "Index " + indexName + " is not exist!"});
                    }
                });
            }
        });
    },
    setConfig: function (config) {
        Search.config = config;
    },
    log: function () {
        return logger;
    },
    searchMatch100Percent: function(params) {
        var query = {};
        query = {
            "query" : {
                "bool": {
                   "must": [
                        {
                            "match": {"plz": params.plz }
                        },
                        {
                            "match": { "ort": params.ort.toLowerCase() }
                        },
                        {
                            "match": { "strasse": params.strasse.toLowerCase() }
                        },
                        {
                            "match": { "hausnr": params.hausNummer }
                        }
                   ]
                }
            },"size": 1000
        }

        //query.size = Search.config.searchSize;
        var searchParamObj = {
            index: Search.config.VAE_index,
            type: Search.config.VAE_type,
            body: query
        };

        console.log("query: " + JSON.stringify(searchParamObj));

        logger.log({
            query: searchParamObj,
            objSearch: params
        });

        return Search.client.search(searchParamObj);
    }
}

Search.initialize();