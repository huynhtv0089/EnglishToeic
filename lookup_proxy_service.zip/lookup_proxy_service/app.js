var fs = require('fs');
module.exports = {
  foo: function () {
    fs.readFile('./city.json', 'utf8', function (err,data) {
	  if (err) {
	    return console.log(err);
	  }
	  var config = JSON.parse(data);
	  console.log(config.name);
	});
  },
  bar: function () {
    // whatever
  }
};

var zemba = function () {
}