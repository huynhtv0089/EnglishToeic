var elasticsearch = require('elasticsearch');
var common = require('../common');
if(typeof SearchVGDL == 'undefined') {
	var SearchVGDL = {};
}

SearchVGDL.initialize = function() {
	this.PICKPOST = 'PICKPOST';
	this.POSTFASH = 'POSTFACH';
		this.MYPOST24 = 'MYPOST24';
	this.POSTLAGERND = 'POSTLAGERND';
	this.FIELD_DL_ZUSATZ_SEARCH = 'asdp_type';
	this.FIELD_PLZ = "plz";
	this.FIELD_FIRST4_PLZ = 'first_4_plz';
	this.FIELD_LAST2_PLZ = 'last_2_plz';
	this.FIELD_FIRST_ORT_NUMBER = 'first_number_ort';
	this.FIELD_ORT_SEARCH = 'ort_search';//Indexed, for a like search => zubofi special search
	this.FIELD_ORT_SEARCH_NOT_ANALYZED = 'ort_search_not_analyzed';
	this.FIELD_ORT_SYNONYM = "ort_synonyms";
	this.FIELD_ORT_TRANSLATE_ACII = "ort_translate_accii";
	this.FIELD_ORT_SEARCHING = "ort_search_rtrim";
	this.FIELD_STRASSE_SEARCH = "strasse_search";
	this.FIELD_STRASSE_SEARCH_NOT_ANALYZED = "strasse_search_not_analyzed";
	this.FIELD_ORT = "ort";
	this.FIELD_HAUSNR = "hausnr";
	this.FIELD_HAUSNRZUSATS = "hausnrzusatz_search_not_analyzed";
	this.NULL_VALUE = "_null_";
	this.supportedTypes = [1,2,3];
    this.FIELD_NAME2 = "name2";
    this.NAME2_VALUE = "Poststellen und Verkauf";
};

SearchVGDL.getSearchParamByType = function(type) {
	var params = {
		bool : {
			must : []
		}
	};
	//Check type of search
	var termpickpost = common.buildMatchQuery(this.FIELD_DL_ZUSATZ_SEARCH, this.PICKPOST);
	var termpostfash = common.buildMatchQuery(this.FIELD_DL_ZUSATZ_SEARCH, this.POSTFASH);
		var termmypost24 = common.buildMatchQuery(this.FIELD_DL_ZUSATZ_SEARCH, this.MYPOST24);
	var termPostlagernd = common.buildMatchQuery(this.FIELD_DL_ZUSATZ_SEARCH, this.POSTLAGERND);
	if(type === 1) {
		params.bool.must.push(termpostfash);
	} else if(type === 2) {
		params.bool.must.push(termpickpost);
	}
        else if(type === 3) {
		params.bool.must.push(termmypost24);
	} else if (type === 4) {
		params.bool.must.push(termPostlagernd);
	}
	else {
		params.bool.must_not = [termpostfash, termpickpost,termmypost24];
	}
	
	return params;
};

SearchVGDL.getSearchPickPostSpecialSameCheckParamByType = function(type) {
	var params = {
		bool : {
			must : []
		}
	};
	//Check type of search
	var termpickpost = common.buildMatchQuery(this.FIELD_DL_ZUSATZ_SEARCH, this.PICKPOST);
	var termpostfash = common.buildMatchQuery(this.FIELD_DL_ZUSATZ_SEARCH, this.POSTFASH);
	if(type % 2 == 1) {
		params.bool.must.push(termpostfash);
	} else {
		params.bool.must.push(termpickpost);
	}
	
	return params;
};

/*
* Make search params for the first case.
* Main Logic: search match for first 4 number of plz and ort
* @param Object rawParam
* @return Object
*/
SearchVGDL.makeSearchVGDLFirstTryParams = function(rawParams) {
	var params = {};
    if(rawParams != undefined) {
    	var strOrt = "";
    	var strPlz = "";
    	var strStrasse = "";
    	var strStrasseTmp = "";
    	var strType = "";
    	
    	if(rawParams.ort != undefined) {
    		strOrt = common.normalizeOrtForSpecialZubofiSearch(rawParams.ort);
    		strOrt = strOrt.trim();
    		strOrt = strOrt.toLowerCase();
    	}
    	if(rawParams.plz != undefined) {
    		strPlz = rawParams.plz.substring(0, 4);
    	} 

    	//Check type of search
    	params = this.getSearchParamByType(rawParams.type);
    	//Add search for plz and ort if any
    	if(strPlz.length > 0) {
    		params.bool.must.push(common.buildMatchQuery(this.FIELD_FIRST4_PLZ, strPlz));
    	}
    	if(strOrt.length > 0) {
    		params.bool.must.push(common.buildMatchQuery(this.FIELD_ORT_SEARCH_NOT_ANALYZED, strOrt));
    	}
	}
    
	return params;
};

SearchVGDL.makeSearchVGDLSecondTryParams = function(rawParams) {
	var params = {};
	if(rawParams != undefined) {
		//Check type of search
    	params = this.getSearchParamByType(rawParams.type);
    	
    	//Add more search logic
		var strOrt = "";
    	var strPlz = "";
    	var strOrtBeforeNumber = "";
    	if(rawParams.ort != undefined) {
    		strOrt = common.normalizeOrtForSpecialZubofiSearch(rawParams.ort);
    		strOrt = strOrt.toLowerCase();
    		
    		strOrt = strOrt + " ";
    		strOrtBeforeNumber = strOrt.split(/\s\d+\s/)[0];
    	}
    	if(rawParams.plz != undefined && rawParams.plz.length > 4) {
    		strPlz = rawParams.plz.substring(0, 4);
    	} else {
            strPlz = rawParams.plz + '';
        }
    	
    	//Case 1: 4 frist number of plz are the same and 2 last digits is 00
    	params.bool.must.push(common.buildMatchQuery(this.FIELD_FIRST4_PLZ, strPlz));
    	//Case 2: 
    	var subBoolQuery = {
    		bool : {
    			should : [],
    			minimum_number_should_match : 1
    		}	
    	};
    	subBoolQuery.bool.should.push(common.buildMatchQuery(this.FIELD_LAST2_PLZ, '00'));
    	var firstOrtNumber = ""; 
    	var removeWrongPhrase = strOrt.replace(/[0-9]+[a-z%&*()_+":,./;'']+|[a-z%&*()_+":,./;'']+[0-9]+/gi, "");
    	var numbers = removeWrongPhrase.match(/^\d+|\d+\b|\d+(?=\w)/g);
    	if(numbers != null && numbers.length > 0) {
    		firstOrtNumber = numbers[0];
    	}
    	subBoolQuery.bool.should.push(common.buildMatchQuery(this.FIELD_FIRST_ORT_NUMBER, firstOrtNumber));
    	params.bool.must.push(subBoolQuery);
    	
    	//Case synonyms
    	strOrtBeforeNumber = strOrtBeforeNumber.trim();
    	var subBoolQuery2 = {
    		bool : {
    			should : [
    			],
    			minimum_number_should_match : 1
    		}	
        };
    	subBoolQuery2.bool.should.push(common.buildPhrasePrefixQuery(this.FIELD_ORT_SYNONYM, strOrtBeforeNumber));
    	subBoolQuery2.bool.should.push(common.buildPhrasePrefixQuery(this.FIELD_ORT_SEARCH_NOT_ANALYZED, strOrtBeforeNumber));	
    	params.bool.must.push(subBoolQuery2);
	}
	
	return params;
}

SearchVGDL.makeSearchVGDLSorting = function() {
	var sortParam = {};
	sortParam[this.FIELD_PLZ] = {
			order : "asc"
	};
	return [sortParam];
}

/**
 * Request id #10890(update 30/09/2016): Search pickpost by plz, ort, strasse, hausnr(without hausnr_zusat)
 */
SearchVGDL.makeSearchPickpostOrMypost24 = function(rawParams) {
    var params = {};
    if(rawParams !== undefined) {
    	params = this.getSearchParamByType(rawParams.type);
    	
		var strOrt = "";
    	var strPlz = "";
    	var strStrasse = "";
        var strHausnr = "";
        
    	if(common.checkValid(rawParams.plz)) {
    		strPlz = rawParams.plz.substring(0, 4);
            params.bool.must.push(common.buildMatchQuery(this.FIELD_FIRST4_PLZ, strPlz));
    	}
        
    	if(common.checkValid(rawParams.ort)) {
            strOrt = common.normalizeOrtForSpecialZubofiSearch(rawParams.ort);
            params.bool.must.push(common.buildMatchQuery(this.FIELD_ORT_SEARCH_NOT_ANALYZED, strOrt));
    	}
        
        if(common.checkValid(rawParams.strasse)) {
    		strStrasse = common.normalizeForMatch(rawParams.strasse);
            params.bool.must.push(common.buildMatchQuery(this.FIELD_STRASSE_SEARCH_NOT_ANALYZED, strStrasse));
    	}
        
        if(rawParams.hausNummer !== undefined) {
            strHausnr = common.normalize(rawParams.hausNummer);
            if(common.checkValid(strHausnr)) {
                params.bool.must.push(common.buildMatchQuery(this.FIELD_HAUSNR, strHausnr));    
            } else {
                params.bool.must.push(common.buildMatchQuery(this.FIELD_HAUSNR, this.NULL_VALUE));
            }
        }
	}
    
    return params;
}

SearchVGDL.makeSearchVGDLPickpostSpecialSameCheckParam = function(rawParams) {
	var params = {};
	if(rawParams != undefined) {
		//Check type of search: Pickpost or Postfach
    	params = this.getSearchPickPostSpecialSameCheckParamByType(rawParams.type);
    	
    	//Add more search logic
		var strOrt = "";
    	var strPlz = "";
    	var strStrasseTmp = "_null_";
    	if(rawParams.ort != undefined) {
    		strOrt = rawParams.ort;
    		if(rawParams.type < 3) {
    			if(strOrt.lastIndexOf(' ') != -1) {
    				strOrt = strOrt.substring(0, strOrt.lastIndexOf(' '));
    			}
    		}
    		strOrt = strOrt.replace("\\", "");
    		strOrt = common.normalizeForMatch(strOrt);
    	}
    	if(rawParams.plz != undefined) {
    		strPlz = rawParams.plz.substring(0, 4);
    	}
    	if(rawParams.strasse) {
    		strStrasseTmp = common.normalizeForMatch(rawParams.strasse);
    	}
    	
    	params.bool.must.push(common.buildMatchQuery(this.FIELD_FIRST4_PLZ, strPlz));
    	if(rawParams.type == 5) {
    		params.bool.must.push(common.buildMatchQuery(this.FIELD_ORT_TRANSLATE_ACII, strOrt));
    	} else if(parseInt((rawParams.type - 1)/2) == 0) {
    		params.bool.must.push(common.buildMatchQuery(this.FIELD_ORT_SEARCHING, strOrt));
    	} else {
    		params.bool.must.push(common.buildPhrasePrefixQuery(this.FIELD_ORT_SEARCHING, strOrt + " "));
    	}
    	
    	params.bool.must.push(common.buildMatchQuery(this.FIELD_STRASSE_SEARCH_NOT_ANALYZED, strStrasseTmp));
	}
    
	return params;
}

SearchVGDL.makeSearchVGDLPickPostSpecialSameCheckSorting = function() {
	var sort = [];
	var firstCond = {
		_script: {
	        script: "_source." + this.FIELD_ORT + ".length()",
	        type: "number",
	        order: "desc"
	      }
	}
	var secondCond = common.buildSortingQuery(this.FIELD_ORT_SEARCH, 'asc');
	
	sort.push(firstCond, secondCond);
	
	return sort;
}

SearchVGDL.makeSearchVGDLPickpostSpecialCheckParam = function(rawParams) {
	var params = {};
    
	if(rawParams != undefined) {
		//Check type of search: Pickpost or Postfach
    	params.bool = {
    		must : []
    	}
    	
    	//Add more search logic
		var strOrt = "";
    	var strPlz = "";
    	var strStrasseTmp = "_null_";
    	var strHausnr = "_null_";
    	var strHausnrzusatz = "_null_";
    	if(rawParams.ort != undefined) {
            strOrt = common.normalizeForMatch(rawParams.ort);
    	}
    	if(rawParams.plz != undefined) {
    		strPlz = rawParams.plz.substring(0, 4);
    	}
    	if(rawParams.strasse) {
    		strStrasseTmp = common.normalizeForMatch(rawParams.strasse);
    	}
    	if(rawParams.hausNummer) {
    		strHausnr = rawParams.hausNummer; 
    	}
    	if(rawParams.hausNummera) {
    		strHausnrzusatz = rawParams.hausNummera.toLowerCase();
    	}
    	params.bool.must.push(common.buildMatchQuery(this.FIELD_DL_ZUSATZ_SEARCH, this.PICKPOST));
    	params.bool.must.push(common.buildMatchQuery(this.FIELD_FIRST4_PLZ, strPlz));
    	params.bool.must.push(common.buildMatchQuery(this.FIELD_ORT_TRANSLATE_ACII, strOrt));
    	params.bool.must.push(common.buildMatchQuery(this.FIELD_STRASSE_SEARCH_NOT_ANALYZED, strStrasseTmp));
        params.bool.must.push(common.buildMatchQuery(this.FIELD_HAUSNR, strHausnr));
    	params.bool.must.push(common.buildMatchQuery(this.FIELD_HAUSNRZUSATS, strHausnrzusatz));
	}
    
	return params;
}

SearchVGDL.makeSearchASDPPostfachWithOrt = function(rawParams) {
    var params = {};
    params.bool = {
        must : []
    };
    
    var strPlz = "";
    var strOrt = "";
    
    params.bool.must.push(common.buildMatchQuery(this.FIELD_DL_ZUSATZ_SEARCH, this.POSTFASH));
    
    params.bool.must.push(common.buildMatchQuery(this.FIELD_NAME2, this.NAME2_VALUE));
    
    if(common.checkValid(rawParams.plz)) {
        strPlz = rawParams.plz;
        params.bool.must.push(common.buildMatchQuery(this.FIELD_FIRST4_PLZ, strPlz));
    } else {
        params.bool.must.push(common.buildMatchQuery(this.FIELD_FIRST4_PLZ, this.NULL_VALUE));
    }
    
    if(rawParams.ort != undefined) {
        strOrt = rawParams.ort;
        strOrt = common.normalizeOrtForSpecialZubofiSearch(strOrt);
        if(common.checkValid(strOrt)) {
            params.bool.must.push(common.buildMatchQuery(this.FIELD_ORT_SEARCH_NOT_ANALYZED, strOrt));
        } else {
            params.bool.must.push(common.buildMatchQuery(this.FIELD_ORT_SEARCH_NOT_ANALYZED, this.NULL_VALUE));
        }
    }
    
    return params;
}

/** Using both Search Postfach and Postlargend */
SearchVGDL.makeSearchASDPPostfachWithoutOrt = function(rawParams) {
    var params = {};
    params.bool = {
        must : []
    };
    
    var strPlz = "";

    params.bool.must.push(common.buildMatchQuery(this.FIELD_DL_ZUSATZ_SEARCH, this.POSTFASH));

    params.bool.must.push(common.buildMatchQuery(this.FIELD_NAME2, this.NAME2_VALUE));
    
    if(common.checkValid(rawParams.plz)) {
        strPlz = rawParams.plz;
        params.bool.must.push(common.buildMatchQuery(this.FIELD_FIRST4_PLZ, strPlz));
    } else {
        params.bool.must.push(common.buildMatchQuery(this.FIELD_FIRST4_PLZ, this.NULL_VALUE));
    }
    
    return params;
}

/** Search Postlagernd in ASDP */
SearchVGDL.makeSearchASDPPostlagernd = function (params, retryTime) {
	var query = {};
	switch (retryTime) {
		case 1: // Search match 100% value PLZ, ORT
			query = this.makeSearchVGDLFirstTryParams(params);
			query.bool.must.push();
			break;
		case 2: // Search like PLZ, ORT
			query = this.makeSearchVGDLSecondTryParams(params); 
			break;
		case 3: // Search match PLZ
			query = this.makeSearchASDPPostfachWithoutOrt(params);
            var name2Query = query.bool.must[1];
			query.bool.must.splice(1, 1);
			break;
		case 4: // Search match PLZ, Name_2
			query = this.makeSearchASDPPostfachWithoutOrt(params);
			break;
	}
	return query;
}

/*
* make it visible for use when using require operator to include
*/
//Easily debug
module.exports = {
	makeSearchVGDLFirstTryParams : function(searchParam) {
		return SearchVGDL.makeSearchVGDLFirstTryParams(searchParam);
	},
	makeSearchVGDLSecondTryParams : function(searchParam) {
		return SearchVGDL.makeSearchVGDLSecondTryParams(searchParam);
	},
	makeSearchVGDLSorting : function() {
		return SearchVGDL.makeSearchVGDLSorting();
	},
	makeSearchVGDLPickpostSpecialSameCheckParam : function(searchParam) {
		return SearchVGDL.makeSearchVGDLPickpostSpecialSameCheckParam(searchParam);
	},
	makeSearchVGDLPickPostSpecialSameCheckSorting : function() {
		return SearchVGDL.makeSearchVGDLPickPostSpecialSameCheckSorting();
	},
	makeSearchVGDLPickpostSpecialCheckParam: function(searchParam) {
		return SearchVGDL.makeSearchVGDLPickpostSpecialCheckParam(searchParam);
	},
    makeSearchPickpostOrMypost24: function(searchParam) {
        return SearchVGDL.makeSearchPickpostOrMypost24(searchParam);
    },
    makeSearchASDPPostfachWithOrt : function(searchParam) {
        return SearchVGDL.makeSearchASDPPostfachWithOrt(searchParam);
    },
    makeSearchASDPPostfachWithoutOrt : function(searchParam) {
        return SearchVGDL.makeSearchASDPPostfachWithoutOrt(searchParam);
	},
	makeSearchASDPPostlagernd : function (searchParam, retryTime) {
		return SearchVGDL.makeSearchASDPPostlagernd(searchParam, retryTime);
	}
}

SearchVGDL.initialize();