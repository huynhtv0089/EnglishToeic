if (typeof LookupExtra == 'undefined') {
	var LookupExtra = {};
}

var common = require('../common');

LookupExtra.initialize = function() {
	var self = this;
	self.lookup_extra_plz = 'plz_search';
	self.lookup_extra_plz_sorting = 'plz';
	self.lookup_extra_ort = 'ort_search_not_analyzed';
	self.lookup_extra_strasse = 'strasse_search_not_analyzed';
	self.lookup_extra_type = 'type';
};

LookupExtra.makeWildcardSearchParam = function(fieldName, term) {
	if (term.length > 0) {
		term = term.replace(/%/gi, '*').replace(/_/gi, '?');
	}
	term = common.normalize(term) + '*';
	var query = {
		wildcard : {}
	};
	query.wildcard[fieldName] = {
		value : term
	}
	return query;

}

LookupExtra.makeMatchSearchParam = function(fieldName, term) {
	var query = {
		match : {}
	};
	query.match[fieldName] = common.normalize(term);
	return query;

}

LookupExtra.build_LookupExtra_Query = function(lookupExtra) {
	var type = typeof lookupExtra.type == 'undefined' ? 1 : lookupExtra.type;
	var query;
	if (type == 'strasse') {
		query = LookupExtra.build_Strasse_LookupExtra_Query(lookupExtra);
	} else {
		query = LookupExtra.build_Plz_Ort_LookupExtra_Query(lookupExtra);
	}
	return query;
}

LookupExtra.build_Plz_Ort_LookupExtra_Query = function(lookupExtra) {
	var query = {
		query : {
			bool : {}
		}
	};
	var mustQueryList = [];
	var plz = lookupExtra.plz;
	if (common.checkValid(plz)) {
		mustQueryList.push(LookupExtra.makeWildcardSearchParam(LookupExtra.lookup_extra_plz, plz));
	}

	var ort = lookupExtra.ort;
	if (common.checkValid(ort)) {
		mustQueryList.push(LookupExtra.makeWildcardSearchParam(LookupExtra.lookup_extra_ort, ort));
	}

	mustQueryList.push(common.buildMatchQuery(LookupExtra.lookup_extra_type, lookupExtra.type));

	if (typeof mustQueryList != 'undefined' && mustQueryList.length > 0) {
		query.query.bool.must = mustQueryList;
	}
	query.sort = [];
	var type = typeof lookupExtra.type == 'undefined' ? 'plz' : lookupExtra.type;
	if (type == 'plz') {
		query.sort.push(common.buildSortingQuery(LookupExtra.lookup_extra_plz_sorting, 'asc'));
		query.sort.push(common.buildSortingQuery(LookupExtra.lookup_extra_ort,'asc'));
	} else {
		query.sort.push(common.buildSortingQuery(LookupExtra.lookup_extra_ort,'asc'));
		query.sort.push(common.buildSortingQuery(LookupExtra.lookup_extra_plz_sorting, 'asc'));
	}
	return query;
}

LookupExtra.build_MatchPlz_PrefixOrt_LookupExtra_Query = function(lookupExtra) {
	var query = {
		query : {
			bool : {}
		}
	};
	var mustQueryList = [];
	var plz = lookupExtra.plz;
	if (common.checkValid(plz)) {
		mustQueryList.push(LookupExtra.makeMatchSearchParam(LookupExtra.lookup_extra_plz, plz));
	}

	var ort = lookupExtra.ort;
	if (common.checkValid(ort)) {
		mustQueryList.push(LookupExtra.makeWildcardSearchParam(LookupExtra.lookup_extra_ort, ort));
	}

	mustQueryList.push(common.buildMatchQuery(LookupExtra.lookup_extra_type, lookupExtra.type));

	if (typeof mustQueryList != 'undefined' && mustQueryList.length > 0) {
		query.query.bool.must = mustQueryList;
	}
	
	return query;
}

LookupExtra.build_Match_PlzAndOrt_LookupExtra_Query = function(lookupExtra) {
	var query = {
		query : {
			bool : {}
		}
	};
	var mustQueryList = [];
	var plz = lookupExtra.plz;
	if (common.checkValid(plz)) {
		mustQueryList.push(LookupExtra.makeMatchSearchParam(LookupExtra.lookup_extra_plz, plz));
	}

	var ort = lookupExtra.ort;
	if (common.checkValid(ort)) {
		mustQueryList.push(LookupExtra.makeMatchSearchParam(LookupExtra.lookup_extra_ort, ort));
	}

	mustQueryList.push(common.buildMatchQuery(LookupExtra.lookup_extra_type, lookupExtra.type));

	if (typeof mustQueryList != 'undefined' && mustQueryList.length > 0) {
		query.query.bool.must = mustQueryList;
	}
	
	return query;
}

LookupExtra.build_Strasse_LookupExtra_Query = function(lookupExtra) {

	var query = {
		query : {
			bool : {}
		}
	};
	var mustQueryList = [];
	var plz = lookupExtra.plz;
	if (common.checkValid(plz)) {
		mustQueryList.push(LookupExtra.makeWildcardSearchParam(LookupExtra.lookup_extra_plz, plz));
	}
	var ort = lookupExtra.ort;
	if (common.checkValid(ort)) {
		mustQueryList.push(LookupExtra.makeWildcardSearchParam(LookupExtra.lookup_extra_ort, ort));
	}
	var strasse = lookupExtra.strasse;
	if (common.checkValid(strasse)) {
		mustQueryList.push(LookupExtra.makeWildcardSearchParam(LookupExtra.lookup_extra_strasse, strasse));
	}

	mustQueryList.push(common.buildMatchQuery(LookupExtra.lookup_extra_type,lookupExtra.type));

	if (typeof mustQueryList != 'undefined' && mustQueryList.length > 0) {
		query.query.bool.must = mustQueryList;
	}
	query.sort = [];
	query.sort.push(common.buildSortingQuery(LookupExtra.lookup_extra_strasse,'asc'));
	query.sort.push(common.buildSortingQuery(LookupExtra.lookup_extra_plz_sorting, 'asc'));

	return query;
}

LookupExtra.build_Plz_LookupExtra_Query = function (plz_6_digits) {
	var query = {
		sort : [],
		query : {
			match: {
				plz: plz_6_digits
			}
		}
	}
	query.sort.push(common.buildSortingQuery(LookupExtra.lookup_extra_ort,'asc'));
	return query;
}

module.exports = {
	build_LookupExtra_Query : function(lookupExtra) {
		return LookupExtra.build_LookupExtra_Query(lookupExtra);
	},
	build_Match_PlzAndOrt_LookupExtra_Query : function(lookupExtra) {
		return LookupExtra.build_Match_PlzAndOrt_LookupExtra_Query(lookupExtra);
	},
	build_MatchPlz_PrefixOrt_LookupExtra_Query : function(lookupExtra) {
		return LookupExtra.build_MatchPlz_PrefixOrt_LookupExtra_Query(lookupExtra);
	}
}

LookupExtra.initialize();