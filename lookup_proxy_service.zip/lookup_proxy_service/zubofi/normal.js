if (typeof Zubofi == 'undefined') {
	var Zubofi = {};
}
var common = require('../common');

Zubofi.initialize = function() {
	this.ort_field = 'ort_search_not_analyzed';
	this.plz_field = 'plz_search';
	this.raw_plz_field = 'plz';
	this.strasse_field = 'strasse_search_not_analyzed';
	this.hausNummer_field = 'hausnr';
	this.hausNummera_field = 'hausnrzusatz_search_not_analyzed';
	this.addressid_field = 'adressid';
	this.hauskey_field = 'hauskey';
	this.NULL_value = '_null_';
};

Zubofi.search_addressId = function(zubofiAddr) {

	var results = {
		mustQueryList : []
	};

	var plz = zubofiAddr.plz;
	var ort = common.normalizeForMatch(zubofiAddr.ort);
	var strasse = common.normalizeForMatch(zubofiAddr.strasse);
	var hausNummer = zubofiAddr.hausNummer;
	var hausNummera = zubofiAddr.hausNummera;

	if (common.checkValid(plz)) {
		var mustItem = common.buildMatchQuery(Zubofi.plz_field, plz);
		results.mustQueryList.push(mustItem);
	}
	if (common.checkValid(ort)) {
		var mustItem = common.buildMatchQuery(Zubofi.ort_field, ort, null, null, 'AND');
		results.mustQueryList.push(mustItem);
	}
	if (common.checkValid(strasse)) {
		var mustItem = common.buildMatchQuery(Zubofi.strasse_field, strasse, null, null, 'AND');
		results.mustQueryList.push(mustItem);
	}
	if (common.checkValid(hausNummer)) {
		var mustItem = common.buildMatchQuery(Zubofi.hausNummer_field, hausNummer);
		results.mustQueryList.push(mustItem);
		if (common.checkValid(hausNummera)) {
			var mustItem = common.buildMatchQuery(Zubofi.hausNummera_field, hausNummera.toLowerCase());
			results.mustQueryList.push(mustItem);
		} else {
			var mustItem = common.buildMatchQuery(Zubofi.hausNummera_field, Zubofi.NULL_value);
			results.mustQueryList.push(mustItem);
		}
	}
	var query = common.buildBoolQuery(results);
	query.sort = common.buildSortingQuery(this.raw_plz_field,'asc');
	return query;
}

Zubofi.search_hauskey = function(zubofiAddr) {
	var results = {
		mustQueryList : []
	};

	var plz = zubofiAddr.plz;
        var ort = common.normalizeForMatch(zubofiAddr.ort);
        var strasse = common.normalizeForMatch(zubofiAddr.strasse);
	var hausNummer = zubofiAddr.hausNummer;
	var hausNummera = zubofiAddr.hausNummera;

	if (common.checkValid(plz)) {
		var mustItem = common.buildMatchQuery(Zubofi.plz_field, plz);
		results.mustQueryList.push(mustItem);
	}
	if (common.checkValid(ort)) {
		var mustItem = common.buildPhrasePrefixQuery(Zubofi.ort_field, ort,
				null, null, 'AND');
		results.mustQueryList.push(mustItem);
	}
	if (common.checkValid(strasse)) {
		var mustItem = common.buildMatchQuery(Zubofi.strasse_field, strasse,
				null, null, 'AND');
		results.mustQueryList.push(mustItem);
	}
	if (!common.checkValid(hausNummer)) {
		var mustItem = common.buildMatchQuery(Zubofi.hausNummer_field,
				Zubofi.NULL_value);
		results.mustQueryList.push(mustItem);
	} else {
		var mustItem = common.buildMatchQuery(Zubofi.hausNummer_field,
				hausNummer);
		results.mustQueryList.push(mustItem);
	}
	if (common.checkValid(hausNummera)) {
		var mustItem = common.buildMatchQuery(Zubofi.hausNummera_field,
				hausNummera.toLowerCase());
		results.mustQueryList.push(mustItem);
	} else {
		var mustItem = common.buildMatchQuery(Zubofi.hausNummera_field,
				Zubofi.NULL_value);
		results.mustQueryList.push(mustItem);
	}
	var query = common.buildBoolQuery(results);
	query.sort = common.buildSortingQuery(this.raw_plz_field,'asc');
	return query;
}

Zubofi.search_street_number_by_parcel_hauskey = function(addressid) {
	var results = {
		mustQueryList : []
	};
	var mustItem = common.buildMatchQuery(Zubofi.hauskey_field, addressid);
	results.mustQueryList.push(mustItem);
	return common.buildBoolQuery(results);
}

/*
 * make it visible for use when using require operator to include
 */
module.exports = {
	search_zubofi_addrid : function(zubofiAddr) {
		return Zubofi.search_addressId(zubofiAddr);
	},
	search_zubofi_hauskey : function(zubofiAddr) {
		return Zubofi.search_hauskey(zubofiAddr);
	},
	find_street_number_by_parcel_hauskey : function(addressid) {
		return Zubofi.search_street_number_by_parcel_hauskey(addressid);
	}
}

Zubofi.initialize();