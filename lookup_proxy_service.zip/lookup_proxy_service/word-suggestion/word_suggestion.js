var common = require('../common');
if (typeof WordSuggestion == 'undefined') {
    var WordSuggestion = {};
}

WordSuggestion.initialize = function () {
    this.FIELD_SUGGEST = "suggest";
    this.FIELD_SUGGEST_WEIGHT = "weight";

};

WordSuggestion.suggest = function (value, size)
{
    return common.buildSuggestQuery(WordSuggestion.FIELD_SUGGEST, common.normalize(value), size);
}

/*
 * make it visible for use when using require operator to include
 */
module.exports = {
    buildSuggest: function (value, size)
    {
        return WordSuggestion.suggest(value, size);
    },
    buildSearchSuggest: function (value)
    {
        return common.buildSearchSuggestQuery(value);
    }
    ,
    buildUpdateWeightSuggest: function (weight)
    {
        return common.buildUpdateWeightSuggestQuery(WordSuggestion.FIELD_SUGGEST_WEIGHT, weight);
    }
}

WordSuggestion.initialize();