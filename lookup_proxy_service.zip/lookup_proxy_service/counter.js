var elasticsearch = require('elasticsearch');
var fs = require('fs');
var ocrStrasse = require('./ocr/strasse');
var ocrOrt = require('./ocr/ort');
var ocrPlz = require('./ocr/plz');
var ocrName = require('./ocr/name');
var common = require('./common');

var graylog2 = require("graylog2");
var logger = null;

if (typeof Counter == 'undefined') {
	var Counter = {};
}

Counter.initialize = function() {
	var self = this;
	if (self.config == undefined) {
		var data = fs.readFileSync('./config/properties.json', 'utf8');
		self.config = JSON.parse(data);
	}

	self.client = elasticsearch.Client({
		hosts : self.config.ES_hosts,
		log : [ {
			type : 'file',
			level : 'info', // change these options
			path : 'logs/elasticsearch.log'
		} ]
	});

	// Init graylog2 for logger
	logger = new graylog2.graylog({
		servers : [ {
			host : self.config.graylog.host,
			port : self.config.graylog.port
		} ]
	});
};

module.exports = {
	countOCRStrasse : function(strasse) {
		var squery = ocrStrasse.buildCheckStrasseExsistenceQuery(strasse);
		var query = {};
		query.query = squery;
		var searchParamObj = {
			index : Counter.config.index_ocr,
			type : Counter.config.index_ocr_strasse,
			body : query
		};

		return Counter.client.count(searchParamObj);
	},
	countOCROrt : function(ort) {
		var squery = ocrOrt.buildCheckOrtExsistenceQuery(ort);
		var query = {};
		query.query = squery;
		var searchParamObj = {
			index : Counter.config.index_ocr,
			type : Counter.config.index_ocr_ort,
			body : query
		};

		return Counter.client.count(searchParamObj);
	},
	countOCRPlz : function(plz) {
		var squery = ocrPlz.buildCheckPlzExsistenceQuery(plz);
		var query = {};
		query.query = squery;
		var searchParamObj = {
			index : Counter.config.index_ocr,
			type : Counter.config.index_ocr_plz,
			body : query
		};
		return Counter.client.count(searchParamObj);
	},
	countOCRName : function(name) {
		var squery = ocrName.buildCheckNameExsistenceQuery(name);
		var query = {};
		query.query = squery;
		var searchParamObj = {
			index : Counter.config.index_ocr,
			type : Counter.config.index_ocr_name,
			body : query
		};
		return Counter.client.count(searchParamObj);
	},
	countFirmaSign : function(sign) {
		var query = {
				query :{
					match_all:{}
				}
		};
		var searchParamObj = {
			index : Counter.config.index_ocr,
			type : Counter.config.index_ocr_firmasign,
			body : query
		};
		if (sign != null && (typeof sign != 'undefined')
				&& sign.toString().trim().length > 0) {
			// TODO -- This count in case value of sign is valid 
		}
		return Counter.client.count(searchParamObj);
	},
	setConfig : function(config) {
		Counter.config = config;
	}
}

Counter.initialize();