var elasticsearch = require('elasticsearch');
var common = require('../common');
if (typeof Suggestion == 'undefined') {
	var Suggestion = {};
}

Suggestion.initialize = function() {
	this.FIELD_PERS_09_NAME = "pers_09_name";
	this.FIELD_QUANTITY = "quantity";
	this.FIELD_PERS_09_NAME_SEARCHING = "pers_09_name_searching";
	this.FIELD_NAME = "name";
	this.FIELD_VN_QUANTITY = "vn_quantity";
	this.FIELD_NN_QUANTITY = "nn_quantity";
	this.FIELD_NAME_SEARCHING = "name_searching";
	this.FIELD_ANREDE = "anrede";
	this.FIELD_ANREDE_SEARCHING = "anrede_searching";
	this.FIELD_PERS_10_NAME = "pers_10_vname_name";
	this.FIELD_PERS_10_NAME_SEARCHING = "pers_10_vname_name_searching";
	this.FIELD_VN_PERCENT = "vn_percent";
	this.FIELD_NN_PERCENT = "nn_percent";

	this.INDEX_TYPE_FIRMA = "firma";
	this.INDEX_TYPE_VORNAME = "vorname";
	this.INDEX_TYPE_NACHNAME = "nachname";
	this.INDEX_TYPE_ZUSAT = "zusat";
	this.INDEX_TYPE_ANREDE = "anrede";
	this.INDEX_TYPE_VORNAMEMORE = "vornamemore";// This type is used for
	// suggestion when pressing
	// "..." button or pressing tab
	// key
	this.INDEX_TYPE_NACHNAMEMORE = "nachnamemore";// This type is used for
	// suggestion when pressing
	// "..." button or pressing
	// tab key
	this.INDEX_TYPE_FIRMENAMEMORE = "firmenamemore";// This type is used for
	// suggestion when pressing
	// "..." button or pressing
	// tab key
	this.INDEX_TYPE_NAME = "name";// this index is also used for swapping
	// vor-name and name
};

Suggestion.checkName = function(name, type, percent) {
	var query = {
		bool : {
			must : []
		}
	};
	var field = (type == 1) ?  this.FIELD_NN_PERCENT : this.FIELD_VN_PERCENT;
	var iname = common.normalize(name).replace(new RegExp('[^0-9a-z\']+', 'g'),
			'');
	var queryName = common.buildMatchQuery(this.FIELD_NAME_SEARCHING, iname);
	var percentRange = {};
	percentRange.range = {};
	percentRange.range[field] = {
		gte : percent
	};
	query.bool.must.push(queryName, percentRange);
	return {
		query : query
	};
}

Suggestion.makeWildcardSearchParam = function(fieldName, term) {
	if (term.length > 0) {
		term = term.replace(/%/gi, '*').replace(/_/gi, '?');
	}
	term = common.normalize(term);
	var query = common.buildStandardWildcardQuery(fieldName, term);
	return {
		query : query
	}
}

Suggestion.makeWildcardSearchSorting = function(sorts) {
	var query = [];
	if (sorts != undefined) {
		sorts.forEach(function(sort) {
			query.push(common.buildSortingQuery(sort.fieldName, sort.order));
		});
	}
	return query;
}
/*
 * make it visible for use when using require operator to include
 */
module.exports = {
	makeKdpAutocomplete : function(type, term) {
		var fieldName = "";
		switch (type) {
		case Suggestion.INDEX_TYPE_FIRMA:
		case Suggestion.INDEX_TYPE_NACHNAMEMORE:
		case Suggestion.INDEX_TYPE_FIRMENAMEMORE:
			fieldName = Suggestion.FIELD_PERS_09_NAME_SEARCHING;
			break;
		case Suggestion.INDEX_TYPE_VORNAME:
		case Suggestion.INDEX_TYPE_NACHNAME:
		case Suggestion.INDEX_TYPE_ZUSAT:
			fieldName = Suggestion.FIELD_NAME_SEARCHING;
			break;
		case Suggestion.INDEX_TYPE_ANREDE:
			fieldName = Suggestion.FIELD_ANREDE_SEARCHING;
			break;
		case Suggestion.INDEX_TYPE_VORNAMEMORE:
			fieldName = Suggestion.FIELD_PERS_10_NAME_SEARCHING;
			break;
		}

		return Suggestion.makeWildcardSearchParam(fieldName, term);
	},
	makeKdpAutocompleteSorting : function(type) {
		var sorts = [];
		switch (type) {
		case Suggestion.INDEX_TYPE_FIRMA:
			sorts.push({
				fieldName : Suggestion.FIELD_PERS_09_NAME_SEARCHING,
				order : 'asc'
			}, {
				fieldName : Suggestion.FIELD_QUANTITY,
				order : 'asc'
			});
			break;
		case Suggestion.INDEX_TYPE_VORNAME:
			sorts.push({
				fieldName : Suggestion.FIELD_NAME_SEARCHING,
				order : 'asc'
			}, {
				fieldName : Suggestion.FIELD_VN_QUANTITY,
				order : 'asc'
			});
			break;
		case Suggestion.INDEX_TYPE_NACHNAME:
			sorts.push({
				fieldName : Suggestion.FIELD_NAME_SEARCHING,
				order : 'asc'
			}, {
				fieldName : Suggestion.FIELD_NN_QUANTITY,
				order : 'asc'
			});
			break;
		case Suggestion.INDEX_TYPE_ZUSAT:
			sorts.push({
				fieldName : Suggestion.FIELD_NAME_SEARCHING,
				order : 'asc'
			});
			break;
		case Suggestion.INDEX_TYPE_ANREDE:
			sorts.push({
				fieldName : Suggestion.FIELD_ANREDE_SEARCHING,
				order : 'asc'
			});
			break;
		case Suggestion.INDEX_TYPE_VORNAMEMORE:
			sorts.push({
				fieldName : Suggestion.FIELD_PERS_10_NAME_SEARCHING,
				order : 'asc'
			});
			break;
		case Suggestion.INDEX_TYPE_NACHNAMEMORE:
		case Suggestion.INDEX_TYPE_FIRMENAMEMORE:
			sorts.push({
				fieldName : Suggestion.FIELD_PERS_09_NAME_SEARCHING,
				order : 'asc'
			});
			break;
		}

		return Suggestion.makeWildcardSearchSorting(sorts);
	},	
	checkName : function(name, type, percent) {
		return Suggestion.checkName(name, type, percent);
	},
	getFIRMA_TYPE : function() {
		return Suggestion.INDEX_TYPE_FIRMA;
	},
	getVORNAME_TYPE : function() {
		return Suggestion.INDEX_TYPE_VORNAME;
	},
	getNACHNAME_TYPE : function() {
		return Suggestion.INDEX_TYPE_NACHNAME;
	},
	getZUSAT_TYPE : function() {
		return Suggestion.INDEX_TYPE_ZUSAT;
	},
	getANREDE_TYPE : function() {
		return Suggestion.INDEX_TYPE_ANREDE;
	},
	getVORNAMEMORE_TYPE : function() {
		return Suggestion.INDEX_TYPE_VORNAMEMORE;
	},
	getNACHNAMEMORE_TYPE : function() {
		return Suggestion.INDEX_TYPE_NACHNAMEMORE;
	},
	getFIRMENAMEMORE_TYPE : function() {
		return Suggestion.INDEX_TYPE_FIRMENAMEMORE;
	},
	getINDEX_TYPE_NAME : function() {
		return Suggestion.INDEX_TYPE_NAME;
	}
}

Suggestion.initialize();