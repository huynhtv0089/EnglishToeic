if (typeof Lookup == 'undefined') {
    var Lookup = {};
}

var common = require('../common');

// TODO-Recheck postfach, pickpost, mypost24
Lookup.initialize = function () {
    var self = this;
    self.lookup_field = 'name_search,name_galias,name_alias,vorname_search,vorname_galias,vorname_alias';
    self.vname_synonym_field = 'vorname_search,vorname_alias';
    self.name_synonym_field = 'name_search,name_alias';
    self.ort_field = 'ort_search';
    self.plz_field = 'plz_search';
    self.stra_field = 'strasse_search';
    self.pf_field = 'level';
    self.hausnr_field = 'hausnr';
    self.hausnr_a_field = 'hausnrzusatz';
    self.kundennumber = 'kundennumber';
    self.kdpid_field = 'kdp_id';
    self.vname_field = 'vorname_search_not_analyzed';
    self.name_field = 'name_search_not_analyzed';
    self.pf_level = '3';
    self.null_value = '_null_';
    self.hauskey = 'hauskey';
    self.mypost24_keywords = ['my post 24', 'mypost24'];
    self.name_analyzed = 'name_search';

    self.type_field = 'type';
    self.anrede_field = 'geschlecht';
    self.adr_id_field = 'adr_id';
    self.aadr_id_field = 'aadr_id';
};

Lookup.buildShouldQuery = function (objectSearch) {
    var results = {
        shouldQueryList: [],
    };
    var mypost24 = objectSearch.mypost24;
    var pickpost = objectSearch.pickpost;

    var is_pf = false;

    if (common.checkValid(mypost24) || common.checkValid(pickpost)) {
        /**
         * build should query for mypost24 and pickpost
         * if myspost24 and pickpost are valid, mypost24 will be used.
         */
        var kundennumber_value = '';

        if (common.checkValid(mypost24)) {
            kundennumber_value = mypost24;
        } else {
            if (common.checkValid(pickpost)) {
                kundennumber_value = pickpost;
            }
        }

        var queryItem = common.buildQueryStringQuery(Lookup.kundennumber, kundennumber_value);
        results.shouldQueryList.push(queryItem);
    } else {
        /**
         * build should query for plz/ort/strasse/hausnr/postfach
         */
        var ort = common.stripAccents(objectSearch.ort);
        var plz = objectSearch.plz;
        var stra = common.stripAccents(objectSearch.strasse);
        var pf = objectSearch.pf;
        var fullHausnr = objectSearch.hausNummer;
        if (common.checkValid(ort)) {
            /**
             * build query for ort
             */
            var shouldItem = common.buildMatchQuery(Lookup.ort_field, ort);
            results.shouldQueryList.push(shouldItem);
        }
        if (common.checkValid(plz)) {
            /**
             * build query for plz
             */
            var shouldItem = common.buildMatchQuery(Lookup.plz_field, plz);
            results.shouldQueryList.push(shouldItem);
        }
        if (common.checkValid(pf)) {
            is_pf = true;
        }
        /**
         * build query for hausnr and hausnr_a
         */
        var isSpecial = Lookup.buildHausnrQuery(results.shouldQueryList, fullHausnr, is_pf);
        results.isSpecial = isSpecial;
        /* if (common.checkValid(fullHausnr) && is_pf == false) {
            var hausnr = fullHausnr.match(/(^[0-9.]+)/gi);
            hausnr = hausnr ? hausnr : "";
            var hausnr_a = fullHausnr.replace(/^([0-9.]+)/gi, '');
            hausnr_a = hausnr_a ? hausnr_a : "";
            if (hausnr.length > 0) {
                hausnr = hausnr[0];
                var shouldItem = common.buildMatchQuery(Lookup.hausnr_field, hausnr);
                results.shouldQueryList.push(shouldItem);
            }
            if (hausnr_a.length > 0) {
                hausnr_a = hausnr_a.replace(/(\+|-|&&|=|\|\||>|<|!|\(|\)|{|}|\[|\]|\^|\"|~|\*|\?|:|\\|\/)/g, '\\$&');
                var shouldItem = common.buildMatchQuery(Lookup.hausnr_a_field, hausnr_a);
                results.shouldQueryList.push(shouldItem);
            }
            results.isSpecial = (hausnr.length > 0 && hausnr_a.length > 0);
        } */
    }
    return results;
}

Lookup.buildHausnrQuery = function (query, fullHausnr, is_pf, isMatchDefaultField) {
    if (common.checkValid(fullHausnr) && is_pf == false) {
        var hausnr = fullHausnr.match(/(^[0-9.]+)/gi);
        hausnr = hausnr ? hausnr : "";
        var hausnr_a = fullHausnr.replace(/^([0-9.]+)/gi, '');
        hausnr_a = hausnr_a ? hausnr_a : "";
        if (hausnr.length > 0) {
            hausnr = hausnr[0];
            if (isMatchDefaultField) {
                var shouldItem = common.buildMatchQuery(Lookup.hausnr_field, hausnr, undefined, undefined, undefined, isMatchDefaultField); 
            } else {
                var shouldItem = common.buildMatchQuery(Lookup.hausnr_field, hausnr);
            }
            query.push(shouldItem);
        }
        if (hausnr_a.length > 0) {
            hausnr_a = hausnr_a.replace(/(\+|-|&&|=|\|\||>|<|!|\(|\)|{|}|\[|\]|\^|\"|~|\*|\?|:|\\|\/)/g, '\\$&');
            if (isMatchDefaultField) {
                var shouldItem = common.buildMatchQuery(Lookup.hausnr_a_field, hausnr_a, undefined, undefined, undefined, isMatchDefaultField);
            } else {
                var shouldItem = common.buildMatchQuery(Lookup.hausnr_a_field, hausnr_a);
            }
            query.push(shouldItem);
        } else if (isMatchDefaultField) {
            var shouldItem = common.buildMatchQuery(Lookup.hausnr_a_field, '_null_', undefined, undefined, undefined, isMatchDefaultField);
            query.push(shouldItem);
        }
        var isSpecial = (hausnr.length > 0 && hausnr_a.length > 0);
        return isSpecial;
    }
    return false;
}

Lookup.buildDefaultQuery = function (objectSearch, fuzziness) {
    var shouldQueryList = [];
    var mustQueryList = [];
    var mustNotQueryList = [];
    var isSpecial = false;
    /**
     * build query for lookup
     */
    var lookup = common.stripAccents(objectSearch.lookup);
    if (common.checkValid(lookup)) {
        var words = lookup.trim().toLowerCase().split(' ');
        if (words.length == 2) {
            if (words[0].trim() == words[1].trim()) {
                var mustItem1 = common.buildWildcard(Lookup.vname_synonym_field.split(','), words[0], fuzziness);
                var mustItem2 = common.buildWildcard(Lookup.name_synonym_field.split(','), words[1], fuzziness);
                mustQueryList.push(mustItem1);
                mustQueryList.push(mustItem2);
            } else {
                var mustItem1 = common.buildWildcard(Lookup.lookup_field.split(','), words[0], fuzziness);
                var mustItem2 = common.buildWildcard(Lookup.lookup_field.split(','), words[1], fuzziness);
                mustQueryList.push(mustItem1);
                mustQueryList.push(mustItem2);
            }

        } else {
            var mustItem = common.buildWildcard(Lookup.lookup_field.split(','), lookup, fuzziness);
            mustQueryList.push(mustItem);
        }
    }

    var stra = common.stripAccents(objectSearch.strasse);

    /**
     * Bug #9602 User can't search kdpid mypost or pickpost when strasse field is got value
     */
    var mypost24 = objectSearch.mypost24;
    var pickpost = objectSearch.pickpost;

    if (common.checkValid(stra) && !common.checkValid(mypost24) && !common.checkValid(pickpost)) {
        /**
         * build must match query for strasse
         */
        var mustItem = common.buildQueryStringQuery(Lookup.stra_field, stra);
        mustQueryList.push(mustItem);
    }

    var pf = objectSearch.pf;

    if (common.checkValid(pf) && !common.checkValid(stra) && !common.checkValid(mypost24) && !common.checkValid(pickpost)) {
       /**
         * Request #10890 (update 30/09/2016)Kdp postfach search in domizil address.
         */
        /** 
         * Generate query for case postfach
         * - Should:
         *  + Match value of plz if plz is exist
         *  + Match value of ort if ort is exist
         * - Must: contains value of lookup field and level equal 3
         */
        /**
         * build should query for postfach
         */
        var results = Lookup.buildShouldQuery(objectSearch);
        var shouldQuery = results.shouldQueryList;
        var size_shouldQuery = shouldQuery.length;

        var msm = size_shouldQuery > 1 ? size_shouldQuery - 1 : size_shouldQuery;
        var queryBool = {
            bool: {
                minimum_should_match: msm
            }
        }
        shouldQueryList = shouldQuery;
        mustNotQueryList.push(common.buildMatchQuery(Lookup.pf_field, Lookup.pf_level));
    } else {
        /**
         * Generate query for kdp_normal, mypost24, pickpost
         * 1. KDP Normal:
         * 	- Should: mini should match = size of match statement - 1
         *   + Match value of plz if plz is exist
         *   + Match value of ort if ort is exist
         *   + Match value of hausnr if hausnr is exist, hausnr_a if hausnr_a is exist
         *  - Must:
         *   + Contains value of lookup field
         *   + Contains value of strasse field
         *  - Must not: level equal 3
         * 2. KDP mypost24:
         * 	- Should: contains value of mypost24 field, minishould match = 0
         *  - Must: contains value of lookup field
         *  - Must not: level = 3, kundennumber is null
         * 3. KDP pickpost:
         * 	- Should: contains value of pickpost field, minishould match = 0
         *  - Must: contains value of lookup field
         *  - Must not: level = 3, kundennumber is null
         */
        /**
         * build must not query for pf in case search kdp_normal, mypost24, pickpost
         */
        mustNotQueryList.push(common.buildMatchQuery(Lookup.pf_field, Lookup.pf_level));
        /**
         * build must not query for kundennumber when lookup mypost24/pickpost
         */
        if (common.checkValid(mypost24) || common.checkValid(pickpost)) {
            mustNotQueryList.push(common.buildMatchQuery(Lookup.kundennumber, Lookup.null_value));
        }
        /**
         * build should query for ort/plz/hausnr/hausnr_a/pickpost/mypost24
         */
        var results = Lookup.buildShouldQuery(objectSearch);
        shouldQueryList = results.shouldQueryList;
        isSpecial = results.isSpecial;
    }
    /**
     * build complete query
     */
    var size_shouldQuery = shouldQueryList.length;
    if (isSpecial) {
        size_shouldQuery = size_shouldQuery - 1;
    }

    /**
     * Bug #9606 KDPID isn't displayed when wrong hausnummer
     */
    if (common.checkValid(stra) && size_shouldQuery == 1 && (!common.checkValid(mypost24) && !common.checkValid(pickpost))) {
        size_shouldQuery = 0;
    }

    var msm = size_shouldQuery > 1 ? size_shouldQuery - 1 : size_shouldQuery;
    var query = {
        query: {
            bool: {
                minimum_should_match: msm
            }
        }
    };

    // assign should query
    if (typeof shouldQueryList != 'undefined' && shouldQueryList.length > 0) {
        query.query.bool.should = shouldQueryList;
    }

    // assign must query
    if (typeof mustQueryList != 'undefined' && mustQueryList.length > 0) {
        query.query.bool.must = mustQueryList;
    }

    // assign must not query
    if (typeof mustNotQueryList != 'undefined' && mustNotQueryList.length > 0) {
        query.query.bool.must_not = mustNotQueryList;
    }

    return query;
}

Lookup.buildMustQuery = function (objectSearch) {
    var query = {
        query : {
            bool : {}
        }
    };
    var mustQueryList = [];
    var mustNotQueryList = [];
    var isMatchDefaultField = true;
    var defaultQuery = Lookup.buildDefaultQuery(objectSearch);
    mustQueryList = defaultQuery.query.bool.must;
    mustNotQueryList = defaultQuery.query.bool.must_not;
    var shouldQueryList = defaultQuery.query.bool.should;
    var shouldItemIgnore = "hausnr; hausnrzusatz";

    if (shouldQueryList != undefined && shouldQueryList.length > 0) {
        shouldQueryList.forEach(function (shouldItem) {
            var matchQuery = shouldItem.match;
            if (matchQuery !== undefined) {
                for (var property in matchQuery) {
                    if (shouldItemIgnore.indexOf(property) === -1) {
                        mustQueryList.push(shouldItem);
                    }
                }
            } else {
                mustQueryList.push(shouldItem);
            }
        });
    }

    var pf = objectSearch.pf;
    var is_pf = false;
    if (common.checkValid(pf)) {
        is_pf = true;
    }
    Lookup.buildHausnrQuery(mustQueryList, objectSearch.hausNummer, is_pf, isMatchDefaultField);
    if (typeof mustQueryList !== undefined && mustQueryList.length > 0) {
        query.query.bool.must = mustQueryList;
    }
    if (typeof mustNotQueryList !== undefined && mustNotQueryList.length > 0) {
        query.query.bool.must_not = mustNotQueryList;
    } 
    return query;
}

Lookup.buildNachNameFuzzyQuery = function (objectSearch) {
    var shouldQueryList = [];
    var mustQueryList = [];
    var filter;
    // var isSpecial = false;

    /**
     * build fuzzy query for nachname
     */
    var lookup = common.stripAccents(objectSearch.lookup);
    if (common.checkValid(lookup)) {
        var mustItem = common.buildWildcard(Lookup.name_synonym_field.split(','), lookup, true);
        mustQueryList.push(mustItem);
    }

    /**
     * build should query for ort/plz/strasse/pf/hausnr/pickpost/mypost24
     */
    var results = Lookup.buildShouldQuery(objectSearch);
    shouldQueryList = results.shouldQueryList;
    filter = results.filter;

    /**
     * build complete query
     */
    var size_shouldQuery = shouldQueryList.length;
    var msm = size_shouldQuery;
    var query = {
        query: {
            bool: {
                minimum_should_match: '100%'
            }
        }
    };
    if (typeof shouldQueryList != 'undefined' && shouldQueryList.length > 0) {
        query.query.bool.should = shouldQueryList;
    }
    if (typeof mustQueryList != 'undefined' && mustQueryList.length > 0) {
        query.query.bool.must = mustQueryList;
    }
    if (typeof filter != 'undefined') {
        query.filter = filter;
    }

    return query;
}

Lookup.find_hauskey_by_kdpid = function (kdpid) {
    var results = {
        mustQueryList: []
    };
    var mustItem = common.buildMatchQuery(Lookup.kdpid_field, kdpid);
    results.mustQueryList.push(mustItem);
    // var mustItem = common.buildMatchQuery(Lookup.is_special_field, 0);
    // is_special_field is removed on new lookup system, 
    // the kundennumber will be used to specify that kdp is special or not.
    var mustItem = common.buildMatchQuery(Lookup.kundennumber, Lookup.null_value);
    results.mustQueryList.push(mustItem);
    return common.buildBoolQuery(results);
}

/*
 * Check duplicate based on fields: name, vorname, ort, strasse, hausnr, hausnr_a, pf 
 * if kdp.type = 0
 *
 * Check duplicate based on fields: kdpType, anrede, name, vorname, adr_id, aadr_id, hauskey
 * if kdp.type = 1
 */
Lookup.count_duplicate = function (kdp) {
    var results = {
        mustQueryList: []
    };
    
    var type = kdp.type;
    if (type == 0) {
        var plz = kdp.plz;
        if (common.checkValid(plz)) {
            var mustItem = common.buildQueryStringQuery(Lookup.plz_field, plz);
            results.mustQueryList.push(mustItem);
        }

        var ort = common.normalizeForMatch(kdp.ort);
        if (common.checkValid(ort)) {
            var mustItem = common.buildMatchQuery(Lookup.ort_field, ort, null, null, 'AND');
            results.mustQueryList.push(mustItem);
        }

        var strasse = common.normalizeForMatch(kdp.strasse);
        if (common.checkValid(strasse)) {
            var mustItem = common.buildMatchQuery(Lookup.stra_field, strasse, null, null, 'AND');
            results.mustQueryList.push(mustItem);
        }
        
        var name = common.normalizeForMatch(kdp.name);
        if (common.checkValid(name)) {
            var mustItem = common.buildMatchQuery(Lookup.name_field, name, null, null, 'AND');
            results.mustQueryList.push(mustItem);
        }

        var vname = common.normalizeForMatch(kdp.vname);
        if (common.checkValid(vname)) {
            var mustItem = common.buildMatchQuery(Lookup.vname_field, vname, null, null, 'AND');
            results.mustQueryList.push(mustItem);
        }

        var hausNummer = common.normalize(kdp.hausNummer);
        if (common.checkValid(hausNummer)) {
            var mustItem = common.buildMatchQuery(Lookup.hausnr_field, hausNummer);
            results.mustQueryList.push(mustItem);
        }

        var hausNummer_a = common.normalize(kdp.hausNummer_a);
        if (common.checkValid(hausNummer_a)) {
            var mustItem = common.buildMatchQuery(Lookup.hausnr_a_field, hausNummer_a);
            results.mustQueryList.push(mustItem);
        }

        var pf = common.normalize(kdp.pf);
        if (common.checkValid(pf)) {
            var mustItem = common.buildMatchQuery(Lookup.pf_field, Lookup.pf_level);
            results.mustQueryList.push(mustItem);
        }
    } else {
        var kdpType = kdp.kdpType;
        if (common.checkValid(kdpType)) {
            var mustItem = common.buildMatchQuery(Lookup.type_field, kdpType);
            results.mustQueryList.push(mustItem);
        }

        var anrede = common.normalize(kdp.anrede);
        if (common.checkValid(anrede)) {
            var mustItem = common.buildMatchQuery(Lookup.anrede_field, anrede);
            results.mustQueryList.push(mustItem);
        }

        var name = common.normalizeForMatch(kdp.name);
        if (common.checkValid(name)) {
            var mustItem = common.buildMatchQuery(Lookup.name_field, name);
            results.mustQueryList.push(mustItem);
        }

        var vorname = common.normalizeForMatch(kdp.vname);
        if (common.checkValid(vorname)) {
            var mustItem = common.buildMatchQuery(Lookup.vname_field, vorname);
            results.mustQueryList.push(mustItem);
        }

        var adr_id = common.normalize(kdp.adr_id);
        if (common.checkValid(adr_id)) {
            var mustItem = common.buildMatchQuery(Lookup.adr_id_field, adr_id);
            results.mustQueryList.push(mustItem);
        }

        var aadr_id = common.normalize(kdp.aadr_id);
        if (common.checkValid(aadr_id)) {
            var mustItem = common.buildMatchQuery(Lookup.aadr_id_field, aadr_id);
            results.mustQueryList.push(mustItem);
        }

        var hauskey = common.normalize(kdp.hauskey);
        if (common.checkValid(hauskey)) {
            var mustItem = common.buildMatchQuery(Lookup.hauskey, hauskey);
            results.mustQueryList.push(mustItem);
        }
    }

    var query = common.buildBoolQuery(results);
    query.size = 2;

    return query;
}

Lookup.findHauskeyByKdpObject = function (kdp) {
    var boolQuery = {
        mustQueryList: [],
        shouldQueryList: [],
        msm: 1
    };

    var plz = kdp.plz;

    if (common.checkValid(plz)) {
        boolQuery.mustQueryList.push(common.buildMatchQuery(Lookup.plz_field, plz));
    } else {
        boolQuery.mustQueryList.push(common.buildMatchQuery(Lookup.plz_field, Lookup.null_value));
    }

    var ort = common.normalize(kdp.ort);
    if (common.checkValid(ort)) {
        boolQuery.mustQueryList.push(common.buildMatchQuery(Lookup.ort_field, ort));
    } else {
        boolQuery.mustQueryList.push(common.buildMatchQuery(Lookup.ort_field, Lookup.null_value));
    }

    var strasse = common.normalize(kdp.strasse);
    if (common.checkValid(strasse)) {
        boolQuery.mustQueryList.push(common.buildMatchQuery(Lookup.stra_field, strasse));
    } else {
        boolQuery.mustQueryList.push(common.buildMatchQuery(Lookup.stra_field, Lookup.null_value));
    }

    if (Lookup.mypost24_keywords.length > 0) {
        for (var i = 0; i < Lookup.mypost24_keywords.length; i++) {
            boolQuery.shouldQueryList.push(common.buildQueryStringQueryWithoutWildcard(Lookup.name_analyzed, Lookup.mypost24_keywords[i], 1, 'AND'));
        }
    }

    return common.buildBoolQuery(boolQuery);
}

module.exports = {
    buildDefaultQuery: function (objectSearch, fuzziness) {
        return Lookup.buildDefaultQuery(objectSearch, fuzziness);
    },
    buildMustQuery: function (objectSearch) {
        return Lookup.buildMustQuery(objectSearch);
    },
    buildNachNameFuzzyQuery: function (objectSearch) {
        return Lookup.buildNachNameFuzzyQuery(objectSearch);
    },
    find_hauskey_by_kdpid: function (kdpid) {
        return Lookup.find_hauskey_by_kdpid(kdpid);
    },
    count_duplicate_kdp: function (kdp) {
        return Lookup.count_duplicate(kdp);
    },
    buildFindHauskeyByKdpObjectQuery: function (kdp) {
        return Lookup.findHauskeyByKdpObject(kdp);
    }
}

Lookup.initialize();