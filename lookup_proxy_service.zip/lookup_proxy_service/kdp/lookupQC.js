if (typeof LookupQC == 'undefined') {
	var LookupQC = {};
}

var common = require('../common');

LookupQC.initialize = function() {
	var self = this;
    self.lookup_field = 'name_search,name_galias,name_alias,vorname_search,vorname_galias,vorname_alias';
	self.name_field = 'vorname_search,vorname_alias';
	self.nach_name_field = 'name_search,name_alias';
	self.ort_field = 'ort_search';
	self.plz_field = 'plz_search';
	self.stra_field = 'strasse_search';
	self.pf_field = 'level';
    self.pf_level = '3';
	self.hausnr_field = 'hausnr';
	self.hausnr_a_field = 'hausnrzusatz';
    self.kundennumber = 'kundennumber';
	self.strasse_boost = 1000;
    self.null_value = '_null_';
};

LookupQC.build_QC_ShouldQuery = function(objectSearch) {
	var results = {
		shouldQueryList : [],
	};
	var mypost24 = objectSearch.mypost24;
	var pickpost = objectSearch.pickpost;

    var is_pf = false;
    
	if (common.checkValid(mypost24) || common.checkValid(pickpost)) {
		/**
		 * build should query for mypost24 and pickpost
         * if myspost24 and pickpost are valid, mypost24 will be used.
		 */
        var kundennumber_value = '';
        
        if(common.checkValid(mypost24)) {
            kundennumber_value = mypost24;
        } else {
            if(common.checkValid(pickpost)) {
                kundennumber_value = pickpost;
            }
        }
        
        var queryItem = common.buildQueryStringQuery(LookupQC.kundennumber, kundennumber_value);
        results.shouldQueryList.push(queryItem);
	} else {
        /**
		 * build should query for plz/ort/strasse/hausnr/postfach
		 */
		var ort = common.stripAccents(objectSearch.ort);
		var plz = objectSearch.plz;
		var stra = common.stripAccents(objectSearch.strasse);
		var pf = objectSearch.pf;
		var fullHausnr = objectSearch.hausNummer;

        /**
         * build query for ort
         */
		if (common.checkValid(ort)) {
			
			var shouldItem = common.buildQueryStringQuery(LookupQC.ort_field, ort);
			results.shouldQueryList.push(shouldItem);
		}
		/**
         * build query for plz
         */
        if (common.checkValid(plz)) {
			var shouldItem = common.buildQueryStringQuery(LookupQC.plz_field, plz);
			results.shouldQueryList.push(shouldItem);
		}
        /**
         * build query for strasse
         */
		if (common.checkValid(stra)) {
			var shouldItem = common.buildQueryStringQuery(LookupQC.stra_field, stra, LookupQC.strasse_boost);
			results.shouldQueryList.push(shouldItem);
		}
		/**
		 * build query for hausnr and hausnr_a
		 */
		if (common.checkValid(fullHausnr)) {
			var hausnr = fullHausnr.match(/(^[0-9.]+)/gi);
			hausnr = hausnr ? hausnr : "";
			var hausnr_a = fullHausnr.replace(/^([0-9.]+)/gi, '');
			hausnr_a = hausnr_a ? hausnr_a : "";
			if (hausnr.length > 0) {
				hausnr = hausnr[0];
				var shouldItem = common.buildMatchQuery(LookupQC.hausnr_field, hausnr);
				results.shouldQueryList.push(shouldItem);
			}
			if (hausnr_a.length > 0) {
				hausnr_a = hausnr_a.replace(/(\+|-|&&|=|\|\||>|<|!|\(|\)|{|}|\[|\]|\^|\"|~|\*|\?|:|\\|\/)/g, '\\$&');
				var shouldItem = common.buildMatchQuery(LookupQC.hausnr_a_field, hausnr_a);
				results.shouldQueryList.push(shouldItem);
			}
			results.isSpecial = (hausnr.length > 0 && hausnr_a.length > 0);
		}
	}
	return results;
}

LookupQC.build_QC_Query = function(objectSearch) {
	var shouldQueryList = [];
	var mustQueryList = [];
    var mustNotQueryList = [];
	var isSpecial = false;

	/**
	 * build query for lookup
	 */
	var lookup = common.stripAccents(objectSearch.lookup);
	if (common.checkValid(lookup)) {
		var words = lookup.trim().toLowerCase().split(' ');
		if (words.length == 2) {
			if (words[0].trim() == words[1].trim()) {
				var mustItem1 = common.buildWildcard(LookupQC.name_field.split(','), words[0]);
				var mustItem2 = common.buildWildcard(LookupQC.nach_name_field.split(','), words[1]);
				mustQueryList.push(mustItem1);
				mustQueryList.push(mustItem2);
			} else {
				var mustItem1 = common.buildWildcard(LookupQC.lookup_field.split(','), words[0]);
				var mustItem2 = common.buildWildcard(LookupQC.lookup_field.split(','), words[1]);
				mustQueryList.push(mustItem1);
				mustQueryList.push(mustItem2);
			}
		} else {
			var mustItem = common.buildWildcard(LookupQC.lookup_field.split(','), lookup);
			mustQueryList.push(mustItem);
		}
	}
	/**
	 * build should query for ort/plz/strasse/hausnr/pickpost/mypost24
	 */
	var results = LookupQC.build_QC_ShouldQuery(objectSearch);
	shouldQueryList = results.shouldQueryList;
    isSpecial = results.isSpecial;
    
    /**
	 * build query for postfach
	 */
    var pf = objectSearch.pf;
    if(common.checkValid(pf)) {
        mustQueryList.push(common.buildMatchQuery(LookupQC.pf_field, LookupQC.pf_level));
    } else {
        mustNotQueryList.push(common.buildMatchQuery(LookupQC.pf_field, LookupQC.pf_level));
    }
    
    var mypost24 = objectSearch.mypost24;
	var pickpost = objectSearch.pickpost;
    
    // Request #12319(Jira): kdp of pickpost or mypost24 could be found when user lookup domizil address.
    if (common.checkValid(mypost24) || common.checkValid(pickpost)) {
        mustNotQueryList.push(common.buildMatchQuery(LookupQC.kundennumber, LookupQC.null_value));
	}
    
	/**
	 * build complete query
	 */
	var size_shouldQuery = shouldQueryList.length;
	if (isSpecial) {
		size_shouldQuery = size_shouldQuery - 1;
	}
	var msm = size_shouldQuery > 3 ? (size_shouldQuery - 2) : 1;
	var query = {
		query : {
			bool : {
				minimum_should_match : msm
			}
		}
	};
	if (typeof shouldQueryList != 'undefined' && shouldQueryList.length > 0) {
		query.query.bool.should = shouldQueryList;
	}
	if (typeof mustQueryList != 'undefined' && mustQueryList.length > 0) {
		query.query.bool.must = mustQueryList;
	}
    if (typeof mustNotQueryList != 'undefined' && mustNotQueryList.length > 0) {
		query.query.bool.must_not = mustNotQueryList;
	}

	return query;
}

module.exports = {
	buildQCQuery : function(searchParam) {
		return LookupQC.build_QC_Query(searchParam);
	}
}

LookupQC.initialize();