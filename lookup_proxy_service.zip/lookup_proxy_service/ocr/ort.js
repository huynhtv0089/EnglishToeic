var elasticsearch = require('elasticsearch');
var fs = require('fs');
var common = require('../common');

if (typeof Ort == 'undefined') {
	var Ort = {};
}

Ort.initialize = function() {
	var self = this;
	self.ort_translate = 'ort_translate';
};

Ort.normalize = function(value){
	var ret = value;
	
	if (common.checkValid(value)) {
		ret = ret.toLowerCase().trim();
		ret = common.normalize(ret);
	}
	
	return ret;
}

module.exports = {
	buildCheckOrtExsistenceQuery : function(ort){
		var normalizedOrt = Ort.normalize(ort);
		return common.buildMatchPhraseQuery(Ort.ort_translate, normalizedOrt);
	}
}

Ort.initialize();