var elasticsearch = require('elasticsearch');
var fs = require('fs');
var common = require('../common');

if (typeof FirmaSign == 'undefined') {
	var FirmaSign = {};
}

FirmaSign.initialize = function() {
	this.full_name = 'full_name';
};

FirmaSign.normalize = function(value){
	var ret = value;
	
	if (common.checkValid(value)) {
		ret = ret.toLowerCase().trim();
		ret = common.normalize(ret);
	}
	
	return ret;
}

module.exports = {
	
}

FirmaSign.initialize();