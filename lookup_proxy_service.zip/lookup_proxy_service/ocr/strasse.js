var elasticsearch = require('elasticsearch');
var fs = require('fs');
var common = require('../common');

if (typeof Strasse == 'undefined') {
	var Strasse = {};
}

Strasse.initialize = function() {
	var self = this;
	self.strasse_translate = 'strasse_translate';
};

Strasse.normalize = function(value){
	var ret = value;
	
	if (common.checkValid(value)) {
		ret = ret.toLowerCase().trim();
		ret = common.normalize(ret);
	}
	
	return ret;
}

module.exports = {
	buildCheckStrasseExsistenceQuery: function(strasse){
		var normalizedStrasse = Strasse.normalize(strasse);
		return common.buildMatchPhraseQuery(Strasse.strasse_translate, normalizedStrasse);
	}
}

Strasse.initialize();