var elasticsearch = require('elasticsearch');
var fs = require('fs');
var common = require('../common');

if (typeof Name == 'undefined') {
	var Name = {};
}

Name.initialize = function() {
	var self = this;
	self.full_name = 'full_name';
};

Name.normalize = function(value){
	var ret = value;
	
	if (common.checkValid(value)) {
		ret = ret.toLowerCase().trim();
		ret = common.normalize(ret);
	}
	
	return ret;
}

module.exports = {
	buildCheckNameExsistenceQuery : function(name){
		var normalizedName = Name.normalize(name);
		return common.buildMatchPhraseQuery(Name.full_name, normalizedName);
	}
}

Name.initialize();