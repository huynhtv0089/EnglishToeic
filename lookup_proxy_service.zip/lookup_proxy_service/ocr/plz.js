var elasticsearch = require('elasticsearch');
var fs = require('fs');
var common = require('../common');

if (typeof Plz == 'undefined') {
	var Plz = {};
}

Plz.initialize = function() {
	var self = this;
	self.plz = 'plz';
};

module.exports = {
	buildCheckPlzExsistenceQuery : function(plz){
		return common.buildMatchPhraseQuery(Plz.plz, plz);
	}
}

Plz.initialize();