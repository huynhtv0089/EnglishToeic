let app = angular.module('myApp', ['angularMoment']);

app.controller('mainCtrl', ['$scope', '$rootScope', '$log', function($scope, $rootScope, $log) {
	$scope.signInSuccess = false;
	
	$scope.statusSignIn = () => {
		$log.log('[mainCtrl]-> method $scope.statusSignIn: execute')
		
		$scope.signInSuccess = true;
	}
	
	$rootScope.$on("callStatusSignInMethod", function(){
		$scope.statusSignIn();
    });

}]);

app.directive('autoFocus', function($timeout) {
    return {
        link: function (scope, element, attrs) {
            attrs.$observe("autoFocus", function(newValue){
                if (newValue === "true")
                    $timeout(function(){element.focus()});
            });
        }
    };
});