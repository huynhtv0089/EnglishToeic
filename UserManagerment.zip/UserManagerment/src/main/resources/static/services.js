app.service('myServices', ['$log', function($log) {
	
	this.arrayOptionsValue = function() {
		return [
			{"value": 1, "view": "100%"},
			{"value": 2, "view": "50%"},
			{"value": 3, "view": "33%"},
			{"value": 4, "view": "25%"},
			{"value": 5, "view": "20%"},
			{"value": 10, "view": "10%"},
			{"value": 0, "view": "0"}
		]; 
	}
	
	this.arrayOptionsInfoUser = function() {
		return [
			{ element: 'true', value: true }, 
			{ element: 'false', value: false }
		];
	}
	
	this.isNumber = function(value) {
		if(angular.isNumber(value)) {
			return 'number'; 
		}
	}
	
}]);