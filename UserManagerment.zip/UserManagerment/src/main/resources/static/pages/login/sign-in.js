app.controller('loginCtrl', ['$scope', '$rootScope', '$http', 'myServices', '$log', function($scope, $rootScope, $http, myServices, $log) {
	$scope.inputUsername = '';
	$scope.invalid = false;
	
	$scope.signIn = () => {
		
		$http.post(
			'/startConfig',
			$scope.inputUsername
		).then(function(response) {
			$log.log('[loginCtrl]-> method $scope.signIn: execute');
			
			if(response.data) {
				$rootScope.$emit("callStatusSignInMethod", {});
				$rootScope.$emit("callInitialMethod", {});
			} else {
				$scope.invalid = true;
			}
		}, function(response) {
			$log.error('method $scope.signIn error: ' + response.statusText);
		});
		
	}

}]);