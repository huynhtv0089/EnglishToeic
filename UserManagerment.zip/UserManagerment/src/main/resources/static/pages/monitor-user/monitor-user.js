app.controller('monitorUserCtrl', ['$scope', '$rootScope', '$http', 'myServices', '$log', 'moment', function($scope, $rootScope, $http, myServices, $log, moment) {
	$scope.notification = ''
	$scope.boolNotify = true;
	let idCurrent;
	$scope.selectedActive = 0;
	$scope.displayMultyChooseUser = false;
	$scope.arrayChoosedId = [];
	$scope.saveNameCopy = {};
	$scope.idPreQsCategory = 0;
	$scope.arrayInserPreQsCategory = {};
	$scope.newTxtPreQsCategory = '';
	$scope.newSelectPreQsCategory = '';
	
	$rootScope.$on("callInitialMethod", function(){
		$scope.initialAllUser();
		$scope.selectProjects();
    });
	
	$scope.initialAllUser = function() {
		$log.log('[monitorUserCtrl]-> method $scope.initialAllUser: execute');
		$scope.waitingCardLeft = false;
		
		$http({
	        method : "GET",
	        url : "/getAllUser"
	    }).then(function mySuccess(response) {
	    	$scope.dataCardInfo = response.data;
	    	let idElementFirst = $scope.dataCardInfo[0].id;
	    	
	    	$scope.userNameTitle = Object.keys($scope.dataCardInfo[0])[1];
	    	$scope.fullNameTitle = Object.keys($scope.dataCardInfo[0])[2];
	    	$scope.scanJobTitle = Object.keys($scope.dataCardInfo[0])[3];
	    	$scope.valueTitle = Object.keys($scope.dataCardInfo[0])[4].substring(0, 5);
	    	
	    	$scope.waitingCardLeft = true;
	    	$scope.showUserById(idElementFirst);
	    	
	    	//Call all data table pre_qs_categoy
	    	$scope.selectAllPreQsCategory();
	    }, function myError(response) {
	    	$log.error('[monitorUserCtrl]-> method $scope.initialAllUser error: ' + response.statusText);
	    });
	}
	
	$scope.optionsValue = myServices.arrayOptionsValue();
	
	$scope.optionsInfoUser = myServices.arrayOptionsInfoUser();
	
	$scope.updateInfo = function(key, value, ctr = 'none') {
		$log.log('[monitorUserCtrl]-> method $scope.updateInfo: execute');
		
		let params = [];
		if(ctr === 'none') {
			params.push([$scope.idUser]);
		} else {
			params.push($scope.arrayChoosedId);
		}
		params.push([key]);
		params.push([value]);
		if(key !== 'scan_job' && key !== 'value') {
			$http.post(
				'/updateInfoUser',
				params
			).then(function(response) {
				$scope.appearNotify(response.data, 'Update');
				if(key === 'user_name') {
					$scope.updateUserSetting(params, key, value, ctr);
				}
			}, function(response) {
				$log.error('[monitorUserCtrl]-> method $scope.updateInfo error: ' + response.statusText);
			});
		} else {
			$scope.updateUserSetting(params, key, value, ctr)
		}
	}
	
	$scope.updateUserSetting = function(params, key, value, ctr = 'none') {
		$log.log('[monitorUserCtrl]-> method $scope.updateUserSetting: execute');
		
		$http.post(
			'/updateInfoUserSetting',
			params
		).then(function(response) {
			$scope.appearNotify(response.data, 'Update');
			if(ctr === 'none') {
				$scope.updateArrData(response.data, key, value);
			} else {
				$scope.updateArrData(response.data, key, value, 'multy');
			}
		}, function(response) {
			$log.error('error: ' + response.statusText);
		});
	}
	
	$scope.updateArrData = function(bool, key, value, ctr = 'none') {
		$log.log('[monitorUserCtrl]-> method $scope.updateArrData: execute');
		
		if(key === 'user_name' || key === 'full_name' || key === 'scan_job' || key === 'value') {
			if(ctr === 'none') {
				if(bool) {
					if(key === 'value') {
						$scope.dataCardInfo.find(x => x.id === $scope.idUser)['value_setting'] = value;
					} else {
						$scope.dataCardInfo.find(x => x.id === $scope.idUser)[key] = value;
					}
				}
			} else if(ctr === 'multy') {
				if(bool) {
					for(let i=0; i<$scope.arrayChoosedId.length; i++) {
						if(key === 'value') {
							$scope.dataCardInfo.find(x => x.id === $scope.arrayChoosedId[i])['value_setting'] = value;
						} else {
							$scope.dataCardInfo.find(x => x.id === $scope.arrayChoosedId[i])[key] = value;
						}
					}
				}
			}
		}
	}
	
	
	$scope.getAllProperties = function() {
		$log.log('[monitorUserCtrl]-> method $scope.getAllProperties: execute');
		
		$scope.properties = {};
		
		$http({
	        method : "GET",
	        url : "/dataTypeUser"
	    }).then(function mySuccess(response) {
	    	for(let key in response.data) {
	    		if(response.data[key].data_type !== 'boolean') {
	    			$scope.properties[response.data[key].column_name] = 'String';
	    		} else {
	    			$scope.properties[response.data[key].column_name] = 'boolean';
	    		}
	    	}
	    	
	    }, function myError(response) {
	    	$log.error('[monitorUserCtrl]-> method $scope.getAllProperties error: ' + response.statusText);
	    });
	}
	
	$scope.getMetadata = function(key, value) {
		$log.log('[monitorUserCtrl]-> method $scope.getMetadata: execute');
		
		if($scope.storeMetadata === undefined) {
			$scope.storeMetadata = {};
		}
		
		$scope.storeMetadata[key] = value;
	}
	
	$scope.createNewUser = function(ctr = 'create') {
		$log.log('[monitorUserCtrl]-> method $scope.insertUserSetting: execute');
		
		$scope.containerValue = []
		if(ctr === 'create') {
			Object.keys($scope.properties).forEach(function(key) {
				if($scope.storeMetadata[key] === undefined && key != 'id') {
					if($scope.properties[key] !== 'boolean') {
						$scope.storeMetadata[key] = '';
					} else {
						$scope.storeMetadata[key] = 'false';
					}
				}
			});
			$scope.containerValue[2] = ['false'];
		} else if (ctr === 'copy') {
			$scope.storeMetadata = {};
			$scope.storeMetadata.user_name = $scope.saveNameCopy.user_name;
			$scope.storeMetadata.full_name = $scope.saveNameCopy.full_name;
			
			Object.keys($scope.dataCardCenter).forEach(function(key) {
				if(key !== 'id' && key !== 'user_name' && key !== 'full_name') {
					if($scope.dataCardCenter[key] === true || $scope.dataCardCenter[key] === false) {
						$scope.storeMetadata[key] = $scope.dataCardCenter[key];
					} else {
						$scope.storeMetadata[key] = $scope.dataCardCenter[key].trim();
					}
				}
			});
			$scope.containerValue[2] = ['true'];
		}
		
		$scope.containerValue[0] = Object.keys($scope.storeMetadata);
		$scope.containerValue[1] = Object.values($scope.storeMetadata);
		
		$http.post(
			'/insertUser',
			$scope.containerValue
		).then(function(response) {
			if(response.data.length > 0) {
				$scope.dataCardInfo.push(response.data[0]);
				$scope.appearNotify(true, 'Create');
				if(ctr === 'copy') {
					$scope.userSettingCopy = $scope.dataCardInfo.find(x => x.id === $scope.dataCardCenter.id);

					$scope.insertUserSetting(response.data[0].id, response.data[0].user_name, 
											$scope.scanJobCopy, $scope.valueCopy);
				}
			} else {
				$scope.appearNotify(false, 'Create');
			}
		}, function(response) {
			$log.error('[monitorUserCtrl]-> method $scope.insertUserSetting error: ' + response.statusText);
			$scope.appearNotify(false, 'Create');
		});
		
		$scope.storeMetadata = {};
		$scope.resetData();
	}
	
	$scope.insertUserSetting = function(id, user_name, scan_job, value) {
		$log.log('[monitorUserCtrl]-> method $scope.insertUserSetting: execute');
		
		let params = [];
		params[0] = [];
		params[1] = new Array(id, user_name, scan_job, value);
		params[2] = new Array(true);
		
		$http.post(
			'/insertUserSetting',
			params
		).then(function(response) {
			$scope.appearNotify(response.data, 'Copy user')
			let userSetting = $scope.dataCardInfo.find(x => x.id === id);
			userSetting.scan_job = scan_job;
			userSetting.value_setting = value;
		}, function(response) {
			$log.error('method $scope.insertUserSetting error: ' + response.statusText);
			$scope.appearNotify(false, 'Copy user');
		});
	}
	
	$scope.resetData = function() {
		$log.log('[monitorUserCtrl]-> method $scope.resetData: execute');
		
		angular.element(document.querySelector('#resetCreateUser')).click();
	}
	
	$scope.appearNotify = function(boolean, str) {
		$log.log('[monitorUserCtrl]-> method $scope.appearNotify: execute');
		
		if(boolean) {
			$scope.notification = str + ' success';
			$scope.boolNotify = true;
		} else {
			$scope.notification = str + ' fail';
			$scope.boolNotify = false;
		}

		let pressNotify = setInterval(function() {
			angular.element(document.querySelector('#notification')).click();
			clearInterval(pressNotify);
		}, 550);
		angular.element(document.querySelector('#notification')).click();
	}
	
	$scope.selectProjects = function() {
		$log.log('[monitorUserCtrl]-> method $scope.selectProjects: execute');
		
		$http({
	        method : "GET",
	        url : "/getProjects"
	    }).then(function mySuccess(response) {
	    	$scope.datascources = response.data;
	    	$scope.arrProjects = [];
	    	
	    	for(let key in $scope.datascources) {
    			$scope.arrProjects.push($scope.datascources[key].project + " " + $scope.datascources[key].environment);
    		}
	    	$scope.project = $scope.arrProjects[0];
	    }, function myError(response) {
	    	$log.error('[monitorUserCtrl]-> method $scope.selectProjects error: ' + response.statusText);
	    });
	}
	
	$scope.selectedProject = function(value) {
		$log.log('[monitorUserCtrl]-> method $scope.active: execute');
		
		$scope.waitingCardLeft = false;
		$scope.waitingCardRIght = false;
		
		//Clear both $scope.dataCardInfo and $scope.dataCardCenter
		$scope.dataCardInfo = [];
		$scope.dataCardCenter = {};
		
		let index = $scope.arrProjects.indexOf(value);
		let datasource = {};
		datasource = $scope.datascources[index];
		
		$http.post(
			'/changeProjects',
			datasource
		).then(function(response) {
			if(response.data == true) {
				$scope.initialAllUser();
			}
		}, function(response) {
			$log.error('method $scope.active error: ' + response.statusText);
		});
	} 
	
	$scope.checkNumber = function(value) {
		$log.log('[monitorUserCtrl]-> method $scope.checkNumber: execute');
		
		return myServices.isNumber(value);
	}
	
	$scope.active = function(index) {
		$log.log('[monitorUserCtrl]-> method $scope.active: execute');
		
		if($scope.arrayChoosedId.length != 1) {
			$scope.selectedActive = index;
		}
    };
    
    $scope.selectedUser = function(selected, id) {
    	$log.log('[monitorUserCtrl]-> method $scope.selectedUser: execute');
    	
    	if(selected == true) {
    		$scope.arrayChoosedId.push(id);
    		
    		if($scope.arrayChoosedId.length > 1) {
    			$scope.displayIsChecked()
    		}
    	} else {
    		let index = $scope.arrayChoosedId.indexOf(id);
    		$scope.arrayChoosedId.splice(index, 1);
    		
			if($scope.arrayChoosedId.length == 1) {
				$scope.displayMultyChooseUser = false;
				let idLast = $scope.arrayChoosedId[0];
				
				$scope.selectedActive = $scope.dataCardInfo.findIndex(x => x.id == idLast);
				$scope.requestShowUserById(idLast);
			}
    	}
    }
    
    $scope.handleMultySelect = function(isChecked) {
    	$log.log('[monitorUserCtrl]-> method $scope.handleMultySelect: execute');
    	
    	if(isChecked) {
    		for(let i=0; i<$scope.dataCardInfo.length; i++) {
    			$scope.arrayChoosedId.push($scope.dataCardInfo[i].id);
    		}
    		$scope.displayIsChecked();
    	} else {
	    	if($scope.arrayChoosedId.length >= 1) {
		    	$scope.arrayChoosedId = [];
		    	$scope.displayMultyChooseUser = false;
		    	
		    	$scope.selectedActive = 0;
		    	$scope.requestShowUserById($scope.dataCardInfo[0].id);
	    	}
    	}
    }
    
    $scope.displayIsChecked = function() {
    	$log.log('[monitorUserCtrl]-> method $scope.displayIsChecked: execute');
    	
    	$scope.textMultySelect = '';
		$scope.valueMultySelect = '';
		$scope.scanJobMultySelect = '';
		
		$scope.displayMultyChooseUser = true;
		$scope.infoUserCurrent('clear');
    }
    
    $scope.showUserById = function(id) {
    	$log.log('[monitorUserCtrl]-> method $scope.showUserById: execute');
    	
		if($scope.arrayChoosedId.length == 0) {
			if(idCurrent !== id) {
				$scope.requestShowUserById(id);
			}
    	}
	}
    
    $scope.requestShowUserById = function(id) {
    	$log.log('[monitorUserCtrl]-> method $scope.requestShowUserById: execute');
    	
    	$scope.waitingCardRight = false;
    	$scope.dataCardCenter = {};
    	
    	$http.post(
			'/getUserById',
			id
		).then(function(response) {
			if(response.data[0] === undefined) {
				$scope.searchText = {};	
			} else {
				$scope.dataCardCenter = response.data[0];
				$scope.infoUserCurrent();
				
				idCurrent = $scope.idUser;
				$scope.getAllProperties();
			}
			$scope.waitingCardRight = true;
		}, function(response) {
			$log.error('[monitorUserCtrl]-> method $scope.requestShowUserById error: ' + response.statusText);
		});
    }
    
    $scope.updateMultySelect = function(key, value) {
    	$log.log('[monitorUserCtrl]-> method $scope.updateMultySelect: execute');
    	
    	$scope.updateInfo(key, value, 'multy');
    }
    
    $scope.infoUserCurrent = function(ctr = 'current') {
    	$log.log('[monitorUserCtrl]-> method $scope.infoUserCurrent: execute');
    	
    	if(ctr === 'current') {
	    	$scope.idUser = $scope.dataCardCenter.id; 
			$scope.userName = $scope.dataCardCenter.user_name;
			$scope.fullName = $scope.dataCardCenter.full_name;
    	} else {
    		$scope.idUser = '...'; 
    		$scope.userName = '...';
    		$scope.fullName = '...';
    	}
    }
    
    $scope.getNameCopy = function(key, value) {
    	$log.log('[monitorUserCtrl]-> method $scope.getNameCopy: execute');
    	
    	if(key === 'user_name') {
    		$scope.saveNameCopy.user_name = value
    	} else if(key === 'full_name') {
    		$scope.saveNameCopy.full_name = value
    	}
    }
    
    $scope.handleCopyUser = function(ctr = 'show') {
    	$log.log('[monitorUserCtrl]-> method $scope.handleCopyUser: execute');
    	
    	if(ctr === 'show') {
    		$scope.displayCardCopy = true;
    		$scope.infoUserCurrent('clear');
    		$scope.userNameCopy = '';
    		$scope.fullNameCopy = '';
    		
    		let userSettingCopy = $scope.dataCardInfo.find(x => x.id === $scope.dataCardCenter.id);
			$scope.scanJobCopy = userSettingCopy.scan_job;
			$scope.valueCopy = userSettingCopy.value_setting; 
    	} else {
    		$scope.displayCardCopy = false;
    		$scope.infoUserCurrent();
    		
    		if(ctr === 'accept') {
    			if($scope.userNameCopy !== '' && $scope.fullNameCopy !== '') {
    				$scope.createNewUser('copy');
    			} else {
    				$scope.appearNotify(false, 'Copy user');
    			}
    		}
    	}
    }
    
    $scope.handleDeleteUser = function() {
    	$log.log('[monitorUserCtrl]-> method $scope.handleDeleteUser: execute');
    	
    	let params = [];
    	$scope.arrayChoosedId.length != 0 ? params = $scope.arrayChoosedId : params.push(idCurrent);
    	
    	$log.log('[delete]: ' + JSON.stringify(params))
    	$http.post(
			'/deleteUser',
			params
		).then(function(response) {
			$scope.appearNotify(response.data, 'Delete User');
			if(response.data) {
				if($scope.arrayChoosedId.length == 0) {
					let position = $scope.dataCardInfo.indexOf($scope.dataCardInfo.find(x => x.id === idCurrent));
					$scope.dataCardInfo.splice(position, 1);
				} else {
					for(let i=0; i<$scope.arrayChoosedId.length; i++) {
						let position = $scope.dataCardInfo.indexOf($scope.dataCardInfo.find(x => x.id === $scope.arrayChoosedId[i]));
						$scope.dataCardInfo.splice(position, 1);
					}
				}
			}
			$scope.displayMultyChooseUser = false;
			$scope.arrayChoosedId = [];
		}, function(response) {
			$log.error('[monitorUserCtrl]-> method $scope.handleDeleteUser error: ' + response.statusText);
		});
    }
    
    
    $scope.reloadPage = () => {
    	$log.log('[monitorUserCtrl]-> method $scope.reloadPage: execute');
    	
    	location.reload();
    }
    
    
    /*
     * Handle scan_job
     */
    //Select all table pre_qs_setting
    $scope.selectAllPreQsCategory = () => {
    	$scope.newTxtPreQsCategory = {};
		$scope.newSelectPreQsCategory = {};
		$scope.displaySuggestPreQsCategory = false;
		$scope.dataPreQsCategory = [];
    	$log.log('[monitorUserCtrl]-> method $scope.selectAllPreQsCategory: execute');
    	
		$http({
	        method : "GET",
	        url : "/getAllPreQsCategory"
	    }).then(function mySuccess(response) {
	    	$scope.dataPreQsCategory = response.data.sort((a, b) => b.user_name < a.user_name);
	    	
	    	if($scope.dataPreQsCategory.length < 1) {
	    		$scope.preQsSetting404 = 'not setting yet.';
	    	} else {
	    		$scope.preQsSetting404 = '';
	    	}
	    }, function myError(response) {
	    	$log.error('[monitorUserCtrl]-> method $scope.selectAllPreQsCategory error: ' + response.statusText);
	    });
	}
    
    $scope.indexPreQsCategory = (index) => {
    	$log.log('[monitorUserCtrl]-> method $scope.indexPreQsCategory: execute');
    	
    	$scope.idPreQsCategory = index;
    }
    
    //Update table pre_qs_setting
    $scope.updatePreQsCategory = (column, value, username, index) => {
    	$log.log('[monitorUserCtrl]-> method $scope.updatePreQsCategory: execute');

		let params = [column, value, username];
	
		$http.post(
			'/updatePreQsCategory',
			params
		).then(function(response) {
			let result = response.data;
			$scope.appearNotify(result, 'Update');
			
			if(result) {
				//Update data inside $scope.dataPreQsCategory after update database success.
				$scope.dataPreQsCategory[index][column] = value;
			}
		}, function(response) {
			$log.error('[monitorUserCtrl]-> method $scope.updatePreQsCategory error: ' + response.statusText);
		});
	}
    
    //Delete row inside table pre_qs_setting
    $scope.deletePreQsCategory = () => {
    	$log.log('[monitorUserCtrl]-> method $scope.deletePreQsCategory: execute');
    	let params = [$scope.dataPreQsCategory[$scope.idPreQsCategory].user_name];
    	$http.post(
			'/deletePreQsCategory',
			params
		).then(function(response) {
			let result = response.data;
			$scope.appearNotify(result, 'Delete');
			
			if(result) {
				//Update data inside $scope.dataPreQsCategory after update database success.
				$scope.dataPreQsCategory.splice($scope.idPreQsCategory, 1);
			}
		}, function(response) {
			$log.log('[monitorUserCtrl]-> method $scope.deletePreQsCategory error: ' + response.statusText);
		});
    } 
    
    // Get user_name form view html
    $scope.setUsernamePreQsCategory = (value) => {
    	$scope.displaySuggestPreQsCategory = false;
    	
    	$scope.newTxtPreQsCategory.user_name = value; 
    	$scope.arrayInserPreQsCategory['user_name'] = value;
    	
    	//Autofocus after user choose data in suggest
    	angular.element(document.querySelector('#newTxtPreQsCategory')).focus();
    }
    
    // Get data for insert, form view html
    $scope.dataInsertPreQsCategory = (column, value) => {
    	$scope.displaySuggestPreQsCategory = true;
		$scope.arrayInserPreQsCategory[column] = value;
    }
    
    //Insert table pre_qs_setting
    $scope.insertPreQsCategory = () => {
    	$log.log('[monitorUserCtrl]-> method $scope.insertPreQsCategory: execute');
    	
    	if($scope.arrayInserPreQsCategory.user_name != null) {
			$scope.arrayInserPreQsCategory.user_name = "'" + $scope.arrayInserPreQsCategory.user_name + "'";
			let params = [Object.keys($scope.arrayInserPreQsCategory), Object.values($scope.arrayInserPreQsCategory)];
			
	    	$log.log('params: ' + JSON.stringify(params));
				
			$http.post(
				'/insertPreQsCategory',
				params
			).then(function(response) {
				let result = response.data;
				$scope.appearNotify(result, 'Insert');
				
				if(result) {
					//If true, then recall method select all table pre_qs_setting.
					$scope.selectAllPreQsCategory();
					
					//Clear arrayInserPreQsCategory after insert into pre_qs_category
		    		$scope.arrayInserPreQsCategory = {};
				}
			}, function(response) {
				$log.log('[monitorUserCtrl]-> method $scope.insertPreQsCategory error: ' + response.statusText);
			});
    	} else {
    		$scope.appearNotify(false, 'Insert');
    	}
	}
    /*  End - Handle scan_job */
}]);