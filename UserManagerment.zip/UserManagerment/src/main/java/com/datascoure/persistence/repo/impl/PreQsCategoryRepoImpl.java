package com.datascoure.persistence.repo.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.datascoure.persistence.configuration.JsonConfig;
import com.datascoure.persistence.repo.Repository;

@Component
public class PreQsCategoryRepoImpl implements Repository {
	
	Logger LOGGER = LoggerFactory.getLogger(PreQsCategoryRepoImpl.class);
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private JsonConfig jsonConfig;
	
	private List<Map<String, Object>> rows;
	private boolean result;
	private String schema;
	private String table;
	
	@Override
	public void connection() {
		this.rows = new ArrayList<>();
		
		if(this.jsonConfig.getConnectDataDource() != null && this.jsonConfig.getArrSchemaAndTable() != null) {
			if(this.jsonConfig.getConnectDataDource().length > 2) {
				this.jdbcTemplate = new JdbcTemplate(this.jsonConfig.getConnectDataDource()[2]);
				this.setSchema(this.jsonConfig.getArrSchemaAndTable()[2][0]);
				this.setTable(this.jsonConfig.getArrSchemaAndTable()[2][1]);
			}
		}
	}

	/* Not use*/
	@Override
	public List<Map<String, Object>> syncUser(List<Map<String, Object>> list) {
		return null;
	}

	@Override
	public List<Map<String, Object>> findAll() {
		this.rows.clear();
		
		if(this.jsonConfig.getConnectDataDource().length > 2) {
			StringBuilder query = new StringBuilder();
			query.append("SELECT *");
			query.append(" FROM ");
			query.append(this.getSchema() + "." + this.getTable());
			LOGGER.info("Function: findAll, Query: {}", query.toString());
			
			try {
				this.rows = jdbcTemplate.queryForList(query.toString()); 
				LOGGER.info("Execute Query Statement: Success");
			} catch(Exception e) {
				e.printStackTrace();
				LOGGER.info("Execute Query Statement: FAIL");
			}
		}
		
		return this.rows;
	}

	@Override
	public List<Map<String, Object>> findGeneral() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, Object>> findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, Object>> findByUsernameAndFullName(String userName, String fullName) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
	@Override
	public List<Map<String, Object>> insert(String[][] params, boolean checkCopy) {
		StringBuilder query = new StringBuilder();
		query.append("INSERT INTO " + this.getSchema() + "." + this.getTable());
		query.append("(" + StringUtils.join(params[0], ", ") +")");	
		query.append("VALUES (" + StringUtils.join(params[1], ", ") + ")");		
		LOGGER.info("Function: insert, Query: {}", query.toString());
		
		try {
			jdbcTemplate.update(query.toString());
			
			LOGGER.info("Execute Query Statement: Success");
			
			return new ArrayList() {{ add(new HashMap() {{ put("result", true); }}); }};
		} catch (Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
		}
		
		return new ArrayList() {{ 
			add(new HashMap() {{ 
				put("result", false); 
			}});
		}};
	}

	@Override
	public boolean update(String[][] params) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public boolean update(String[] params) {
		StringBuilder query = new StringBuilder();
		query.append("UPDATE " + this.getSchema() + "." + this.getTable() + " SET ");
		query.append(params[0] + " = ");
		query.append("'" + params[1] + "'");
		query.append(" WHERE user_name ='" + params[2] + "'");
		LOGGER.info("Function: update, Query: {}", query.toString());
		
		try {
			jdbcTemplate.update(query.toString());
			
			LOGGER.info("Execute Query Statement: Success");
			this.result = true;
		} catch (Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
			this.result = false;
		}
		
		return result;
	}

	@Override
	public boolean delete(String[] params) {
		StringBuilder query = new StringBuilder();
		query.append("DELETE FROM ");
		query.append(this.getSchema() + "." + this.getTable());
		query.append(" WHERE user_name = '" + params[0] + "'");
		LOGGER.info("Function: delete, Query: {}", query.toString());
		
		try {
			jdbcTemplate.execute(query.toString());;
			LOGGER.info("Execute Query Statement: Success");
			this.result = true;
		} catch (Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
			this.result = false;
		}
		
		return result;
	}

	@Override
	public List<Map<String, Object>> getDataType() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

}
