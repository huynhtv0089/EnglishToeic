package com.datascoure.persistence.repo.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.datascoure.persistence.configuration.JsonConfig;
import com.datascoure.persistence.repo.Repository;

@Component
public class UserSettingRepoImpl implements Repository {
	Logger LOGGER = LoggerFactory.getLogger(UserSettingRepoImpl.class);
	
	@Autowired
	private JsonConfig jsonConfig;
	
	private JdbcTemplate jdbcTemplate;
	private List<Map<String, Object>> rows;
	private boolean result;
	private String schema;
	private String table;
	
	@Override
	public void connection() {
		rows = new ArrayList<>();
		
		if(this.jsonConfig.getConnectDataDource() != null && this.jsonConfig.getArrSchemaAndTable() != null) {
			this.jdbcTemplate = new JdbcTemplate(this.jsonConfig.getConnectDataDource()[1]);
			this.setSchema(this.jsonConfig.getArrSchemaAndTable()[1][0]);
			this.setTable(this.jsonConfig.getArrSchemaAndTable()[1][1]);
		}
	}
	
	public List<Map<String, Object>> syncUser(List<Map<String, Object>> list) {
		this.rows.clear();
		StringBuilder query = new StringBuilder();
		query.append("SELECT * FROM (");
			query.append("SELECT regexp_split_to_table(");
			query.append("'"+ list.get(0).get("user_id") +"', ';')::integer user_id,");
			query.append("regexp_split_to_table(");
			query.append("'"+ list.get(0).get("user_name") +"', ';')::text user_name");
			query.append(") as tmp");
		query.append(" WHERE");
			query.append(" user_id");
			query.append(" NOT IN");
			query.append(" (SELECT");
			query.append(" user_id");
			query.append(" FROM ");
			query.append(this.getSchema() + "." + this.getTable());
			query.append(")");
		query.append(" AND");
			query.append(" user_name");
			query.append(" NOT IN");
			query.append(" (SELECT");
			query.append(" user_name");
			query.append(" FROM ");
			query.append(this.getSchema() + "." + this.getTable());
			query.append(")");
		LOGGER.info("Execute function: syncUser");
		
		try {
			this.rows = jdbcTemplate.queryForList(query.toString()); 
			LOGGER.info("Execute Query Statement: Success");

			if(this.rows.size() != 0) {
				String[][] params = new String[2][2];
				params[0][0] = "user_id"; 
				params[0][1] = "user_name";
						
				for(int i=0; i<this.rows.size(); i++) {
					params[1][0] = String.valueOf(this.rows.get(i).get("user_id"));
					params[1][1] = String.valueOf(this.rows.get(i).get("user_name"));
					this.insert(params, false);
				}
			}
		} catch(Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
		}
		
		return null;
	}
	
	@Override
	public List<Map<String, Object>> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, Object>> findGeneral() {
		this.rows.clear();
		StringBuilder query = new StringBuilder();
		query.append("SELECT");
			query.append(" string_agg(user_id::text, ';') as id,");
			query.append(" string_agg(user_name::text, ';') as user_name,");
			query.append(" string_agg(scan_job::text, ';') as scan_job,");
			query.append(" string_agg(value::text, ';') as value_setting");
		query.append(" FROM ");
		query.append(this.getSchema() + "." + this.getTable());
		LOGGER.info("Execute function: findGeneral");
		
		try {
			this.rows = jdbcTemplate.queryForList(query.toString()); 
			LOGGER.info("Execute Query Statement: Success");
		} catch(Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
		}
		
		return rows;
	}
	
	@Override
	public List<Map<String, Object>> findByUsernameAndFullName(String userName, String fullName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Map<String, Object>> findById(String id) {
		this.rows.clear();
		StringBuilder query = new StringBuilder();
		query.append("SELECT * ");
		query.append(" FROM ");
		query.append(this.getSchema() + "." + this.getTable());
		query.append(" WHERE user_id = ");
		query.append(id);
		LOGGER.info("Function: findById, Query: {}", query.toString());
		
		try {
			this.rows = jdbcTemplate.queryForList(query.toString()); 
			LOGGER.info("Execute Query Statement: Success");
		} catch(Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
		}
		
		return rows;
	}

	@Override
	public List<Map<String, Object>> insert(String[][] params, boolean checkCopy) {
		StringBuilder query = new StringBuilder();
		
		query.append("INSERT INTO " + this.getSchema() + "." + this.getTable());
		query.append("(user_id, user_name, scan_job, value)");
		if(!checkCopy) {
			query.append("VALUES (" + params[1][0] + ", '" + params[1][1] + "', -1, 1)");
		} else {
			query.append("VALUES (" + params[1][0] + ", '" + params[1][1] + "', " + params[1][2] + ", " + params[1][3] + ")");
		}
		
		LOGGER.info("Function: insert, Query: {}", query.toString());
		
		try {
			jdbcTemplate.update(query.toString());
			
			LOGGER.info("Execute Query Statement: Success");
			this.result = true;
		} catch (Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
			this.result = false;
		}
		
		return null;
	}

	@Override
	public boolean update(String[][] params) {
		StringBuilder query = new StringBuilder();
		query.append("UPDATE " + this.getSchema() + "." + this.getTable() + " SET ");
		query.append(params[1][0] + " = ");
		query.append("'" + params[2][0] + "'");
		query.append(" WHERE user_id IN(");
		for(int i=0; i<params[0].length; i++) {
			if(i == params[0].length-1) {
				query.append(params[0][i]);
				break;
			}
			query.append(params[0][i] + ", ");
		}
		query.append(")");
		LOGGER.info("Function: update, Query: {}", query.toString());
		
		try {
			jdbcTemplate.update(query.toString());
			
			LOGGER.info("Execute Query Statement: Success");
			this.result = true;
		} catch (Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
			this.result = false;
		}
		
		return result;
	}
	
	@Override
	public boolean update(String[] params) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(String[] params) {
		StringBuilder query = new StringBuilder();
		query.append("DELETE FROM ");
		query.append(this.getSchema() + "." + this.getTable());
		query.append(" WHERE user_id IN(");
		for(int i=0; i<params.length; i++) {
			if(i == params.length-1) {
				query.append(params[i]);
				break;
			}
			query.append(params[i] + ", ");
		}
		query.append(")");
		LOGGER.info("Function: delete, Query: {}", query.toString());
		
		try {
			jdbcTemplate.execute(query.toString());;
			LOGGER.info("Execute Query Statement: Success");
			this.result = true;
		} catch (Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
			this.result = false;
		}
		
		return result;
	}
	
	@Override
	public List<Map<String, Object>> getDataType() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

}
