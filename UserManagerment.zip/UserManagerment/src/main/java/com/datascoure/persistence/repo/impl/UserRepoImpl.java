package com.datascoure.persistence.repo.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.datascoure.persistence.configuration.JsonConfig;
import com.datascoure.persistence.repo.Repository;

@Component
public class UserRepoImpl implements Repository {
	Logger LOGGER = LoggerFactory.getLogger(UserRepoImpl.class);
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private JsonConfig jsonConfig;
	
	@Autowired
	private UserSettingRepoImpl userSettingRepo;
	
	private List<Map<String, Object>> rows;
	private List<Map<String, Object>> dataType;
	private boolean result;
	private String schema;
	private String table;
	
	@Override
	public void connection() {
		rows = new ArrayList<>();
		dataType = new ArrayList<>();
		
		if(this.jsonConfig.getConnectDataDource() != null && this.jsonConfig.getArrSchemaAndTable() != null) {
			this.jdbcTemplate = new JdbcTemplate(this.jsonConfig.getConnectDataDource()[0]);
			this.setSchema(this.jsonConfig.getArrSchemaAndTable()[0][0]);
			this.setTable(this.jsonConfig.getArrSchemaAndTable()[0][1]);
			this.getDataType();
		}
	}
	
	public List<Map<String, Object>> syncUser(List<Map<String, Object>> list) {
		this.rows.clear();
		StringBuilder query = new StringBuilder();
		query.append("SELECT string_agg(");
		query.append("id");
		query.append("::text, ';') as user_id,");
		query.append(" string_agg(");
		query.append("user_name");
		query.append("::text, ';') as user_name");
		query.append(" FROM ");
		query.append(this.getSchema() + "." + this.getTable());
		LOGGER.info("Execute function: syncUser");
		
		try {
			this.rows = jdbcTemplate.queryForList(query.toString()); 
			LOGGER.info("Execute Query Statement: Success");
		} catch(Exception e) {
			e.printStackTrace();
			LOGGER.info("Execute Query Statement: FAIL");
		}
		
		return this.rows;
	}
	
	@Override
	public List<Map<String, Object>> findAll() {
		this.rows.clear();
		StringBuilder query = new StringBuilder();
		query.append("SELECT * ");
		query.append(" FROM ");
		query.append(this.getSchema() + "." + this.getTable());
		LOGGER.info("Function: findAll, Query: {}", query.toString());
		
		try {
			this.rows = jdbcTemplate.queryForList(query.toString()); 
			LOGGER.info("Execute Query Statement: Success");
		} catch(Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
		}
		
		return this.rows;
	}
	
	@Override
	public List<Map<String, Object>> findGeneral() {
		this.rows.clear();
		Map<String, Object> pre_qs_setting = this.userSettingRepo.findGeneral().get(0);
		StringBuilder query = new StringBuilder();
		
		query.append("SELECT");
			query.append(" u.id, u.user_name, u.full_name, pre_qs_setting.scan_job, pre_qs_setting.value_setting");
		query.append(" FROM ");
			query.append(this.getSchema() + "." + this.getTable() + " u,");
			query.append(" (SELECT");
				query.append(" regexp_split_to_table('");
				query.append(pre_qs_setting.get("id"));
				query.append("', ';')::integer id,");
				
				query.append(" regexp_split_to_table('");
				query.append(pre_qs_setting.get("user_name"));
				query.append("', ';')::text user_name,");
			
				query.append(" regexp_split_to_table('");
				query.append(pre_qs_setting.get("scan_job"));
				query.append("', ';')::character varying scan_job,");
				
				query.append(" regexp_split_to_table('");
				query.append(pre_qs_setting.get("value_setting"));
				query.append("', ';')::integer value_setting)");
			query.append(" as pre_qs_setting");
		query.append(" WHERE");
			query.append(" u.id = pre_qs_setting.id");
			query.append(" AND");
			query.append(" u.user_name = pre_qs_setting.user_name");
		
		//LOGGER.info("Function: findGeneral, Query: {}", query.toString());
		LOGGER.info("Execute function: findGeneral");
			
		try {
			this.rows = jdbcTemplate.queryForList(query.toString());
			LOGGER.info("Execute Query Statement: Success");
		} catch(Exception e) {
			e.printStackTrace();
			LOGGER.info("Execute Query Statement: FAIL");
		}
		
		return rows;
	}
	
	@Override
	public List<Map<String, Object>> findByUsernameAndFullName(String userName, String fullName) {
		this.rows.clear();
		StringBuilder query = new StringBuilder();
		query.append("SELECT ");
		for (int i=0; i<PARAMS_USER_RIGHT.length; i++) {
			if(i == PARAMS_USER_RIGHT.length-1) {
				query.append(PARAMS_USER_RIGHT[i] + " ");
			} else {
				query.append(PARAMS_USER_RIGHT[i] + ", ");
			}
		}
		query.append("FROM ");
		query.append(this.getSchema() + "." + this.getTable());
		query.append(" WHERE user_name = '");
		query.append(userName);
		query.append("' AND full_name = '");
		query.append(fullName);
		query.append("'");
		LOGGER.info("Function: findByUsernameAndFullName, Query: {}", query.toString());
		
		try {
			this.rows = jdbcTemplate.queryForList(query.toString()); 
			LOGGER.info("Execute Query Statement: Success");
		} catch(Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
		}
		
		return rows;
	}

	@Override
	public List<Map<String, Object>> findById(String id) {
		this.rows.clear();
		StringBuilder query = new StringBuilder();
		query.append("SELECT *");
		query.append(" FROM ");
		query.append(this.getSchema() + "." + this.getTable());
		query.append(" WHERE id = ");
		query.append(id);
		LOGGER.info("Function: findById, Query: {}", query.toString());
		
		try {
			this.rows = jdbcTemplate.queryForList(query.toString());
			
			int count = 0;
			boolean checkNull = false;
			String columns = "";
			
			for(String key : this.rows.get(0).keySet()) {
				if(this.rows.get(0).get(key) == null) {
					if(this.dataType.get(count).toString().indexOf("boolean") != -1) {
						columns += key + "=false" + ", ";
					} else {
						columns += key + "='', ";
					}
					checkNull = true;
				}
				count++;
			}
			
			if(checkNull) {
				this.rows.clear();
				
				String queryUpdate = "UPDATE " + this.getSchema() + "." + this.getTable() + " SET " + columns.substring(0, (columns.length()-2)) + " WHERE id=" + id;
				LOGGER.info("Function: findById, Query update value is null: {}", queryUpdate.toString());
				jdbcTemplate.update(queryUpdate.toString());
				
				this.rows = jdbcTemplate.queryForList(query.toString());
			}
			
			LOGGER.info("Execute Query Statement: Success");
		} catch(Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
		}
		
		return rows;
	}
	
	@Override
	public List<Map<String, Object>> insert(String[][] PARAMS_USER_RIGHT, boolean checkCopy) {
		this.rows.clear();
		StringBuilder query = new StringBuilder();
		
		query.append("INSERT INTO " + this.getSchema() + "." + this.getTable() + "(");
		for (int i=0;i<PARAMS_USER_RIGHT[0].length; i++) {
			if (i == (PARAMS_USER_RIGHT[0].length-1)) {
				query.append(PARAMS_USER_RIGHT[0][i] + ") ");
				break;
			}
			query.append(PARAMS_USER_RIGHT[0][i] + ", ");
		}
		
		query.append("VALUES (");
		for (int i=0;i<PARAMS_USER_RIGHT[1].length; i++) {
			if (i == (PARAMS_USER_RIGHT[1].length-1)) {
				query.append("'" + PARAMS_USER_RIGHT[1][i] + "') ");
				break;
			}
			query.append("'" + PARAMS_USER_RIGHT[1][i] + "', ");
		}
		
		LOGGER.info("Function: insert, Query: {}", query.toString());
		
		List<Map<String, Object>> rowTmp = null;
		try {
			jdbcTemplate.update(query.toString());
			
			LOGGER.info("Execute Query Insert Statement: Success");
			rowTmp = this.findByUsernameAndFullName(PARAMS_USER_RIGHT[1][0], PARAMS_USER_RIGHT[1][1]);
			
			if(!checkCopy) {
				String id = String.valueOf(rowTmp.get(0).get("id"));
				String[][] params = new String[2][2];
				params[1][0] = id;
				params[1][1] = PARAMS_USER_RIGHT[1][0];
				this.userSettingRepo.insert(params, false);
				
				rowTmp.get(0).put("scan_job", "-1");
				rowTmp.get(0).put("value", "1");
				LOGGER.info("Sync user both table: Success");
			}
		} catch (Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
		}
		
		return rowTmp; 
	}

	@Override
	public boolean update(String[][] params) {
		StringBuilder query = new StringBuilder();
		query.append("UPDATE " + this.getSchema() + "." + this.getTable() + " SET ");
		query.append(params[1][0] + " = ");
		query.append("'" + params[2][0] + "'");
		query.append(" WHERE id IN(");
		for(int i=0; i<params[0].length; i++) {
			if(i == params[0].length-1) {
				query.append(params[0][i]);
				break;
			}
			query.append(params[0][i] + ", ");
		}
		query.append(")");
		LOGGER.info("Function: update, Query: {}", query.toString());
		
		try {
			jdbcTemplate.update(query.toString());
			
			LOGGER.info("Execute Query Statement: Success");
			this.result = true;
		} catch (Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
			this.result = false;
		}
		
		return result;
	}
	
	@Override
	public boolean update(String[] params) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(String[] params) {
		StringBuilder query = new StringBuilder();
		query.append("DELETE FROM ");
		query.append(this.getSchema() + "." + this.getTable());
		query.append(" WHERE id IN(");
		for(int i=0; i<params.length; i++) {
			if(i == params.length-1) {
				query.append(params[i]);
				break;
			}
			query.append(params[i] + ", ");
		}
		query.append(")");
		LOGGER.info("Function: delete, Query: {}", query.toString());
		
		try {
			jdbcTemplate.execute(query.toString());;
			LOGGER.info("Execute Query Statement: Success");
			this.result = true;
		} catch (Exception e) {
			LOGGER.info("Execute Query Statement: FAIL");
			this.result = false;
		}
		
		this.userSettingRepo.delete(params);
		return result;
	}
	
	@Override
	public List<Map<String, Object>> getDataType() {
		StringBuilder query = new StringBuilder();
		query.append("SELECT");
		query.append(" column_name");
		query.append(", data_type");
		query.append(" FROM");
		query.append(" information_schema.columns");
		query.append(" WHERE table_name = ");
		query.append("'" + this.getTable() + "'");
		query.append(" and table_schema = ");
		query.append("'" + this.getSchema() + "'");
		LOGGER.info("Function: getDataType, Query: {}", query.toString());
		
		try {
			this.dataType = jdbcTemplate.queryForList(query.toString());
			LOGGER.info("Execute Query Statement: Success");
		} catch(Exception e) {
			e.printStackTrace();
			LOGGER.info("Execute Query Statement: FAIL");
		}
		return this.dataType;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

}
