package com.datascoure.persistence.configuration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

import com.datascoure.persistence.domain.Datasource;
import com.google.gson.Gson;

@Component
public class JsonConfig {
	private static final Logger LOGGER = LoggerFactory.getLogger(JsonConfig.class);
	
	public Datasource[] datasources;
	public Datasource objDatasources;
	public int length;
	public DriverManagerDataSource[] connectDataDource;
	public String[][] arrSchemaAndTable;
	
	public boolean parseJsonConfig(String username) throws IOException {
		String strJson;
		
		try {
			strJson = new String(Files.readAllBytes(new File(this.pathResourceJSON("build")).toPath()), StandardCharsets.UTF_8);
		} catch (Exception e) {
			LOGGER.error("Read file JSON fault, read again");
			strJson = new String(Files.readAllBytes(new File(this.pathResourceJSON("dev")).toPath()), StandardCharsets.UTF_8);
		}
		
		this.datasources = new Gson().fromJson(strJson, Datasource[].class);
		this.datasources = Arrays.stream(this.datasources).filter(
				e -> ArrayUtils.indexOf(e.getUsers(), username) != -1
		).toArray(Datasource[]::new);
		
		if(this.datasources.length > 0) {
			this.connection(this.datasources[0]);
			this.schemaAndTable(this.datasources[0]);
		} else {
			LOGGER.info("Sign in with username: {} is fault.", username);
			return false;
		}
		
		return true;
	}
	
	/**
	 * Connection database
	 * 
	 * @param objDatasource
	 */
	public void connection(Datasource objDatasource) {
		this.length = objDatasource.getDatabases().length;
		this.connectDataDource = new DriverManagerDataSource[this.length];
		
		for(int i=0; i<this.length; i++) {
			DriverManagerDataSource dataSource = new DriverManagerDataSource();
			dataSource.setDriverClassName("org.postgresql.Driver");
			dataSource.setUrl("jdbc:postgresql://" + objDatasource.getServer() + "/" + objDatasource.getDatabases()[i].getDatabase());
	        dataSource.setUsername(objDatasource.getUsername());
	        dataSource.setPassword(objDatasource.getPassword());
	        
	        this.connectDataDource[i] = dataSource;
	        LOGGER.info("Save database: {} of server: {}", objDatasource.getDatabases()[i].getDatabase(), objDatasource.getServer());
		}
	}
	
	/**
	 * Container Schema and Table
	 * 
	 * @param objDatasource
	 */
	public void schemaAndTable(Datasource objDatasource) {
		this.arrSchemaAndTable = new String[this.length][this.length];
		
		for(int i=0; i<this.length; i++) {
			String schema = objDatasource.getDatabases()[i].getSchema();
			String table = objDatasource.getDatabases()[i].getTable();
			
			this.arrSchemaAndTable[i][0] = schema;
			this.arrSchemaAndTable[i][1] = table;
			LOGGER.info("Save schema: {} and table: {} of database: {}", schema, table, objDatasource.getDatabases()[i].getDatabase());
		}
	}
	
	public void changeProjectCurrent(Datasource objDatasource) {
		this.connection(objDatasource);
		this.schemaAndTable(objDatasource);
	}

	public Datasource[] getDatasources() {
		return datasources;
	}

	public DriverManagerDataSource[] getConnectDataDource() {
		return connectDataDource;
	}

	public String[][] getArrSchemaAndTable() {
		return arrSchemaAndTable;
	}
	
	public String pathResourceJSON(String opt) throws IOException {
		StringBuilder fileJson = new StringBuilder();
		if("build".equals(opt)) {
			fileJson.append(System.getProperty("user.dir"));
		} else if("dev".equals(opt)) { 
			fileJson.append(System.getProperty("user.dir") + File.separator + "src/main/resources");
		}
		
		fileJson.append(File.separator);
		fileJson.append("config");
		fileJson.append(File.separator);
		fileJson.append("datasources.json");
		LOGGER.info("JSON path: {}", fileJson.toString());
		
		return fileJson.toString();
		
	}
}
