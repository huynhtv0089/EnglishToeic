package com.datascoure.persistence.domain;

public class Datasource {
	
	private String server;
	
	private Databases[] databases;
	
	private String username;
	
	private String password;
	
	private String project;
	
	private String[] users;
	
	private String environment;
	
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	
	public Databases[] getDatabases() {
		return databases;
	}
	public void setDatabases(Databases[] databases) {
		this.databases = databases;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	
	public String[] getUsers() {
		return users;
	}
	public void setUsers(String[] users) {
		this.users = users;
	}
	
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	
}
