package com.datascoure.persistence.repo;

import java.util.List;
import java.util.Map;

public interface Repository {
	public static final String[] PARAMS_USER_RIGHT = {"id", "user_name", "full_name"};
	
	public void connection();
	
	public List<Map<String, Object>> syncUser(List<Map<String, Object>> list);
	
	public List<Map<String, Object>> findAll();
	
	public List<Map<String, Object>> findGeneral();
	
	public List<Map<String, Object>> findById(String id);
	
	public List<Map<String, Object>> findByUsernameAndFullName(String userName, String fullName);
	
	public List<Map<String, Object>> insert(String[][] params, boolean checkCopy);
	
	public boolean update(String[][] params);
	public boolean update(String[] params);
	
	public boolean delete(String[] params);
	
	public List<Map<String, Object>> getDataType();
}
