package com.datascoure.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.datascoure.services.PreQsCategoryService;

@RestController
public class preQsCategory {
	
	@Autowired
	private PreQsCategoryService preQsCategoryService;
	
	@RequestMapping(value="/getAllPreQsCategory", method=RequestMethod.GET)
	public ResponseEntity<List<Map<String, Object>>> allPreQsCategory() {
		
		List<Map<String, Object>> result = null;
		
		try {
			result = preQsCategoryService.getListPreQsSetting();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<List<Map<String, Object>>>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/insertPreQsCategory", method=RequestMethod.POST)
	public ResponseEntity<Boolean> insertPreQsCategory(@RequestBody String[][] params) {
		boolean result = this.preQsCategoryService.insertPreQsSetting(params);
		
		return new ResponseEntity<Boolean>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/updatePreQsCategory", method=RequestMethod.POST)
	public ResponseEntity<Boolean> updatePreQsCategory(@RequestBody String[] params) {
		boolean result = this.preQsCategoryService.updatePreQsSetting(params);
		
		return new ResponseEntity<Boolean>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/deletePreQsCategory", method=RequestMethod.POST)
	public ResponseEntity<Boolean> deletePreQsCategory(@RequestBody String[] params) {
		boolean result = this.preQsCategoryService.deletePreQsSetting(params);
		
		return new ResponseEntity<Boolean>(result, HttpStatus.OK);
	}
	
}
