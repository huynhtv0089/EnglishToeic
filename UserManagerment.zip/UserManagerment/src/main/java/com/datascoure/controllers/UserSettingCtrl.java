package com.datascoure.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.datascoure.services.UserSettingService;

@RestController
public class UserSettingCtrl {
	@Autowired
	private UserSettingService userSettingService;
	
	@RequestMapping(value="/getUserSetting", method=RequestMethod.POST)
	public ResponseEntity<List<Map<String, Object>>> userSettingByUsername(@RequestBody String[] params) {
		List<Map<String, Object>> result = userSettingService.getUserSetting(params);
		
		return new ResponseEntity<List<Map<String, Object>>>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/updateInfoUserSetting", method=RequestMethod.POST)
	public ResponseEntity<Boolean> updateInfo(@RequestBody String[][] params) {
		boolean result = userSettingService.updateUserSetting(params);
		
		return new ResponseEntity<Boolean>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/insertUserSetting", method=RequestMethod.POST)
	public ResponseEntity<Boolean> handleInsertUserSetting(@RequestBody String[][] params) {
		boolean result = userSettingService.insertUserSetting(params);
		
		return new ResponseEntity<Boolean>(result, HttpStatus.OK);
	}
	
}
