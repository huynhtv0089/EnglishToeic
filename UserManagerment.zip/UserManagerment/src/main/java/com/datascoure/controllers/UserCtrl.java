package com.datascoure.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.datascoure.services.UserService;

@RestController
public class UserCtrl {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/getAllUser", method=RequestMethod.GET)
	public ResponseEntity<List<Map<String, Object>>> allUser() {
		List<Map<String, Object>> result = null;
		
		try {
			result = userService.getListUser();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<List<Map<String, Object>>>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/getUserById", method=RequestMethod.POST)
	public ResponseEntity<List<Map<String, Object>>> userById(@RequestBody String id) {
		List<Map<String, Object>> result = null;
		
		try {
			result = userService.getUserById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<List<Map<String, Object>>>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/getUserInserted", method=RequestMethod.POST)
	public ResponseEntity<List<Map<String, Object>>> userInserted(@RequestBody String[] params) {
		List<Map<String, Object>> result = null;
		
		try {
			result = userService.getUserInserted(params[0], params[1]);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<List<Map<String, Object>>>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/updateInfoUser", method=RequestMethod.POST)
	public ResponseEntity<Boolean> updateInfo(@RequestBody String[][] params) {
		boolean result = userService.updateUser(params);
		
		return new ResponseEntity<Boolean>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/insertUser", method=RequestMethod.POST)
	public ResponseEntity<List<Map<String, Object>>> handleInsertUser(@RequestBody String[][] params) {
		
		List<Map<String, Object>> result = null;
		
		try {
			result = userService.insertUser(params);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<List<Map<String, Object>>>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/deleteUser", method=RequestMethod.POST)
	public ResponseEntity<Boolean> handleDeleteUser(@RequestBody String[] params) {
		boolean result = userService.deleteUser(params);
		
		return new ResponseEntity<Boolean>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/dataTypeUser", method=RequestMethod.GET)
	public ResponseEntity<List<Map<String, Object>>> getListDataType() {
		List<Map<String, Object>> result = null;
		
		try {
			result = userService.listDataType();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<List<Map<String, Object>>>(result, HttpStatus.OK);
	}
}
