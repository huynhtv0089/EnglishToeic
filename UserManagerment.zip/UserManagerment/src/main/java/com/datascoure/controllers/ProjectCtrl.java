package com.datascoure.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.datascoure.persistence.domain.Datasource;
import com.datascoure.services.ProjectService;

@RestController
public class ProjectCtrl {
	
	@Autowired
	private ProjectService projectService;
	
	@RequestMapping(value="/getProjects", method=RequestMethod.GET)
	public ResponseEntity<Datasource[]> allProjects() {
		Datasource[] result = projectService.getAllProjects();
		
		return new ResponseEntity<Datasource[]>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/changeProjects", method=RequestMethod.POST)
	public ResponseEntity<Boolean> chooseProject(@RequestBody Datasource datasource) {
		
		Boolean result = projectService.changeDatasource(datasource);
		
		return new ResponseEntity<Boolean>(result, HttpStatus.OK);
	}
}
