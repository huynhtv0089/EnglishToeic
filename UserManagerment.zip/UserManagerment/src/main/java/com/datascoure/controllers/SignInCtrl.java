package com.datascoure.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.datascoure.persistence.configuration.JsonConfig;
import com.datascoure.persistence.repo.impl.PreQsCategoryRepoImpl;
import com.datascoure.persistence.repo.impl.UserRepoImpl;
import com.datascoure.persistence.repo.impl.UserSettingRepoImpl;
import com.datascoure.services.ProjectService;

@RestController
public class SignInCtrl {
	
	@Autowired
	private JsonConfig jsonConfig;
	
	@Autowired
	private UserRepoImpl userRepo;
	
	@Autowired
	private UserSettingRepoImpl userSettingRepo;
	
	@Autowired
	private PreQsCategoryRepoImpl preQsCategoryRepoImpl;
	
	@Autowired
	private ProjectService projectService;
	
	@RequestMapping(value="/startConfig", method=RequestMethod.POST)
	public ResponseEntity<Boolean> usersLogin(@RequestBody String username) throws IOException {
		final boolean result = jsonConfig.parseJsonConfig(username);
		
		if(result) {
			userRepo.connection();
			userSettingRepo.connection();
			projectService.syncUser();
			preQsCategoryRepoImpl.connection();
			
			return new ResponseEntity<Boolean>(result, HttpStatus.OK);
		} 
		
		return new ResponseEntity<Boolean>(false, HttpStatus.OK);
	}
}
