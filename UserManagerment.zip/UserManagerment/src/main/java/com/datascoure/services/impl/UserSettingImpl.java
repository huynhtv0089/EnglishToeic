package com.datascoure.services.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datascoure.persistence.repo.impl.UserSettingRepoImpl;
import com.datascoure.services.UserSettingService;

@Service
public class UserSettingImpl implements UserSettingService {

	@Autowired
	private UserSettingRepoImpl userSettingRepo; 
	
	@Override
	public List<Map<String, Object>> getUserSetting(String[] params) {
		
		List<Map<String, Object>> row = null;
		try {
			row = userSettingRepo.findById(params[0]);
			if(row.size() == 0) {
				insertUserSetting(new String[][] {{}, {params[0], params[1]}});
				row = userSettingRepo.findById(params[0]);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return row;
	}
	
	@Override
	public boolean insertUserSetting(String[][] params) {
		try {
			userSettingRepo.insert(params, Boolean.parseBoolean(params[2][0]));
			return true;
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	@Override
	public boolean updateUserSetting(String[][] params) {
		if(params[0].length != 0 && params[1].length != 0 && params[2].length != 0) {
			return userSettingRepo.update(params);
		}
			
		return false;
	}

}
