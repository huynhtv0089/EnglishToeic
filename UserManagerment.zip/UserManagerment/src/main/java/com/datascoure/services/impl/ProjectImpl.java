package com.datascoure.services.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datascoure.persistence.configuration.JsonConfig;
import com.datascoure.persistence.domain.Datasource;
import com.datascoure.persistence.repo.impl.PreQsCategoryRepoImpl;
import com.datascoure.persistence.repo.impl.UserRepoImpl;
import com.datascoure.persistence.repo.impl.UserSettingRepoImpl;
import com.datascoure.services.ProjectService;

@Service
public class ProjectImpl implements ProjectService {
	
	@Autowired
	private JsonConfig jsonConfig;
	
	@Autowired
	private UserRepoImpl userRepo; 
	
	@Autowired
	private UserSettingRepoImpl userSettingRepo;
	
	@Autowired
	private PreQsCategoryRepoImpl preQsCategoryRepoImpl; 
		
	@Override
	public void syncUser() {
		userSettingRepo.syncUser(userRepo.syncUser(new ArrayList<>()));
	}
	
	@Override
	public Datasource[] getAllProjects() {
		final Datasource[] arrDatasource = jsonConfig.getDatasources();
		
		if(arrDatasource.length != 0) {
			return jsonConfig.getDatasources();
		} else {
			return null;
		}
	}
	
	@Override
	public Boolean changeDatasource(Datasource datasource) {
		jsonConfig.changeProjectCurrent(datasource);
		
		userRepo.connection();
		userSettingRepo.connection();
		preQsCategoryRepoImpl.connection();
		
		this.syncUser();
		return true;
	}
	
}
