package com.datascoure.services;

import java.util.List;
import java.util.Map;

public interface PreQsCategoryService {
	public List<Map<String, Object>> getListPreQsSetting();
	public boolean insertPreQsSetting(String[][] params);
	public boolean updatePreQsSetting(String[] params);
	public boolean deletePreQsSetting(String[] params);
}
