package com.datascoure.services;

import java.util.List;
import java.util.Map;

public interface UserSettingService {
	public List<Map<String, Object>> getUserSetting(String[] params);
	public boolean insertUserSetting(String[][] params); 
	public boolean updateUserSetting(String[][] params);
}
