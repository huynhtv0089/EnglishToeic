package com.datascoure.services.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datascoure.persistence.repo.impl.UserRepoImpl;
import com.datascoure.services.UserService;

@Service
public class UserImpl implements UserService {
	
	@Autowired
	private UserRepoImpl userRepo; 
	
	@Override
	public List<Map<String, Object>> getListUser() {
		List<Map<String, Object>> row = null;
		
		try {
			row = userRepo.findGeneral();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return row;
	}
	
	@Override
	public List<Map<String, Object>> getUserById(String id) {
		List<Map<String, Object>> row = null;
		try {
			row = userRepo.findById(id);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return row;
	}
	
	@Override
	public List<Map<String, Object>> insertUser(String[][] params) {
		List<Map<String, Object>> row = null;
		if(params[0].length != 0 && params[1].length != 0 && params[2].length != 0) { 
			try {
				row = userRepo.insert(params, Boolean.parseBoolean(params[2][0]));
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return row;
	}
	
	@Override
	public List<Map<String, Object>> getUserInserted(String userName, String fullName) {
		List<Map<String, Object>> row = null;
		try {
			row = userRepo.findByUsernameAndFullName(userName, fullName);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return row;
	}
	
	@Override
	public boolean updateUser(String[][] params) {
		if(params[0].length != 0 && params[1].length != 0 && params[2].length != 0) {
			return userRepo.update(params);
		}
			
		return false;
	}
	
	@Override
	public boolean deleteUser(String[] params) {
		if(params.length != 0) {
			return userRepo.delete(params);
		}
		return false;
	}
	
	@Override
	public List<Map<String, Object>> listDataType() {
		List<Map<String, Object>> row = null;
		try {
			row = userRepo.getDataType();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return row;
	}

}
