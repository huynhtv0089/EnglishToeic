package com.datascoure.services.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datascoure.persistence.repo.impl.PreQsCategoryRepoImpl;
import com.datascoure.services.PreQsCategoryService;

@Service
public class PreQsCategoryImpl implements PreQsCategoryService {
	
	@Autowired
	private PreQsCategoryRepoImpl preQsCategoryRepoImpl; 

	@Override
	public List<Map<String, Object>> getListPreQsSetting() {
		return preQsCategoryRepoImpl.findAll();
	}

	@Override
	public boolean insertPreQsSetting(String[][] params) {
		return (boolean)preQsCategoryRepoImpl.insert(params, false).get(0).get("result");
	}

	@Override
	public boolean updatePreQsSetting(String[] params) {
		return preQsCategoryRepoImpl.update(params);
	}

	@Override
	public boolean deletePreQsSetting(String[] params) {
		return preQsCategoryRepoImpl.delete(params);
	}
	
}
