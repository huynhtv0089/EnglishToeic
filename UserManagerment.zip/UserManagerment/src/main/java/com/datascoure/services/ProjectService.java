package com.datascoure.services;

import com.datascoure.persistence.domain.Datasource;

public interface ProjectService {
	public void syncUser();
	public Datasource[] getAllProjects();
	public Boolean changeDatasource(Datasource datasource);
}
