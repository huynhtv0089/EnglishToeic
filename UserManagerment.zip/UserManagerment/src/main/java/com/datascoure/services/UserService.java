package com.datascoure.services;

import java.util.List;
import java.util.Map;

public interface UserService {
	public List<Map<String, Object>> getListUser();
	public List<Map<String, Object>> getUserById(String id);
	public List<Map<String, Object>>  insertUser(String[][] params);
	public List<Map<String, Object>> getUserInserted(String userName, String fullName);
	public boolean updateUser(String[][] params);
	public boolean deleteUser(String[] params);
	public List<Map<String, Object>> listDataType();
}
