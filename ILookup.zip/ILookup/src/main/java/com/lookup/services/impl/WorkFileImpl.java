package com.lookup.services.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.lookup.services.WorkerFile;


@Service
public class WorkFileImpl implements WorkerFile {
	private static final Logger LOGGER = LoggerFactory.getLogger(WorkFileImpl.class);
	private static String EXTENSION = ".csv";
	
	@Value("${app.file-info.url}")
	private String url;
	
	@Override
	public List<String> getChildFolders() {
		LOGGER.info("getChildFolders() | URL: " + url);
		
		File directoryRoot = new File(url);
		if(directoryRoot.isDirectory() && directoryRoot.list().length > 0){
			List<String> listChildFolder = new ArrayList<>();
			File[] lstDirectory = directoryRoot.listFiles();
			//for (int i=0; i<lstDirectory.length; i++) {
			for(File folder : lstDirectory) {
				if(folder.isDirectory() == true) {
					String childDirectory =  folder.getName();
					listChildFolder.add(childDirectory);
				}
			}
			return listChildFolder;
		} else {
			LOGGER.info("getChildFolders(): URL isn't directory");
		}
		
		return null;
	}
	
	@Override
	public List<String[]> getListFile(String directoryName) {
		LOGGER.info("getListFile() | Params: [directory: {}]", directoryName);
		LOGGER.info("getListFile() | URL: " + url + "\\" + directoryName);
		
		File directory = new File(url + File.separator + directoryName);
		if(directory.isDirectory() && directory.list().length > 0) {
			List<String[]> listFiles = new ArrayList<>();
			File[] files = directory.listFiles();
			for(File file : files) {
				String[] containerData = new String[2];
				containerData[0] = directoryName;
				containerData[1] = file.getName().split("\\.")[0];
				listFiles.add(containerData);
			}
			return listFiles;
		} else {
			LOGGER.info("getListFile(): URL isn't directory");
		}
		
		return null;
	}
	
	@Override
	public String getMetaDataFile(String directory, String fileName) {
		LOGGER.info("getMetaDataFile() | Params: [directory: {}, fileName: {}]", directory, fileName);
		String file = url + File.separator + directory + File.separator + fileName + EXTENSION;
		LOGGER.info("getMetaDataFile() | URL: " + file);
		try {
			//List<String> data = new ArrayList<>();
			String strData = new String(Files.readAllBytes(Paths.get(file)));
			//data.add(strData);
			
			return strData;
		} catch (IOException e) {
			e.printStackTrace();
			LOGGER.info(e.getMessage(), e);
		}
		return null;

	}

}
