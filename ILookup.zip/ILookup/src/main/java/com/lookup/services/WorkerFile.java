package com.lookup.services;

import java.util.List;

public interface WorkerFile {
	public List<String> getChildFolders();
	public List<String[]> getListFile(String fileName);
	public String getMetaDataFile(String directory, String fileName);
}
