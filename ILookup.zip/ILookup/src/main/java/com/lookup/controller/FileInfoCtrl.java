package com.lookup.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lookup.services.WorkerFile;

@RestController
@RequestMapping("/file-info")
public class FileInfoCtrl {
	private static final Logger LOGGER = LoggerFactory.getLogger(FileInfoCtrl.class);
	
	/* Service */
	@Autowired
	private WorkerFile workerFile;
	
	@RequestMapping(value="/directorys", method = RequestMethod.GET)
	public ResponseEntity<List<String>> getListDirectorys() {
		LOGGER.info("getListDirectorys(): load child directorys");
		List<String> listDirectorys = workerFile.getChildFolders();
		
		return new ResponseEntity<List<String>>(listDirectorys, HttpStatus.OK);
	}
	
	@RequestMapping(value="/chooseDirectory", method = RequestMethod.POST)
    public ResponseEntity<List<String[]>> getListFiles(@RequestBody String nameDirectory) {
		LOGGER.info("getListFiles(): load list files | Params: {}", nameDirectory);
		List<String[]> listFiles = workerFile.getListFile(nameDirectory);
		
        return new ResponseEntity<List<String[]>>(listFiles, HttpStatus.OK);
    }
	
	@RequestMapping(value="/chooseFile", method=RequestMethod.POST, produces={"application/text"})
    public ResponseEntity<String> getDataFile(@RequestBody String[] params) {
		LOGGER.info("getListFiles(): load meta data in file | Params: [{},{}]", params[0], params[1]);
		String data = workerFile.getMetaDataFile(params[0], params[1]);
		
        return new ResponseEntity<String>(data, HttpStatus.OK);
    }
	
}
