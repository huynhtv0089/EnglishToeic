var app = angular.module('myApp', []);

app.controller('myCtrl', ['$scope', '$http', function($scope, $http) {
	var metaData;
	$scope.myKeyWord = '';
	$scope.listLimits = ['100', '300', '500', 'ALL'];
	$scope.limit = $scope.listLimits[0];
	
	$http({
        method : "GET",
        url : "/file-info/directorys"
    }).then(function mySuccess(success) {
    	$scope.listChildDirectorys = success.data;
        $scope.directory = success.data[0];
        $scope.chooseDirectory(success.data[0]);
    }, function myError(response) {
        console.log('Error url /file-info/directorys: ' + response);
    });
	
	$scope.chooseDirectory = function(index) {
		$http.post(
			'/file-info/chooseDirectory',
			index
		).then(function mySuccess(success) {
			$scope.myKeyWord = '';
			$scope.resultTable = '';
			for(var i=0; i<success.data.length; i++) {
	        	if(success.data[i] === 'DE') {
	        		success.data.splice(0, 0, success.data.splice(i, 1)[0]);
	        		break;
	        	}
	        }
	        $scope.dataSelect = success.data;
	        $scope.file = success.data[0];
	        $scope.chooseFile($scope.file);
	    }, function myError(response) {
	    	console.log('1. response: ' + JSON.stringify(response));
	        console.log('Error method chooseDirectory(): ' + response);
	    });
	}

	$scope.chooseFile = function(index) {
		console.log('chooseFile');
		$http.post(
			'/file-info/chooseFile',
			index
		).then(function mySuccess(success) {
			console.log('success: ' + JSON.stringify(success));
			$scope.myKeyWord = '';
			$scope.resultTable = '';
	        metaData = success.data;
	        console.log('success.data: ' + JSON.stringify(success.data));
	    }, function myError(response) {
	        $scope.myWelcome = response.statusText;
	        console.log('Error method chooseFile(): ' + response);
	    });
	}
	
	$scope.getLimitValue = function(index) {
		$scopelimit = index;
		$scope.getInput();
	}
	
	$scope.getInput = function() {
		if($scope.myKeyWord.length !== 0) {
			console.log('limit: ' + $scope.limit);
			console.log('dataInput: ' + JSON.stringify($scope.myKeyWord));
			console.log('metaData: ' + JSON.stringify(metaData));
	        
			$scope.resultTable = [];
			var regular = new RegExp('\\b' + $scope.myKeyWord.replace(/%/g, '.*') + '.*', 'ig');
			var result = metaData.match(regular);
			for(var x in result) {
				if(x > parseInt($scope.limit) && $scope.limit !== 'ALL') {
					break;
				}
				console.log('x: ' + x);
				$scope.resultTable.push(result[x].split(';'));
				
			}
			console.log('$scope.resultTable: ' + JSON.stringify($scope.resultTable));
		}
	}

}]);
