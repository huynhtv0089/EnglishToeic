'use strict';
var app = angular.module('myApp', []);

app.controller('myCtrl', ['$scope', '$http', function($scope, $http) {
	/* Select Box: Project */
	$http({
        method : "GET",
        url : "/filter/loadInput"
    }).then(function mySuccess(response) {
    	$scope.projects = response.data;
    	$scope.project = Object.keys($scope.projects)[0];
    	$scope.chooseProjectName($scope.project);
    }, function myError(response) {
    	console.log('error: ' + response.statusText);
    });
	
	/* Select Box: Log Folders */
	$scope.chooseProjectName = function(project) {
		$('.loader').css('display', 'block');
		$scope.logFolder = '';
		$http.post(
			'/filter/listChildDirectory',
			project
		).then(function(response) {
			
			$scope.logDirectorys = response.data;
			$scope.arrListDir = [];
			var arrTemp = [];
			for (var key in response.data) {
				if(key !== 'ALL') {
					$scope.arrListDir.push([key, response.data[key]]);
				} else {
					arrTemp.push([key, response.data[key]]);
				}
			}
			
			$scope.arrListDir.sort(function(a,b){return b[1][0] - a[1][0]});
			$scope.arrListDir.unshift(arrTemp[0]);
	    	$scope.logFolder = $scope.arrListDir[0];
	    	
	    	$('.loader').css('display', 'none');
		}, function(response) {
			console.log('error: ' + response.statusText);
		});
	}
	
	/* Button: Refresh */
	$scope.refresh = function() {
		$scope.chooseProjectName($scope.project);
	}
    
	/* Button: Submit */
    $scope.submit = function() {
    	$scope.disableAllFunction('block');
    	
    	var params = [$scope.logFolder[1][0], $scope.logFolder[1][1]];
    	
    	$http.post(
				'/filter/handleFile',
				params
		).then(function(response) {
			
			$scope.result = [];
	    	angular.forEach(response.data, function(value, key) {
	    		var lengtArr = value.length;
	    		var objectError = {'errorName': key, 'firstFileName': value[0], 'fileNameArr': value.splice(1), 'rowspan': lengtArr};
	    		$scope.result.push(objectError);
	    	});
	    	
	    	$scope.disableAllFunction('none');
		}, function(response) {
			console.log('error: ' + response.statusText);
		});
    }
    
    /* Button: CleanUp */
    $scope.cleanUp = function() {
    	var params = [];
    	params.push($scope.projects[$scope.project]);
    	params.push($scope.project);
    	params.push(Object.keys($scope.projects).indexOf($scope.project));
    	
    	$http.post(
    			'/filter/cleanUp', 
    			params
    	).then(function(success) {
    		$scope.chooseProjectName($scope.project);
    		$scope.result = [];
    	}, function(response) {
			console.log('error: ' + response.statusText);
		});
    }
    
    $scope.disableAllFunction = function(condition) {
    	if(condition === 'block') {
    		$scope.result = [];
    		$('#formCtrl').find('input, button, select').attr('disabled','disabled');
    	} else if(condition === 'none') {
    		$('#formCtrl').find('input, button, select').removeAttr('disabled');
    	}
    	$('.loader').css('display', condition);
    }
    
    $scope.disableAllFunction = function(condition) {
    	if(condition === 'block') {
    		$scope.result = [];
    		$('#formCtrl').find('input, button, select').attr('disabled','disabled');
    	} else if(condition === 'none') {
    		$('#formCtrl').find('input, button, select').removeAttr('disabled');
    	}
    	$('.loader').css('display', condition);
    }
}]);