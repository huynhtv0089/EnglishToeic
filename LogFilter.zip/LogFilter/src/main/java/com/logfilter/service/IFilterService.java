package com.logfilter.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface IFilterService {
	Map<String, String> handeInput() throws IOException;
	Map<String, String[]> getChildDirectory(String projectName);
	Map<String, List<String>> handleData(String[] params);
	void handleCleanUp(String[] params) throws IOException;
}
