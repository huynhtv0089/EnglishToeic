
package com.logfilter.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.io.FileExistsException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.logfilter.domain.LogError;
import com.logfilter.service.IFilterService;

@Service
public class FilterServiceImpl implements IFilterService {
	Logger LOGGER = LoggerFactory.getLogger(FilterServiceImpl.class);

	private static String SPLIT_STRING = "GEMA.xml: ";
	private static String NAME_FOLDER_CLEANUP = "CleanUp";
	
	/*Just commend 1 in 2 line code below*/
	// Use Developer
	private static String RESOURCES = System.getProperty("user.dir") + File.separator + "src/main/resources";
	// Use Build
	//private static String RESOURCES = System.getProperty("user.dir");
	
	private LogError[] logErrors;
	private File[] folders;
	private boolean waitingProcess;
	
	public FilterServiceImpl() {
		this.waitingProcess = false;
	}
	
	@Override
	public Map<String, String> handeInput() throws IOException {
		Map<String, String> listProjects = new HashMap<>();
		StringBuilder fileJson = new StringBuilder(RESOURCES);
		fileJson.append(File.separator);
		fileJson.append("config");
		fileJson.append(File.separator);
		fileJson.append("projects.json");
		LOGGER.info("JSON path: {}", fileJson.toString());
		
		String strJson = new String(Files.readAllBytes(new File(fileJson.toString()).toPath()), StandardCharsets.UTF_8);
		logErrors = new Gson().fromJson(strJson, LogError[].class);
		for(LogError logError : logErrors) {
			listProjects.put(logError.getLogFolders(), logError.getProject() + " " + logError.getEnvironment());
		}
		
		// Check when user F5 page
		this.waitingProcess = false;
		
		return listProjects;
	}
	
	@Override
	public Map<String, String[]> getChildDirectory(String pathDirectory) {
		Map<String, String[]> childDirectorys = new HashMap<>();
		
		// Check Separator at the end string
		if(!"/".equals(String.valueOf(pathDirectory.charAt(pathDirectory.length()-1))))
			pathDirectory += "/";
		
		File rootFolder = new File(pathDirectory);
		// Create Folder CleanUp
		Path pathCleanUp = Paths.get(rootFolder.toString() + File.separator + NAME_FOLDER_CLEANUP);
		if(Files.notExists(pathCleanUp)) {
			try {
				LOGGER.info("Create folder CleanUp");
				Files.createDirectories(pathCleanUp);
			} catch (IOException e) { 
				LOGGER.error("Error: Not create folder CleanUp");
			}
		}
		
		// Get all child folder give into Map
		this.folders = rootFolder.listFiles((FileFilter) FileFilterUtils.directoryFileFilter());
		childDirectorys.put("ALL", new String[] {"ALL", pathDirectory});
		for(File folder : folders) {
			// Check folder CleanUp then ignore
			if(folder.toString().indexOf(NAME_FOLDER_CLEANUP) != -1)
				continue;
			
			int quantityFiles = 0;
			try {
				quantityFiles = Files.list(folder.toPath()).filter(s -> s.toString().endsWith(".log")).toArray().length;
			} catch (IOException e) {
				e.printStackTrace();
			}
			String[] arrValue = {folder.getName(), pathDirectory+folder.getName()};
			
			if(quantityFiles == 0) {
				childDirectorys.put(folder.getName() + " [Empty]", arrValue);
			} else {
				childDirectorys.put(folder.getName() + " [" + quantityFiles + " Erros]", arrValue);
			}
		}
		
		return childDirectorys;
	}
	
	@Override
	public Map<String, List<String>> handleData(String[] params) {
		Map<String, List<String>> containerData = new HashMap<>();
		
		this.waitingProcess = true;
		if("ALL".equals(params[0])) {
			try {
				for(Object file : Files.list(new File(params[1]).toPath()).filter(s -> !s.toString().endsWith("CleanUp")).toArray()) {
					containerData = this.processHandleFile(file.toString(), containerData);
				}
			} catch (IOException e1) {
				LOGGER.error("Error: Fail when read content file With Function read 'Log folder: ALL'");
			}
		} else {
			containerData = this.processHandleFile(params[1], null);
		}
		this.waitingProcess = false;
		
		return containerData;
	}
	
	@Override
	public void handleCleanUp(String[] params) throws IOException {
		StringBuilder urlDir = new StringBuilder(RESOURCES);
		urlDir.append(File.separator);
		urlDir.append("tmp");
		urlDir.append(File.separator);
		
		for(File srcDir : this.folders) {
			if("CleanUp".equals(srcDir.getName())) {
				continue;
			}
			
			String urlDest = params[1] + File.separator + "CleanUp" + File.separator + srcDir.getName();
			File destDir = new File(urlDest);
			try {
				FileUtils.moveDirectory(srcDir, destDir);
			} catch (FileExistsException e) {
				LOGGER.error("Destination '" + urlDest + "' already exists");
				LOGGER.info("Begin handle directory already exists");

				File tmpDir = new File(urlDir + srcDir.getName() + "_tmp_" + UUID.randomUUID().toString()); 
				FileUtils.moveDirectory(destDir, tmpDir);
				FileUtils.moveDirectory(srcDir, destDir);
				FileUtils.deleteDirectory(tmpDir);
				LOGGER.info("Handle directory already exists success");
			}
		}
		
		//Call Function (store procedure)
		try {
			final String schema = params[0].split("\\ ")[0];	
			LOGGER.info("Call function (store procedure) with schema: {}", schema);
			
			SimpleJdbcCall updateEmployeeCall = new SimpleJdbcCall(this.connection(this.logErrors[Integer.parseInt(params[2])]));
			updateEmployeeCall.setSchemaName(schema);
			updateEmployeeCall.withFunctionName("cleanup_export");
			
			updateEmployeeCall.execute();
			LOGGER.info("Handle CleanUp Done");
		} catch(Exception e) {
			LOGGER.error("Error: Call function (store procedure) fail");
		}
	}
	
	public Map<String, List<String>> processHandleFile(String dirPath, Map<String, List<String>> data) {
		Map<String, List<String>> container;
		if(data == null) {
			container = new HashMap<>();
		} else {
			container = data;
		}
		
		Collection<File> files = FileUtils.listFiles(new File(dirPath), null, false);
		for(File file : files) {
			if(!this.waitingProcess) {
				break;
			}
			
			if(file.toString().indexOf(NAME_FOLDER_CLEANUP) != -1) {
				continue;
			}
				
			String fileName = file.getName();
			//Filter these file have extension is .log
			if(!"log".equals(fileName.split("\\.")[1])) {
				continue;
			}
			
			String nameError = null;
			try (BufferedReader buffer = Files.newBufferedReader(file.toPath())) {
				String firstLine = buffer.readLine();
				int indexOfGema = firstLine.indexOf(SPLIT_STRING);
				if(indexOfGema != -1) {
					nameError = firstLine.split(SPLIT_STRING)[1];
				} else {
					nameError = firstLine; 
				}
				
				if(container.isEmpty()) {
					List<String> firstList = new ArrayList<>();
					firstList.add(fileName);
					container.put(nameError, firstList);
				} else {
					if(container.containsKey(nameError)) {
						container.get(nameError).add(fileName);
					} else {
						List<String> newList = new ArrayList<>();
						newList.add(fileName);
						container.put(nameError, newList);
					}
				}
	        } catch (IOException e) {
	        	LOGGER.error("Error: Fail when read content file");
			}
		}
		
		return container;
	}
	
	public DriverManagerDataSource connection(LogError datasource) {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.postgresql.Driver");
		dataSource.setUrl("jdbc:postgresql://" + datasource.getServer() + "/" + datasource.getDatabase());
        dataSource.setUsername(datasource.getUsername());
        dataSource.setPassword(datasource.getPassword());
        
        LOGGER.info("Connect Database: [{}] of Server: [{}]", datasource.getDatabase(), datasource.getServer());
        return dataSource;
	}
}
