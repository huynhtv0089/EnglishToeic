package com.logfilter.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.logfilter.service.IFilterService;

@Controller
@RequestMapping("/filter")
public class FilterCtrl {
	Logger LOGGER = LoggerFactory.getLogger(FilterCtrl.class);
	
	@Autowired
	private IFilterService filterService;
	
	@RequestMapping(value="/loadInput", method=RequestMethod.GET)
	public ResponseEntity<Map<String, String>> handleInput() throws IOException {
		LOGGER.info("Read file JSON");
		
		Map<String, String> projects = filterService.handeInput();
		
		return new ResponseEntity<Map<String, String>>(projects, HttpStatus.OK);
	}
	
	@RequestMapping(value="/listChildDirectory", method=RequestMethod.POST)
	public ResponseEntity<Map<String, String[]>> getProjectName(@RequestBody String projectName) {
		LOGGER.info("Getting child directory in Project name: {}", projectName);
		
		Map<String, String[]> data = filterService.getChildDirectory(projectName);
		
		return new ResponseEntity<Map<String, String[]>>(data, HttpStatus.OK);
	}
	
	@RequestMapping(value="/handleFile", method=RequestMethod.POST)
	public ResponseEntity<Map<String, List<String>>> handleProcess(@RequestBody String[] params) {
		LOGGER.info("Handle Directory: {}", params[1]);
		LOGGER.info("params: {} | {}", params[0], params[1]);
		
		Map<String, List<String>> data = filterService.handleData(params);
		
		return new ResponseEntity<Map<String, List<String>>>(data, HttpStatus.OK);
	}
	
	@RequestMapping(value="/cleanUp", method=RequestMethod.POST)
	public ResponseEntity<String[]> handleCleanUp(@RequestBody String[] params)  throws IOException {
		LOGGER.info("CleanUp directory-> Project: {}, directory: {}, position inside array: {}", params[0], params[1], params[2]);
		
		filterService.handleCleanUp(params);
		
		return new ResponseEntity<String[]>(new String[] {"success"}, HttpStatus.OK);
	}
	
}
