'use restrict';
var shopApp = angular.module('ShopApp', ['ngMessages', 'ngRoute']);
	
shopApp.directive('mySidebar', function() {
	return {
		templateUrl : '../static/apps/pages/sidebar.html'
	};
});

// Check Validate
shopApp.directive('myDirective', function() {
	return {
		restrict: 'A',
		require: 'ngModel',
		link: function(scope, element, attr, ctrl){
			function customValidator(value) {
				if(value.indexOf('e') > -1) {
					ctrl.$setValidity('charE', true);
				} else {
					ctrl.$setValidity('charE', false);
				}
				return value;
			}
			ctrl.$parsers.push(customValidator);
		}
	};
});

shopApp.directive('checkPassword', function() {
	return {
		restrict: 'A',
		require: 'ngModel',
		link: function(scope, element, attr, ctrl){
			function customValidator(value) {
				if(/[A-Z]/.test(value)) {
					ctrl.$setValidity('uppercaseValidator', true);
				} else {
					ctrl.$setValidity('uppercaseValidator', false);
				}

				if(/[0-9]/.test(value)) {
					ctrl.$setValidity('numberValidator', true);
				} else {
					ctrl.$setValidity('numberValidator', false);
				}

				if(value.length === 6) {
					ctrl.$setValidity('sixCharactersValidator', true);
				} else {
					ctrl.$setValidity('sixCharactersValidator', false);
				}

				return value;
			}
			ctrl.$parsers.push(customValidator);
		}
	};
});

shopApp.config(['$routeProvider', function($routeProvider) {
	$routeProvider
		.when('/', {
			templateUrl : '../static/apps/pages/home.html'
		})
		.when('/products', {
			templateUrl : '../static/apps/pages/products.html'
		})
		.when('/product-details', {
			templateUrl : '../static/apps/pages/product-details.html'
		})
		.when('/checkout', {
			templateUrl : '../static/apps/pages/checkout.html'
		})
		.when('/cart', {
			templateUrl : '../static/apps/pages/cart.html'
		})
		.when('/login', {
			controller: 'loginCtr', 
			templateUrl : '../static/apps/pages/login.html'
		})
		.when('/blog', {
			templateUrl : '../static/apps/pages/blog.html'
		})
		.when('/blog-single', {
			templateUrl : '../static/apps/pages/blog-single.html'
		})
		.otherwise({
			redirectTo: '/'
		});
}]);

shopApp.controller('indexController', ['$scope', function($scope) {
	$scope.demo = 'hello angular';
}]);