var checkoutCtr = shopApp.controller('checkoutCtr', ['$scope', '$http', function($scope, $http){
	$scope.hello = 'hello page checkout'; 
}]);