var homeCtr = shopApp.controller('homeCtr', ['$scope', '$http', function($scope, $http){
	$scope.hello = 'hello page home'; 
}]);