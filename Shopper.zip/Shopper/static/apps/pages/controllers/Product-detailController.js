var productDetailCtr = shopApp.controller('productDetailCtr', ['$scope', '$http', function($scope, $http){
	$scope.hello = 'hello page product-details'; 
}]);