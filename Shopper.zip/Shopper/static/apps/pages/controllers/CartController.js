var cartCtr = shopApp.controller('cartCtr', ['$scope', '$http', function($scope, $http){
	$scope.hello = 'hello page cart'; 
}]);