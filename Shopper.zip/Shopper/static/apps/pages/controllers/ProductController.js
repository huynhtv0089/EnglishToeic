var productCtr = shopApp.controller('productCtr', ['$scope', '$http', function($scope, $http){
	
	var data =  [
					{
						'image' : 'product12.jpg',
						'price' : 56,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product11.jpg',
						'price' : 57,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product10.jpg',
						'price' : 58,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product9.jpg',
						'price' : 59,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product8.jpg',
						'price' : 55,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product7.jpg',
						'price' : 54,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product6.jpg',
						'price' : 53,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product5.jpg',
						'price' : 52,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product4.jpg',
						'price' : 51,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product3.jpg',
						'price' : 60,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product2.jpg',
						'price' : 61,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					},
					{
						'image' : 'product1.jpg',
						'price' : 62,
						'nameProduct' : 'Easy Polo Black Edition',
						'urlProduct' : '#'
					}		
				];

	$scope.currentTable = 1;
	$scope.totalItemsPerTable = 9;
	$scope.totalItems = data.length;
	$scope.datas = [];
	
	/* function show total table */
	$scope.totalTables = function() {
		return Math.ceil($scope.totalItems / $scope.totalItemsPerTable);
	}
	
	/* function filter data which show in per table */
	$scope.dataTable = function(currentTable) {
		(currentTable == undefined)? currentTable = 1 : currentTable;
		var startItem = ((currentTable-1) * $scope.totalItemsPerTable);
		var endItem = startItem + $scope.totalItemsPerTable;
		var dataItems = data.slice(startItem, endItem);		
		return dataItems; 
	}
	
	// get first data which show first table
	$scope.datas = $scope.dataTable($scope.currentTable);
	
	/* function get data which show per table */
	$scope.getData = function(currentTable) {
		$scope.datas = $scope.dataTable(currentTable);
	}
	
	/* function call Next table and Previous table */
	$scope.nextPrevTable = function(option) {
		if(option == 'prev'){
			if($scope.currentTable > 1){
				$scope.currentTable--;
			}
		}else if(option == 'next') {
			if($scope.currentTable < $scope.totalTables()) {
				$scope.currentTable++;
			}
		}
		$scope.datas = $scope.dataTable($scope.currentTable);
	}
}]);