package com.hai.oc.cho.entity;

public class CanHo {
	
	private String soCanHo;
	
	private String dienTich;
	
	private String loaiCanHo;
	
	private String chuHo;
	
	private String cacThanhVien;
	
	private String dkGuiXe;
	
	private String thongTinGuiXe;
	
	private long giaTienNuoc;

	public CanHo() {
		
	}
	
	public CanHo(String soCanHo, String dienTich, String loaiCanHo, String chuHo, String cacThanhVien, String dkGuiXe,
			String thongTinGuiXe, Long giaTienNuoc) {
		super();
		this.soCanHo = soCanHo;
		this.dienTich = dienTich;
		this.loaiCanHo = loaiCanHo;
		this.chuHo = chuHo;
		this.cacThanhVien = cacThanhVien;
		this.dkGuiXe = dkGuiXe;
		this.thongTinGuiXe = thongTinGuiXe;
		this.giaTienNuoc = giaTienNuoc;
	}

	public String getSoCanHo() {
		return soCanHo;
	}

	public void setSoCanHo(String soCanHo) {
		this.soCanHo = soCanHo;
	}

	public String getDienTich() {
		return dienTich;
	}

	public void setDienTich(String dienTich) {
		this.dienTich = dienTich;
	}

	public String getLoaiCanHo() {
		return loaiCanHo;
	}

	public void setLoaiCanHo(String loaiCanHo) {
		this.loaiCanHo = loaiCanHo;
	}

	public String getChuHo() {
		return chuHo;
	}

	public void setChuHo(String chuHo) {
		this.chuHo = chuHo;
	}

	public String getCacThanhVien() {
		return cacThanhVien;
	}

	public void setCacThanhVien(String cacThanhVien) {
		this.cacThanhVien = cacThanhVien;
	}

	public String getDkGuiXe() {
		return dkGuiXe;
	}

	public void setDkGuiXe(String dkGuiXe) {
		this.dkGuiXe = dkGuiXe;
	}

	public String getThongTinGuiXe() {
		return thongTinGuiXe;
	}

	public void setThongTinGuiXe(String thongTinGuiXe) {
		this.thongTinGuiXe = thongTinGuiXe;
	}

	public Long getGiaTienNuoc() {
		return giaTienNuoc;
	}

	public void setGiaTienNuoc(long giaTienNuoc) {
		this.giaTienNuoc = giaTienNuoc;
	}

	@Override
	public String toString() {
		return "[Số căn hộ: " + soCanHo + ", diện tích: " + dienTich + ", loại căn hộ: " + loaiCanHo + ", chủ hộ: " + chuHo
				+ ", các thành viên: " + cacThanhVien + ", đăng ký gửi xe: " + dkGuiXe + ", thông tin gửi xe: " + thongTinGuiXe
				+ ", giá tiền nước: " + giaTienNuoc + "]";
	}
	
}
