package com.hai.oc.cho.excel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import com.hai.oc.cho.entity.CanHo;

public class XuatFileExcel {
	
	private static HSSFCellStyle createStyleForTitle(HSSFWorkbook workbook) {
        HSSFFont font = workbook.createFont();
        font.setBold(true);
        HSSFCellStyle style = workbook.createCellStyle();
        style.setFont(font);
        return style;
    }
	
	public static void xuatFileExcel(List<CanHo> canho) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Employees sheet");
		
		int rownum = 0;
        Cell cell;
        Row row;
        
        HSSFCellStyle style = createStyleForTitle(workbook);
        row = sheet.createRow(rownum);
        
        // So can ho
        cell = row.createCell(0, CellType.STRING);
        cell.setCellValue("So can HO");
        cell.setCellStyle(style);
        // Dien tich
        cell = row.createCell(1, CellType.STRING);
        cell.setCellValue("Dien tich");
        cell.setCellStyle(style);
        // Loai Can Ho
        cell = row.createCell(2, CellType.STRING);
        cell.setCellValue("Loai can ho");
        cell.setCellStyle(style);
        // Chu ho
        cell = row.createCell(3, CellType.STRING);
        cell.setCellValue("Chu ho");
        cell.setCellStyle(style);
        // Cac thanh vien
        cell = row.createCell(4, CellType.STRING);
        cell.setCellValue("Cac thanh vien");
        cell.setCellStyle(style);
        
        // Dang ky gui xe
        cell = row.createCell(5, CellType.STRING);
        cell.setCellValue("Dang ky gui xe");
        cell.setCellStyle(style);
        
        // Thong tin gui xe
        cell = row.createCell(6, CellType.STRING);
        cell.setCellValue("Thong tin gui xe");
        cell.setCellStyle(style);
        
        // Gia tien nuoc
        cell = row.createCell(7, CellType.STRING);
        cell.setCellValue("Gia tien nuoc");
        cell.setCellStyle(style);
        
        // Data
        for (CanHo ch : canho) {
            rownum++;
            row = sheet.createRow(rownum);
 
            // So can ho (A)
            cell = row.createCell(0, CellType.STRING);
            cell.setCellValue(ch.getSoCanHo());
            // Dien tich (B)
            cell = row.createCell(1, CellType.STRING);
            cell.setCellValue(ch.getDienTich());
            // Loai can ho (C)
            cell = row.createCell(2, CellType.STRING);
            cell.setCellValue(ch.getLoaiCanHo());
            // Chu ho (D)
            cell = row.createCell(3, CellType.STRING);
            cell.setCellValue(ch.getChuHo());
            // Cac thanh vien (E)
            cell = row.createCell(4, CellType.STRING);
            cell.setCellValue(ch.getCacThanhVien());
            // Dang ky gui xe (F)
            cell = row.createCell(5, CellType.STRING);
            cell.setCellValue(ch.getDkGuiXe());
            // Thong tin gui xe (G)
            cell = row.createCell(6, CellType.STRING);
            cell.setCellValue(ch.getThongTinGuiXe());
            // Gia tien nuoc (H)
            cell = row.createCell(7, CellType.NUMERIC);
            cell.setCellValue(ch.getGiaTienNuoc());
        }
        
        File file = new File("danhsach2.xls");
        //file.getParentFile().mkdirs();
 
        FileOutputStream outFile = new FileOutputStream(file);
        workbook.write(outFile);
        System.out.println("Da Xuat file: " + file.getAbsolutePath() + "và kết thúc chương trình.");
	}
	
}
