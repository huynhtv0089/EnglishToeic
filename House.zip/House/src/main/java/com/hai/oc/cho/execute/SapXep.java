package com.hai.oc.cho.execute;

import java.util.List;

import com.hai.oc.cho.entity.CanHo;

public class SapXep {

	public static void sapxepDienTich(List<CanHo> list) {
		for (int i = 0; i < list.size() - 1; i++) {
			int index = i;
			for (int j = i + 1; j < list.size(); j++) {
				String strDienTich01[] = list.get(j).getDienTich().split("x");
				long longDientich01 = Long.parseLong(strDienTich01[0]) * Long.parseLong(strDienTich01[1]); 
				
				String strDienTich02[] = list.get(index).getDienTich().split("x");
				long longDientich02 = Long.parseLong(strDienTich02[0]) * Long.parseLong(strDienTich02[1]); 
				
				
				if (longDientich01 < longDientich02) {
					index = j;
				}
			}
			
			CanHo canHoTmp = list.get(index);
			
			list.remove(index);
			list.add(index, list.get(i));
			
			list.remove(i);
			list.add(i, canHoTmp);
		}
	}
	
	public static void sapxepSoCanHo(List<CanHo> list) {
		for (int i = 0; i < list.size() - 1; i++) {
			int index = i;
			for (int j = i + 1; j < list.size(); j++) {
				String soCanHo01[] = list.get(j).getSoCanHo().split("\\.")[1].split("\\-");
				int intSoCanHo01 = Integer.parseInt(soCanHo01[0] + soCanHo01[1]); 
				
				String soCanHo02[] = list.get(index).getSoCanHo().split("\\.")[1].split("\\-");
				int intSoCanHo02 = Integer.parseInt(soCanHo02[0] + soCanHo02[1]);
				
				
				if (intSoCanHo01 < intSoCanHo02) {
					index = j;
				}
			}
			
			CanHo canHoTmp = list.get(index);
			
			list.remove(index);
			list.add(index, list.get(i));
			
			list.remove(i);
			list.add(i, canHoTmp);
		}
	}
}
