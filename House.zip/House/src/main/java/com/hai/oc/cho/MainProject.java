package com.hai.oc.cho;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import com.hai.oc.cho.entity.CanHo;
import com.hai.oc.cho.excel.DocFileExcel;
import com.hai.oc.cho.excel.XuatFileExcel;
import com.hai.oc.cho.execute.SapXep;
import com.hai.oc.cho.execute.ThaoTac;

public class MainProject {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		// Cau 1: Doc file excel
		List<CanHo> lstCanHo = DocFileExcel.getDanhSachCanHo();
		
		while(true) {
			System.out.println("//=====================================================================\\\\");
			System.out.println("||                                Lựa chọn.                            ||");
			System.out.println("||                                                                     ||");
			System.out.println("|| 1. Sắp xếp danh sách theo diện tích.                                ||");
			System.out.println("|| 2. Săp xếp dánh sách theo số căn hộ.                                ||");
			System.out.println("|| 3. Chèn 1 căn hộ mới vào danh sách.                                 ||");
			System.out.println("|| 4. Xóa 1 căn hộ.                                                    ||");
			System.out.println("|| 5. Tìm kiếm 1 căn hộ.                                               ||");
			System.out.println("|| 6. Xuất danh sách căn hộ ra file excel và kết thúc chương trình.    ||");
			System.out.println("\\\\=====================================================================//");
			System.out.print("==> Nhập lựa chọn: ");
			Scanner scanner = new Scanner(System.in);
			int number = scanner.nextInt();
			
			if(number > 0 && number <= 6) {
				System.out.println();
				
				if(number == 1) {
					// Cau 2: Sap xep nhung Can Ho theo dien tich
					
					SapXep.sapxepDienTich(lstCanHo);
					for(CanHo ch : lstCanHo) {
						System.out.println(ch.toString());
					}
				} else if(number == 2) {
					// Cau 2: Sap xep nhung Can Ho so can ho
					SapXep.sapxepSoCanHo(lstCanHo);
					
					for(CanHo ch : lstCanHo) {
						System.out.println(ch.toString());
					}
				} else if(number == 3) {
					//Cau 3: Chen 1 can ho moi vao danh sach
					
					ThaoTac.chenCanHo(lstCanHo);
					System.out.println();
					for(CanHo ch : lstCanHo) {
						System.out.println(ch.toString());
					}
				} else if(number == 4) {
					//Cau 4: Xoa 1 can ho
					
					ThaoTac.xoaHoacTimKiemCanHo(lstCanHo, "xoa");
					for(CanHo ch : lstCanHo) {
						System.out.println(ch.toString());
					}
				} else if(number == 5) {
					//Cau 5: Tim kiem 1 can ho
					
					ThaoTac.xoaHoacTimKiemCanHo(lstCanHo, "timkiem");
				} else if(number == 6) {
					//Cau 7: "Xuat file excel
					
					XuatFileExcel.xuatFileExcel(lstCanHo);
					break;
				}
				
				System.out.println();
			}
		}

	}
}
