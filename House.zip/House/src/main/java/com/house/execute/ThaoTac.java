package com.house.execute;

import java.util.List;
import java.util.Scanner;

import com.house.entity.CanHo;

public class ThaoTac {
	
	@SuppressWarnings("resource")
	public static void chenCanHo(List<CanHo> canHo) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Nhap so can ho: (vd: P1-69.69): ");
		String soCanHo = sc.nextLine(); 
		
		System.out.print("Nhap dien tich: (vd: 69x69): ");
		String dientich = sc.nextLine();
		
		System.out.print("Nhap loai can ho: (vd: 1 phong ngu): ");
		String loaiCanHo = sc.nextLine();
		
		System.out.print("Nhap chu ho: (vd: Nguyen Van A): ");
		String chuHo = sc.nextLine();
		
		System.out.print("Nhap cac thanh vien: ");
		String thanhVien = sc.nextLine();
		
		System.out.print("Dang ky gui xe (vd: co || khong): ");
		String dangKyGuiXe = sc.nextLine();
		
		String thongTinGuiXe = "";
		if("co".equals(dangKyGuiXe)) {
			System.out.print("Nhap thong tin gui xe (vd: xe may, bien so: 69F69 6969): ");
			thongTinGuiXe = sc.nextLine();
		}
		
		System.out.print("Nhap gia tien nuoc (vd: 1000000): ");
		long soTienNuoc = sc.nextLong();
		
		CanHo ch = new CanHo(soCanHo, dientich, loaiCanHo, chuHo, thanhVien, dangKyGuiXe, thongTinGuiXe, soTienNuoc);
		canHo.add(ch);
	}
	
	@SuppressWarnings("resource")
	public static void xoaHoacTimKiemCanHo(List<CanHo> canHo, String luaChon) {
		Scanner sc = new Scanner(System.in);
		
		if("xoa".equalsIgnoreCase(luaChon)) System.out.print("Nhap tu khoa de xoa can ho: ");
		else if("timkiem".equalsIgnoreCase(luaChon)) System.out.print("Nhap tu khoa de tim can ho: ");
		String keyword = sc.nextLine();
		
		for(int i = 0; i < canHo.size(); i++) {
			boolean remote = false;
			
			if(canHo.get(i).getSoCanHo().toLowerCase().indexOf(keyword.toLowerCase()) != -1) {
				remote = true;
			}
			
			if(canHo.get(i).getDienTich().toLowerCase().indexOf(keyword.toLowerCase()) != -1) {
				remote = true;
			}
			
			if(canHo.get(i).getLoaiCanHo().toLowerCase().indexOf(keyword.toLowerCase()) != -1) {
				remote = true;
			}
			
			if(canHo.get(i).getChuHo().toLowerCase().indexOf(keyword.toLowerCase()) != -1) {
				remote = true;
			}
			
			if(canHo.get(i).getCacThanhVien().toLowerCase().indexOf(keyword.toLowerCase()) != -1) {
				remote = true;
			}
			
			if(canHo.get(i).getDkGuiXe().toLowerCase().indexOf(keyword.toLowerCase()) != -1) {
				remote = true;
			}
			
			if(canHo.get(i).getThongTinGuiXe().toLowerCase().indexOf(keyword.toLowerCase()) != -1) {
				remote = true;
			}
			
			if(String.valueOf(canHo.get(i).getGiaTienNuoc()).indexOf(keyword) != -1) {
				remote = true;
			}
			
			if(remote) {
				if("xoa".equalsIgnoreCase(luaChon)) canHo.remove(i);
				else if("timkiem".equalsIgnoreCase(luaChon)) System.out.println("Tim thay: " + canHo.get(i).toString());
			}
		}
	}
	
}
