package com.house.excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import com.house.entity.CanHo;

public class DocFileExcel {
	@SuppressWarnings({ "resource", "unused" })
	public static List<CanHo> getDanhSachCanHo() throws IOException {
		List<CanHo> lstCanHo = new ArrayList<>();
		
		FileInputStream inputStream = new FileInputStream(new File("danhsach.xls"));
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheetAt(0);
		Iterator<Row> rowIterator = sheet.iterator();

		int i=0;
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			 
			if(i > 0) {
				int j = 0;
				CanHo canHo = new CanHo();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					CellType cellType = cell.getCellTypeEnum();					
		
					if(j == 0) {
						canHo.setSoCanHo(cell.getStringCellValue());
					} else if(j == 1) {
						canHo.setDienTich(cell.getStringCellValue());
					} else if(j == 2) {
						canHo.setLoaiCanHo(cell.getStringCellValue());
					} else if(j == 3) {
						canHo.setChuHo(cell.getStringCellValue());
					} else if(j == 4) {
						canHo.setCacThanhVien(cell.getStringCellValue());
					} else if(j == 5) {
						canHo.setDkGuiXe("co".equals(cell.getStringCellValue().toLowerCase()) ? "co" : "");
					} else if(j == 6) {
						canHo.setThongTinGuiXe(cell.getStringCellValue());
					} else if(j == 7) {
						canHo.setGiaTienNuoc((long)cell.getNumericCellValue());
					}
					
					j++;
				}
				lstCanHo.add(canHo);
			}
			i++;
		}
		
		return lstCanHo;
	}
}
