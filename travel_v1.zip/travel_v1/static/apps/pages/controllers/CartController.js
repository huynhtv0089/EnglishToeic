var cartCtr = shopApp.controller('cartCtr', ['AppService', '$scope', '$http', function(AppService, $scope, $http){
	$scope.carts = AppService.dataCart();

	console.log('carts: ' + JSON.stringify($scope.carts));

}]);