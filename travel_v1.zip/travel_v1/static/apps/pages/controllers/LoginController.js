var loginCtr = shopApp.controller('loginCtr', ['$scope', '$http', function($scope, $http){
	$scope.hello = 'hello page login'; 
}]);