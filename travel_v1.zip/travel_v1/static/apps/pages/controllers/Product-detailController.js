var productDetailCtr = shopApp.controller('productDetailCtr', ['AppService', '$scope', '$http', function(AppService, $scope, $http){
	$scope.imageViewProduct = AppService.imageViewProduct();
	
	$scope.recommended = AppService.dataRecommendedItems();
}]);