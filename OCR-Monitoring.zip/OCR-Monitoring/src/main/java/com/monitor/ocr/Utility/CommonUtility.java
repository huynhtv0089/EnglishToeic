package com.monitor.ocr.Utility;

import java.io.IOException;

public class CommonUtility {
	
	public static void runTimeDocker(String active, String[] names) {
		try {
			for(String name : names) {
				Runtime.getRuntime().exec("docker " + active + " " + name);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
