package com.monitor.ocr.domain;

import java.io.File;
import java.util.Collection;

import org.apache.commons.io.FileUtils;

public class PerOCR implements Runnable {
	
	private String name;
	private String path;
	private int processing;
	private int newComing;
	private int processed;
	private Collection<File> filesTmp;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public int getProcessing() {
		return processing;
	}
	public void setProcessing(int processing) {
		this.processing = processing;
	}
	public int getNewComing() {
		return newComing;
	}
	public void setNewComing(int newComing) {
		this.newComing = newComing;
	}
	public int getProcessed() {
		return processed;
	}
	public void setProcessed(int processed) {
		this.processed = processed;
	}
	
	@Override
	public void run() {
		Collection<File> files = FileUtils.listFiles(new File(this.path), null, false);
		this.processing = files.size();
		if(filesTmp != null) {
			if(files.toString().indexOf(filesTmp.toString()) == -1) {
				
				this.newComing = 0;
				this.processed = 0;
	
				if(files.size() == filesTmp.size()) {
					files.forEach((file) -> {
						if(!filesTmp.contains(file)) {
							this.newComing += 1;
							this.processed += 1;
						}
					});
				} else {
					this.processed = filesTmp.size();
					files.forEach((file) -> {
						if(filesTmp.contains(file)) {
							this.processed -= 1;						
						} else {
							this.newComing += 1;
						}
					});
				}
			}
		}
		
		filesTmp = files;
	}
	
	@Override
	public String toString() {
		return "OCR name: " + name + " -> [Processing: " + processing + ", New Coming: " + newComing + ", Processed: " + processed + "]";
	}
}
