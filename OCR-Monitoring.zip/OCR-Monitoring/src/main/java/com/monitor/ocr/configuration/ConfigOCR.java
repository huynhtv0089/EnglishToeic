package com.monitor.ocr.configuration;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.monitor.ocr.domain.OCR_Center;

@Configuration
@ConfigurationProperties(prefix="app")
public class ConfigOCR {
	
	private List<OCR_Center> ocrCenter = new ArrayList<>();

	public List<OCR_Center> getOcrCenter() {
		return ocrCenter;
	}

	public void setOcrCenter(List<OCR_Center> ocrCenter) {
		this.ocrCenter = ocrCenter;
	}

}
