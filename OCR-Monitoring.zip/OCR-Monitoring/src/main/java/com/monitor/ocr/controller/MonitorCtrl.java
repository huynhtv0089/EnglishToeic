package com.monitor.ocr.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.monitor.ocr.domain.OCR_Center;
import com.monitor.ocr.services.MonitorServices;

@RestController
public class MonitorCtrl {
	
	@Autowired
	private MonitorServices monitorServices;
	
	@Value("${docker.url}")
	private String urlDocker;
	
	@RequestMapping(value="/infoOCRs", method=RequestMethod.GET)
	public ResponseEntity<List<OCR_Center>> infomationOCR() {
		List<OCR_Center> lstOCRs = null;
		try {
			lstOCRs = monitorServices.containerOCRs();
			
			return new ResponseEntity<List<OCR_Center>>(lstOCRs, HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<List<OCR_Center>>(lstOCRs, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@RequestMapping(value="/infoDockerURL", method=RequestMethod.GET, produces=MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String> infomationDockerUrl() {
		try {
			return new ResponseEntity<String>(urlDocker, HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
