package com.monitor.ocr.services;

import java.util.List;

import com.monitor.ocr.domain.OCR_Center;

public interface MonitorServices {
	public List<OCR_Center> containerOCRs();
}
