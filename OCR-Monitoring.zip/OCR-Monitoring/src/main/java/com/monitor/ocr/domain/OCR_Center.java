package com.monitor.ocr.domain;

import java.util.List;

public class OCR_Center {
	
	private String serverName;
	private List<PerOCR> OCRs;
	
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public List<PerOCR> getOCRs() {
		return OCRs;
	}
	public void setOCRs(List<PerOCR> oCRs) {
		OCRs = oCRs;
	}
	
}
