package com.monitor.ocr.services.impl;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.monitor.ocr.configuration.ConfigOCR;
import com.monitor.ocr.domain.OCR_Center;
import com.monitor.ocr.services.MonitorServices;

@Service
public class MonitorServiceImpl implements MonitorServices {
	
	@Autowired
	private ConfigOCR configOCR;
	
	@Override
	public List<OCR_Center> containerOCRs() {
		ExecutorService executor = Executors.newFixedThreadPool(1);
		
		int i=0;
		while(true) {
			try {
				for(int j=0; j<configOCR.getOcrCenter().get(i).getOCRs().size(); j++) {
					executor.execute(configOCR.getOcrCenter().get(i).getOCRs().get(j));
				}
				i++;
			} catch(Exception e) {
				break;
			}
		}
		
        executor.shutdown();
		
		return configOCR.getOcrCenter();
	}
	
}
