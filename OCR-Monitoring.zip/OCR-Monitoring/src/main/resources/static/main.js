var app = angular.module('myApp', []);

app.controller('myCtrl', ['$scope', '$http', '$interval', '$sce', '$log', function($scope, $http, $interval, $sce, $log) {
	$scope.dataInTable = [];
	$scope.arrChecked = [];
	var locationCurrent = window.location;
	
	$scope.infomationOCRs = function() {
		$interval(function () {
			$http({
				  method: 'GET',
				  url: locationCurrent + '/infoOCRs'
			}).then(function successCallback(response) {
				$scope.arrOCR = response.data;
			}, function errorCallback(response) {
				$log.error('Error: ' + response.status);
	 	    });
		}, 1000);
	}
	
	$scope.infomationDockerUrl = function() {
		$http({
			  method: 'GET',
			  url: locationCurrent + '/infoDockerURL'
		}).then(function successCallback(response) {
			$scope.dockerUrl = $sce.trustAsResourceUrl(response.data);
		}, function errorCallback(response) {
			$log.error('Error: ' + response.status);
	    });
	}
	
	
}]);