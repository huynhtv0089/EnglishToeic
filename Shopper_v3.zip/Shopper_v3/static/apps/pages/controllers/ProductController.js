var productCtr = shopApp.controller('productCtr', ['AppService', '$scope', '$http', function(AppService, $scope, $http){
	
	var data =  AppService.dataProduction();

	$scope.currentTable = 1;
	$scope.totalItemsPerTable = 9;
	$scope.totalItems = data.length;
	$scope.datas = [];
	
	/* function show total table */
	$scope.totalTables = function() {
		return Math.ceil($scope.totalItems / $scope.totalItemsPerTable);
	}
	
	/* function filter data which show in per table */
	$scope.dataTable = function(currentTable) {
		(currentTable == undefined)? currentTable = 1 : currentTable;
		var startItem = ((currentTable-1) * $scope.totalItemsPerTable);
		var endItem = startItem + $scope.totalItemsPerTable;
		var dataItems = data.slice(startItem, endItem);		
		return dataItems; 
	}
	
	// get first data which show first table
	$scope.datas = $scope.dataTable($scope.currentTable);
	
	/* function get data which show per table */
	$scope.getData = function(currentTable) {
		$scope.datas = $scope.dataTable(currentTable);
	}
	
	/* function call Next table and Previous table */
	$scope.nextPrevTable = function(option) {
		if(option == 'prev'){
			if($scope.currentTable > 1){
				$scope.currentTable--;
			}
		}else if(option == 'next') {
			if($scope.currentTable < $scope.totalTables()) {
				$scope.currentTable++;
			}
		}
		$scope.datas = $scope.dataTable($scope.currentTable);
	}
}]);