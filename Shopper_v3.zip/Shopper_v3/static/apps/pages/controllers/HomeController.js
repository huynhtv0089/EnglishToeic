var homeCtr = shopApp.controller('homeCtr', ['AppService', '$scope', '$http', function(AppService, $scope, $http){
	$scope.featuresItems = AppService.dataFeaturesItems();
	$scope.tShirt = AppService.dataTShirt();
	$scope.blazers = AppService.dataBlazers();
	$scope.sunglass = AppService.dataSunglass();
	$scope.kids = AppService.dataKids();
	$scope.poloShirt = AppService.dataPoloShirt();

	$scope.recommended = AppService.dataRecommendedItems();
}]);