import React, {Component} from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faBuilding } from '@fortawesome/free-solid-svg-icons';

import uuid from 'uuid';

class CategoryRight extends Component {

    constructor() {
        super();
        this.state = {
            activeMenu: false,
            items: [
                {
                    id: uuid.v4(),
                    name: 'House',
                    icon: faHome
                },
                {
                    id: uuid.v4(),
                    name: 'Office',
                    icon: faBuilding
                },
                {
                    id: uuid.v4(),
                    name: 'Office Office Office Office Office Office Office',
                    icon: faBuilding
                }
            ]
        }
    }

    toggleMenu = () => {
        this.setState({activeMenu: !this.state.activeMenu});
    }

    render() {

        return (
            <aside className="category-right w-15 h-100 float-right">
                <div className="category-fab position-fixed pointer" onClick={this.toggleMenu}>
                    <span className={this.state.activeMenu ? 'category-menu-rotate' : ''}>
                        <i className="i-line-top position-absolute"></i>
                        <i className="i-line-center position-absolute"></i>
                        <i className="i-line-bottom position-absolute"></i>
                    </span>
                </div>

                <ul className={`category-right-quickview position-fixed w-15 h-100 bg-white list-inline overflow-auto ${this.state.activeMenu ? 'd-block' : 'd-none'}`}>
                    {this.state.items.map((item) =>
                        <li key={item.id} className="">
                            <a href="#" className="mr-1 p-2 text-dark d-flex justify-content-between draw meet">
                                <span className="text-break align-self-center ml-3">{item.name}</span>
                                <FontAwesomeIcon icon={item.icon} className="fontawesome p-2 mr-2 align-self-center" />
                            </a>
                        </li>
                    )}
                </ul>
            </aside>
        )
    }
}

export default CategoryRight;