import React, {Component} from 'react';

class Filters extends Component {

    constructor() {
        super();
    }

    render() {
        return (
            <span>
                <div className="sidebar-left-quickview-header d-flex justify-content-between">
                    <h2 className="p-4 pl-3 pr-2 text-dark">shopping cart</h2>
                    <div className="align-self-center">
                        <span className="close rotate-360 pointer" onClick={this.props.toggleCollapse} aria-hidden="true">&times;</span>
                    </div>
                </div>

            </span>
        )
    }
}

export default Filters;