import React, {Component} from 'react';
import ShoppingCart from './shopping-cart';
import Filters from './filters';

class QuickView extends Component {

    constructor() {
        super();
    }

    render() {
        return (
            <div className={`sidebar-left-quickview position-absolute bg-white h-100 w-80 ${this.props.activeCollapse ? 'collapse-horizontal-left' : ''}`}>
                {this.props.currentBrand === 'Shopping Cart' && <ShoppingCart toggleCollapse={this.props.toggleCollapse} />}
                {this.props.currentBrand === 'Search' && <Filters toggleCollapse={this.props.toggleCollapse} />}
                {this.props.currentBrand === 'Filter' && <Filters toggleCollapse={this.props.toggleCollapse} />}
            </div>
        )
    }
}

export default QuickView;