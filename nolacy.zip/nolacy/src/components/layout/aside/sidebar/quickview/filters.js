import React, {Component} from 'react';

class Filters extends Component {

    constructor() {
        super();
    }

    render() {
        return (
            <span className="h-100">
                <div className="sidebar-left-quickview-header d-flex justify-content-between">
                    <h2 className="p-4 pl-3 pr-2 text-dark">BỘ LỌC</h2>
                    <div className="align-self-center">
                        <span className="close rotate-360 pointer" onClick={this.props.toggleCollapse} aria-hidden="true">&times;</span>
                    </div>
                </div>

                <div className="sidebar-left-quickview-body p-4 pl-3 overflow-auto">
                    <div className="mb-5">
                        <h4>Chủ đề</h4>
                        <div className="checkbox-wrap d-flex justify-content-between flex-wrap">
                            <div className="p-2">
                                <label className="checkbox-ele bg-white text-dark pointer">
                                    <input type="checkbox" className="position-absolute" id="theThao" />
                                    <span className="checkmark p-0 position-relative"></span>
                                    Thể thao
                                </label>
                            </div>

                            <div className="p-2">
                                <label className="checkbox-ele bg-white text-dark pointer">
                                    <input type="checkbox" className="position-absolute" id="dongVat" />
                                    <span className="checkmark p-0 position-relative"></span>
                                    Động vật
                                </label>
                            </div>

                            <div className="p-2">
                                <label className="checkbox-ele bg-white text-dark pointer">
                                    <input type="checkbox" className="position-absolute" id="phim" />
                                    <span className="checkmark p-0 position-relative"></span>
                                    Động vật
                                </label>
                            </div>

                            <div className="p-2">
                                <label className="checkbox-ele bg-white text-dark pointer">
                                    <input type="checkbox" className="position-absolute" id="tatCa" />
                                    <span className="checkmark p-0 position-relative"></span>
                                    Tất cả
                                </label>
                            </div>
                        </div>
                    </div>

                    <div className="mb-5">
                        <h4>Màu sắc</h4>
                        <div className="checkbox-wrap d-flex justify-content-between flex-wrap">
                            <div className="p-2">
                                <label className="checkbox-ele bg-white text-dark pointer">
                                    <input type="checkbox" className="position-absolute" id="trang" />
                                    <span className="checkmark p-0 position-relative"></span>
                                    Trắng
                                </label>
                            </div>

                            <div className="p-2">
                                <label className="checkbox-ele bg-white text-dark pointer">
                                    <input type="checkbox" className="position-absolute" id="den" />
                                    <span className="checkmark p-0 position-relative"></span>
                                    Đen
                                </label>
                            </div>

                            <div className="p-2">
                                <label className="checkbox-ele bg-white text-dark pointer">
                                    <input type="checkbox" className="position-absolute" id="xanh" />
                                    <span className="checkmark p-0 position-relative"></span>
                                    Xanh
                                </label>
                            </div>

                            <div className="p-2">
                                <label className="checkbox-ele bg-white text-dark pointer">
                                    <input type="checkbox" className="position-absolute" id="do" />
                                    <span className="checkmark p-0 position-relative"></span>
                                    Đỏ
                                </label>
                            </div>

                            <div className="p-2">
                                <label className="checkbox-ele bg-white text-dark pointer">
                                    <input type="checkbox" className="position-absolute" id="vang" />
                                    <span className="checkmark p-0 position-relative"></span>
                                    Vàng
                                </label>
                            </div>

                            <div className="p-2">
                                <label className="checkbox-ele bg-white text-dark pointer">
                                    <input type="checkbox" className="position-absolute" id="xamChuot" />
                                    <span className="checkmark p-0 position-relative"></span>
                                    Xám Chuột
                                </label>
                            </div>
                        </div>
                    </div>

                    <div className="mb-5">
                        <h4>Giá</h4>
                        <div className="d-flex">
                            <p>0</p>
                            <div className="w-100 ml-2 mr-2 text-center">
                                <input type="range" className="form-range-input w-100 h-10" min="1" max="1500" />
                                <p>Từ 0 đến 1.000.000</p>
                            </div>
                            <p>1500</p>
                        </div>
                    </div>

                    <div className="mb-5"> <h4>Giá</h4> </div>
                </div>
            </span>
        )
    }
}

export default Filters;