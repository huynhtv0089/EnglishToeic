import React, { Component } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faShoppingCart, faSearch, faCog } from '@fortawesome/free-solid-svg-icons';
import QuickView from './quickview/quick-view';
import uuid from 'uuid';

class SidebarLeft extends Component {

    constructor() {
        super();
        this.state = {
            activeCollapse: false,
            brands : [
                {
                    id: uuid.v4(),
                    name: 'Shopping Cart',
                    icon: faShoppingCart,
                },
                {
                    id: uuid.v4(),
                    name: 'Search',
                    icon: faSearch,
                },
                {
                    id: uuid.v4(),
                    name: 'Filter',
                    icon: faCog,
                }
            ],
            currentBrand: 'home'
        };
    }

    toggleCollapse = () => {
        this.setState({ activeCollapse: !this.state.activeCollapse});
    }

    changeBrand = (newBrand) => {
        console.log(newBrand);
        this.setState({ currentBrand: newBrand });
    }

    render() {
        return (
            <aside className="sidebar-left position-relative d-flex float-left w-20 h-100">
                <ul className="sidebar-left-brand position-absolute bg-white list-inline w-20 h-100">
                    <li className="p-3 mb-2 mt-2">
                        <a href="#"className="d-flex justify-content-center">
                            <FontAwesomeIcon icon={faHome} className="fontawesome" />
                        </a>
                    </li>

                    {this.state.brands.map((brand) => 
                        <li className="p-3 mb-2 mt-2" key={brand.id} onClick={() => {this.toggleCollapse(); this.changeBrand(brand.name)}}>
                            <a href="#"className="d-flex justify-content-center">
                                <FontAwesomeIcon icon={brand.icon} className={`fontawesome ${brand.name === 'Filter' ? 'rotate-360' : ''}`} />
                            </a>
                        </li>
                    )}
                </ul>

                <QuickView toggleCollapse={this.toggleCollapse} activeCollapse={this.state.activeCollapse} currentBrand={this.state.currentBrand} />
            </aside>
        )
    }
}

export default SidebarLeft;