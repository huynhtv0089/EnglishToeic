import React, {Component} from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome } from '@fortawesome/free-solid-svg-icons';

class NavbarMobile extends Component {

    constructor() {
        super();
        this.state = {
            activeMenu: false
        }
    }

    toggleMenu = () => {
        this.setState({activeMenu: !this.state.activeMenu});
    }

    render() {
        //navbar for tablet and mobile
        return (
            <header className="header-mobile d-flex flex-column">
                <div className="nav-mobile d-flex flex-row justify-content-between p-3 h-8">
                    <a href="#" className="text-dark">
                        <FontAwesomeIcon icon={faHome} className="nav-mobile-fontawesome" />
                    </a>
                    
                    <a href="#" className="text-dark">
                        <FontAwesomeIcon icon={faHome} className="nav-mobile-fontawesome" />
                    </a>


                    <div className="nav-mobile-fab position-relative pointer" onClick={this.toggleMenu}>
                        <span className={this.state.activeMenu ? 'category-menu-rotate' : ''}>
                            <i className="i-line-top position-absolute"></i>
                            <i className="i-line-center position-absolute"></i>
                            <i className="i-line-bottom position-absolute"></i>
                        </span>
                    </div>
                </div>

                <div className={`d-flex border ${this.state.activeMenu ? 'd-block' : 'd-none'}`}>
                    <div className="p-3">home</div>
                    <div className="p-3">home</div>
                    <div className="p-3">home</div>
                    <div className="p-3">home</div>
                </div>
            </header>
        );
    }
}

export default NavbarMobile;