import React, {Component} from 'react';
import uuid from 'uuid';

class Home extends Component {

    constructor() {
        super();

        this.state = {
            imagesSlide: [
                {
                    id: uuid.v4(),
                    src: 'images/main-bg.jpg',
                    alt: 'main background'
                }
            ]
        }
    }

    render() {
        console.log()
        return (
            <section className="content position-absolute w-95-9 h-100">
                { this.state.imagesSlide.map((image) => 
                    <img src={image.src} key={image.id} className="w-100 h-99-5" alt={image.alt} />    
                )}

                {/*<ul className="stick-dots list-inline position-fixed">
                    { this.state.imagesSlide.map((image) => 
                        <li key={image.id} className="dot d-inline-block pointer"></li>
                    )}
                </ul>*/}

                <ul className="stick-dots list-inline position-fixed">
                    <li className="dot d-inline-block pointer"></li>
                    <li className="dot d-inline-block pointer"></li>
                    <li className="dot d-inline-block pointer"></li>
                </ul>
            </section>
        );
    }
}

export default Home;