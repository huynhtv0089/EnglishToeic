import React, { Component } from 'react';
import './App.css';
import NavbarMobile from './components/layout/navbar/navbar-mobile';
import SidebarLeft from './components/layout/aside/sidebar/sidebar-left';
import CategoryRight from './components/layout/aside/category/category-right';
import Home from './components/layout/contents/home';

class App extends Component {
    
    render() {
        return (
            <div className="h-100">
                <NavbarMobile />
                <SidebarLeft />
                <CategoryRight />
                <Home />
            </div>
        );
    }
}

export default App;
