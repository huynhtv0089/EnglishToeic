package vn.bamberg.module;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import vn.bamberg.services.EncryptDecryptUtils;

@Configuration
@ConfigurationProperties(prefix = "spring.jdbc-template")
public class ConnectionDB {
	
	private String driver;
	
	private String url;
	
	private String username;
	
	private String password;
	
	@Bean
	public DriverManagerDataSource connection() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driver);
		dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(EncryptDecryptUtils.decrypt(password));
        
		return dataSource;
	}
	
	public String getDriver() {
		return driver;
	}
	
	public void setDriver(String driver) {
		this.driver = driver;
	}
	
	public String getUrl() {
		return url;
	}
	
	public void setUrl(String url) {
		this.url = url;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
