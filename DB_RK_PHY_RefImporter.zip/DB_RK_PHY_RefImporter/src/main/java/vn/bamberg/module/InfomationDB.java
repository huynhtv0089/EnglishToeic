package vn.bamberg.module;

import java.util.ArrayList;
import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "infomation-db")
public class InfomationDB {
	
	private String schema;
	
	private List<Table> listTable = new ArrayList<>();

	public List<Table> getListTable() {
		return listTable;
	}

	public void setListTable(List<Table> listTable) {
		this.listTable = listTable;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}
	
}
