package vn.bamberg.services;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipInputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.FileHeader;

import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.util.http.fileupload.FileUtils;

@Service
public class ExtractData {

	Logger LOGGER = LoggerFactory.getLogger(ExtractData.class);

	@Autowired
	private Datasource datasource;

	@Value("${sleep-after-execute-query}")
	private long sleepAfterExecuteQuery;

	@Value("${collect-query-for-import}")
	private int collectQuery;
	
	@Value("${zip.password}")
	private String zipPassword;

	private static String USER_DIR_DEV = System.getProperty("user.dir") + "/src/main/resources";

	private static String USER_DIR_DEPLOY = System.getProperty("user.dir");

	private String pathDirUnzip;

	private List<String> logProcess = new ArrayList<>();

	private Boolean flagCancelProcess;

	public void dirUnzip() {
		this.logProcess.clear();
		File envPathUnzip = new File(Helper.convertSlash(USER_DIR_DEV));

		if(envPathUnzip.exists()) { // Enviroment dev
			this.pathDirUnzip = Helper.convertSlash(USER_DIR_DEV + "/unzip");
			this.handleDirNotExists(this.pathDirUnzip);
		} else { 	// Enviroment deploy
			this.pathDirUnzip = Helper.convertSlash(USER_DIR_DEPLOY + "/unzip");
			this.handleDirNotExists(this.pathDirUnzip);
		}
	}

	public void handleDirNotExists(String pathDirUnzip) {
		File pathUnzip = new File(pathDirUnzip);

		if(!pathUnzip.exists()) {
			pathUnzip.mkdir();
		} else {
			try {
				FileUtils.cleanDirectory(pathUnzip);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public Boolean extractFileUpload(MultipartFile file) {
		String nameFileZip = this.pathDirUnzip + File.separator + file.getOriginalFilename();
		LOGGER.info("Begin extract file {}.", file.getOriginalFilename());
		this.logProcess.add(LocalDateTime.now() + " --- INFO: Extract file: " + file.getOriginalFilename());
		
		try {
			File fileZipEncrypt = new File(nameFileZip);
			file.transferTo(fileZipEncrypt);
			
			ZipFile zipFile = new ZipFile(fileZipEncrypt);
			
			//Check password file zip
			if (zipFile.isEncrypted()) zipFile.setPassword(EncryptDecryptUtils.decrypt(zipPassword));
			
			List fileHeaderList = zipFile.getFileHeaders();
			for (int i = 0; i < fileHeaderList.size(); i++) {
				FileHeader fileHeader = (FileHeader) fileHeaderList.get(i);
				
				//Check file csv...
				if(!isFileCSV(fileHeader.getFileName())) continue;
				
				zipFile.extractFile(
					fileHeader.getFileName(), 
					this.pathDirUnzip
				);
			}

			//Delete file zip  
			fileZipEncrypt.delete();
			
			LOGGER.info("Extract file {} success.", file.getOriginalFilename());
			this.logProcess.add(LocalDateTime.now() + " --- INFO: Extract file: " + file.getOriginalFilename() + " ==> success");
			return true;
		} catch (net.lingala.zip4j.exception.ZipException | IllegalStateException | IOException e) {
			e.printStackTrace();
			
			LOGGER.error("Extract file {} false.", file.getOriginalFilename());
			this.logProcess.add(LocalDateTime.now() + " --- ERROR: " + e.toString());
		}

		return false;
	}

	public Boolean handleImport() {
		try (Stream<Path> filePathStream = Files.walk(Paths.get(this.pathDirUnzip))) {
		    filePathStream.forEach(filePath -> {
		        if (Files.isRegularFile(filePath)) {
		        	// Case: user click button cancel
					if(this.flagCancelProcess) return;
		            
					
		            LOGGER.info("Extract data from file: {}", filePath.getFileName());
		            this.insertToDB(
						filePath.getFileName().toString(), 
						Helper.convertSlash(filePath.getParent() + File.separator + filePath.getFileName())
					);
		        }
		    });
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		//After all clear folder unzip
		try {
			FileUtils.cleanDirectory(new File(this.pathDirUnzip));
		} catch (IOException e) {
			e.printStackTrace();
		}

		return true;
	}

	public Boolean insertToDB(String fileName, String path) {
		StringBuilder sql = new StringBuilder();
		boolean isSuccess = false;
		int index = 0;

		this.logProcess.add(LocalDateTime.now() + " --- INFO: Begin extract data file name: " + fileName);
		try (Stream<String> stream = Files.lines(Paths.get(path))) {
			List<String> lstData = stream.collect(Collectors.toList());

			if(lstData.size() > 1) {
				datasource.detectInfoTable(fileName, this.logProcess);

				// Check firt row -> if first row is header then increase index to 1 for loop
				// from 1 to the end
				// otherwise must loop from 0 to the end and index is 0.
				String firtRow = lstData.get(0);
				if (datasource.getColumns().equals(Helper.convertSemicolonToComma(firtRow))) {
					index = 1;
				} else {
					lstData.remove(0);
					lstData.add(0, Helper.removeUnicode(firtRow));
				}

				// Fisrt, must delete all data in table.
				datasource.delTable(this.logProcess);
			}

			for(int i = index; i < lstData.size(); i++) {
				// Case: user click button cancel
				if (this.flagCancelProcess)
					break;

				String sQuery = datasource.createQuery(changeQueryDataInsert(lstData.get(i)));
				sql.append(sQuery);

				if (((i < lstData.size() && (i % collectQuery == 0)) || i == (lstData.size() - 1))) {
					if (StringUtils.isEmpty(datasource.getTable())) {
						LOGGER.info("CAN NOT FIND TO TABLE DATABASE FOR INSERT DATA FROM FILE NAME: {}", fileName);
						break;
					}

					// Second, insert data into table.
					isSuccess = datasource.insertData(sql.toString(), this.logProcess);
					if (!isSuccess) {
						datasource.delTable(this.logProcess);
						LOGGER.info("CAN'T INSERT DATA FROM FILE {}", path);
						this.logProcess.add(LocalDateTime.now() + " --- ERROR: can't import file name: " + fileName);
						break;
					}

					sql.setLength(0);
					sql = new StringBuilder();

					try {
						TimeUnit.MILLISECONDS.sleep(sleepAfterExecuteQuery);
					} catch (Exception e) {
						e.printStackTrace();
						this.logProcess.add(LocalDateTime.now() + " --- ERROR: " + e.toString());
					}
				}
			}

			// Reset table and columns
			datasource.setTable("");
			datasource.setColumns("");

			if (isSuccess)
				this.logProcess
						.add(LocalDateTime.now() + " --- INFO: import data file name: " + fileName + " ==> success");
			LOGGER.info("Done import data from file: {}", path);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			this.logProcess.add(LocalDateTime.now() + " --- ERROR: " + e.toString());
		}

		return false;
	}

	private String changeQueryDataInsert(String value) {
		int doubleQuotes = value.indexOf("\""), apostropheInsideStr = value.indexOf("'");

		if (doubleQuotes != -1 && apostropheInsideStr == -1) {
			return Helper.caseDoubleQuotes(value, false);
		} else if (doubleQuotes == -1 && apostropheInsideStr != -1) {
			return Helper.caseApostropheAndSlashInsideStr(value);
		} else if (doubleQuotes != -1 && apostropheInsideStr != -1) {
			// return Helper.caseBothApostropheAndDoubleQuotes(value);
			// case both `'` And `"`
			return Helper.caseDoubleQuotes(value, true);
		} else {
			return Helper.convertMetaDATA(value);
		}
	}

	public List<String> fetchLogProcess() {
		return this.logProcess;
	}

	public void setFlagCancelProcess(Boolean value) {
		this.flagCancelProcess = value;
	}
	
	public boolean isFileCSV(String fileName) {
		return (fileName.indexOf("csv") != -1) ? true : false;
	}
}
