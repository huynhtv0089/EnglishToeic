package vn.bamberg.services;

import org.apache.commons.lang3.StringUtils;

public class Helper {
	
	/**
	 * Convert `\` => `/`, file path.
	 * @param path
	 * @return
	 */
	public static String convertSlash(String path) {
		return path.replaceAll("\\\\+|\\/+", "/");
	}
	
	/**
	 * Remove non-printable characters, unicode from file CSV.
	 * Research google: Remove Emojis from a Java String || remove unincode ? java
	 * @param value
	 * @return
	 */
	public static String removeUnicode(String value) {
		//return value.replace('\uFEFF', '\0');
		//return value;
		
		// strips off all non-ASCII characters
		value = value.replaceAll("[^\\x00-\\x7F]", "");
	 
	    // erases all the ASCII control characters
		value = value.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "");
	     
	    // removes non-printable characters from Unicode
		value = value.replaceAll("\\p{C}", "");
	 
	    return value.trim();
	}
	
	/**
	 * Convert `;` => result: `,`
	 * @param value
	 * @return
	 */
	public static String convertSemicolonToComma(String value) {
		value = Helper.removeUnicode(value);
		value = value.replaceAll("\\;", ",");
		
		return value.trim();
	}
	
	
	/**
	 * Convert character, case `"` and something and `"`
	 * @param value
	 * @return
	 */
	public static String caseDoubleQuotes(String value, boolean both) {
		// Insert `|` to string have `"` after split string.
		String[] arrValue = value.replaceAll("\"(.*?)\"", "|\"$1\"|").split("\\|");
        		
		// Handle per string after split `|`
        StringBuilder sb = new StringBuilder();
		for(String aValue: arrValue) {
			if(aValue.indexOf("\"") != -1) {
				//First: remove `"` => empty
				//Second: replace `;` > `!`
				sb.append(aValue.replace("\"", "").replace(";", "+!"));
			} else {
				sb.append(aValue);
			}
		}
		
		String result;
		if(both) {
			result = Helper.caseApostropheAndSlashInsideStr(sb.toString());
		} else {
			result =  Helper.convertMetaDATA(sb.toString());
		}
		
		return result.replaceAll("\\+\\!", ";");
	}
	
	/**
	 * Convert `;` => `,` and handle special character inside string.
	 * @param value
	 * @return
	 */
	public static String caseApostropheAndSlashInsideStr(String value) {
		String[] arrValue = value.split(";");      

		for(int i=0; i< arrValue.length; i++) {
			if(arrValue[i].indexOf("'") != -1 || arrValue[i].indexOf("/") != -1) {
				arrValue[i] = "E'" + arrValue[i].replaceAll("\\'", "\\\\'") + "'";
	        } else {
	        	arrValue[i] = "'" + arrValue[i] + "'";
	        }
		}
		
		return StringUtils.join(arrValue, ",");
	}
	
	/**
	 * Change string to MetaData for create query statement. 
	 * @param value
	 * @return
	 */
	public static String convertMetaDATA(String value) {
		//Replace character apostrophe to \'
		value = value.replaceAll("\\'", "\\\\'") + ";";
		
		//Insert couple apostrophe to all column
		value = value.replaceAll("(.*?)\\;", "'$1',");
		 
		//Remove couple apostrophe at ID column
		value = value.replaceFirst("\\'(.*?)\\'\\,", "$1,");
		
		//System.out.println("result: " + result);
		return value.substring(0, value.length() - 1);
	}

}
