package vn.bamberg.services;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import vn.bamberg.module.InfomationDB;
import vn.bamberg.module.Table;

@Service
public class Datasource {
	
	Logger LOGGER = LoggerFactory.getLogger(Datasource.class);
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private InfomationDB infomationDB;
	
	private String columns;
	
	private String table;
	
	List<Map<String, Object>> lstDataType;
	
	
	public void setColumns(String value) {
		this.columns = value;
	}
	
	public String getColumns() {
		return columns;
	}
	
	public void setTable(String value) {
		this.table = value;
	}
	
	public String getTable() {
		return this.table;
	}
	
	public void detectInfoTable(String fileName, List<String> logProcess) {
		for(Table table : infomationDB.getListTable()) {
			String nameTable = table.getName();
			String header = table.getHeader();
			
			if("ref_travel".equals(nameTable)) {
				if(fileName.indexOf("data") != -1) {
					this.setTable(nameTable);
				}
			} else if("ref_user_home".equals(nameTable)) {
				if(fileName.indexOf("user") != -1 && fileName.indexOf("home") != -1) {
					this.setTable(nameTable);
				}
			} else if("ref_user".equals(nameTable)) {
				if(fileName.indexOf("user") != -1 && fileName.indexOf("home") == -1) {
					this.setTable(nameTable);
				}
			} else if("ref_verpl".equals(nameTable)) {
				if(fileName.indexOf("verp") != -1 ) {
					this.setTable(nameTable);
				}
			} else {
				if(fileName.indexOf(nameTable.substring(4)) != -1) {
					this.setTable(nameTable);
				}
			}
			
			if(!StringUtils.isEmpty(this.table)) {
				this.setColumns(Helper.convertSemicolonToComma(header));
				break;
			}
		}
		
		logProcess.add(LocalDateTime.now() + " --- ERROR: can not found table of file: " + fileName);
	}
	
	public void delTable(List<String> logProcess) {
		StringBuilder query = new StringBuilder("DELETE FROM ");
		query.append(infomationDB.getSchema() + "." + table + ";");
	
		//LOGGER.info("Query delete: {}", query.toString());
		try {
			jdbcTemplate.execute(query.toString());
			
			jdbcTemplate.getDataSource().getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
			logProcess.add(LocalDateTime.now() + " --- ERROR: " + e.toString());
		}
	}
	
	public boolean insertData(String lstQuery, List<String> logProcess) {
		try {
			jdbcTemplate.execute(lstQuery);
			
			jdbcTemplate.getDataSource().getConnection().close();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			logProcess.add(LocalDateTime.now() + " --- ERROR: " + e.toString());
			return false;
		}
	}
	
	public String createQuery(String data){
		StringBuilder query = new StringBuilder("INSERT INTO " + infomationDB.getSchema() + "." + table);
		query.append("(" + columns + ")");
		query.append(" VALUES");
		query.append("(" + data + ");");
		
		//LOGGER.info("Query insert: {}", query.toString());
		return query.toString();
	}
}
