package vn.bamberg.services;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

@SuppressWarnings("restriction")
public class EncryptDecryptUtils {

    public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
    public static final String DES_ENCRYPTION_SCHEME = "DES";
    public static final String DEFAULT_ENCRYPTION_KEY = "This is a fairly long phrase used to encrypt";
    private static KeySpec keySpec;
    private static SecretKeyFactory keyFactory;
    private static Cipher cipher;
    private static final String UNICODE_FORMAT = "UTF8";

    /**
     *
     * @param encryptionScheme
     * @throws EncryptionException
     */
    public EncryptDecryptUtils(String encryptionScheme) throws Exception {
        this(encryptionScheme, DEFAULT_ENCRYPTION_KEY);
    }

    /**
     *
     * @param encryptionScheme
     * @param encryptionKey
     * @throws EncryptionException
     */
    public EncryptDecryptUtils(String encryptionScheme, String encryptionKey)
            throws Exception {

        if (encryptionKey == null) {
            throw new IllegalArgumentException("encryption key was null");
        }
        if (encryptionKey.trim().length() < 24) {
            throw new IllegalArgumentException(
                    "encryption key was less than 24 characters");
        }

        try {
            byte[] keyAsBytes = encryptionKey.getBytes(UNICODE_FORMAT);

            if (encryptionScheme.equals(DESEDE_ENCRYPTION_SCHEME)) {
                keySpec = new DESedeKeySpec(keyAsBytes);
            } else if (encryptionScheme.equals(DES_ENCRYPTION_SCHEME)) {
                keySpec = new DESKeySpec(keyAsBytes);
            } else {
                throw new IllegalArgumentException(
                        "Encryption scheme not supported: " + encryptionScheme);
            }

            keyFactory = SecretKeyFactory.getInstance(encryptionScheme);
            cipher = Cipher.getInstance(encryptionScheme);

        } catch (Exception e) {
            throw e;
        }

    }

    /**
     *
     * @param unencryptedString
     * @return
     * @throws EncryptionException
     */
	public static String encrypt(String unencryptedString) {
        String retVal = "";
        if (unencryptedString != null && unencryptedString.trim().length() > 0) {
            try {
                String encryptionKey = DEFAULT_ENCRYPTION_KEY;
                byte[] keyAsBytes = encryptionKey.getBytes(UNICODE_FORMAT);
                keySpec = new DESKeySpec(keyAsBytes);
                keyFactory = SecretKeyFactory.getInstance(DES_ENCRYPTION_SCHEME);
                cipher = Cipher.getInstance(DES_ENCRYPTION_SCHEME);

                SecretKey key = keyFactory.generateSecret(keySpec);
                cipher.init(Cipher.ENCRYPT_MODE, key);
                byte[] cleartext = unencryptedString.getBytes(UNICODE_FORMAT);
                byte[] ciphertext = cipher.doFinal(cleartext);

                BASE64Encoder base64encoder = new BASE64Encoder();
                retVal = base64encoder.encode(ciphertext);
            } catch (Exception e) {
            }
        }
        return retVal;
    }

    /**
     *
     * @param encryptedString
     * @return
     * @throws EncryptionException
     */
    public static String decrypt(String encryptedString) {
        String retVal = "";
        if (encryptedString != null && encryptedString.trim().length() > 0) {
            try {
                String encryptionKey = DEFAULT_ENCRYPTION_KEY;
                byte[] keyAsBytes = encryptionKey.getBytes(UNICODE_FORMAT);
                keySpec = new DESKeySpec(keyAsBytes);
                keyFactory = SecretKeyFactory.getInstance(DES_ENCRYPTION_SCHEME);
                cipher = Cipher.getInstance(DES_ENCRYPTION_SCHEME);

                SecretKey key = keyFactory.generateSecret(keySpec);
                cipher.init(Cipher.DECRYPT_MODE, key);
                BASE64Decoder base64decoder = new BASE64Decoder();
                byte[] cleartext = base64decoder.decodeBuffer(encryptedString);
                byte[] ciphertext = cipher.doFinal(cleartext);

                retVal = bytes2String(ciphertext);
            } catch (Exception e) {
//                logger.error("Error while decrypting data: " + encryptedString + ", " + e.getMessage());
                return encryptedString;
            }
        }
        return retVal;
    }

    /**
     *
     * @param bytes
     * @return
     */
    private static String bytes2String(byte[] bytes) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < bytes.length; i++) {
            stringBuffer.append((char) bytes[i]);
        }
        return stringBuffer.toString();
    }

    /**
     * @author ttduy
     * @todo get EncryptDecryptUtils encrypted string from given str
     * @param str
     * @return
     */
    public static String getEncryptDecryptUtilsDigest(String str) throws Exception {
        try {
            byte[] buffer = str.getBytes();
            byte[] result = null;
            StringBuffer buf = null;
            MessageDigest EncryptDecryptUtils = MessageDigest.getInstance("EncryptDecryptUtils");
            // allocate room for the hash
            result = new byte[EncryptDecryptUtils.getDigestLength()];
            // calculate hash
            EncryptDecryptUtils.reset();
            EncryptDecryptUtils.update(buffer);
            result = EncryptDecryptUtils.digest();
            // create hex string from the 16-byte hash
            buf = new StringBuffer(result.length * 2);
            for (int i = 0; i < result.length; i++) {
                int intVal = result[i] & 0xff;
                if (intVal < 0x10) {
                    buf.append("0");
                }
                buf.append(Integer.toHexString(intVal).toUpperCase());
            }
            return buf.toString();
        } catch (NoSuchAlgorithmException e) {
            throw e;
        }
    }
    
    public static String getMD5Digest(String str) throws Exception {
        try {
            byte[] buffer = str.getBytes();
            byte[] result = null;
            StringBuffer buf = null;
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            // allocate room for the hash
            result = new byte[md5.getDigestLength()];
            // calculate hash
            md5.reset();
            md5.update(buffer);
            result = md5.digest();
            // create hex string from the 16-byte hash
            buf = new StringBuffer(result.length * 2);
            for (int i = 0; i < result.length; i++) {
                int intVal = result[i] & 0xff;
                if (intVal < 0x10) {
                    buf.append("0");
                }
                buf.append(Integer.toHexString(intVal).toUpperCase());
            }
            return buf.toString();
        } catch (NoSuchAlgorithmException e) {
            throw e;
        }
    }
    
    /*public static void main(String[] args) throws Exception {
    	EncryptDecryptUtils encryptDecryptUtils = new EncryptDecryptUtils("DES");
    	//System.out.println(encryptDecryptUtils.encrypt("Test$&789"));
    	//System.out.println(encryptDecryptUtils.decrypt("15vONe50IYz1XTPT4rjSRA=="));
    	
    	//System.out.println(encryptDecryptUtils.encrypt("123456"));
    	//System.out.println(encryptDecryptUtils.decrypt("3wlB9ck9iJ0="));
	}*/
}