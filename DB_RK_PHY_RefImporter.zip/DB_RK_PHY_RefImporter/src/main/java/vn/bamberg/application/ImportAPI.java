package vn.bamberg.application;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import vn.bamberg.services.ExtractData;


@RestController
public class ImportAPI {
	
	Logger LOGGER = LoggerFactory.getLogger(ImportAPI.class);

	@Value("${title}")
	String[] title;
	
	@Autowired
	private ExtractData extractData;
	
	@RequestMapping(value="/init", method=RequestMethod.GET)
	public ResponseEntity<List<String>> initial() { 		
		return new ResponseEntity<List<String>>(Arrays.asList(title), HttpStatus.OK);
	}
	 
	/* String "file" in @RequestParam is attribute name="file" inside tag <input /> or fd.append() in file main.js */
	@RequestMapping(value="/uploadFile", method=RequestMethod.POST)
	public ResponseEntity<Boolean> handleFileUpload(@RequestParam("file") MultipartFile file) { 
		// Step1: Check folder unzip exist.
		extractData.dirUnzip();
		
		// Step2: Unzip file upload into folder unzip.
		Boolean status = extractData.extractFileUpload(file);
		
		return new ResponseEntity<Boolean>(status, HttpStatus.OK);
	}
	
	@RequestMapping(value="/importToDB", method=RequestMethod.GET)
	public ResponseEntity<Boolean> handleImport() {
		extractData.setFlagCancelProcess(false);
		
		Boolean result = extractData.handleImport();
		
		return new ResponseEntity<Boolean>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value="/fetchLog", method=RequestMethod.GET)
	public ResponseEntity<List<String>> fetchLog() {
		return new ResponseEntity<List<String>>(extractData.fetchLogProcess(), HttpStatus.OK);
	}
	
	@RequestMapping(value="/cancelProcess", method=RequestMethod.GET)
	public void cancelProcess() {
		extractData.setFlagCancelProcess(true);
		LOGGER.info("User has stoped process.");
	}
}
