let app = angular.module('myApp', []);

app.controller('mainCtrl', ['$scope', '$http', '$log', '$interval', function($scope, $http, $log, $interval) {
	$scope.logger = [];
	$scope.loader = false;
	$scope.flagImporting = false;
	
	$scope.initial = function() {
		$http({
	        method : "GET",
	        url : "/init"
	    }).then(function mySuccess(response) {
	    	$scope.title = response.data;
	    	$log.log($scope.title);
	    }, function myError(response) {
	    	$log.error('error: ' + response.statusText);
	    });
	}
	
	$scope.submit = function() {
		if($scope.multipartFile === undefined) {
			$scope.logger.push("ERROR: You must choose file zip to import.");
			return;
		}
		
		if($scope.multipartFile.name.indexOf(".zip") == -1 || $scope.multipartFile.type !== 'application/x-zip-compressed') {
			$scope.logger.push("ERROR: file [" + $scope.multipartFile.name + "] doesn't file zip");
			return;
		}
		
		
		$log.log('Import file ' + $scope.multipartFile.name);
		$scope.loader = true;	// trigger show animation loader
		$scope.clearLogger();
		
		var fd = new FormData();
        fd.append('file', $scope.multipartFile);
     
        $http.post(
        	"/uploadFile", 
        	fd, 
        	{ transformRequest: angular.identity, headers: {'Content-Type': undefined} }
        ).then(function(response) {
        	if(response.data) {
        		//Disable both button import and input choose file
        		$scope.flagImporting = true;
        		
        		//Begin process import and per seconds fetch log.
        		$scope.handleImport();
        		$scope.intervalLog();
        	} else {
        		$scope.fetchLog();
        		$scope.loader = false;	// trigger hide animation loader
        	}
		}, function(response) {
			$log.error('error: ' + response.statusText);
		});
	}
	
	$scope.handleImport = function() {
		$log.log('Processing import data to database');
		
		$http({
	        method : "GET",
	        url : "/importToDB"
	    }).then(function mySuccess(response) {
	    	if(response.data) {
	    		//Disbale animation loader
	    		$scope.loader = false;
	    		
	    		//Unable both button import and input choose file
	    		$scope.flagImporting = false;
	    		
	    		//Clear interval
	    		$interval.cancel($scope.intervalLogProcess);
	    		
	    		//More time fetch log 
	    		$scope.fetchLog();
	    	}
	    }, function myError(response) {
	    	$log.error('error: ' + response.statusText);
	    });
	}
	
	$scope.clearLogger = function() {
		$scope.logger = [];
	}

	$scope.intervalLog = function() {
		$scope.intervalLogProcess = $interval(function () {
			$scope.fetchLog();
		}, 1000);
	}
	
	$scope.fetchLog = function() {
		$http({
	        method : "GET",
	        url : "/fetchLog"
	    }).then(function mySuccess(response) {
	    	//Get logger
	    	$scope.logger = response.data;
	    }, function myError(response) {
	    	$log.error('error: ' + response.statusText);
	    });
	}
	
	$scope.cancelProcess = function() {
		$log.log('User has canceled process.');
		
		$http({
	        method : "GET",
	        url : "/cancelProcess"
	    }).then(function mySuccess(response) {
	    	//Unable both button import and input choose file
    		$scope.flagImporting = false;
	    }, function myError(response) {
	    	$log.error('error: ' + response.statusText);
	    });
	}
	
}]);

app.directive('fileModel', ['$parse', function ($parse) {
    return {
       restrict: 'A',
       link: function(scope, element, attrs) {
          var model = $parse(attrs.fileModel);
          var modelSetter = model.assign;
          
          element.bind('change', function() {
             scope.$apply(function() {
                modelSetter(scope, element[0].files[0]);
             });
          });
       }
    };
 }]);
