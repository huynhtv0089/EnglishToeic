shopApp.service('AppService', [function(){
	this.dataProduction = function() {
		return  [
			{
				'image' : 'product12.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product11.jpg',
				'price' : 57000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product10.jpg',
				'price' : 58000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product9.jpg',
				'price' : 59000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product8.jpg',
				'price' : 55000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product7.jpg',
				'price' : 54000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product6.jpg',
				'price' : 53000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product5.jpg',
				'price' : 52000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product4.jpg',
				'price' : 51000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product3.jpg',
				'price' : 60000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product2.jpg',
				'price' : 61000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product1.jpg',
				'price' : 62000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			}		
		]; 
	}

	this.dataFeaturesItems = function() {
		return [
			{
				'image' : 'halong.jpg',
				'price' : 'Đã có 16,000 lượt khách',
				'nameProduct' : 'Hạ Long',
				'urlProduct' : '#',
				'newProduct' : ''
			},
			{
				'image' : 'sapa.jpg',
				'price' : 'Đã có 26,000 lượt khách',
				'nameProduct' : 'Sapa',
				'urlProduct' : '#',
				'newProduct' : ''
			},
			{
				'image' : 'hoian.jpg',
				'price' : 'Đã có 100,000 lượt khách',
				'nameProduct' : 'Hội An',
				'urlProduct' : '#'
			},
			{
				'image' : 'quynhon.jpg',
				'price' : 'Đã có 57,000 lượt khách',
				'nameProduct' : 'Quy Nhơn',
				'urlProduct' : '#',
				'newProduct' : 'new.png'
			},
			{
				'image' : 'chaua.jpg',
				'price' : 'Đã có 146,000 lượt khách',
				'nameProduct' : 'Châu Á',
				'urlProduct' : '#',
				'newProduct' : ''
			},
			{
				'image' : 'chaumy.jpg',
				'price' : 'Đã có 62,000 lượt khách',
				'nameProduct' : 'Châu Mỹ',
				'urlProduct' : '#',
				'newProduct' : ''
			},
			{
				'image' : 'chauphi.jpg',
				'price' : 'Đã có 14,000 lượt khách',
				'nameProduct' : 'Châu Phi',
				'urlProduct' : '#',
				'newProduct' : ''
			},
			{
				'image' : 'chauau.jpg',
				'price' : 'Đã có 106,000 lượt khách',
				'nameProduct' : 'Châu Âu',
				'urlProduct' : '#',
				'newProduct' : ''
			}
		];
	}

	this.dataTShirt = function() {
		return [
			{
				'image' : 'gallery1.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery1.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataBlazers = function() {
		return [
			{
				'image' : 'gallery4.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery1.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataSunglass = function() {
		return [
			{
				'image' : 'gallery3.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery1.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataKids = function() {
		return [
			{
				'image' : 'gallery1.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery1.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataPoloShirt = function() {
		return [
			{
				'image' : 'gallery2.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery1.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56000,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataRecommendedItems = function() {
		return [
			{
				'image' : 'qnpy.jpg',
				'price' : '7,290,000 đ',
				'nameProduct' : 'Phú Yên - Quy Nhơn',
				'urlProduct' : '#',
			},
			{
				'image' : 'ita.jpg',
				'price' : '49,990,000 đ',
				'nameProduct' : 'Ý: Milan - Venie - Pisa',
				'urlProduct' : '#',
			},
			{
				'image' : 'db.jpg',
				'price' : '32,990,000 đ',
				'nameProduct' : 'Abu Dhabi - Dubai',
				'urlProduct' : '#',
			},
			{
				'image' : 'namphi.jpg',
				'price' : '64,990,000 đ',
				'nameProduct' : 'Nam Phi: Johannesburg',
				'urlProduct' : '#',
			}
		];
	}

	this.dataCategory = function() {
		return [
			{'name': 'Giày thể thao', 'url': '#'},
			{'name': 'Đồ nam', 'url': '#'},
			{'name': 'Đồ trẻ em', 'url': '#'},
			{'name': 'Thời trang', 'url': '#'},
			{'name': 'Áo Households', 'url': '#'},
			{'name': 'Áo Interiors', 'url': '#'},
			{'name': 'Khăn choàng', 'url': '#'},
			{'name': 'Cặp da', 'url': '#'},
			{'name': 'Giày da', 'url': '#'}
		];
	}

	this.dataBrands = function() {
		return [
			{'name': 'Acne', 'quantity': 5, 'url': '#'},
			{'name': 'Grüne Erde', 'quantity': 56, 'url': '#'},
			{'name': 'Albiro', 'quantity': 27, 'url': '#'},
			{'name': 'Ronhill', 'quantity': 32, 'url': '#'},
			{'name': 'Oddmolly', 'quantity': 5, 'url': '#'},
			{'name': 'Boudestijn', 'quantity': 9, 'url': '#'},
			{'name': 'Rösch creative culture', 'quantity': 4, 'url': '#'}
		];
	}

	this.imageViewProduct = function() {
		return 'bang.png';
	}

	this.dataCart = function() {
		return [
			{'name': 'Colorblock Scuba', 'price': 59000, 'quantity': 1, 'total': 59000, 'image': 'one.png'},
			{'name': 'Colorblock Scuba', 'price': 59000, 'quantity': 2, 'total': 118000, 'image': 'two.png'},
			{'name': 'Colorblock Scuba', 'price': 59000, 'quantity': 3, 'total': 177000, 'image': 'three.png'},
		];
	}

}]);