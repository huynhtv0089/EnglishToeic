var sidebarCtr = shopApp.controller('sidebarCtr', ['AppService', '$scope', '$http', function(AppService, $scope, $http){
	$scope.category = AppService.dataCategory();
	$scope.brands = AppService.dataBrands();
	
}]);