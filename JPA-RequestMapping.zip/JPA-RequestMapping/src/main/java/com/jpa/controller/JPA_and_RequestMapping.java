package com.jpa.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.jpa.model.entity.ContainerUser;
import com.jpa.model.entity.Nation;
import com.jpa.model.entity.Room;
import com.jpa.model.entity.User;
import com.jpa.model.repository.ContainerUserRepo;
import com.jpa.model.repository.RoomRepo;
import com.jpa.model.repository.UserRepo;

@RestController
//@Controller
@RequestMapping("/RESTful")
public class JPA_and_RequestMapping {
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	ContainerUserRepo containerUser;
	
	@Autowired
	RoomRepo roomRepo;
	
	List<ContainerUser> lstContainerUser = new ArrayList<>();
	List<Room> lstRoom = new ArrayList<>();
	private User userHandl;
	private ContainerUser containerUserHandl;
	
	@RequestMapping(value="/createUser", method=RequestMethod.GET, produces={"application/text"})
	public @ResponseBody String createUser() {
		String userId = "";
		try {
			
			for (int i=0; i<100000; i++) {
				Room room = new Room("room " + (i+1));
				roomRepo.save(room);
				
				User user = new User("htvy9", "huynhtv9999", this.lstContainerUser.get(0), room);
				userRepo.save(user);
				this.lstContainerUser.get(0).setLstUser(user);
				userId = String.valueOf(user.getId());
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return "User successfully created with id = " + userId;
	}
	
	@RequestMapping(value="/createContainerUser", method={RequestMethod.POST, RequestMethod.GET})
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	public String createContainerUser() {
		String containerUserId = "";
		Map<String, String> containerJson = new HashMap<String, String>();
		try {
			ContainerUser container = new ContainerUser("container 9");
			containerUser.save(container);
			containerUserId = String.valueOf(container.getId());
			lstContainerUser.add(container);
			
			
			containerJson.put("result", "Container successfully created with id =" + containerUserId);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return "Container successfully created with id =" + containerUserId;
		//return containerJson;
		//return new ResponseEntity<Map<String, String>>(containerJson, HttpStatus.OK);
	}
	
	@RequestMapping("/showContainer")  //Use both method Post and method GET is OK
	public String showContainer() {
		String result = "";
		for (User u : this.lstContainerUser.get(0).getLstUser()) {
			result += "id: " + u.getId() + ", email: " + u.getEmail() + ", name: " + u.getName() + ", size: " + this.lstContainerUser.get(0).getLstUser().size() + "<br />"; 
		}
		
		return result;
	}
	
	@RequestMapping("/createRoom")
	public String createRoom() {
		String roomId = "";
		try {
			Room room = new Room("room 1");
			roomRepo.save(room);
			this.lstRoom.add(room);
			roomId = String.valueOf(room.getId());
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return "Room successfully created with id = " + roomId;
	} 
	
	@RequestMapping("/searchAllUser")
	@ResponseBody
	public String getSearchAllUser() {
		String result = "";
		try {
			for(User user : (List<User>)userRepo.findAll()) {
				result += "id: " + user.getId() + ", email: " + user.getEmail() + ", name: " + user.getName() + "<br />"; 
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	@RequestMapping("/deleteUser")
	@ResponseBody
	public String deleteUser(long id) {
		String result = ""; 
		try {
			userRepo.findById(id).ifPresent(user -> { userHandl = user; });
			result += "id: " + this.userHandl.getId() + ", email: " + this.userHandl.getEmail() + ", name: " + this.userHandl.getName() + "<br />"; 	
			
			userRepo.delete(userHandl);
		} catch(Exception e) {
			return "Error deleting the user" + e.toString();
		}
		return result;
	}
	
	@RequestMapping("/deleteContainerName")
	@ResponseBody
	public String deleteContainerUser(long id) {
		String result = ""; 
		try {
			containerUser.findById(id).ifPresent(containerUser -> { containerUserHandl = containerUser; });
			result += "id: " + this.containerUserHandl.getId() + ", Container name: " + this.containerUserHandl.getContainerName() + "<br />"; 
			
			containerUser.delete(containerUserHandl);
		} catch(Exception e) {
			return "Error deleting the user" + e.toString();
		}
		return result;
	}
	
	@RequestMapping("/updateUser")
	@ResponseBody
	public String updateUser(long id, String email, String name) {
		String result = ""; 
		try {
			userRepo.findById(id).ifPresent(user -> {userHandl = user;});
			this.userHandl.setEmail(email);
			this.userHandl.setName(name);
			userRepo.save(this.userHandl);
			result += "id: " + this.userHandl.getId() + ", email: " + this.userHandl.getEmail() + ", name: " + this.userHandl.getName() + "<br />";
		} catch (Exception e) {
			return "Error updating the user " + e.toString();
		}
		return "User succesfully updated, result: " + result;
	}
	
	@RequestMapping("/updateContainerUser")
	@ResponseBody
	public String updateContainerUser(long id, String containerName) {
		String result = ""; 
		try {
			containerUser.findById(id).ifPresent(containerUser -> { containerUserHandl = containerUser; });
			this.containerUserHandl.setContainerName(containerName);
			containerUser.save(this.containerUserHandl);
			result += "id: " + this.containerUserHandl.getId() + ", Container name: " + this.containerUserHandl.getContainerName() + "<br />"; 
		} catch (Exception e) {
			return "Error updating the user " + e.toString();
		}
		return "User succesfully updated, result: " + result;
	}	
	
	@RequestMapping("/searchAllUserOnContainer")
	@ResponseBody
	public String showIdContainerToUser(long id) {
		String result = ""; 
		try {	
			final List<User> lstUser = this.containerUser.findUserByIdContainer(id);
			result += String.valueOf(lstUser.size()) + "<br />";
			for(User u : lstUser) { 
				result += "id: " + u.getId() + ", email: " + u.getEmail() + ", name: " + u.getName() + ", containerUser_id: " + u.getContainerUser().getId() + ", room_id: " + u.getRoomUser().getId() + "<br />";
			}
			
		} catch (Exception e) {
			return "Error search the user " + e.toString();
		}
		return "Search succesfully, have: " + result + " user";
	}
	
	
	
	
	
	/* Note: Entity RequestBody haven't constructor ,if entity that have constructor then error will happen
	 * RequestMethod is POST
	 * Postman app: Body -> {"name": "VN", "area":"asia" } -> choose JSON(application/json)
	 */
	@RequestMapping(value="callAPIParamsJSON/object", method=RequestMethod.POST)
	public ResponseEntity<List<Nation>> paramsJSON_Object(@RequestBody Nation requestNation) {
		System.out.println("nation.getName(): " + requestNation.getName());
		System.out.println("nation.getArea(): " + requestNation.getArea());

		List<Nation> lstNation = new ArrayList<>();
		//Nation nation = null; //new Nation("name", "area");
		lstNation.add(requestNation);
		
		return new ResponseEntity<List<Nation>>(lstNation, HttpStatus.OK);
	}
	
	/* Postman app: Body -> ["john", "boo", "foo"] -> choose JSON(application/json) */
	@RequestMapping(value="callAPIParamsJSON/array", method=RequestMethod.POST)
	public ResponseEntity<String[]> paramsJSON_Array(@RequestBody String[] strArr) {
		System.out.println("length array: " + strArr.length);

		for(String element : strArr) {
			System.out.println("Element: " + element);
		}
		
		return new ResponseEntity<String[]>(strArr, HttpStatus.OK);
	}
	
	/*
	 * Call API, pass param from URL
	 * Use both: POST and GET
	 * Use annotaion: @RequestParam 
	 */
	@RequestMapping(value="callAPIParamsURL/POST", method=RequestMethod.POST)
	public ResponseEntity<List<Nation>> paramsURL_Post(@RequestParam("name") String valueName, @RequestParam("area") String valueArea) {
		System.out.println("valueName: " + valueName);
		System.out.println("valueArea: " + valueArea);

		List<Nation> lstNation = new ArrayList<>();
		Nation nation = new Nation();
		nation.setArea(valueArea);
		nation.setName(valueName);
		lstNation.add(nation);
		
		return new ResponseEntity<List<Nation>>(lstNation, HttpStatus.OK);
	}
	
	@RequestMapping(value="callAPIParamsURL/GET", method=RequestMethod.GET)
	public ResponseEntity<List<Nation>> paramsURL_GET(@RequestParam("name") String valueName, @RequestParam("area") String valueArea) {
		System.out.println("valueName: " + valueName);
		System.out.println("valueArea: " + valueArea);

		List<Nation> lstNation = new ArrayList<>();
		Nation nation = new Nation();
		nation.setArea(valueArea);
		nation.setName(valueName);
		lstNation.add(nation);
		
		return new ResponseEntity<List<Nation>>(lstNation, HttpStatus.OK);
	}
	
	/*
	 * Call API, pass param from URL, use: @PathVariable
	 * Use both: POST and GET
	 * Use annotaion: @PathVariable 
	 */
	@RequestMapping(value="callAPIPPathVariable/{id}/{name}", method= {RequestMethod.POST, RequestMethod.GET})
	public ResponseEntity<String> getPathVariable(@PathVariable String id, @PathVariable String name) {
		System.out.println("id: " + id);
		System.out.println("name: " + name);
		
		return new ResponseEntity<String>(id + " | "+ name, HttpStatus.OK);
	}
	
}
