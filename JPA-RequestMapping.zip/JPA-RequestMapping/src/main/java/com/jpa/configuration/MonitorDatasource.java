package com.jpa.configuration;


import org.springframework.jmx.export.annotation.ManagedResource;


@ManagedResource
public class MonitorDatasource {
	/*@Bean
    protected ConnectionPool euroTourJmxPool(DataSource dataSource) {
		return ((DataSourceProxy) dataSource).getPool().getJmxPool();
    }*/
}
