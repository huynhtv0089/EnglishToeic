package com.jpa.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="room")
public class Room implements Serializable {

	private static final long serialVersionUID = 6671165971129879620L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="name_room", length=50, nullable=false)
	private String nameRoom;
	
	@OneToOne(mappedBy="roomUser")
	private User user;

	public Room() {}
	
	public Room(String nameRoom) {
		this.nameRoom = nameRoom;
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNameRoom() {
		return nameRoom;
	}

	public void setNameRoom(String nameRoom) {
		this.nameRoom = nameRoom;
	}
	
	
}
