package com.jpa.model.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="containerUser")
public class ContainerUser implements Serializable {
	
	private static final long serialVersionUID = 3202740047491562235L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="containerName", length=50, nullable=false)
	private String containerName;
	
	@OneToMany(mappedBy="containerUser", fetch = FetchType.LAZY)
	private List<User> lstUser;
	
	public ContainerUser() {}
	
	public ContainerUser(String containerName) {
		this.containerName = containerName;
		lstUser = new ArrayList<>();
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getContainerName() {
		return containerName;
	}

	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}

	public List<User> getLstUser() {
		return lstUser;
	}

	public void setLstUser(User user) {
		this.lstUser.add(user);
	}
	
}
