package com.jpa.model.entity;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="user")
public class User implements Serializable {

	private static final long serialVersionUID = -1172926230162634050L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name="email", length=50, nullable=true)
	private String email;
	
	@Column(name="name", length=50, nullable=false)
	private String name;
	
	/* LAZY: get current table that and not get data fom these relationship, EAGER: get all table join together or these relationship with tables*/
	@ManyToOne(fetch = FetchType.LAZY) 
	//@JoinColumn(name="containerUser_id") (Default created)
	private ContainerUser containerUser;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="room_id") 
	private Room roomUser;
	
	public User() { }
	
	public User(String email, String name, ContainerUser containerUser, Room roomUser) {
		this.email = email;
		this.name = name;
		this.containerUser = containerUser;
		this.roomUser = roomUser;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ContainerUser getContainerUser() {
		return containerUser;
	}

	public void setContainerUser(ContainerUser containerUser) {
		this.containerUser = containerUser;
	}

	public Room getRoomUser() {
		return roomUser;
	}

	public void setRoomUser(Room roomUser) {
		this.roomUser = roomUser;
	}
	
}
