#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [ -d $DIR/config ]; then
	APPCONFIG=$(ls $DIR/config | grep application.properties | head -n 1)
	LOGCONFIG=$(ls $DIR/config | grep logback-spring.xml | head -n 1)
fi
JARFILE=$(ls $DIR | grep *jar | head -n 1)
if ! [ -z $JARFILE ] && ! [ -z $APPCONFIG ] && ! [ -z $LOGCONFIG ]; then
	java -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.port=5000 -jar $DIR/$JARFILE --logging.config=file:$DIR/config/$LOGCONFIG "$@"
else
	echo "Cannot find executable JAR file or necessary configuration files."
fi
