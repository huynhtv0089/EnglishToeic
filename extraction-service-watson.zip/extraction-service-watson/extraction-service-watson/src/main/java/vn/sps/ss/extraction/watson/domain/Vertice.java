package vn.sps.ss.extraction.watson.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class Vertice implements Serializable {
	
	private static final long serialVersionUID = 6864485064683158922L;
	
	@JsonProperty("x")
	private int x;
	
	@JsonProperty("y")
	private int y;

	public Vertice() {
	}

	public Vertice(Vertice vertice) {
		this.x = vertice.getX();
		this.y = vertice.getY();
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	@Override
	public String toString() {
		return "Vertice [x=" + x + ", y=" + y + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vertice other = (Vertice) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}
}