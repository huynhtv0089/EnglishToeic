package vn.sps.ss.extraction.watson.application.service.ocr.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.cloud.vision.v1.Feature.Type;

import vn.sps.ss.extraction.watson.domain.GoogleResponse;
import vn.sps.ss.extraction.watson.domain.OCRRequest;
import vn.sps.ss.extraction.watson.domain.OCRResponse;
import vn.sps.ss.extraction.watson.domain.http.FeatureRequest;
import vn.sps.ss.extraction.watson.domain.http.GoogleClientRequest;
import vn.sps.ss.extraction.watson.domain.http.GoogleMessage;
import vn.sps.ss.extraction.watson.domain.http.ImageRequest;
import vn.sps.ss.extraction.watson.infrastructure.configuration.GoogleProperties;
@Service
@Primary
@ConditionalOnProperty(name = "ocr.image.service-class", havingValue = "vn.sps.ss.extraction.watson.application.service.ocr.impl.ImageGoogleClientImpl")
public class ImageGoogleClientImpl implements ImageService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ImageGoogleClientImpl.class);
	
	@Autowired
	private GoogleProperties properties;
	
	@Autowired
	private RestTemplate googleRestTemplate;
	
	@Override
	public OCRResponse doOCR(OCRRequest request) {

		final Map<String, Object> result = new HashMap<>();
		final OCRResponse ocrResponse = new OCRResponse();
		ocrResponse.setResult(result);

		try {
			// encodeBase64 byte[] image
			String content = Base64.encodeBase64String(request.getInput());
			
			ImageRequest image = new ImageRequest(content);
			FeatureRequest feature = new FeatureRequest(Type.DOCUMENT_TEXT_DETECTION, 10);
			GoogleClientRequest google = new GoogleClientRequest(image);
			google.addFeature(feature);
			List<GoogleClientRequest> requests = new ArrayList<>();
			requests.add(google);
			
			final GoogleResponse response = postGoogle(requests);
			result.put("result", response.getFullTextAnnotation() != null ? response.getFullTextAnnotation().getText() : "");
			result.put("chars", response.getTextAnnotations());
			//result.put("chars", "");
			
		} catch (Exception e) {
			result.put("result", "");
			result.put("chars", "");
			LOGGER.error("Error when doing OCR", e);
		}
		return ocrResponse;
	}

	private GoogleResponse postGoogle(List<GoogleClientRequest> requests) {
		String url = this.properties.getUrl() +"?key="+ this.properties.getApiKey();
		Map<String, List<GoogleClientRequest>> body = new HashMap<>();
		body.put("requests", requests);
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json");
		HttpEntity<Map<String, List<GoogleClientRequest>>> entity = new HttpEntity<>(body, header);
		GoogleMessage message = this.googleRestTemplate.exchange(url, HttpMethod.POST, entity, GoogleMessage.class).getBody();
		return message.getResponses().get(0);
	}
	
}
