package vn.sps.ss.extraction.watson.application.service.ocr.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.activation.UnsupportedDataTypeException;

import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import vn.sps.ss.extraction.watson.application.service.ocr.OCRService;
import vn.sps.ss.extraction.watson.domain.GoogleRequest;
import vn.sps.ss.extraction.watson.domain.OCRRequest;
import vn.sps.ss.extraction.watson.domain.OCRResponse;
import vn.sps.ss.extraction.watson.infrastructure.configuration.GoogleProperties;

@Service
@Primary
@ConditionalOnProperty(name = "ocr.service-class", havingValue = "vn.sps.ss.extraction.watson.application.service.ocr.impl.GoogleOCRImpl")
public class GoogleOCRImpl implements OCRService {

    private static final Logger LOGGER = LoggerFactory.getLogger(GoogleOCRImpl.class);

    @Autowired
    private RestTemplate googleRestTemplate;

    @Autowired
    private GoogleProperties googleProperties;


    @Override
    public OCRResponse doOCR(OCRRequest request) throws UnsupportedDataTypeException {
        final OCRResponse ocrResponse = new OCRResponse();
        try {
            final HttpEntity<GoogleRequest> entity = new HttpEntity<>(new GoogleRequest(Base64.encodeBase64String(request.getInput())));

            final List<?> result = this.googleRestTemplate.postForObject(
                    this.googleProperties.getUrl(),
                    entity,
                    ArrayList.class);

            if (!result.isEmpty() && result.size() >= 1) {
                ocrResponse.setResult((Map<String, Object>) result.get(0));
            } else  {
                LOGGER.warn("Cannot get data from google ocr");
            }

        } catch (Exception e) {
            LOGGER.error("Error when doing OCR", e);
        }
        return  ocrResponse;
    }

}
