package vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ItemTypeEntity;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemTypeHit extends AbstractHit implements Serializable {

	private static final long serialVersionUID = 6595503172063404345L;
	
	@JsonProperty(value = "sourceAsMap")
    private ItemTypeEntity _source;

    public ItemTypeEntity get_source() {
        return _source;
    }

    public void set_source(ItemTypeEntity _source) {
        this._source = _source;
    }
}
