/*
 * Class: PaymentMethodEntity
 *
 * Created on Oct 17, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentMethodEntity implements Serializable {

    private static final long serialVersionUID = 2283202688172169045L;

    @JsonProperty(value = "payment_method_id")
    private String paymentMethodId;

    @JsonProperty(value = "payment_method_desc")
    private String paymentMethodDesc;
    
    public PaymentMethodEntity() {
        // TODO Auto-generated constructor stub
    }

    public String getPaymentMethodId() {
        return paymentMethodId;
    }

    public void setPaymentMethodId(String paymentMethodId) {
        this.paymentMethodId = paymentMethodId;
    }

    public String getPaymentMethodDesc() {
        return paymentMethodDesc;
    }

    public void setPaymentMethodDesc(String paymentMethodDesc) {
        this.paymentMethodDesc = paymentMethodDesc;
    }
    
}
