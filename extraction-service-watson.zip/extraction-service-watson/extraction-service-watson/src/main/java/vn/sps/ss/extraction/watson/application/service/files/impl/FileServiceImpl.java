package vn.sps.ss.extraction.watson.application.service.files.impl;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import vn.sps.ss.extraction.watson.application.service.files.FileService;
import vn.sps.ss.extraction.watson.infrastructure.configuration.FileServiceProperties;

@Service
@ConditionalOnProperty(name = "ocr.file-service-class", havingValue = "vn.sps.ss.extraction.watson.application.service.files.impl.FileServiceImpl")
public class FileServiceImpl implements FileService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FileServiceImpl.class);
	
    @Autowired
    @Qualifier("fileRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private FileServiceProperties fileServiceProperties;

    @Override
    public  byte[] get(String file) {
        try {
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(this.fileServiceProperties.getUrl()).queryParam("fileId", file);
            InputStreamResource resource = this.restTemplate.getForObject(builder.build().toUriString(), InputStreamResource.class);
            InputStream stream = resource.getInputStream();
            return IOUtils.toByteArray(stream);
        } catch (Exception e) {
        	LOGGER.info("Error when convert file to byte", e);
            return null;
        }
    }
}
