package vn.sps.ss.extraction.watson.infrastructure.configuration;

import static org.apache.commons.lang.StringUtils.substringAfterLast;
import static org.apache.commons.lang.StringUtils.substringBeforeLast;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.Assert;

@Configuration
@ConfigurationProperties(prefix = "filter.rule.elasticsearch")
public class ElasticsearchFilterRuleConfiguration {
	
	static final String COLON = ":";
	private static final Logger LOGGER = LoggerFactory.getLogger(ElasticsearchFilterRuleConfiguration.class);
    
	private String server;
	
	private String clusterName;
	
	private String index;
	
	private String type;
	
	private String username;
	
	private String password;
	
	private TransportClient client = null;
	
	public String getServer() {
		return server;
	}

	public void setServer(String server) {
		this.server = server;
	}

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Bean
	@ConditionalOnProperty(name = "filter.service-class", havingValue = "vn.sps.ss.extraction.watson.application.service.correction.filter.impl.ElasticsearchFilterImpl")
	public Client filterRuleClient() {
		
		try {
			client = new PreBuiltTransportClient(settings());
			Assert.hasText(this.getServer(), "[Assertion failed] server settings missing.");
	
			String hostName = substringBeforeLast(this.getServer(), COLON);
			String port = substringAfterLast(this.getServer(), COLON);
			Assert.hasText(hostName, "[Assertion failed] missing host name in 'server'");
			Assert.hasText(port, "[Assertion failed] missing port in 'server'");
			LOGGER.info("Adding transport node : {}", this.getServer());

			client.addTransportAddress(
					new TransportAddress(InetAddress.getByName(hostName), Integer.valueOf(port)));
			
			client.connectedNodes().forEach(i -> 
				LOGGER.info("Explored node: {}, {}", i.getHostName(), i.getHostAddress())
			);
		} catch (NumberFormatException | UnknownHostException e) {
			LOGGER.error("Error: ", e);
		}
		return client;
	}
	
	private Settings settings() {
		return Settings.builder().put("cluster.name", this.getClusterName()).build();
	}
}
