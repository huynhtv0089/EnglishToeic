package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import vn.sps.ss.extraction.watson.domain.TextAnnotation;


@Entity
@Table(name = "management",indexes= {@Index(columnList="requestId")})
public class ManagementEntity implements Serializable {

    private static final long serialVersionUID = 1868751097440276180L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 30, nullable = true)
    private String requestId;

    @Column(length = 500, nullable = true)
    private String imagePath;

    private Long beginOcr;

    private Long endOcr;

    private Long beginExtract;

    private Long endExtract;

    private Long beginCorrect;

    private Long endCorrect;
    
    private Long receiveTime;

    @OneToOne(mappedBy = "management", fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.MERGE})
    private RawDataEntity raw;

    @OneToOne(mappedBy = "management", fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.MERGE})
    private EntitiesCorrectionEntity correct;

    @OneToMany(mappedBy = "management", fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.MERGE})
    private List<EntitiesEntity> item;
    
    @OneToMany(mappedBy = "management", fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.MERGE})
    private List<RelationsEntity> relation;
    
    @OneToMany(mappedBy = "management", fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.MERGE})
    @MapKey(name="id")
    private Map<String, RelationsCorrectionEntity> itemCorrect;
    
    @Transient
    private List<TextAnnotation> textAnnotations;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public Long getBeginExtract() {
        return beginExtract;
    }

    public void setBeginExtract(Long beginExtract) {
        this.beginExtract = beginExtract;
    }

    public Long getEndExtract() {
        return endExtract;
    }

    public void setEndExtract(Long endExtract) {
        this.endExtract = endExtract;
    }

    public Long getBeginCorrect() {
        return beginCorrect;
    }

    public void setBeginCorrect(Long beginCorrect) {
        this.beginCorrect = beginCorrect;
    }

    public Long getEndCorrect() {
        return endCorrect;
    }

    public void setEndCorrect(Long endCorrect) {
        this.endCorrect = endCorrect;
    }

    public List<EntitiesEntity> getItem() {
        return item;
    }

    public void setItem(List<EntitiesEntity> item) {
        this.item = item;
    }

    public Long getBeginOcr() {
        return beginOcr;
    }

    public void setBeginOcr(Long beginOcr) {
        this.beginOcr = beginOcr;
    }

    public Long getEndOcr() {
        return endOcr;
    }

    public void setEndOcr(Long endOcr) {
        this.endOcr = endOcr;
    }

    public RawDataEntity getRaw() {
        return raw;
    }

    public void setRaw(RawDataEntity raw) {
        this.raw = raw;
    }

    public EntitiesCorrectionEntity getCorrect() {
        return correct;
    }

    public void setCorrect(EntitiesCorrectionEntity correct) {
        this.correct = correct;
    }

	public Long getReceiveTime() {
		return receiveTime;
	}

	public void setReceiveTime(Long receiveTime) {
		this.receiveTime = receiveTime;
	}

	public Map<String, RelationsCorrectionEntity> getItemCorrect() {
		return itemCorrect;
	}

	public void setItemCorrect(Map<String, RelationsCorrectionEntity> itemCorrects) {
		this.itemCorrect = itemCorrects;
	}

	public List<RelationsEntity> getRelation() {
		return relation;
	}

	public void setRelation(List<RelationsEntity> relation) {
		this.relation = relation;
	}

	public List<TextAnnotation> getTextAnnotations() {
		return textAnnotations;
	}

	public void setTextAnnotations(List<TextAnnotation> textAnnotations) {
		this.textAnnotations = textAnnotations;
	}
}
