package vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter.FilterRuleEntity;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FilterRuleHit extends AbstractHit implements Serializable {

	private static final long serialVersionUID = 7230782782697971961L;
	
	@JsonProperty(value = "sourceAsMap")
	@SerializedName(value = "_source")
    private FilterRuleEntity source;

    public FilterRuleEntity getSource() {
        return source;
    }

    public void setSource(FilterRuleEntity source) {
        this.source = source;
    }
    
}
