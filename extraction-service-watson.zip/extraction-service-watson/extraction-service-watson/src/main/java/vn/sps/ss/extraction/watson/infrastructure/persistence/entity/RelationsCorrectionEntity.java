package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;
import java.util.*;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.util.CollectionUtils;

import scala.collection.immutable.HashMap;
import vn.sps.ss.extraction.watson.domain.BoundaryResult;

@Entity
@Table(name = "relations_correction", indexes = {
		@Index(name = "index_relations_correction", columnList = "requestId") })
public class RelationsCorrectionEntity implements Serializable {

	private static final long serialVersionUID = -1666462375943281309L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(length = 30, nullable = true)
	private String requestId;

	@Column(length = 255, nullable = true)
	private String itemName;

	@Column(length = 10, nullable = true)
	private String itemNameConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String itemNameBoundary;
	
	@Transient
	private List<BoundaryResult> listItemNameBoundary;

	@Column(length = 255, nullable = true)
	private String itemId;
	
	@Transient
	private TreeMap<Double,String> listItemId;

	@Column(length = 10, nullable = true)
	private String itemIdConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String itemIdBoundary;
	
	@Transient
	private List<BoundaryResult> listItemIdBoundary;

	@Column(length = 255, nullable = true)
	private String quantity;

	@Column(length = 10, nullable = true)
	private String quantityConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String itemQuantityBoundary;
	
	@Transient
	private List<BoundaryResult> listItemQuantityBoundary;

	@Column(length = 255, nullable = true)
	private String itemPrice;
	
	@Transient
	private TreeMap<Double,String> listItemPrice;

	@Column(length = 10, nullable = true)
	private String itemPriceConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String itemPriceBoundary;
	
	@Transient
	private List<BoundaryResult> listItemPriceBoundary;

	@Transient
	private List<String> subItems;
	
	@Transient
	private List<BoundaryResult> listSubItemsBoundary;
	
	@Column(length = 255, nullable = true)
	private String itemType;
	
	@Column(length = 255, nullable = true)
	private String itemTypeId;

	@Column(length = 10, nullable = true)
	private String itemTypeConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String itemTypeBoundary;
	
	@Transient
	private List<BoundaryResult> listItemTypeBoundary;

	@Column(length = 255, nullable = true)
	private String itemUnit;
	
	@Column(length = 255, nullable = true)
	private String itemUnitId;

	@Column(length = 10, nullable = true)
	private String itemUnitConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String itemUnitBoundary;
	
	@Transient
	private List<BoundaryResult> listItemUnitBoundary;
	
	@ManyToOne(fetch=FetchType.LAZY)
	private ManagementEntity management;
	
	@Transient
	private int count;
	
	public RelationsCorrectionEntity() {
		this.subItems = new ArrayList<String>();
	}
	
	public RelationsCorrectionEntity(ManagementEntity management) {
		this.management = management;
		this.itemType = "general";
		this.listItemId = new TreeMap<>();
		this.listItemPrice = new TreeMap<>();
		this.subItems = new ArrayList<>();
		this.listItemIdBoundary = new ArrayList<>();
		this.listItemNameBoundary = new ArrayList<>();
		this.listItemPriceBoundary = new ArrayList<>();
		this.listItemQuantityBoundary = new ArrayList<>();
		this.listSubItemsBoundary = new ArrayList<>();
		this.listItemTypeBoundary = new ArrayList<>();
	}

	public RelationsCorrectionEntity(String itemName, String itemPrice, ManagementEntity management) {
		this.management = management;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
	}
	
	public String getQuantityConfidence() {
		return quantityConfidence;
	}

	public void setQuantityConfidence(String quantityConfidence) {
		this.quantityConfidence = quantityConfidence;
	}

	public String getItemPriceConfidence() {
		return itemPriceConfidence;
	}

	public void setItemPriceConfidence(String itemPriceConfidence) {
		this.itemPriceConfidence = itemPriceConfidence;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public String getItemTypeConfidence() {
		return itemTypeConfidence;
	}

	public void setItemTypeConfidence(String itemTypeConfidence) {
		this.itemTypeConfidence = itemTypeConfidence;
	}

	public String getItemUnit() {
		return itemUnit;
	}

	public void setItemUnit(String itemUnit) {
		this.itemUnit = itemUnit;
	}

	public String getItemUnitConfidence() {
		return itemUnitConfidence;
	}

	public void setItemUnitConfidence(String itemUnitConfidence) {
		this.itemUnitConfidence = itemUnitConfidence;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemNameConfidence() {
		return itemNameConfidence;
	}

	public void setItemNameConfidence(String itemNameConfidence) {
		this.itemNameConfidence = itemNameConfidence;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getItemIdConfidence() {
		return itemIdConfidence;
	}

	public void setItemIdConfidence(String itemIdConfidence) {
		this.itemIdConfidence = itemIdConfidence;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(String itemPrice) {
		this.itemPrice = itemPrice;
	}

	public List<String> getSubItems() {
		return subItems;
	}

	public void setSubItems(String subItem) {
		this.subItems.add(subItem);
	}

	public ManagementEntity getManagement() {
		return management;
	}

	public void setManagement(ManagementEntity management) {
		this.management = management;
	}

	public String getItemTypeId() {
		return itemTypeId;
	}

	public void setItemTypeId(String itemTypeId) {
		this.itemTypeId = itemTypeId;
	}

	public String getItemUnitId() {
		return itemUnitId;
	}

	public void setItemUnitId(String itemUnitId) {
		this.itemUnitId = itemUnitId;
	}
	
	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	public TreeMap<Double,String> getListItemId() {
		return listItemId;
	}

	public void setListItemId(Double score, String listItemId) {
		this.listItemId.put(score, listItemId);
	}

	public TreeMap<Double,String> getListItemPrice() {
		return listItemPrice;
	}

	public void setListItemPrice(Double score, String itemPrice) {
		this.listItemPrice.put(score, itemPrice);
	}

	public String getItemNameBoundary() {
		return itemNameBoundary;
	}

	public void setItemNameBoundary(String itemNameBoundary) {
		this.itemNameBoundary = itemNameBoundary;
	}

	public String getItemIdBoundary() {
		return itemIdBoundary;
	}

	public void setItemIdBoundary(String itemIdBoundary) {
		this.itemIdBoundary = itemIdBoundary;
	}

	public String getItemQuantityBoundary() {
		return itemQuantityBoundary;
	}

	public void setItemQuantityBoundary(String itemQuantityBoundary) {
		this.itemQuantityBoundary = itemQuantityBoundary;
	}

	public String getItemPriceBoundary() {
		return itemPriceBoundary;
	}

	public void setItemPriceBoundary(String itemPriceBoundary) {
		this.itemPriceBoundary = itemPriceBoundary;
	}

	public String getItemTypeBoundary() {
		return itemTypeBoundary;
	}

	public void setItemTypeBoundary(String itemTypeBoundary) {
		this.itemTypeBoundary = itemTypeBoundary;
	}

	public String getItemUnitBoundary() {
		return itemUnitBoundary;
	}

	public void setItemUnitBoundary(String itemUnitBoundary) {
		this.itemUnitBoundary = itemUnitBoundary;
	}

	public List<BoundaryResult> getListItemNameBoundary() {
		return listItemNameBoundary;
	}

	public void setListItemNameBoundary(List<BoundaryResult> listItemNameBoundary) {
		this.listItemNameBoundary = listItemNameBoundary;
	}

	public List<BoundaryResult> getListItemIdBoundary() {
		return listItemIdBoundary;
	}

	public void setListItemIdBoundary(List<BoundaryResult> listItemIdBoundary) {
		this.listItemIdBoundary = listItemIdBoundary;
	}

	public List<BoundaryResult> getListItemQuantityBoundary() {
		return listItemQuantityBoundary;
	}

	public void setListItemQuantityBoundary(List<BoundaryResult> listItemQuantityBoundary) {
		this.listItemQuantityBoundary = listItemQuantityBoundary;
	}

	public List<BoundaryResult> getListItemPriceBoundary() {
		return listItemPriceBoundary;
	}

	public void setListItemPriceBoundary(List<BoundaryResult> listItemPriceBoundary) {
		this.listItemPriceBoundary = listItemPriceBoundary;
	}

	public List<BoundaryResult> getListSubItemsBoundary() {
		return listSubItemsBoundary;
	}

	public void setListSubItemsBoundary(List<BoundaryResult> listSubItemsBoundary) {
		this.listSubItemsBoundary = listSubItemsBoundary;
	}

	public List<BoundaryResult> getListItemTypeBoundary() {
		return listItemTypeBoundary;
	}

	public void setListItemTypeBoundary(List<BoundaryResult> listItemTypeBoundary) {
		this.listItemTypeBoundary = listItemTypeBoundary;
	}

	public List<BoundaryResult> getListItemUnitBoundary() {
		return listItemUnitBoundary;
	}

	public void setListItemUnitBoundary(List<BoundaryResult> listItemUnitBoundary) {
		this.listItemUnitBoundary = listItemUnitBoundary;
	}

	

	@Override
	public String toString() {
		return "RelationsCorrectionEntity [itemName=" + itemName + ", listItemNameBoundary=" + listItemNameBoundary
				+ ", itemId=" + itemId + ", listItemIdBoundary=" + listItemIdBoundary + ", quantity=" + quantity
				+ ", listItemQuantityBoundary=" + listItemQuantityBoundary + ", itemPrice=" + itemPrice
				+ ", listItemPriceBoundary=" + listItemPriceBoundary + ", subItems=" + subItems
				+ ", listSubItemsBoundary=" + listSubItemsBoundary + ", itemType=" + itemType
				+ ", listItemTypeBoundary=" + listItemTypeBoundary + ", itemUnit=" + itemUnit
				+ ", listItemUnitBoundary=" + listItemUnitBoundary + "]";
	}

	public int compareTo(RelationsCorrectionEntity rc) {
		if (!CollectionUtils.isEmpty(this.listItemNameBoundary)
				&& !CollectionUtils.isEmpty(rc.getListItemNameBoundary()))
			return this.listItemNameBoundary.get(0).getFinalRectangle()
					.compareTo(rc.getListItemNameBoundary().get(0).getFinalRectangle());

		if (!CollectionUtils.isEmpty(this.listItemNameBoundary) && !CollectionUtils.isEmpty(rc.getListItemIdBoundary()))
			return this.listItemNameBoundary.get(0).getFinalRectangle()
					.compareTo(rc.getListItemIdBoundary().get(0).getFinalRectangle());

		if (!CollectionUtils.isEmpty(this.listItemIdBoundary) && !CollectionUtils.isEmpty(rc.getListItemNameBoundary()))
			return this.listItemIdBoundary.get(0).getFinalRectangle()
					.compareTo(rc.getListItemNameBoundary().get(0).getFinalRectangle());

		if (!CollectionUtils.isEmpty(this.listItemIdBoundary) && !CollectionUtils.isEmpty(rc.getListItemIdBoundary()))
			return this.listItemIdBoundary.get(0).getFinalRectangle()
					.compareTo(rc.getListItemIdBoundary().get(0).getFinalRectangle());
		return 0;
	}
	
}
