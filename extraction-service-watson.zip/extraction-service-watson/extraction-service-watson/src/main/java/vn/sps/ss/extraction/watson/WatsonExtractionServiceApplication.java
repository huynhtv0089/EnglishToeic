package vn.sps.ss.extraction.watson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WatsonExtractionServiceApplication {
	
    public static void main(String[] args) {
        SpringApplication.run(WatsonExtractionServiceApplication.class, args);
    }
}