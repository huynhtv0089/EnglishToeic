package vn.sps.ss.extraction.watson.application.common.util;

import org.jasypt.util.text.BasicTextEncryptor;

public final class Jasypt {

	public static String encryptText(String secretkey, String text) {
		BasicTextEncryptor encryptor = new BasicTextEncryptor();
		encryptor.setPassword(secretkey);
		return encryptor.encrypt(text);
	}
		
	public static String decryptText(String secretkey, String text) {
		BasicTextEncryptor encryptor = new BasicTextEncryptor();
		encryptor.setPassword(secretkey);
		return encryptor.decrypt(text);
	}
	
	public static void main(String[] args) {
		//System.out.println(decryptText("A looooooooooooooooooooong secret key", "FdsgYOiWwBAw8iVcV6Z/2WakdK/+5G0Z"));
		System.out.println(encryptText("A looooooooooooooooooooong secret key", "FdsgYOiWwBAw8iVcV6Z/2WakdK/+5G0Z"));
	}
}
