/*
 * Class: CorrectionRequest
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.domain;

import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;

/**
 * The Class CorrectionRequest.
 */
public class CorrectionRequest extends MeasurableModel {

    /** The management. */
    private ManagementEntity management;

    /**
     * The receipt id.
     */
    private final String receiptId;

    /**
     * Instantiates a new correction request.
     *
     * @param receiptId     the receipt id
     * @param management the management
     */
    public CorrectionRequest(final String receiptId,
            final ManagementEntity management) {
        super();
        this.receiptId = receiptId;
        this.management = management;
    }

    /**
     * Gets the management.
     *
     * @return the management
     */
    public ManagementEntity getManagement() {
        return this.management;
    }

    /**
     * Gets the receipt id.
     *
     * @return the receipt id
     */
    public String getReceiptId() {
        return this.receiptId;
    }

    /**
     * Sets the management.
     *
     * @param management the new management
     */
    public void setManagement(final ManagementEntity management) {
        this.management = management;
    }

}
