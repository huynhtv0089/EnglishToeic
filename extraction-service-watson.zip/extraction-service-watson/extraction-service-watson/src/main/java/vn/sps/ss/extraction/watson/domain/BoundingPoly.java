package vn.sps.ss.extraction.watson.domain;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class BoundingPoly implements Serializable {
	
	private static final long serialVersionUID = 6864485064683158911L;
	
	@JsonProperty("vertices")
	private List<Vertice> vertices;

	public List<Vertice> getVertices() {
		return vertices;
	}

	public void setVertices(List<Vertice> vertices) {
		this.vertices = vertices;
	}

	@Override
	public String toString() {
		return "BoundingPoly [vertices=" + vertices + "]";
	}
}
