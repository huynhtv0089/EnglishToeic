/*
 * Class: ElasticsearchValidationConfiguration
 *
 * Created on Oct 23, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.configuration;

import org.elasticsearch.common.unit.Fuzziness;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "validation.elasticsearch")
public class ElasticsearchValidationConfiguration {

    private String defaultFuzziness;

    private int minConfidence;

    private int houseNrConfidence;

    public Fuzziness getDefaultFuzziness() {
        Fuzziness fuzziness = Fuzziness.AUTO;
        switch (defaultFuzziness) {
        case "1":
            fuzziness = Fuzziness.ONE;
            break;
        case "2":
            fuzziness = Fuzziness.TWO;
            break;
        default:
            fuzziness = Fuzziness.AUTO;
            break;
        }
        return fuzziness;
    }

    public void setDefaultFuzziness(String defaultFuzziness) {
        this.defaultFuzziness = defaultFuzziness;
    }

    public int getMinConfidence() {
        return minConfidence;
    }

    public void setMinConfidence(int minConfidence) {
        this.minConfidence = minConfidence;
    }

    public int getHouseNrConfidence() {
        return houseNrConfidence;
    }

    public void setHouseNrConfidence(int houseNrConfidence) {
        this.houseNrConfidence = houseNrConfidence;
    }

}
