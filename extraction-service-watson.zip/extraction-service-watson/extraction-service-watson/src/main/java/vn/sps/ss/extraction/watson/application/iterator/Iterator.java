package vn.sps.ss.extraction.watson.application.iterator;

import vn.sps.ss.extraction.watson.application.iterator.interceptor.Interceptor;

public interface Iterator <T extends Interceptor> {

	boolean hasNext();

	T next();
	
}
