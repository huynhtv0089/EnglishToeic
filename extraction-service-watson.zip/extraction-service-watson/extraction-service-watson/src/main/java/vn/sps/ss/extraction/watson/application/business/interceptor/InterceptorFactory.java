package vn.sps.ss.extraction.watson.application.business.interceptor;

import java.util.List;

import vn.sps.ss.extraction.watson.infrastructure.ifa.ExternalSubmitter;

public interface InterceptorFactory<T> {
	
	/**
	 * Handler layer will get available interceptors
	 * @param interceptorKeys
	 * @return
	 */
	List<Interceptor> getInterceptors(ExternalSubmitter<T> handler);
}
