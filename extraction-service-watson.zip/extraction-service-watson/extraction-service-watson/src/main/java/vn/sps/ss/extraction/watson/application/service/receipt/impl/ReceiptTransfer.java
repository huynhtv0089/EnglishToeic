package vn.sps.ss.extraction.watson.application.service.receipt.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.util.CollectionUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import vn.sps.ss.extraction.model.extract.ExtractTripAsset;
import vn.sps.ss.extraction.model.extract.ExtractTripBoundaryDetails;
import vn.sps.ss.extraction.model.extract.ExtractTripCoordinate;
import vn.sps.ss.extraction.model.extract.ExtractTripData;
import vn.sps.ss.extraction.model.extract.ExtractTripEntries;
import vn.sps.ss.extraction.model.extract.Trip;
import vn.sps.ss.extraction.model.item.ExtractItem;
import vn.sps.ss.extraction.model.item.ExtractItemAsset;
import vn.sps.ss.extraction.model.item.ExtractItemBoundaryDetails;
import vn.sps.ss.extraction.model.item.ExtractItemCoordinate;
import vn.sps.ss.extraction.model.item.ExtractItemData;
import vn.sps.ss.extraction.model.item.ExtractItemEntries;
import vn.sps.ss.extraction.model.item.Item;
import vn.sps.ss.extraction.watson.application.common.util.StringUtil;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ReceiptCredential;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsCorrectionEntity;

public class ReceiptTransfer {
	
	private ReceiptTransfer() {}

	public static Trip transferFrom(ReceiptCredential credential, List<EntitiesCorrectionEntity> corrections, String requestId) {
		List<ExtractTripData> list = corrections.parallelStream().map(correction -> {
			return transferFrom(credential, correction);
		}).collect(Collectors.toList());
		ExtractTripData[] data = list.toArray(new ExtractTripData[list.size()]);

		ExtractTripEntries entries = new ExtractTripEntries();
		entries.setData(data);
		
		ExtractTripAsset[] extractTripAsset = new ExtractTripAsset[data.length];
		
		for (int i = 0; i < corrections.size(); i++) {
			extractTripAsset[i] = new ExtractTripAsset();
			extractTripAsset[i].setBoundary(transferAsset(credential, corrections.get(i)));
		}
		
		entries.setAsset(extractTripAsset);
		Trip extract = new Trip();
		extract.setEntries(entries);
		return extract;
	}
	
	private static ExtractTripBoundaryDetails transferAsset(ReceiptCredential credential, EntitiesCorrectionEntity correction) {
		Gson gson = new Gson();
		
		ExtractTripBoundaryDetails extractTripBoundaryDetails = new ExtractTripBoundaryDetails();

		extractTripBoundaryDetails.setCity(convertExtractTripBoundary(credential.isReadingCity(), gson, correction.getCityBoundary()));

		extractTripBoundaryDetails.setHousenumber(convertExtractTripBoundary(credential.isReadingHouseNumber(), gson, correction.getHouseNumberBoundary()));

		extractTripBoundaryDetails.setLoyalty(convertExtractTripBoundary(credential.isReadingLoyalty(), gson, correction.getLoyaltyBoundary()));

		extractTripBoundaryDetails.setMerchantname(convertExtractTripBoundary(credential.isReadingMerchant(), gson, correction.getMerchantBoundary()));

		extractTripBoundaryDetails.setMerchantphone(convertExtractTripBoundary(credential.isReadingMerchantPhone(), gson, correction.getMerchantPhoneBoundary()));

		extractTripBoundaryDetails.setOrdernumber(convertExtractTripBoundary(credential.isReadingOrderNumber(), gson, correction.getOrderNumberBoundary()));

		extractTripBoundaryDetails.setPaymentmethoddesc(convertExtractTripBoundary(credential.isReadingPaymentMethod(), gson, correction.getPaymentMethodBoundary()));

		extractTripBoundaryDetails.setPurchasedate(convertExtractTripBoundary(credential.isReadingPurchaseDate(), gson, correction.getPurchaseDateBoundary()));

		extractTripBoundaryDetails.setPurchasetime(convertExtractTripBoundary(credential.isReadingPurchaseTime(), gson, correction.getPurchaseTimeBoundary()));

		extractTripBoundaryDetails.setReceiptypedesc(convertExtractTripBoundary(credential.isReadingReceiptType(), gson, correction.getReceiptTypeBoundary()));

		extractTripBoundaryDetails.setServicetype(convertExtractTripBoundary(credential.isReadingServiceType(), gson, correction.getServiceTypeBoundary()));

		extractTripBoundaryDetails.setState(convertExtractTripBoundary(credential.isReadingState(), gson, correction.getStateBoundary()));

		extractTripBoundaryDetails.setStorenumber(convertExtractTripBoundary(credential.isReadingStoreNumber(), gson, correction.getStoreNumberBoundary()));

		extractTripBoundaryDetails.setAddress(convertExtractTripBoundary(credential.isReadingAddress(), gson, correction.getStreetAddressBoundary()));

		extractTripBoundaryDetails.setTotalpaid(convertExtractTripBoundary(credential.isReadingTotalPaid(), gson, correction.getTotalPaidBoundary()));

		extractTripBoundaryDetails.setZip(convertExtractTripBoundary(credential.isReadingZip(), gson, correction.getZipBoundary()));

		return extractTripBoundaryDetails;
	}
	
	private static ExtractTripCoordinate[] convertExtractTripBoundary(Boolean isProcessced, Gson gson, String field) {
		if (isProcessced) {
			Collection<ExtractTripCoordinate> list = gson.fromJson(field, new TypeToken<List<ExtractTripCoordinate>>() {}.getType());
			return CollectionUtils.isEmpty(list) ? null : list.toArray(new ExtractTripCoordinate[list.size()]);
		} else {
			return null;
		}
	}

	private static ExtractTripData transferFrom(ReceiptCredential credential, EntitiesCorrectionEntity correction) {
		
		ExtractTripData receipt = new ExtractTripData();

		receipt.setCity(credential.isReadingCity() ? correction.getCity() : "");
		
		receipt.setHouseNumber(credential.isReadingHouseNumber() ? correction.getHouseNumber() : "");

		receipt.setLoyaltyCard(credential.isReadingLoyalty() ? correction.getLoyalty() : "");

		receipt.setMerchant(credential.isReadingMerchant() ? correction.getMerchant() : "");

		receipt.setMerchantPhone(credential.isReadingMerchantPhone() ? correction.getMerchantPhone() : "");

		receipt.setOrderNumber(credential.isReadingOrderNumber() ? correction.getOrderNumber() : "");

		receipt.setPaymentMethod(credential.isReadingPaymentMethod() ? correction.getPaymentMethod() : "");

		receipt.setPurchaseDate(credential.isReadingPurchaseDate() ? correction.getPurchaseDate() : "");

		receipt.setPurchaseTime(credential.isReadingPurchaseTime() ? correction.getPurchaseTime() : "");

		receipt.setReceiptType(credential.isReadingReceiptType() ? correction.getReceiptType() : "");

		receipt.setServiceType(credential.isReadingServiceType() ? correction.getServiceType() : "");

		receipt.setState(credential.isReadingState() ? correction.getState() : "");

		receipt.setStoreNumber(credential.isReadingStoreNumber() ? correction.getStoreNumber() : "");

		receipt.setAddress(credential.isReadingAddress() ? correction.getStreetAddress() : "");

		receipt.setTotalPaid(credential.isReadingTotalPaid() ? correction.getTotalPaid() : "");

		receipt.setZip(credential.isReadingZip() ? correction.getZip() : "");

		// similar condition with merchant name
		receipt.setMerchantId(credential.isReadingMerchant() ? correction.getMerchantId() : "");

		// similar condition with payment method
		receipt.setPaymentMethodId(credential.isReadingPaymentMethod() ? correction.getPaymentMethodId() : "");

		return receipt;
	}
	
	private static ExtractItemData transferFrom(RelationsCorrectionEntity correction) {
		ExtractItemData receipt = new ExtractItemData();

		receipt.setItemId(correction.getItemId());
		
		receipt.setItemName(correction.getItemName());
		
		receipt.setItemPrice(correction.getItemPrice());
		
		receipt.setItemQuantity(correction.getQuantity());

		receipt.setItemType(correction.getItemType());
		
		receipt.setItemTypeId(correction.getItemTypeId());
		
		receipt.setItemUnit(correction.getItemUnit());
		
		receipt.setItemUnitId(correction.getItemUnitId());
		
		return receipt;
	}
	
	private static ExtractItemBoundaryDetails transferBoundaryFrom(RelationsCorrectionEntity correction) {

		Gson gson = new Gson();

		ExtractItemBoundaryDetails extractItemBoundaryDetails = new ExtractItemBoundaryDetails();

		extractItemBoundaryDetails.setItemName(convertExtractItemBoundary(gson, correction.getItemNameBoundary()));
		
		extractItemBoundaryDetails.setItemId(convertExtractItemBoundary(gson, correction.getItemIdBoundary()));
		
		extractItemBoundaryDetails.setItemPrice(convertExtractItemBoundary(gson, correction.getItemPriceBoundary()));
		
		extractItemBoundaryDetails.setItemQuantity(convertExtractItemBoundary(gson, correction.getItemQuantityBoundary()));
		
		extractItemBoundaryDetails.setItemType(convertExtractItemBoundary(gson, correction.getItemTypeBoundary()));
		
		extractItemBoundaryDetails.setItemUnit(convertExtractItemBoundary(gson, correction.getItemUnitBoundary()));

		return extractItemBoundaryDetails;
	}
	
	private static ExtractItemCoordinate[] convertExtractItemBoundary(Gson gson, String field) {
		if (StringUtil.isNullOrEmpty(field))
			return null;
		Collection<ExtractItemCoordinate> list = gson.fromJson(field, new TypeToken<List<ExtractItemCoordinate>>() {}.getType());
		return CollectionUtils.isEmpty(list) ? null : list.toArray(new ExtractItemCoordinate[list.size()]);
	}

	public static Item transferFrom(List<List<RelationsCorrectionEntity>> results) {
		
		List<ExtractItem> listExtractItemData = new ArrayList<>();
		results.forEach(result -> {
			List<ExtractItemData> listData = result.parallelStream().map(correction -> {
				return transferFrom(correction);
			}).collect(Collectors.toList());
			
			List<ExtractItemBoundaryDetails> listBoundary = result.parallelStream().map(correction -> {
				return transferBoundaryFrom(correction);
			}).collect(Collectors.toList());
			
			ExtractItemData[] extractItem = listData.toArray(new ExtractItemData[listData.size()]);
			ExtractItem extractItemData = new ExtractItem();
			extractItemData.setData(extractItem);
			
			ExtractItemAsset[] extractItemAsset = new ExtractItemAsset[extractItem.length];
			
			for (int i = 0; i < extractItem.length; i++) {
				extractItemAsset[i] = new ExtractItemAsset();
				extractItemAsset[i].setBoundary(listBoundary.get(i));
			}
			
			extractItemData.setAsset(extractItemAsset);
			listExtractItemData.add(extractItemData);
		});
		ExtractItem[] extractItemDatas = listExtractItemData.toArray(new ExtractItem[listExtractItemData.size()]);
		ExtractItemEntries entries = new ExtractItemEntries();
		entries.setItems(extractItemDatas);
		
		Item item = new Item();
		item.setItems(entries);
		return item;
	}
}
