package vn.sps.ss.extraction.watson.application.iterator.interceptor.extraction;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.iterator.interceptor.AbstractInterceptor;

public class MatchingBoundaryInterceptor extends AbstractInterceptor {

	private static final String MATCHING_BOUNDARY = "matchingBoundary";
	
	private static final MatchingBoundaryInterceptor INSTANCE = new MatchingBoundaryInterceptor();
	
	private MatchingBoundaryInterceptor() {
		super(MATCHING_BOUNDARY);
	}
	
	public static MatchingBoundaryInterceptor getInstance() {
		return INSTANCE;
	}

	@Override
	public ProcessingContext process(ProcessingContext context) {
		return context;
	}
	
}
