package vn.sps.ss.extraction.watson.application.business.interceptor.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.google.gson.Gson;

import vn.sps.ss.extraction.model.extract.ExtractTripCoordinate;
import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.common.util.Constant.Field;
import vn.sps.ss.extraction.watson.application.common.util.HighlightUtil;
import vn.sps.ss.extraction.watson.domain.BoundaryResult;
import vn.sps.ss.extraction.watson.domain.TextAnnotation;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;

@Service
class EntityHighlightInterceptor extends AbstractInterceptor {

	private static final String ENTITY_HIGHLIGHT = "entityhighlight";
	
	private static final Logger LOG = LoggerFactory.getLogger(EntityHighlightInterceptor.class);
	
	private static final EntityHighlightInterceptor INSTANCE = new EntityHighlightInterceptor();
	
	private EntityHighlightInterceptor() {
		super(ENTITY_HIGHLIGHT);
	}
	
	public static EntityHighlightInterceptor getInstance() {
		return INSTANCE;
	}
	
	@Override
	public ProcessingContext process(ProcessingContext context) {
		final long begin = System.currentTimeMillis();
		LOG.info("Start process interceptor {} for request {}.", ENTITY_HIGHLIGHT, context.getId());
		if (context.getManagementEntity().getCorrect() != null) {
			this.updateEntities(context.getManagementEntity(), this.processHighlight(context.getManagementEntity()));
		} else {
			LOG.warn("Trip hightlight process of request {} has been not processed because EntitiesCorrectionEntity is null", context.getId());
		}
		LOG.info("End process interceptor {} for request {} took {}", ENTITY_HIGHLIGHT, context.getId(), System.currentTimeMillis() - begin);
		return context;
	}
	
	private Map<String, List<BoundaryResult>> processHighlight(ManagementEntity management) {
    	Map<String, List<BoundaryResult>> mapResult = new HashMap<>();
        
        mapResult.put(Field.A_MERCHANT, boundary(management.getCorrect().getMerchant(), management.getTextAnnotations()));
        
        mapResult.put(Field.D_ZIP, boundary(management.getCorrect().getZip(), management.getTextAnnotations()));
        
        mapResult.put(Field.O_SERVICE_TYPE, boundary(management.getCorrect().getServiceType(), management.getTextAnnotations()));
        
        mapResult.put(Field.F_CITY, boundary(management.getCorrect().getCity(), management.getTextAnnotations()));
        
        mapResult.put(Field.B_STORE_NUMBER, boundary(management.getCorrect().getStoreNumber(), management.getTextAnnotations()));
        
        mapResult.put(Field.D_ADDRESS, boundary(management.getCorrect().getStreetAddress(), management.getTextAnnotations()));
        
        mapResult.put(Field.F_STATE, boundary(management.getCorrect().getState(), management.getTextAnnotations()));
        
        mapResult.put(Field.C_HOUSE_NUMBER, boundary(management.getCorrect().getHouseNumber(), management.getTextAnnotations()));
        
        mapResult.put(Field.G_PHONE, boundary(management.getCorrect().getMerchantPhone(), management.getTextAnnotations()));
        
        mapResult.put(Field.H_PURCHASE_DATE, boundary(management.getCorrect().getPurchaseDate(), management.getTextAnnotations()));
        
        mapResult.put(Field.I_PURCHASE_TIME, boundary(management.getCorrect().getPurchaseTime(), management.getTextAnnotations()));
        
        mapResult.put(Field.J_TOTAL_PAID, boundary(management.getCorrect().getTotalPaid(), management.getTextAnnotations()));
        
        mapResult.put(Field.M_LOYALTY_CARD, boundary(management.getCorrect().getLoyalty(), management.getTextAnnotations()));
        
        mapResult.put(Field.N_ORDER_NUMBER, boundary(management.getCorrect().getOrderNumber(), management.getTextAnnotations()));
        
        if (!CollectionUtils.isEmpty(management.getCorrect().getExtractPaymentMethods())) {
        	management.getCorrect().getExtractPaymentMethods().forEach(t -> {
        		if (mapResult.get(Field.K_PAYMENT_METHOD) == null) {
        			mapResult.put(Field.K_PAYMENT_METHOD, boundary(t, management.getTextAnnotations()));
        		} else {
        			mapResult.get(Field.K_PAYMENT_METHOD).addAll(boundary(t, management.getTextAnnotations()));
        		}
        	});
        }
        
        //Remove overload
        for (Entry<String, List<BoundaryResult>> entry : mapResult.entrySet()) {
        	HighlightUtil.overload(entry.getKey(), entry.getValue(), mapResult);
        }
        
        return mapResult;
	}
	
	private void updateEntities(ManagementEntity management, Map<String, List<BoundaryResult>> mapResult) {
		// update more columns boundary in entities_correction table
        Gson gson = new Gson();
    	management.getCorrect().setMerchantBoundary(convertJson(gson, mapResult.get(Field.A_MERCHANT)));
    	management.getCorrect().setStoreNumberBoundary(convertJson(gson, mapResult.get(Field.B_STORE_NUMBER)));
    	management.getCorrect().setHouseNumberBoundary(convertJson(gson, mapResult.get(Field.C_HOUSE_NUMBER)));
    	management.getCorrect().setStreetAddressBoundary(convertJson(gson, mapResult.get(Field.D_ADDRESS)));
    	management.getCorrect().setZipBoundary(convertJson(gson, mapResult.get(Field.D_ZIP)));
    	management.getCorrect().setCityBoundary(convertJson(gson, mapResult.get(Field.F_CITY)));
    	management.getCorrect().setStateBoundary(convertJson(gson, mapResult.get(Field.F_STATE)));
    	management.getCorrect().setMerchantPhoneBoundary(convertJson(gson, mapResult.get(Field.G_PHONE)));
    	management.getCorrect().setPurchaseDateBoundary(convertJson(gson, mapResult.get(Field.H_PURCHASE_DATE)));
    	management.getCorrect().setPurchaseTimeBoundary(convertJson(gson, mapResult.get(Field.I_PURCHASE_TIME)));
    	management.getCorrect().setPaymentMethodBoundary(convertJson(gson, mapResult.get(Field.K_PAYMENT_METHOD)));
    	management.getCorrect().setTotalPaidBoundary(convertJson(gson, mapResult.get(Field.J_TOTAL_PAID)));
    	management.getCorrect().setOrderNumberBoundary(convertJson(gson, mapResult.get(Field.N_ORDER_NUMBER)));
    	management.getCorrect().setLoyaltyBoundary(convertJson(gson, mapResult.get(Field.M_LOYALTY_CARD)));
    	management.getCorrect().setServiceTypeBoundary(convertJson(gson, mapResult.get(Field.O_SERVICE_TYPE)));
	}
    
    private String convertJson(Gson gson, List<BoundaryResult> list) {
    	if (CollectionUtils.isEmpty(list))
    		return "";
    	return gson.toJson(list.stream().map(i -> new ExtractTripCoordinate(i.getFinalRectangle().getVertices().get(0).getX(), 
    			i.getFinalRectangle().getVertices().get(0).getY(), i.getFinalRectangle().getVertices().get(1).getX(),
    			i.getFinalRectangle().getVertices().get(1).getY(), i.getFinalRectangle().getVertices().get(2).getX(),
    			i.getFinalRectangle().getVertices().get(2).getY(), i.getFinalRectangle().getVertices().get(3).getX(),
    			i.getFinalRectangle().getVertices().get(3).getY())).collect(Collectors.toList()));
    }

	private List<BoundaryResult> boundary(String field, List<TextAnnotation> textAnnotations) {
    	List<BoundaryResult> listBoundary = HighlightUtil.getBoundary(field, textAnnotations);
    	
    	// remove duplicate
        if (!CollectionUtils.isEmpty(listBoundary) && listBoundary.size() > 1) {
        	HighlightUtil.duplicate(listBoundary);
        }
        return listBoundary;
	}
}
