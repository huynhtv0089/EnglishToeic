/*
 * Class: ExtractionControllerImpl
 *
 * Created on Sep 30, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.presentation.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import vn.sps.ss.extraction.model.ExtractionRequest;
import vn.sps.ss.extraction.model.ExtractionResponse;
import vn.sps.ss.extraction.watson.application.business.OCRHandler;
import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.infrastructure.configuration.TypeProperties;

@RestController
public class ExtractionController {

    private static final Logger LOG = LoggerFactory
        .getLogger(ExtractionController.class);

    @Autowired
    private OCRHandler ocrHandler;

    @Autowired
    private TypeProperties typeProperties;

    @PostMapping("/extract")
    public @ResponseBody ExtractionResponse extract(
        @RequestBody(required = true) final ExtractionRequest request,
        final HttpServletRequest client) {

        final String requestId = request.getId();
        LOG.info(
            "Receive request extraction for request {} receipt time {}",
            requestId,
            WallClock.milli());

        final ExtractionResponse response = new ExtractionResponse();
        
        if (!StringUtils.isEmpty(request.getFilePath())
                && !StringUtils.isEmpty(request.getId())) {
        	response.setId(request.getId());
        	response.setFilePath(request.getFilePath());
            final ProcessingContext context = new ProcessingContext(request,
                response);
            {
                context.setTypeProperties(typeProperties);
                context.setReceiveTime(WallClock.milli());
            }
            this.ocrHandler.submitItem(requestId, context);
        }
        else {
            LOG.info(
                "Failed to handle request extraction for request {}, request is empty!",
                request.getId());
        }

        return response;
    }

    /*ExtractionResponse extractAsync(
        final ExtractionRequest request,
        final HttpServletRequest client) {
        return null;
    }*/
}
