package vn.sps.ss.extraction.watson.application.iterator.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.iterator.CorrectionIterator;
import vn.sps.ss.extraction.watson.application.iterator.interceptor.Interceptor;
import vn.sps.ss.extraction.watson.application.iterator.interceptor.correction.MerchantRuleInterceptor;
import vn.sps.ss.extraction.watson.infrastructure.configuration.InterceptorConfiguration;

@Component
public class CorrectionIteratorImpl extends AbstractIterator implements CorrectionIterator {
	
	@Autowired
	private InterceptorConfiguration configuration;
	
	private final Map<String, Interceptor> allInterceptors = new HashMap<>();
	
	@PostConstruct
	private void setup() {
		this.loadAllInterceptors();
		this.addInterceptor();
	}
	
	private void loadAllInterceptors() {
		this.allInterceptors.put(MerchantRuleInterceptor.getInstance().getName(), MerchantRuleInterceptor.getInstance());
	}
	
	@Override
	protected ArrayList<String> getConfiguration() {
		return this.configuration.getCorrectionConfig();
	}

	@Override
	protected Map<String, Interceptor> getAllInterceptors() {
		return this.allInterceptors;
	}

	@Override
	public ProcessingContext apply(ProcessingContext context) {
		while (this.hasNext()) {
			context = this.next().process(context);
		}
		return context;
	}
	
}
