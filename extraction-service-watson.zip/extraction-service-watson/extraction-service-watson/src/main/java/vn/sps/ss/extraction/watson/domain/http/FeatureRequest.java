package vn.sps.ss.extraction.watson.domain.http;

import java.io.Serializable;

import com.google.cloud.vision.v1.Feature.Type;

public class FeatureRequest implements Serializable {

	private static final long serialVersionUID = -1433829891417151866L;

	private final Type type;

	private final Integer maxResults;

	public FeatureRequest(Type type, Integer maxResults) {
		this.type = type;
		this.maxResults = maxResults;
	}

	public Type getType() {
		return type;
	}

	public Integer getMaxResults() {
		return maxResults;
	}

}
