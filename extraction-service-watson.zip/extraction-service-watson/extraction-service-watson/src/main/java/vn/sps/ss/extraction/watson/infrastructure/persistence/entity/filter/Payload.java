package vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class Payload implements Serializable {

    private static final long serialVersionUID = -61847776394275L;

    @SerializedName(value = "merchant_id")
    private String merchantId;
    
    @SerializedName(value = "merchant_name")
    private String merchantName;
    
    @SerializedName(value = "transaction_type")
    private String transactionType;
    
    @SerializedName(value = "loyalty_status")
    private String loyaltyStatus;
    
    @SerializedName(value = "loyalty_program_name")
    private String loyaltyProgramName;
    
    @SerializedName(value = "driverthru_inclusion")
    private String driverthruInclusion;
    
    @SerializedName(value = "address_inclusion")
    private String addressInclusion;
    
    @SerializedName(value = "ordernumber")
    private String orderNumber;
    
    @SerializedName(value = "merchant_name_1")
    private String merchantName1;
    
    @SerializedName(value = "merchant_id_1")
    private String merchantid1;
    
    @SerializedName(value = "cash_inclusion")
    private String cashInclusion;
    
    @SerializedName(value = "loyalty_number_inclusion")
    private String loyaltyNumberInclusion;
    
    @SerializedName(value = "store_number_inclusion")
    private String storeNumberInclusion;
    
	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getLoyaltyStatus() {
		return loyaltyStatus;
	}

	public void setLoyaltyStatus(String loyaltyStatus) {
		this.loyaltyStatus = loyaltyStatus;
	}

	public String getLoyaltyProgramName() {
		return loyaltyProgramName;
	}

	public void setLoyaltyProgramName(String loyaltyProgramName) {
		this.loyaltyProgramName = loyaltyProgramName;
	}

	public String getDriverthruInclusion() {
		return driverthruInclusion;
	}

	public void setDriverthruInclusion(String driverthruInclusion) {
		this.driverthruInclusion = driverthruInclusion;
	}

	public String getAddressInclusion() {
		return addressInclusion;
	}

	public void setAddressInclusion(String addressInclusion) {
		this.addressInclusion = addressInclusion;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getMerchantName1() {
		return merchantName1;
	}

	public void setMerchantName1(String merchantName1) {
		this.merchantName1 = merchantName1;
	}

	public String getMerchantId1() {
		return merchantid1;
	}

	public void setMerchantId1(String merchantid1) {
		this.merchantid1 = merchantid1;
	}

	public String getCashInclusion() {
		return cashInclusion;
	}

	public void setCashInclusion(String cashInclusion) {
		this.cashInclusion = cashInclusion;
	}

	public String getLoyaltyNumberInclusion() {
		return loyaltyNumberInclusion;
	}

	public void setLoyaltyNumberInclusion(String loyaltyNumberInclusion) {
		this.loyaltyNumberInclusion = loyaltyNumberInclusion;
	}

	public String getStoreNumberInclusion() {
		return storeNumberInclusion;
	}

	public void setStoreNumberInclusion(String storeNumberInclusion) {
		this.storeNumberInclusion = storeNumberInclusion;
	}
}
