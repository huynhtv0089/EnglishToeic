package vn.sps.ss.extraction.watson.application.iterator.interceptor.correction;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.iterator.interceptor.AbstractInterceptor;

public class MerchantRuleInterceptor extends AbstractInterceptor {
	
	private static final String MERCHANT_RULE = "merchantRule";
	
	private static final MerchantRuleInterceptor INSTANCE = new MerchantRuleInterceptor();
	
	public static MerchantRuleInterceptor getInstance() {
		return INSTANCE;
	}
	
	private MerchantRuleInterceptor() {
		super(MERCHANT_RULE);
	}

	@Override
	public ProcessingContext process(ProcessingContext context) {
		return null;
	}
	
}
