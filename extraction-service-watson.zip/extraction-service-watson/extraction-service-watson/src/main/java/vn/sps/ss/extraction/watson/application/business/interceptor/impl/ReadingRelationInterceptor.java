package vn.sps.ss.extraction.watson.application.business.interceptor.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalysisResults;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationArgument;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationEntity;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationsResult;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.common.util.Constant.Field;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsEntity;

/**
 * Read watson relation interceptor
 * @author nttung_3
 */
@Service
class ReadingRelationInterceptor extends AbstractInterceptor {
	
	private static final Logger LOG = LoggerFactory.getLogger(ReadingRelationInterceptor.class);
	
	private static final String READING_RELATION = "readingRelation";
	
	private static final ReadingRelationInterceptor INSTANCE = new ReadingRelationInterceptor();
	
	private ReadingRelationInterceptor() {
		super(READING_RELATION);
	}
	
	public static ReadingRelationInterceptor getInstance() {
		return INSTANCE;
	}

	@Override
	public ProcessingContext process(final ProcessingContext context) {
		final long begin = System.currentTimeMillis();
		LOG.info("Begin to read watson relation of receipt {}", context.getId());
		final ManagementEntity management = context.getManagementEntity();
		final AnalysisResults analysisContent = context.getWatsonResponse().getContent();
		if (analysisContent != null && !CollectionUtils.isEmpty(analysisContent.getRelations())) {
			this.processRelation(context.getManagementEntity(), analysisContent.getRelations());
		} else {
			LOG.warn("Watson service return response Relation is empty or receipt {} have error", context.getId());
		}
		final Map<String, RelationsCorrectionEntity> itemCorrect = new LinkedHashMap<>();
        management.setItemCorrect(itemCorrect);
		LOG.info("Reading watson relation of receipt {} took {}", context.getId(), System.currentTimeMillis() - begin);
		return context;
	}
	
	private void processRelation(ManagementEntity management, List<RelationsResult> relations) {
		List<RelationsEntity> result = new ArrayList<>();
		for (int i = 0; i < relations.size(); i++) {
			RelationsResult relation = relations.get(i);
			
			RelationsEntity entity = new RelationsEntity();
			entity.setRelation(relation.getType());
			entity.setScore(relation.getScore());
			entity.setManagement(management);
			
			for (RelationArgument relationArgument : relation.getArguments()) {
				for (RelationEntity relationEntity : relationArgument.getEntities()) {
					// Main Type: ITEM_NAME
					if (Field.ITEM_NAME.equalsIgnoreCase(relationEntity.getType()) ) {
						entity.setMainTextExtract(relationEntity.getText());
						entity.setMainType(relationEntity.getType());
					} else {
						entity.setSecondTextExtract(relationEntity.getText());
						entity.setSecondType(relationEntity.getType());
					}
				}
			}
			result.add(entity);
		}
		
		management.setRelation(result);
		
	}
	
}
