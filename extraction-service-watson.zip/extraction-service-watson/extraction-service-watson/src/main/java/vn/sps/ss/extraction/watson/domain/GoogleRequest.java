package vn.sps.ss.extraction.watson.domain;

public class GoogleRequest {
    private String image;

    public GoogleRequest(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
