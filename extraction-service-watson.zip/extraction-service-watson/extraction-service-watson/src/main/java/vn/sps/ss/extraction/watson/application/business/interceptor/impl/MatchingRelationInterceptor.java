package vn.sps.ss.extraction.watson.application.business.interceptor.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationArgument;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationEntity;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationsResult;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.common.util.Constant.Field;
import vn.sps.ss.extraction.watson.application.common.util.Constant.RelationType;
import vn.sps.ss.extraction.watson.application.common.util.StringUtil;
import vn.sps.ss.extraction.watson.domain.watson.LineItem;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsEntity;

/**
 * Transfer watson relation to a line item
 * @author nttung_3
 */
@Service	
class MatchingRelationInterceptor extends AbstractInterceptor {

	private static final String MATCHING_RELATION = "matchingRelation";

	private static final MatchingRelationInterceptor INSTANCE = new MatchingRelationInterceptor();

	private MatchingRelationInterceptor() {
		super(MATCHING_RELATION);
	}

	public static MatchingRelationInterceptor getInstance() {
		return INSTANCE;
	}

	@Override
	public ProcessingContext process(ProcessingContext context) {
		List<RelationsEntity> relations = context.getManagementEntity().getRelation()
				.parallelStream().filter(r -> !r.getMainType().contains(",") && r.getSecondType().contains(",")).collect(Collectors.toList());
		
		List<String> items = context.getManagementEntity().getItem()
				.parallelStream().filter(i -> i.getType().equals(Field.ITEM_NAME)).map(i -> i.getTextExtract()).collect(Collectors.toList());
		
		Map<String, LineItem> lineItems = new HashMap<>();
		
		for (String itemName : items) {
			if (lineItems.containsKey(itemName)) {
				LineItem lineItem = lineItems.get(itemName);
			} else {
				List<RelationsEntity> relationsOfItem = relations.parallelStream()
						.filter(r -> r.getMainTextExtract().equalsIgnoreCase(itemName)).collect(Collectors.toList());
				LineItem lineItem = new LineItem().hasName(itemName);
				lineItem.setRelations(relations);
			}
		}
		
		return null;
	}
	
	private LineItem transferRelation(RelationsEntity relationsResult, LineItem lineItem) {
		String relationType = relationsResult.getRelation();
		String value = relationsResult.getSecondTextExtract();
		switch (relationType) {
		case RelationType.COST:
			return lineItem.cost(value);

		case RelationType.DISCOUNT:
			return lineItem.promote(value);
		case RelationType.HAS:
			return lineItem.has(value);
		case RelationType.IDENTIFIED_BY:
			return lineItem.identifiedBy(value);
		case RelationType.INCLUDE_IN:
			// do with sub_item
			return null;
		default:
			// throw exception NOT_SUPPORT_RELATION
			return null;
		}
	}
	

	private void transferRelation(RelationsResult relationsResult, Map<String, LineItem> lineItems) {
		String relationType = relationsResult.getType();
		String lineItemKey = getLineItemKey(relationsResult.getArguments());
		if (StringUtil.isNullOrEmpty(lineItemKey)) {
			LineItem lineItem = lineItems.get(lineItemKey);
			switch (relationType) {
			case RelationType.COST:

				break;

			case RelationType.DISCOUNT:

				break;
			case RelationType.HAS:

				break;
			case RelationType.IDENTIFIED_BY:

				break;
			case RelationType.INCLUDE_IN:

				break;
			default:
				break;
			}
		}

		
	}

	private String getLineItemKey(List<RelationArgument> arguments) {
		if (!CollectionUtils.isEmpty(arguments)) {
			for (RelationArgument argument : arguments) {
				if (argument.getEntities().size() == 1) {
					if (argument.getEntities().get(0).getType().equalsIgnoreCase(Field.ITEM_NAME)) {
						RelationEntity entity = argument.getEntities().get(0);
						return entity.getText();
					} else {
						continue;
					}
				} else {
					// throw exceptions: entities has more 1 element
					return null;
				}
			}
		} else {
			// throw exceptions: RelationArgument is null or empty
			return null;
		}
		// throw exceptions: Not exist ITEM_NAME in relation (RelationArgument)
		return null;
		
	}

}
