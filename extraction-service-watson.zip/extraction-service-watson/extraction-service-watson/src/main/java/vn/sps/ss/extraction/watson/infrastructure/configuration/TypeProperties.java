package vn.sps.ss.extraction.watson.infrastructure.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "extract.type")
public class TypeProperties {

    private String address;

    private String city;

    private String houseNumber;

    private String loyaltyCard;

    private String merchant;

    private String merchantPhone;

    private String orderNumber;

    private String paymentMethod;

    private String purchaseDate;

    private String purchaseTime;

    private String receiptType;

    private String serviceType;

    private String state;

    private String storeNumber;

    private String totalPaid;

    private String zip;
    
    private String driveThru;
    
    private String counter;
    
    private String mainItem;

    public String getAddress() {
        return this.address;
    }

    public String getCity() {
        return this.city;
    }

    public String getHouseNumber() {
        return this.houseNumber;
    }

    public String getLoyaltyCard() {
        return this.loyaltyCard;
    }

    public String getMerchant() {
        return this.merchant;
    }

    public String getMerchantPhone() {
        return this.merchantPhone;
    }

    public String getOrderNumber() {
        return this.orderNumber;
    }

    public String getPaymentMethod() {
        return this.paymentMethod;
    }

    public String getPurchaseDate() {
        return this.purchaseDate;
    }

    public String getPurchaseTime() {
        return this.purchaseTime;
    }

    public String getReceiptType() {
        return this.receiptType;
    }

    public String getServiceType() {
        return this.serviceType;
    }

    public String getState() {
        return this.state;
    }

    public String getStoreNumber() {
        return this.storeNumber;
    }

    public String getTotalPaid() {
        return this.totalPaid;
    }

    public String getZip() {
        return this.zip;
    }

    public void setAddress(final String address) {
        this.address = address;
    }

    public void setCity(final String city) {
        this.city = city;
    }

    public void setHouseNumber(final String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public void setLoyaltyCard(final String loyaltyCard) {
        this.loyaltyCard = loyaltyCard;
    }

    public void setMerchant(final String merchant) {
        this.merchant = merchant;
    }

    public void setMerchantPhone(final String merchantPhone) {
        this.merchantPhone = merchantPhone;
    }

    public void setOrderNumber(final String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public void setPaymentMethod(final String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public void setPurchaseDate(final String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public void setPurchaseTime(final String purchaseTime) {
        this.purchaseTime = purchaseTime;
    }

    public void setReceiptType(final String receiptType) {
        this.receiptType = receiptType;
    }

    public void setServiceType(final String serviceType) {
        this.serviceType = serviceType;
    }

    public void setState(final String state) {
        this.state = state;
    }

    public void setStoreNumber(final String storeNumber) {
        this.storeNumber = storeNumber;
    }

    public void setTotalPaid(final String totalPaid) {
        this.totalPaid = totalPaid;
    }

    public void setZip(final String zip) {
        this.zip = zip;
    }

    public String getDriveThru() {
        return driveThru;
    }

    public void setDriveThru(String driveThru) {
        this.driveThru = driveThru;
    }

    public String getCounter() {
        return counter;
    }

    public void setCounter(String counter) {
        this.counter = counter;
    }

	public String getMainItem() {
		return mainItem;
	}

	public void setMainItem(String mainItem) {
		this.mainItem = mainItem;
	}

}
