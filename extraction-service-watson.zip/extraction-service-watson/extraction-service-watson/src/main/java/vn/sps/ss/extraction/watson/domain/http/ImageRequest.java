package vn.sps.ss.extraction.watson.domain.http;

import java.io.Serializable;

public class ImageRequest implements Serializable {
	
	private static final long serialVersionUID = 3510381522005890426L;
	
	private final String content;
	
	public ImageRequest(String content) {
		this.content = content;
	}

	public String getContent() {
		return content;
	}
	
}
