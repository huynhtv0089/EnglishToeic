package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "entities")
public class EntitiesEntity implements Serializable {

    private static final long serialVersionUID = 914804574224165781L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 200, nullable = true)
    private String textExtract;

    @Column(length = 50, nullable = true)
    private String type;

    @ManyToOne
    @JoinColumn(name = "management_id")
    private ManagementEntity management;

    public EntitiesEntity() {
    }

    public EntitiesEntity(String textExtract, String type) {
        this.textExtract = textExtract;
        this.type = type;
    }

    public EntitiesEntity(String textExtract, String type,
            ManagementEntity management) {
        this.textExtract = textExtract;
        this.type = type;
        this.management = management;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTextExtract() {
        return textExtract;
    }

    public void setTextExtract(String textExtract) {
        this.textExtract = textExtract;
    }

    public ManagementEntity getManagement() {
        return management;
    }

    public void setManagement(ManagementEntity management) {
        this.management = management;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
