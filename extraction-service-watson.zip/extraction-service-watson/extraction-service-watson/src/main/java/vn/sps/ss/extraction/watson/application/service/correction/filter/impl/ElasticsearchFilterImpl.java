package vn.sps.ss.extraction.watson.application.service.correction.filter.impl;

import java.util.HashMap;
import java.util.Map;

import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import vn.sps.ss.extraction.watson.application.common.util.Constant.FilterRuleFields;
import vn.sps.ss.extraction.watson.application.service.correction.filter.FilterRuleProvider;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ElasticsearchFilterRuleConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.MerchantEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch.MerchantHit;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter.FilterRule;

/**
 * 
 * @author vctoan
 *	This service is used for new version of Elasticsearch
 */

@Service
@Primary
@ConditionalOnProperty(
	name = "filter.service-class", 
	havingValue = "vn.sps.ss.extraction.watson.application.service.correction.filter.impl.ElasticsearchFilterImpl"
)
public class ElasticsearchFilterImpl implements FilterRuleProvider {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ElasticsearchFilterImpl.class);
	
	private static final String ONE = "1";
	
	private Map<String, FilterRule> listRule = new HashMap<>();

	@Autowired
	private ElasticsearchFilterRuleConfiguration filterRuleConfiguration;
	
	@Autowired
    private Client filterRuleClient;

	@Override
	public FilterRule getRule(String merchant) {
		
		//Check if this rule already existed then return the rule
		if (this.listRule.containsKey(merchant)) {
			return this.listRule.get(merchant);
		}
		
		FilterRule filterRule = null;
		final ObjectMapper mapper = new ObjectMapper();
        mapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
		
		final SearchRequestBuilder searchRequestBuilder = filterRuleClient.prepareSearch()
				.setIndices(this.filterRuleConfiguration.getIndex())
				.setTypes(this.filterRuleConfiguration.getType())
				.setQuery(QueryBuilders.matchQuery(FilterRuleFields.MERCHANT_NAME, merchant))
				.setSize(1);
		
		MerchantHit filterRuleHit = null;
		
		if (searchRequestBuilder != null) {
			SearchResponse response = searchRequestBuilder.get();
			if (response.getHits().getTotalHits() > 0) {
				final SearchHit hit = response.getHits().getAt(0);
				filterRuleHit = mapper.convertValue(hit, MerchantHit.class);
				
				// process merchant rule
				if (filterRuleHit != null) {
					filterRule = processRule(hit.getSourceAsString(), filterRuleHit);
					if (filterRule != null) this.listRule.put(merchant, filterRule);
				}
			}
		}
		return filterRule;
	}
	
	private FilterRule processRule(String ruleJson, MerchantHit filterRuleHit) {

		final MerchantEntity rule = filterRuleHit.getSource();

		if (rule == null)
			return null;

		FilterRule filterRule = new FilterRule();

		//store rule to track the history
		filterRule.setRule(ruleJson);
		// Common
		filterRule.setZip(true);
		filterRule.setMerchantPhone(true);
		filterRule.setPurchaseDate(true);
		filterRule.setPurchaseTime(true);
		filterRule.setTotalPaid(true);
		filterRule.setMerchant(true);
		filterRule.setPaymentMethod(true);
		filterRule.setReceiptType(true);

		// loyalty status
		if (!StringUtils.isEmpty(rule.getLoyaltyStatus()) && ONE.equalsIgnoreCase(rule.getLoyaltyStatus())) {
			filterRule.setLoyalty(true);
		}

		// driverthru
		if (!StringUtils.isEmpty(rule.getDriverthruInclusion()) && ONE.equalsIgnoreCase(rule.getDriverthruInclusion())) {
			filterRule.setServiceType(true);
		}

		// address
		if (!StringUtils.isEmpty(rule.getAddressInclusion()) && ONE.equalsIgnoreCase(rule.getAddressInclusion())) {
			filterRule.setStoreNumber(true);
			filterRule.setCity(true);
			filterRule.setState(true);
			filterRule.setStreetAddress(true);
			filterRule.setHouseNumber(true);
		}

		// order number
		if (!StringUtils.isEmpty(rule.getOrderNumber()) && ONE.equalsIgnoreCase(rule.getOrderNumber())) {
			filterRule.setOrderNumber(true);
		}
		return filterRule;
	}
}
