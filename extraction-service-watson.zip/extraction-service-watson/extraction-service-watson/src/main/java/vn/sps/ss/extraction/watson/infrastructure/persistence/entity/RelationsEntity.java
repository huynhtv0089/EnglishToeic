package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import vn.sps.ss.extraction.watson.application.common.util.StringUtil;

@Entity
@Table(name = "relations")
public class RelationsEntity implements Serializable {

	private static final long serialVersionUID = 6915894228614833585L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 50, nullable = true)
    private String mainType;
	
    @Column(length = 200, nullable = true)
    private String mainTextExtract;
    
    @Column(length = 50, nullable = true)
    private String secondType;
	
    @Column(length = 200, nullable = true)
    private String secondTextExtract;
    
    @Column(length = 200, nullable = true)
    private String relation;
    
    @Column(length = 200, nullable = true)
    private double score;
    
    @ManyToOne
    @JoinColumn(name = "management_id")
    private ManagementEntity management;

    public RelationsEntity() {
    	
    }

	public RelationsEntity(String mainType, String mainTextExtract, String secondType, String secondTextExtract,
			String relation, double score, ManagementEntity management) {
		this.mainType = mainType;
		this.mainTextExtract = mainTextExtract;
		this.secondType = secondType;
		this.secondTextExtract = secondTextExtract;
		this.relation = relation;
		this.score = score;
		this.management = management;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ManagementEntity getManagement() {
        return management;
    }

    public void setManagement(ManagementEntity management) {
        this.management = management;
    }

	public String getMainType() {
		return mainType;
	}

	public void setMainType(String mainType) {
		if (StringUtil.isNullOrEmpty(this.mainType)) {
			this.mainType = mainType;
		} else {
			this.mainType += ", " + mainType;
		}
	}

	public String getMainTextExtract() {
		return mainTextExtract;
	}

	public void setMainTextExtract(String mainTextExtract) {
		if (StringUtil.isNullOrEmpty(this.mainTextExtract)) {
			this.mainTextExtract = mainTextExtract;
		} else {
			this.mainTextExtract += ", " + mainTextExtract;
		}
		
	}

	public String getSecondType() {
		return secondType;
	}

	public void setSecondType(String secondType) {
		if (StringUtil.isNullOrEmpty(this.secondType)) {
			this.secondType = secondType;
		} else {
			this.secondType += ", " + secondType;
		}
	}

	public String getSecondTextExtract() {
		return secondTextExtract;
	}

	public void setSecondTextExtract(String secondTextExtract) {
		if (StringUtil.isNullOrEmpty(this.secondTextExtract)) {
			this.secondTextExtract = secondTextExtract;
		} else {
			this.secondTextExtract += ", " + secondTextExtract;
		}
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}
}
