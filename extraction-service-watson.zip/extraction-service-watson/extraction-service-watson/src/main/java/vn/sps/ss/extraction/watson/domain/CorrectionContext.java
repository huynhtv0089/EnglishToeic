/*
 * Class: CorrectionContext
 *
 * Created on Oct 16, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.domain;

import vn.sps.ss.extraction.watson.domain.CorrectionRequest;
import vn.sps.ss.extraction.watson.domain.CorrectionResponse;

/**
 * The Class CorrectionContext.
 */
public class CorrectionContext {

    /** The request. */
    private final CorrectionRequest request;

    /** The response. */
    private final CorrectionResponse response;

    /**
     * Instantiates a new correction context.
     *
     * @param request the request
     * @param response the response
     */
    public CorrectionContext(final CorrectionRequest request,
            final CorrectionResponse response) {
        this.request = request;
        this.response = response;
    }

    /**
     * Gets the request.
     *
     * @return the request
     */
    public CorrectionRequest getRequest() {
        return this.request;
    }

    /**
     * Gets the response.
     *
     * @return the response
     */
    public CorrectionResponse getResponse() {
        return this.response;
    }

}
