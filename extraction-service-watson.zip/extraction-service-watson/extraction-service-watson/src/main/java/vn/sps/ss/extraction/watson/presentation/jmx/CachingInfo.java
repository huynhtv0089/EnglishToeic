package vn.sps.ss.extraction.watson.presentation.jmx;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource
public interface CachingInfo {

	@ManagedOperation
	void disable(boolean isDisable);
	
	@ManagedAttribute
	boolean getActive();
}
