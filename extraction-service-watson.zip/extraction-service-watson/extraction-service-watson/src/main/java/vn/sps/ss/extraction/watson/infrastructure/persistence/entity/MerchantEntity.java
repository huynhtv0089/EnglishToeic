/*
 * Class: MerchantEntity
 *
 * Created on Oct 13, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantEntity implements Serializable {

    private static final long serialVersionUID = 5544151276367447682L;

    @JsonProperty(value = "merchant_name_1")
    private String merchantName1;

    @JsonProperty(value = "loyalty_status")
    private String loyaltyStatus;

    @JsonProperty(value = "create_time")
    private String createTime;

    @JsonProperty(value = "merchant_name")
    private String merchantName;

    @JsonProperty(value = "merchant_id")
    private String merchantId;

    @JsonProperty(value = "address_inclusion")
    private String addressInclusion;

    @JsonProperty(value = "message")
    private String message;

    @JsonProperty(value = "transaction_type")
    private String transactionType;

    @JsonProperty(value = "merchant_id_1")
    private String merchantId1;

    @JsonProperty(value = "ordernumber")
    private String orderNumber;

    @JsonProperty(value = "driverthru_inclusion")
    private String driverthruInclusion;

    @JsonProperty(value = "id")
    private String id;

    @JsonProperty(value = "loyalty_program_name")
    private String loyaltyProgramName;

    @JsonProperty(value = "ort")
    private String ort;

    public String getMerchantName1() {
        return merchantName1;
    }

    public void setMerchantName1(String merchantName1) {
        this.merchantName1 = merchantName1;
    }

    public String getLoyaltyStatus() {
        return loyaltyStatus;
    }

    public void setLoyaltyStatus(String loyaltyStatus) {
        this.loyaltyStatus = loyaltyStatus;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getAddressInclusion() {
        return addressInclusion;
    }

    public void setAddressInclusion(String addressInclusion) {
        this.addressInclusion = addressInclusion;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getMerchantId1() {
        return merchantId1;
    }

    public void setMerchantId1(String merchantId1) {
        this.merchantId1 = merchantId1;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getDriverthruInclusion() {
        return driverthruInclusion;
    }

    public void setDriverthruInclusion(String driverthruInclusion) {
        this.driverthruInclusion = driverthruInclusion;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLoyaltyProgramName() {
        return loyaltyProgramName;
    }

    public void setLoyaltyProgramName(String loyaltyProgramName) {
        this.loyaltyProgramName = loyaltyProgramName;
    }

    public String getOrt() {
        return ort;
    }

    public void setOrt(String ort) {
        this.ort = ort;
    }
}
