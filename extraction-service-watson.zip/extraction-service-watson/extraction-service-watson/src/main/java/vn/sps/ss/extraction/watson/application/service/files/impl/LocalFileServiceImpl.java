package vn.sps.ss.extraction.watson.application.service.files.impl;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import vn.sps.ss.extraction.watson.application.service.files.FileService;
import vn.sps.ss.extraction.watson.infrastructure.configuration.CommonConfiguration;

@Service
@ConditionalOnProperty(name = "ocr.file-service-class", havingValue = "vn.sps.ss.extraction.watson.application.service.files.impl.LocalFileServiceImpl")
public class LocalFileServiceImpl implements FileService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(LocalFileServiceImpl.class);
	
	/** The configuration. */
    @Autowired
    private CommonConfiguration configuration;

	@Override
	public byte[] get(String filePath) {
		try {
			Path path = Paths.get(this.configuration.getDirPrefix(), filePath);
			return Files.readAllBytes(path);
		} catch (Exception e) {
			LOGGER.info("Error when convert file to byte", e);
			return null;
		}
	}
}
