/*
 * Class: RegularExpressionUtils
 *
 * Created on Oct 19, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.common.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressionUtils {

    public static boolean match(final String regex, final String text) {
        if(StringUtil.isNullOrEmpty(regex)) {
            return true;
        }
        
        if(StringUtil.isNullOrEmpty(text)) {
            return true;
        }
        
        Pattern pattern = Pattern.compile(regex);
        Matcher match = pattern.matcher(text);
        if(match.find()) {
            return true;
        }
        
        return false;
    }
}
