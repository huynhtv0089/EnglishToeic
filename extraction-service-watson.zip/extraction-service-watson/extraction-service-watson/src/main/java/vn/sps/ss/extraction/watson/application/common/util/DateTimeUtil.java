/*
 * Class: DateTimeUtil
 *
 * Created on Oct 23, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.common.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateTimeUtil {

	private static final SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");

	private static final Logger LOGGER = LoggerFactory.getLogger(DateTimeUtil.class);

	private DateTimeUtil() {
	}

	public static Date getDateWithFormat(final String text, final List<String> formats) {
		if (StringUtil.isNullOrEmpty(text)) {
			return null;
		}

		for (String format : formats) {
			if (!StringUtil.isNullOrEmpty(format)) {
				try {
					DateFormat dateFormat = new SimpleDateFormat(format);
					Date retDate = dateFormat.parse(text);

					if (text.equalsIgnoreCase(dateFormat.format(retDate))) {
						LOGGER.debug("Date format {} is valid with value {}.", format, text);
						return retDate;
					}
				} catch (Exception e) {
					LOGGER.debug("Date format {} is invalid with value {}.", format, text, e);
				}
			}
		}

		return null;
	}

	public static int getHour(final Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.HOUR_OF_DAY);
	}

	public static long getEpochTime(int hour, int minute) {
		Calendar cal = Calendar.getInstance();
		cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), hour, minute);
		return cal.getTimeInMillis();
	}

	public static String getHumanTime(long timestamp) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(timestamp);
		return format.format(cal.getTime());
	}
}
