/*
 * Class: CorrectionServiceImpl
 *
 * Created on Sep 30, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.service.correction.impl;

import org.elasticsearch.client.Client;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.application.service.correction.CorrectionService;
import vn.sps.ss.extraction.watson.application.service.correction.filter.FilterRuleProvider;
import vn.sps.ss.extraction.watson.application.service.correction.processor.CorrectionProcessor;
import vn.sps.ss.extraction.watson.application.service.correction.processor.ElasticsearchCorrectionProcessor;
import vn.sps.ss.extraction.watson.application.service.correction.processor.RegCorrectionProcessor;
import vn.sps.ss.extraction.watson.domain.CorrectionContext;
import vn.sps.ss.extraction.watson.domain.CorrectionRequest;
import vn.sps.ss.extraction.watson.domain.CorrectionResponse;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ElasticsearchConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ElasticsearchValidationConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.configuration.RegexValidationConfiguration;

import javax.annotation.PostConstruct;

/**
 * The Class CorrectionServiceImpl.
 */
@Service
public class CorrectionServiceImpl implements CorrectionService {

    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory
        .getLogger(CorrectionServiceImpl.class);

    @Autowired
    private Client client;

    @Autowired
    private ElasticsearchConfiguration configuration;

    @Autowired
    private ElasticsearchValidationConfiguration esValidationConfiguration;

    @Autowired
    private RegexValidationConfiguration regexValidation;
    
    @Autowired
    private FilterRuleProvider filterRuleProvider;

    /** The processor. */
    private CorrectionProcessor processor;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.ss.extraction.watson.application.service.correction.CorrectionService#correct(vn.sps.ss.extraction.watson.domain.CorrectionRequest)
     */
    @Override
    public CorrectionResponse correct(final CorrectionRequest request) {

        final String receiptId = request.getReceiptId();

        final long startTime = WallClock.milli();
        LOGGER.info("Start correct receipt {} at {}.", receiptId, WallClock.milli());

        final CorrectionResponse response = new CorrectionResponse();
        final CorrectionContext context = new CorrectionContext(request,
            response);

        try {
            this.processor.handle(context);

            final long endTime = WallClock.milli();
            LOGGER.info(
                "End correct receipt {}. Took {} milis.",
                receiptId,
                endTime - startTime);
        }
        catch (Exception e) {
            final long endTime = WallClock.milli();
            LOGGER.error(
                "Error while correct receipt {}. Took {} milis. Detail: ",
                receiptId,
                endTime - startTime,
                e);
        }
        return context.getResponse();
    }

    @PostConstruct
    protected void init() {
        this.processor = new ElasticsearchCorrectionProcessor(
            new RegCorrectionProcessor(null, this.regexValidation), this.client,
            this.configuration, this.esValidationConfiguration, this.filterRuleProvider);
    }

}
