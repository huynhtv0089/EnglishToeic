/*
 * Class: ElasticsearchRestClientConfiguration
 *
 * Created on Oct 12, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.configuration;

import static org.apache.commons.lang.StringUtils.split;
import static org.apache.commons.lang.StringUtils.substringAfterLast;
import static org.apache.commons.lang.StringUtils.substringBeforeLast;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.settings.Settings.Builder;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.Assert;

@Configuration
public class ElasticsearchRestClientConfiguration {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ElasticsearchRestClientConfiguration.class);

    static final String COLON = ":";
    static final String COMMA = ",";
    
    private String clusterName = "elasticsearch";
    private Boolean clientTransportSniff = true;
    private Boolean clientIgnoreClusterName = Boolean.FALSE;
    private String clientPingTimeout = "5s";
    private String clientNodesSamplerInterval = "5s";
    
    private TransportClient client = null;
    
    @Autowired
    private ElasticsearchConfiguration elasticsearchConfiguration;
    
    @Bean
    public Client client() {
        Assert.notNull(this.elasticsearchConfiguration, "[Assertion failed] elasticsearch properties must not be null.");
        
		try {
	        client = new PreBuiltTransportClient(settings(this.elasticsearchConfiguration));
	        Assert.hasText(this.elasticsearchConfiguration.getClusterNodes(), "[Assertion failed] clusterNodes settings missing.");
	        
	        for (String clusterNode : split(this.elasticsearchConfiguration.getClusterNodes(), COMMA)) {
	            String hostName = substringBeforeLast(clusterNode, COLON);
	            String port = substringAfterLast(clusterNode, COLON);
	            Assert.hasText(hostName, "[Assertion failed] missing host name in 'clusterNodes'");
	            Assert.hasText(port, "[Assertion failed] missing port in 'clusterNodes'");
	            LOGGER.info("Adding transport node : {}", clusterNode);
	            
	            client.addTransportAddress(new TransportAddress(InetAddress.getByName(hostName), Integer.valueOf(port)));
	        }
	        
	        client.connectedNodes().forEach(i -> 
	            LOGGER.info("Explored node: {}, {}", i.getHostName(), i.getHostAddress())
	        );
		} catch (NumberFormatException | UnknownHostException e) {
			LOGGER.error("Error: ", e);
		} 
        
        return client;
    }
    
    private Settings settings(ElasticsearchConfiguration elasticsearchConfiguration) {
        if (elasticsearchConfiguration.getProperties() != null) {
        	Builder builder = Settings.builder().put("cluster.name", elasticsearchConfiguration.getClusterName());
        	elasticsearchConfiguration.getProperties().forEach((k,v) -> builder.put(k, v));
            return builder.build();
        }
        return Settings.builder()
                .put("cluster.name", clusterName)
                .put("client.transport.sniff", clientTransportSniff)
                .put("client.transport.ignore_cluster_name", clientIgnoreClusterName)
                .put("client.transport.ping_timeout", clientPingTimeout)
                .put("client.transport.nodes_sampler_interval", clientNodesSamplerInterval)
                .build();
    }
}
