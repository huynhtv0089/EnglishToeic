/*
 * Class: OCRService
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.service.ocr;

import javax.activation.UnsupportedDataTypeException;

import vn.sps.ss.extraction.watson.domain.OCRRequest;
import vn.sps.ss.extraction.watson.domain.OCRResponse;

/**
 * The Interface OCRService.
 */
public interface OCRService {

    /**
     * Do OCR.
     *
     * @param request the request
     * @return the OCR response, the respose can be null
     * @throws UnsupportedDataTypeException the unsupported data type exception
     */
    OCRResponse doOCR(OCRRequest request) throws UnsupportedDataTypeException;

}
