package vn.sps.ss.extraction.watson.application.iterator.interceptor;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;

public interface Interceptor {
	
	ProcessingContext process(ProcessingContext context);
}
