package vn.sps.ss.extraction.watson.application.service.correction.filter;

import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter.FilterRule;

public interface FilterRuleProvider {

	FilterRule getRule(String merchant);
}
