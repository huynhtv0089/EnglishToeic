package vn.sps.ss.extraction.watson.infrastructure.configuration;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "ocr")
public class OcrProperties {

    private String url;

    private String username;

    private String password;

    private Map<String, String> payload;

    private Transform transform;

    public static class Transform {

        private List<String> replaceFrom;

        private List<String> replaceTo;

        public List<String> getReplaceFrom() {
            return replaceFrom;
        }

        public void setReplaceFrom(List<String> replaceFrom) {
            this.replaceFrom = replaceFrom;
        }

        public List<String> getReplaceTo() {
            return replaceTo;
        }

        public void setReplaceTo(List<String> replaceTo) {
            this.replaceTo = replaceTo;
        }
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Transform getTransform() {
        return transform;
    }

    public void setTransform(Transform transform) {
        this.transform = transform;
    }

    public Map<String, String> getPayload() {
        return payload;
    }

    public void setPayload(Map<String, String> payload) {
        this.payload = payload;
    }
}
