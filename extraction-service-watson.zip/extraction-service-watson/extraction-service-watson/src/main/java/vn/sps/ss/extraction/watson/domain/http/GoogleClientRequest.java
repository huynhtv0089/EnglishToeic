package vn.sps.ss.extraction.watson.domain.http;

import java.io.Serializable;
import java.util.ArrayList;

public class GoogleClientRequest implements Serializable {

	private static final long serialVersionUID = -6155494414702154645L;

	private final ImageRequest image;

	private final ArrayList<FeatureRequest> features;

	public GoogleClientRequest(ImageRequest image) {
		this.image = image;
		this.features = new ArrayList<>();
	}

	public ImageRequest getImage() {
		return image;
	}

	public ArrayList<FeatureRequest> getFeatures() {
		return features;
	}

	public void addFeature(FeatureRequest featureRequest) {
		this.features.add(featureRequest);
	}
	

}
