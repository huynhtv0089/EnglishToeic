package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemUnitEntity implements Serializable {

	private static final long serialVersionUID = 7855678484779618385L;

	@JsonProperty(value = "unit_id")
    private String itemUnitId;
    
    @JsonProperty(value = "unit_desc")
    private String itemUnitDesc;

	public String getItemUnitId() {
		return itemUnitId;
	}

	public void setItemUnitId(String itemUnitId) {
		this.itemUnitId = itemUnitId;
	}

	public String getItemUnitDesc() {
		return itemUnitDesc;
	}

	public void setItemUnitDesc(String itemUnitDesc) {
		this.itemUnitDesc = itemUnitDesc;
	}
}
