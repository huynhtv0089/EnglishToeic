package vn.sps.ss.extraction.watson.infrastructure.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix="receipt.credential")
public class ReceiptCredential {

	private boolean isReadingCity = true;
	private boolean isReadingHouseNumber = true;
	private boolean isReadingLoyalty = true;
	private boolean isReadingMerchant = true;
	private boolean isReadingMerchantPhone = true;
	private boolean isReadingOrderNumber = true;
	private boolean isReadingPaymentMethod = true;
	private boolean isReadingPurchaseDate = true;
	private boolean isReadingPurchaseTime = true;
	private boolean isReadingReceiptType = true;
	private boolean isReadingServiceType = true;
	private boolean isReadingState = true;
	private boolean isReadingStoreNumber =  true;
	private boolean isReadingAddress = true;
	private boolean isReadingTotalPaid = true;
	private boolean isReadingZip = true;

	public boolean isReadingCity() {
		return isReadingCity;
	}

	public void setReadingCity(boolean isReadingCity) {
		this.isReadingCity = isReadingCity;
	}

	public boolean isReadingHouseNumber() {
		return isReadingHouseNumber;
	}

	public void setReadingHouseNumber(boolean isReadingHouseNumber) {
		this.isReadingHouseNumber = isReadingHouseNumber;
	}

	public boolean isReadingLoyalty() {
		return isReadingLoyalty;
	}

	public void setReadingLoyalty(boolean isReadingLoyalty) {
		this.isReadingLoyalty = isReadingLoyalty;
	}

	public boolean isReadingMerchant() {
		return isReadingMerchant;
	}

	public void setReadingMerchant(boolean isReadingMerchant) {
		this.isReadingMerchant = isReadingMerchant;
	}

	public boolean isReadingMerchantPhone() {
		return isReadingMerchantPhone;
	}

	public void setReadingMerchantPhone(boolean isReadingMerchantPhone) {
		this.isReadingMerchantPhone = isReadingMerchantPhone;
	}

	public boolean isReadingOrderNumber() {
		return isReadingOrderNumber;
	}

	public void setReadingOrderNumber(boolean isReadingOrderNumber) {
		this.isReadingOrderNumber = isReadingOrderNumber;
	}

	public boolean isReadingPaymentMethod() {
		return isReadingPaymentMethod;
	}

	public void setReadingPaymentMethod(boolean isReadingPaymentMethod) {
		this.isReadingPaymentMethod = isReadingPaymentMethod;
	}

	public boolean isReadingPurchaseDate() {
		return isReadingPurchaseDate;
	}

	public void setReadingPurchaseDate(boolean isReadingPurchaseDate) {
		this.isReadingPurchaseDate = isReadingPurchaseDate;
	}

	public boolean isReadingPurchaseTime() {
		return isReadingPurchaseTime;
	}

	public void setReadingPurchaseTime(boolean isReadingPurchaseTime) {
		this.isReadingPurchaseTime = isReadingPurchaseTime;
	}

	public boolean isReadingReceiptType() {
		return isReadingReceiptType;
	}

	public void setReadingReceiptType(boolean isReadingReceiptType) {
		this.isReadingReceiptType = isReadingReceiptType;
	}

	public boolean isReadingServiceType() {
		return isReadingServiceType;
	}

	public void setReadingServiceType(boolean isReadingServiceType) {
		this.isReadingServiceType = isReadingServiceType;
	}

	public boolean isReadingState() {
		return isReadingState;
	}

	public void setReadingState(boolean isReadingState) {
		this.isReadingState = isReadingState;
	}

	public boolean isReadingStoreNumber() {
		return isReadingStoreNumber;
	}

	public void setReadingStoreNumber(boolean isReadingStoreNumber) {
		this.isReadingStoreNumber = isReadingStoreNumber;
	}

	public boolean isReadingAddress() {
		return isReadingAddress;
	}

	public void setReadingAddress(boolean isReadingAddress) {
		this.isReadingAddress = isReadingAddress;
	}

	public boolean isReadingTotalPaid() {
		return isReadingTotalPaid;
	}

	public void setReadingTotalPaid(boolean isReadingTotalPaid) {
		this.isReadingTotalPaid = isReadingTotalPaid;
	}

	public boolean isReadingZip() {
		return isReadingZip;
	}

	public void setReadingZip(boolean isReadingZip) {
		this.isReadingZip = isReadingZip;
	}

}
