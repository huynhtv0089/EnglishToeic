package vn.sps.ss.extraction.watson.domain.watson;

import java.util.ArrayList;
import java.util.List;

import vn.sps.ss.extraction.watson.application.common.util.StringUtil;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsEntity;

/**
 * One line item of NPD
 * @author nttung_3
 */
public class LineItem {

	/** itemNumber
	 * Line items have a same item_name but different itemNumber. 
	 */
	private ArrayList<String> itemNumbers;
	
	/** itemNumerConfidences */
	private ArrayList<Double> itemNumerConfidences;

	/** item description */
	private String itemName;

	/** prices
	 * Line items have a same item_name but different prices. 
	 */
	private ArrayList<String> prices;
	
	/** priceConfidences */
	private ArrayList<Double> priceConfidences;

	/** quantities
	 * Line items have a same item_name but different quantities. 
	 */
	private ArrayList<String> quantities;
	
	/** quantityConfidences */
	private ArrayList<Double> quantityConfidences;

	/** discounts
	 * Line items have a same item_name but different discounts. 
	 */
	private ArrayList<String> discounts;
	
	/** priceConfidences */
	private ArrayList<Double> discountConfidences;
	
	/** priceConfidences */
	private List<RelationsEntity> relations;

	public LineItem() {
		this.prices = new ArrayList<>();
		this.quantities = new ArrayList<>();
		this.discounts = new ArrayList<>();
	}

	public  ArrayList<String> getItemNumbers() {
		return this.itemNumbers;
	}

	public String getItemName() {
		return this.itemName;
	}

	public ArrayList<String> getPrices() {
		return this.prices;
	}

	public ArrayList<String> getQuantities() {
		return this.quantities;
	}

	public ArrayList<String> getDiscounts() {
		return this.discounts;
	}
	
	public LineItem hasName(String itemName) {
		this.itemName = itemName;
		return this;
	}

	public LineItem identifiedBy(String itemNumber) {
		if (StringUtil.isNullOrEmpty(itemNumber)) {
			this.itemNumbers.add(itemNumber);
		}
		return this;
	}

	public LineItem cost(String price) {
		if (StringUtil.isNullOrEmpty(price)) {
			this.prices.add(price);
		}
		return this;
	}

	public LineItem has(String quantity) {
		if (StringUtil.isNullOrEmpty(quantity)) {
			this.quantities.add(quantity);
		}
		return this;
	}

	public LineItem promote(String discount) {
		if (StringUtil.isNullOrEmpty(discount)) {
			this.discounts.add(discount);
		}
		return this;
	}

	public List<RelationsEntity> getRelations() {
		return relations;
	}

	public void setRelations(List<RelationsEntity> relations) {
		this.relations = relations;
	}
	
	
	
}
