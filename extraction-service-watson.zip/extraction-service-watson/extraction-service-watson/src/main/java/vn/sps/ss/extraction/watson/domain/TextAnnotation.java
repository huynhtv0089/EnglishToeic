package vn.sps.ss.extraction.watson.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class TextAnnotation implements Serializable {
	
	private static final long serialVersionUID = 6864485064683158961L;
	
	@JsonProperty("locale")
	private String locale;

	@JsonProperty("description")
	private String description;
	
	@JsonProperty("boundingPoly")
	private BoundingPoly boundingPoly;

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BoundingPoly getBoundingPoly() {
		return boundingPoly;
	}

	public void setBoundingPoly(BoundingPoly boundingPoly) {
		this.boundingPoly = boundingPoly;
	}

	@Override
	public String toString() {
		return "TextAnnotation [locale=" + locale + ", description=" + description + ", boundingPoly=" + boundingPoly
				+ "]";
	}
}
