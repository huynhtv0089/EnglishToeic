/*
 * Class: DefaultAsyncWorkerJmxInfoImpl
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.presentation.jmx.impl;

import org.springframework.context.annotation.Configuration;

@Configuration
public class DefaultAsyncWorkerJmxInfoImpl {

}
