/*
 * Class: OCRWorker
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.business.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalysisResults;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationArgument;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationEntity;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationsResult;

import vn.sps.ss.extraction.watson.application.business.CorrectionHandler;
import vn.sps.ss.extraction.watson.application.business.WatsonExtractionHandler;
import vn.sps.ss.extraction.watson.application.business.interceptor.Interceptor;
import vn.sps.ss.extraction.watson.application.business.interceptor.InterceptorFactory;
import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.application.common.util.Constant.Field;
import vn.sps.ss.extraction.watson.application.service.extraction.WatsonService;
import vn.sps.ss.extraction.watson.domain.CorrectionRequest;
import vn.sps.ss.extraction.watson.domain.WatsonRequest;
import vn.sps.ss.extraction.watson.domain.WatsonResponse;
import vn.sps.ss.extraction.watson.infrastructure.configuration.TypeProperties;
import vn.sps.ss.extraction.watson.infrastructure.ifa.impl.AbstractAsyncWorker;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa.ManagementRepository;

/**
 * The Class WatsonExtractionHandlerImpl.
 */
@Component

public class WatsonExtractionHandlerImpl
        extends AbstractAsyncWorker<ProcessingContext>
        implements WatsonExtractionHandler {

    /**
     * The Constant LOG.
     */
    private static final Logger LOG = LoggerFactory
        .getLogger(WatsonExtractionHandlerImpl.class);

    /**
     * The correction handler.
     */
    @Autowired
    private CorrectionHandler correctionHandler;

    /**
     * The extraction task executor.
     */
    @Autowired
    private AsyncTaskExecutor extractionTaskExecutor;

    /**
     * The management repository.
     */
    @Autowired
    private ManagementRepository managementRepository;
    
    /**
     * The watson service.
     */
    @Autowired
    private WatsonService watsonService;
    
    /**
     * The type properties
     */
    @Autowired
    private TypeProperties typeProperties;
    
    @Autowired
    private InterceptorFactory<ProcessingContext> interceptorFactory;
    
    private List<Interceptor> interceptors;
    
    @PostConstruct
    private void setup() {
    	this.interceptors = this.interceptorFactory.getInterceptors(this);
	}

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.ss.extraction.watson.infrastructure.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected AsyncTaskExecutor getExecutor() {
        return this.extractionTaskExecutor;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.ss.extraction.watson.infrastructure.ifa.impl.AbstractAsyncWorker#handle(java.lang.Object)
     */
    @Override
    protected void handle(final ProcessingContext context) {

        final String requestId = context.getId();
        final long begin = WallClock.milli();
        LOG.info("Process Watson Extraction for request {}", requestId);

        try {

            final WatsonRequest watsonRequest = context.getWatsonRequest();
            final WatsonResponse res = this.watsonService
                .extract(watsonRequest);
            if (res != null) {
                context.setWatsonResponse(res);
                final long end = WallClock.milli();
                LOG.info(
                    "Process Watson Extraction for request {} took {} milis",
                    requestId,
                    end - begin);

                final ManagementEntity management = context
                    .getManagementEntity();
                {
                    management.setBeginExtract(begin);
                    management.setEndExtract(end);
                    management.setRelation(new ArrayList<>());
                }

				 // Process interceptors
                LOG.info("Process interceptors for request {}", requestId);
                if (!CollectionUtils.isEmpty(this.interceptors)) {
                	this.interceptors.forEach(i -> i.process(context));
                }
				final EntitiesCorrectionEntity tmpTripCorrect = management.getCorrect();
				final Map<String, RelationsCorrectionEntity> tmpItemCorrect = management.getItemCorrect(); 
				management.setCorrect(null);
				management.setItemCorrect(null);
				this.managementRepository.save(management);
				management.setCorrect(tmpTripCorrect);
				management.setItemCorrect(tmpItemCorrect);

                LOG.info(
                    "Store Watson Extraction for  request {} to DB took {} milis",
                    requestId,
                    WallClock.milli() - end);
                LOG.info(
                        "End Process Watson Extraction for request {} took {} milis at {}",
                        requestId,
                        WallClock.milli() - begin, WallClock.milli());
                if (!CollectionUtils.isEmpty(management.getItem())) {

                    final CorrectionRequest request = new CorrectionRequest(
                        management.getRequestId(), management);

                    context.setCorrectionRequest(request);

                    this.correctionHandler.submitItem(requestId, context);
                    LOG.info("Forward request {} to Correction", requestId);
                }
                else {
                    LOG.info(
                        "Ignore forward request {} to Correction, Content or Entities empty!",
                        requestId);
                }
            }
            else {
                LOG.info(
                    "Response Watson service of request {} have error!",
                    requestId);
            }
        }
        catch (final Exception e) {
            LOG.info(
                "Failed to process Watson Extraction with request {}",
                requestId,
                e);
        }
    }
    
}
