/*
 * Class: RegexValidationConfiguration
 *
 * Created on Oct 19, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "validation.regular-expression.receipt")
public class RegexValidationConfiguration {

    private Map<String, Validation> rules = new HashMap<>();

    public Map<String, Validation> getRules() {
        return rules;
    }

    public Validation getRule(final String fieldName) {
        return this.rules.get(fieldName);
    }

    public static class Validation {

        private List<Replacement> replaces = new ArrayList<>();
        
        private List<String> correctFormats = new ArrayList<>();
        
        private String convertTo;
        
        private String validatePattern;
        
        private String preValidatePattern;

        public List<Replacement> getReplaces() {
            return replaces;
        }

        public void setReplaces(List<Replacement> replaces) {
            this.replaces = replaces;
        }

        public List<String> getCorrectFormats() {
            return correctFormats;
        }

        public void setCorrectFormats(List<String> correctFormats) {
            this.correctFormats = correctFormats;
        }

        public String getConvertTo() {
            return convertTo;
        }

        public void setConvertTo(String convertTo) {
            this.convertTo = convertTo;
        }

        public String getValidatePattern() {
            return validatePattern;
        }

        public void setValidatePattern(String validatePattern) {
            this.validatePattern = validatePattern;
        }

        public String getPreValidatePattern() {
            return preValidatePattern;
        }

        public void setPreValidatePattern(String preValidatePattern) {
            this.preValidatePattern = preValidatePattern;
        }

    }
    
    public static class Replacement {
        
        private String replacePattern;
        
        private String replaceValue;

        public String getReplacePattern() {
            return replacePattern;
        }

        public void setReplacePattern(String replacePattern) {
            this.replacePattern = replacePattern;
        }

        public String getReplaceValue() {
            return replaceValue;
        }

        public void setReplaceValue(String replaceValue) {
            this.replaceValue = replaceValue;
        }
        
    }
}
