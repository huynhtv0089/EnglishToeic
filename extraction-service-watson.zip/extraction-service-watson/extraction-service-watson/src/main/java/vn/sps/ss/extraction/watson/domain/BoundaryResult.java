package vn.sps.ss.extraction.watson.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

public class BoundaryResult {
	
	private HighlightRectangle finalRectangle;
	
	private List<HighlightRectangle> elements;

	public BoundaryResult() {
		
	}

	public BoundaryResult(BoundaryResult boundaryResult) {
		this.finalRectangle = new HighlightRectangle(boundaryResult.getFinalRectangle().getVertices());
		this.elements = new ArrayList<>();
		for (HighlightRectangle hr : boundaryResult.getElements()) {
			this.elements.add(new HighlightRectangle(hr.getVertices()));
		}
	}

	public HighlightRectangle getFinalRectangle() {
		return finalRectangle;
	}

	public void setFinalRectangle(HighlightRectangle finalRectangle) {
		this.finalRectangle = finalRectangle;
	}

	public List<HighlightRectangle> getElements() {
		return elements;
	}

	public void setElements(List<HighlightRectangle> elements) {
		this.elements = elements;
	}
	
	public boolean isDuplicate(BoundaryResult target) {
		if (CollectionUtils.isEmpty(target.getElements()))
			return false;
		for (HighlightRectangle hl : target.getElements()) {
			if (this.elements.contains(hl))
				return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((finalRectangle == null) ? 0 : finalRectangle.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BoundaryResult other = (BoundaryResult) obj;
		if (finalRectangle == null) {
			if (other.finalRectangle != null)
				return false;
		} else if (!finalRectangle.equals(other.finalRectangle))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BoundaryResult [finalRectangle=" + finalRectangle + "]";
	}
}
