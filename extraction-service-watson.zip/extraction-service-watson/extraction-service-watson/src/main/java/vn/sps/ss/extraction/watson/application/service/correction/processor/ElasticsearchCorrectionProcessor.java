/*
 * Class: ElasticsearchCorrectionHandler
 *
 * Created on Oct 16, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.service.correction.processor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.MultiSearchRequestBuilder;
import org.elasticsearch.action.search.MultiSearchResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.common.unit.Fuzziness;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.Operator;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.sort.ScriptSortBuilder.ScriptSortType;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import vn.sps.ss.extraction.watson.application.common.util.Constant.ElasticsearchIndex;
import vn.sps.ss.extraction.watson.application.common.util.Constant.ElasticsearchType;
import vn.sps.ss.extraction.watson.application.common.util.Constant.FilterRuleFields;
import vn.sps.ss.extraction.watson.application.common.util.Constant.ItemNumberDescFields;
import vn.sps.ss.extraction.watson.application.common.util.Constant.MerchantFields;
import vn.sps.ss.extraction.watson.application.common.util.Constant.NpdItemTypeFields;
import vn.sps.ss.extraction.watson.application.common.util.Constant.NpdItemUnitFields;
import vn.sps.ss.extraction.watson.application.common.util.Constant.NpdPaymentMethodFields;
import vn.sps.ss.extraction.watson.application.common.util.Constant.NpdPlzOrtFields;
import vn.sps.ss.extraction.watson.application.common.util.Constant.NpdStoreNumberFields;
import vn.sps.ss.extraction.watson.application.common.util.Constant.NpdStrasseFields;
import vn.sps.ss.extraction.watson.application.common.util.Constant.RegexValidtionFields;
import vn.sps.ss.extraction.watson.application.common.util.Constant.ScriptIds;
import vn.sps.ss.extraction.watson.application.common.util.Constant.ScriptParams;
import vn.sps.ss.extraction.watson.application.common.util.StringUtil;
import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.application.service.correction.filter.FilterRuleProvider;
import vn.sps.ss.extraction.watson.domain.CorrectionContext;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ElasticsearchConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ElasticsearchConfiguration.Index;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ElasticsearchValidationConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch.AddressHit;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch.ItemHit;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch.ItemTypeHit;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch.ItemUnitHit;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch.MerchantHit;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch.PaymentMethodHit;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch.StoreNumberHit;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch.StreetHit;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter.FilterRule;

public class ElasticsearchCorrectionProcessor
        extends AbstractCorrectionProcessor implements CorrectionProcessor {

    private static final Logger LOGGER = LoggerFactory
        .getLogger(ElasticsearchCorrectionProcessor.class);

    private final Client client;

    private final ElasticsearchConfiguration elasticsearchConfiguration;

    private final ElasticsearchValidationConfiguration elasticsearchValidationConfiguration;
    
    private final FilterRuleProvider filterRuleProvider;

    public ElasticsearchCorrectionProcessor(
            final CorrectionProcessor nextHandler, final Client client,
            final ElasticsearchConfiguration elasticsearchConfiguration,
            final ElasticsearchValidationConfiguration elasticsearchValidationConfiguration, final FilterRuleProvider filterRuleProvider) {
        super("ES", nextHandler);
        this.client = client;
        this.elasticsearchConfiguration = elasticsearchConfiguration;
        this.elasticsearchValidationConfiguration = elasticsearchValidationConfiguration;
        this.filterRuleProvider = filterRuleProvider;
    }

    @Override
    protected void filter(final CorrectionContext request) {
    	//do nothing
    }

    @Override
    protected void process(final CorrectionContext request) {

        Long startTime = WallClock.milli();

        final ObjectMapper mapper = new ObjectMapper();
        mapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);

        final EntitiesCorrectionEntity entity = request.getRequest().getManagement().getCorrect();
        final String receiptId = request.getRequest().getReceiptId();
        final Map<String, RelationsCorrectionEntity> itemEntities = request.getRequest().getManagement().getItemCorrect();

        //Build search request for merchant.
        buildMerchantSearch(receiptId, entity.getMerchant(), mapper, entity);
        //Implement to get the rule
        if (!StringUtil.isNullOrEmpty(entity.getMerchant())) {
        	Long startTimeGetRule = WallClock.milli();
        	LOGGER.info("Start process merchant rule for {} with {} ", receiptId, entity.getMerchant());
	        FilterRule merchantRule = filterRuleProvider.getRule(entity.getMerchant());
	        if (merchantRule != null) {
	        	processRule(merchantRule, entity);
	        } else {
	        	LOGGER.warn("Merchant rule of merchant {} is empty.", entity.getMerchant());
	        }
	        LOGGER.info("End process merchant rule for {}. Took {} milis. ", entity.getMerchant(), WallClock.milli() - startTimeGetRule);
        }
        
        try {

            LOGGER.info("Begin correct with ES for receipt {}.", receiptId);

            // Build multi search query, execute search and update context.
            final MultiSearchRequestBuilder multiRequestBuilder = buildMultiQuery(receiptId, entity, itemEntities);
            // Get response
            processRespone(multiRequestBuilder, entity, itemEntities, mapper, receiptId);
            

            LOGGER.info(
                "End correct with ES for receipt {}. Took {} milis.",
                receiptId,
                WallClock.milli() - startTime);
        }
        catch (Exception e) {
            LOGGER.error(
                "Error while correct receipt {} with ES. Took {} milis. Detail: ",
                receiptId,
                WallClock.milli() - startTime,
                e);
        }
    }

	private MultiSearchRequestBuilder buildItemMultiQuery(MultiSearchRequestBuilder multiRequestBuilder,
			String receiptId, Map<String, RelationsCorrectionEntity> itemEntities, String merchantName) {
		itemEntities.entrySet().stream()
				.filter(
					item -> (!StringUtil.isNullOrEmpty(item.getValue().getItemId()) || !StringUtil.isNullOrEmpty(item.getValue().getItemName())))
				.forEach(item -> {
					buildItemQuery(merchantName, item, multiRequestBuilder);
					multiRequestBuilder.add(buildItemTypeQuery(item.getKey(), item.getValue().getItemType()));
					multiRequestBuilder.add(buildItemUnitQuery(item.getKey(), item.getValue().getItemUnit()));
				});
		return multiRequestBuilder;
	}
	
	private SearchRequestBuilder getZipQuery(final String zip) {
		final Index zipCityIndex = this.elasticsearchConfiguration.getIndex(ElasticsearchIndex.NPD_ZIP_CITY);

		if (zipCityIndex != null) {

			QueryBuilder matchZipQuery = QueryBuilders
					.matchQuery(zipCityIndex.getFields().get(NpdPlzOrtFields.ZIP), zip.toLowerCase())
					.fuzziness(Fuzziness.AUTO);

			final Map<String, Object> zipParams = new HashMap<>();
			zipParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.VALUE), zip.toLowerCase());
			zipParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
					zipCityIndex.getFields().get(NpdPlzOrtFields.ZIP));

			return this.client.prepareSearch().setIndices(zipCityIndex.getName())
					.setTypes(zipCityIndex.getTypes().get(ElasticsearchType.ZIP_CITY)).setQuery(matchZipQuery)
					.setFetchSource(true)
					.addScriptField(zipCityIndex.getFields().get(NpdPlzOrtFields.ZIP),
							new Script(ScriptType.STORED, null,
									this.elasticsearchConfiguration.getScript(ScriptIds.LEVENSTEIN_DISTANCE),
									zipParams))
					.addSort(
							SortBuilders
									.scriptSort(
											new Script(ScriptType.STORED, null,
													this.elasticsearchConfiguration
															.getScript(ScriptIds.LEVENSTEIN_DISTANCE),
													zipParams),
											ScriptSortType.NUMBER)
									.order(SortOrder.DESC))
					.setSize(1);
		} else {
			LOGGER.info("Build Zip query failed. ZipCity's index info is missing.");
		}
		return null;
	}

	private void processRespone(MultiSearchRequestBuilder multiRequestBuilder, EntitiesCorrectionEntity entity, Map<String, RelationsCorrectionEntity> itemEntities, ObjectMapper mapper, String receiptId) {
		if (!CollectionUtils.isEmpty(multiRequestBuilder.request().requests())) {

			Map<String, PaymentMethodES> paymentMethods = new HashMap<>();

			final MultiSearchResponse responses = multiRequestBuilder.get();
			responses.forEach(res -> {
				final SearchResponse response = res.getResponse();
				if (response.getHits().getTotalHits() > 0) {
					final SearchHit hit = response.getHits().getAt(0);

					final String indexKey = this.elasticsearchConfiguration.getIndexKeyByName(hit.getIndex());

					final Index index = this.elasticsearchConfiguration.getIndex(indexKey);

					if (!StringUtil.isNullOrEmpty(indexKey)) {

						switch (indexKey) {
						case ElasticsearchIndex.NPD_MERCHANT_NAME:
							merchantIndexRespones(mapper, hit, index, receiptId, entity);
							break;

						case ElasticsearchIndex.NPD_ZIP_CITY:
							zipCityIndexRespones(mapper, hit, index, receiptId, entity);
							break;

						case ElasticsearchIndex.NPD_STORE_NUMBER:
							storeNumberIndexRespones(mapper, hit, index, receiptId, entity);
							break;

						case ElasticsearchIndex.NPD_STREET:
							streetIndexRespones(mapper, hit, index, receiptId, entity);
							break;

						case ElasticsearchIndex.NPD_PAYMENT_METHOD:
							paymentMethodIndexRespones(mapper, hit, index, receiptId, paymentMethods);
							break;
							
						case ElasticsearchIndex.NPD_ITEM:
							itemNumberDescIndexRespones(mapper, hit, index, receiptId, itemEntities);
							break;
							
						case ElasticsearchIndex.NPD_ITEM_TYPE:
							typdesItemIndexRespones(mapper, hit, index, receiptId, itemEntities);
							break;
							
						case ElasticsearchIndex.NPD_ITEM_UNIT:
							itemUnitIndexRespones(mapper, hit, index, receiptId, itemEntities);
							break;
							
						default:
							LOGGER.warn("Index: {} not found in configuration.", hit.getIndex());
							break;
						}
					} else {
						LOGGER.warn("Index: {} not found in configuration.", hit.getIndex());
					}
				}
			});

			// Process payment method
			paymentMethodProcess(mapper, entity, paymentMethods, receiptId);
		} else {
			LOGGER.warn("There is no any data in receipt {} for correction.", receiptId);
		}
	}

	private void paymentMethodProcess(ObjectMapper mapper, EntitiesCorrectionEntity entity, Map<String, PaymentMethodES> paymentMethods, String receiptId) {
		if (CollectionUtils.isEmpty(paymentMethods)) {
        	entity.setPaymentMethod("");
			entity.setPaymentMethodId("");
        } else {
        	//If have more than one payment method, then use Combo
			if (paymentMethods.size() >= 2) {
				SearchRequestBuilder paymentMethodSearchBuilder = this.getPaymentMethodDescQuery("Combo");
				if (paymentMethodSearchBuilder != null) {
					SearchResponse response = paymentMethodSearchBuilder.get();
					if (response.getHits().getTotalHits() > 0) {
						final SearchHit hit = response.getHits().getAt(0);

						final PaymentMethodHit paymentMethodHit = mapper.convertValue(hit, PaymentMethodHit.class);

						entity.setPaymentMethod(paymentMethodHit.get_source().getPaymentMethodDesc());
						entity.setPaymentMethodId(paymentMethodHit.get_source().getPaymentMethodId());
						
						LOGGER.info(
                                "Finished correct Payment Method [corrected: {}, confidence: {}] of receipt {}.",
                                entity.getPaymentMethod(),
                                entity.getPaymentMethodConfidence(),
                                receiptId);
					} else {
						entity.setPaymentMethod("");
						entity.setPaymentMethodId("");
					}
				}
			} else {
				Map.Entry<String, PaymentMethodES> entry = paymentMethods.entrySet().iterator().next();
				entity.setPaymentMethodId(entry.getKey());
				entity.setPaymentMethod(entry.getValue().getDescription());
				entity.setPaymentMethodConfidence(entry.getValue().getConfident());
			}
        }
	}
	
	private void itemNumberDescIndexRespones(ObjectMapper mapper, SearchHit hit, Index index, String receiptId,
			Map<String, RelationsCorrectionEntity> itemEntities) {
		ItemHit itemHit = mapper.convertValue(hit, ItemHit.class);

		int itemIdConfidence = hit.field(index.getFields().get(ItemNumberDescFields.ITEM_ID)) != null
				? hit.field(index.getFields().get(ItemNumberDescFields.ITEM_ID)).getValue()
				: 0;

		int itemNameConfidence = hit.field(index.getFields().get(ItemNumberDescFields.ITEM_NAME)) != null
				? hit.field(index.getFields().get(ItemNumberDescFields.ITEM_NAME)).getValue()
				: 0;

		int itemConfidence = itemIdConfidence > 0 ? itemIdConfidence : itemNameConfidence;
		
		String key = hit.field(this.elasticsearchConfiguration.getParam(ScriptParams.KEY)) != null
				? hit.field(this.elasticsearchConfiguration.getParam(ScriptParams.KEY)).getValue()
				: "";
				
		if (itemConfidence >= this.elasticsearchValidationConfiguration.getMinConfidence()) {

			if (itemEntities.containsKey(key) && (itemEntities.get(key).getItemIdConfidence() != null
					? Integer.parseInt(itemEntities.get(key).getItemIdConfidence())
					: 0) < itemConfidence) {
				itemEntities.get(key).setItemName(itemHit.get_source().getItemName());
				itemEntities.get(key).setItemNameConfidence(String.valueOf(itemConfidence));
				itemEntities.get(key).setItemId(itemHit.get_source().getItemId());
				itemEntities.get(key).setItemIdConfidence(String.valueOf(itemConfidence));
			}
		}
		
		if (itemEntities.containsKey(key)) {
			LOGGER.info("Finished correct item line [corrected: ({} - {}), confidence: ({})] of receipt {}.",
					itemEntities.get(key).getItemName(), itemEntities.get(key).getItemId(), itemConfidence, receiptId);
		}
	}
	
	private void itemUnitIndexRespones(ObjectMapper mapper, SearchHit hit, Index index, String receiptId,
			Map<String, RelationsCorrectionEntity> itemEntities) {
		ItemUnitHit itemUnitHit = mapper.convertValue(hit, ItemUnitHit.class);

		String key = hit.field(this.elasticsearchConfiguration.getParam(ScriptParams.KEY)) != null
				? hit.field(this.elasticsearchConfiguration.getParam(ScriptParams.KEY)).getValue()
				: "";
		if (itemEntities.containsKey(key)) {
			itemEntities.get(key).setItemUnit(itemUnitHit.get_source().getItemUnitDesc());
			itemEntities.get(key).setItemUnitConfidence(String.valueOf(100));
			itemEntities.get(key).setItemUnitId(itemUnitHit.get_source().getItemUnitId());

			LOGGER.info("Finished correct item line: item unit of ({} - {}) [corrected: ({}), confidence: ({})] of receipt {}.",
					itemEntities.get(key).getItemName(), itemEntities.get(key).getItemId(),
					itemEntities.get(key).getItemUnit(), 100, receiptId);
		}
	}

	private void typdesItemIndexRespones(ObjectMapper mapper, SearchHit hit, Index index, String receiptId,
			Map<String, RelationsCorrectionEntity> itemEntities) {
		ItemTypeHit itemTypeHit = mapper.convertValue(hit, ItemTypeHit.class);

		String key = hit.field(this.elasticsearchConfiguration.getParam(ScriptParams.KEY)) != null
				? hit.field(this.elasticsearchConfiguration.getParam(ScriptParams.KEY)).getValue()
				: "";
		if (itemEntities.containsKey(key)) {
			itemEntities.get(key).setItemType(itemTypeHit.get_source().getReceiptItemTypeDesc());
			itemEntities.get(key).setItemTypeConfidence(String.valueOf(100));
			itemEntities.get(key).setItemTypeId(itemTypeHit.get_source().getReceiptItemTypeId());

			LOGGER.info(
					"Finished correct item line: item type of ({} - {}) [corrected: ({}), confidence: ({})] of receipt {}.",
					itemEntities.get(key).getItemName(), itemEntities.get(key).getItemId(),
					itemEntities.get(key).getItemType(), 100, receiptId);
		}
	}

	private void paymentMethodIndexRespones(ObjectMapper mapper, SearchHit hit, Index index, String receiptId, Map<String, PaymentMethodES> paymentMethods) {
		PaymentMethodHit paymentHit = mapper.convertValue(hit, PaymentMethodHit.class);

		int paymentConfidence = hit.field(index.getFields().get(NpdPaymentMethodFields.PAYMENT_METHOD_REGEX)) != null
				? hit.field(index.getFields().get(NpdPaymentMethodFields.PAYMENT_METHOD_REGEX)).getValue()
				: 0;
				
		if (paymentConfidence >= this.elasticsearchValidationConfiguration.getMinConfidence()) {
			paymentMethods.put(paymentHit.get_source().getPaymentMethodId(),
					new PaymentMethodES(paymentHit.get_source().getPaymentMethodId(),
							paymentHit.get_source().getPaymentMethodDesc(), String.valueOf(paymentConfidence)));
		}
		
		LOGGER.info("Correct Payment Method [corrected: {}, confidence: {}] of receipt {}.",
				paymentHit.get_source().getPaymentMethodDesc(), paymentConfidence, receiptId);
	}

	private void streetIndexRespones(ObjectMapper mapper, SearchHit hit, Index index, String receiptId,
			EntitiesCorrectionEntity entity) {
		StreetHit streetHit = mapper.convertValue(hit, StreetHit.class);

		int streetConfidence = hit.field(index.getFields().get(NpdStrasseFields.STREET)) != null
				? hit.field(index.getFields().get(NpdStrasseFields.STREET)).getValue()
				: 0;

		if (streetConfidence >= this.elasticsearchValidationConfiguration.getMinConfidence()) {
			entity.setStreetAddress(streetHit.get_source().getStrasse());
			entity.setStreetAddressConfidence(String.valueOf(streetConfidence));
		}
		
		LOGGER.info("Finished correct Street [corrected: {}, confidence: {}] of receipt {}.",
				streetHit.get_source().getStrasse(), streetConfidence, receiptId);
	}

	private void storeNumberIndexRespones(ObjectMapper mapper, SearchHit hit, Index index, String receiptId,
			EntitiesCorrectionEntity entity) {
		StoreNumberHit storeNumberHit = mapper.convertValue(hit, StoreNumberHit.class);
		
		//Store number
		int storeNrConfidence = hit.field(index.getFields().get(NpdStoreNumberFields.STORE_NUMBER)) != null
				? hit.field(index.getFields().get(NpdStoreNumberFields.STORE_NUMBER)).getValue()
				: 0;

		if (storeNrConfidence >= this.elasticsearchValidationConfiguration.getMinConfidence()) {
			entity.setStoreNumber(storeNumberHit.get_source().getStoreNumber());
			entity.setStoreNumberConfidence(String.valueOf(storeNrConfidence));
		}
		
		if (hit.field(index.getFields().get(NpdStoreNumberFields.STORE_NUMBER)) != null)
			LOGGER.info("Finished correct StoreNr [corrected: {}, confidence: {}] of receipt {}.",
					storeNumberHit.get_source().getStoreNumber(), storeNrConfidence, receiptId);

		//House number
		int houseNrConfidence = hit.field(index.getFields().get(NpdStoreNumberFields.HOUSE_NUMBER)) != null
				? hit.field(index.getFields().get(NpdStoreNumberFields.HOUSE_NUMBER)).getValue()
				: 0;
		
		if (houseNrConfidence >= this.elasticsearchValidationConfiguration.getHouseNrConfidence()) {
			entity.setHouseNumber(storeNumberHit.get_source().getHousenumber());
			entity.setHouseNumberConfidence(String.valueOf(houseNrConfidence));
		}

		if (hit.field(index.getFields().get(NpdStoreNumberFields.HOUSE_NUMBER)) != null)
			LOGGER.info("Finished correct HouseNr [corrected: {}, confidence: {}] of receipt {}.",
					storeNumberHit.get_source().getHousenumber(), houseNrConfidence, receiptId);
	}

	private void merchantIndexRespones(ObjectMapper mapper, SearchHit hit, Index index, String receiptId, 
			EntitiesCorrectionEntity entity) {
		final MerchantHit merchantHit = mapper.convertValue(hit, MerchantHit.class);

		int merchantConfidence = hit.field(index.getFields().get(MerchantFields.MERCHANT_NAME)) != null
				? hit.field(index.getFields().get(MerchantFields.MERCHANT_NAME)).getValue()
				: 0;

		if (merchantConfidence >= this.elasticsearchValidationConfiguration.getMinConfidence()) {
			entity.setMerchant(merchantHit.getSource().getMerchantName());
			entity.setMerchantConfidence(
					hit.field(index.getFields().get(MerchantFields.MERCHANT_NAME)).getValue().toString());
		}
		
		LOGGER.info("Finished correct merchant [corrected: {}, confidence: {}] of receipt {}.",
				merchantHit.getSource().getMerchantName(), merchantConfidence, receiptId);
	}
	
	private void zipCityIndexRespones(ObjectMapper mapper, SearchHit hit, Index index, String receiptId, 
			EntitiesCorrectionEntity entity) {
		
		final AddressHit addressHit = mapper.convertValue(hit, AddressHit.class);
		
		// City
		int cityConfidence = hit.field(index.getFields().get(NpdPlzOrtFields.CITY)) != null
				? hit.field(index.getFields().get(NpdPlzOrtFields.CITY)).getValue()
				: 0;

		if (cityConfidence >= this.elasticsearchValidationConfiguration.getMinConfidence()) {
			entity.setCity(addressHit.get_source().getOrt());
			entity.setCityConfidence(String.valueOf(cityConfidence));
		}
		
		if (hit.field(index.getFields().get(NpdPlzOrtFields.CITY)) != null)
			LOGGER.info("Finished correct City [corrected: {}, confidence: {}] of receipt {}.", addressHit.get_source().getOrt(),
					cityConfidence, receiptId);

		// Zip
		int zipConfidence = hit.field(index.getFields().get(NpdPlzOrtFields.ZIP)) != null
				? hit.field(index.getFields().get(NpdPlzOrtFields.ZIP)).getValue()
				: 0;

		if (zipConfidence >= this.elasticsearchValidationConfiguration.getMinConfidence()) {
			entity.setZip(addressHit.get_source().getPlz());
			entity.setZipConfidence(String.valueOf(zipConfidence));
		}
		
		if (hit.field(index.getFields().get(NpdPlzOrtFields.ZIP)) != null)
			LOGGER.info("Finished correct Zip [corrected: {}, confidence: {}] of receipt {}.", addressHit.get_source().getPlz(),
					zipConfidence, receiptId);

		// State
		int stateConfidence = hit.field(index.getFields().get(NpdPlzOrtFields.STATE)) != null
				? hit.field(index.getFields().get(NpdPlzOrtFields.STATE)).getValue()
				: 0;
				
		if (stateConfidence >= this.elasticsearchValidationConfiguration.getMinConfidence()) {
			entity.setState(addressHit.get_source().getState());
			entity.setStateConfidence(String.valueOf(stateConfidence));
		}
		
		if (hit.field(index.getFields().get(NpdPlzOrtFields.STATE)) != null)
			LOGGER.info("Finished correct State [corrected: {}, confidence: {}] of receipt {}.", addressHit.get_source().getState(),
					stateConfidence, receiptId);
	}

	private void processRule(FilterRule merchantRule, EntitiesCorrectionEntity entity) {
		
		//Store merchant rule
		entity.setMerchantRule(merchantRule.getRule());
		
		// Merchant
		if (!merchantRule.isMerchant()) {
			entity.setMerchant(FilterRuleFields.SPACE);
		}
		// StoreNumber
		if (!merchantRule.isStoreNumber()) {
			entity.setStoreNumber(FilterRuleFields.SPACE);
		}
		// HouseNumber
		if (!merchantRule.isHouseNumber()) {
			entity.setHouseNumber(FilterRuleFields.SPACE);
		}
		// StreetAddress
		if (!merchantRule.isStreetAddress()) {
			entity.setStreetAddress(FilterRuleFields.SPACE);
		}
		// City
		if (!merchantRule.isCity()) {
			entity.setCity(FilterRuleFields.SPACE);
		}
		// State
		if (!merchantRule.isState()) {
			entity.setState(FilterRuleFields.SPACE);
		}
		// merchant Phone
		if (!merchantRule.isMerchantPhone()) {
			entity.setMerchantPhone(FilterRuleFields.SPACE);
		}
		// purchase Date
		if (!merchantRule.isPurchaseDate()) {
			entity.setPurchaseDate(FilterRuleFields.SPACE);
		}
		// purchase Time
		if (!merchantRule.isPurchaseTime()) {
			entity.setPurchaseTime(FilterRuleFields.SPACE);
		}
		// Total Paid
		if (!merchantRule.isTotalPaid()) {
			entity.setTotalPaid(FilterRuleFields.SPACE);
		}
		// payment method
		if (!merchantRule.isPaymentMethod()) {
			entity.setPaymentMethod(FilterRuleFields.SPACE);
		}
		// loyalty
		if (!merchantRule.isLoyalty()) {
			entity.setLoyalty(FilterRuleFields.SPACE);
		}
		// order Number
		if (!merchantRule.isOrderNumber()) {
			entity.setOrderNumber(FilterRuleFields.SPACE);
		}
		// service Type
		if (!merchantRule.isServiceType()) {
			entity.setServiceType(FilterRuleFields.SPACE);
		}
		// receipt Type
		if (!merchantRule.isReceiptType()) {
			entity.setReceiptType(FilterRuleFields.SPACE);
		}
	}

	private void buildMerchantSearch(String receiptId, String field, ObjectMapper mapper, EntitiesCorrectionEntity entity) {
		if (!StringUtil.isNullOrEmpty(field)) {
			SearchRequestBuilder merchantSearchBuilder = this.getMerchantQuery(field);
			if (merchantSearchBuilder != null) {
				SearchResponse response = merchantSearchBuilder.get();
				if (response.getHits().getTotalHits() > 0) {
					final SearchHit hit = response.getHits().getAt(0);

					final String indexKey = this.elasticsearchConfiguration.getIndexKeyByName(hit.getIndex());

					final Index index = this.elasticsearchConfiguration.getIndex(indexKey);

					if (!StringUtil.isNullOrEmpty(indexKey)) {

						final MerchantHit merchantHit = mapper.convertValue(hit, MerchantHit.class);

						int merchantConfidence = hit
								.field(index.getFields().get(MerchantFields.MERCHANT_NAME)) != null
										? hit.field(index.getFields().get(MerchantFields.MERCHANT_NAME)).getValue()
										: 0;

						if (merchantConfidence >= this.elasticsearchValidationConfiguration.getMinConfidence()) {

							entity.setMerchant(merchantHit.getSource().getMerchantName().replaceAll("\\\\", "").replaceAll("]", ""));
							entity.setMerchantConfidence(
									hit.field(index.getFields().get(MerchantFields.MERCHANT_NAME)).getValue()
											.toString());
							entity.setMerchantId(merchantHit.getSource().getMerchantId());

							LOGGER.info("Finished correct merchant [corrected: {}, confidence: {}] of receipt {}.",
									entity.getMerchant(), entity.getMerchantConfidence(), receiptId);
						}
					}
				}
			}
		} else {
			entity.setMerchant("");
			entity.setMerchantId("");
			LOGGER.warn("Merchant of receipt {} is empty.", receiptId);
		}
	}

	@SuppressWarnings("unused")
    private SearchRequestBuilder getMerchantPhoneQuery(
        final String merchantPhone) {

        final Index storeNumberIndex = this.elasticsearchConfiguration
            .getIndex(ElasticsearchIndex.NPD_STORE_NUMBER);

        if (storeNumberIndex != null) {
            final Map<String, Object> params = new HashMap<>();
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                merchantPhone.toLowerCase());
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                storeNumberIndex.getFields()
                    .get(RegexValidtionFields.MERCHANT_PHONE));

            QueryBuilder matchMerchantPhoneQuery = QueryBuilders.matchQuery(
                storeNumberIndex.getFields()
                    .get(RegexValidtionFields.MERCHANT_PHONE),
                merchantPhone.toLowerCase()).fuzziness(Fuzziness.AUTO);

            return this.client.prepareSearch()
                .setIndices(storeNumberIndex.getName())
                .setTypes(
                    storeNumberIndex.getTypes()
                        .get(ElasticsearchType.STORE_NUMBER))
                .setQuery(matchMerchantPhoneQuery).setFetchSource(true)
                .addScriptField(
                    storeNumberIndex.getFields()
                        .get(RegexValidtionFields.MERCHANT_PHONE),
                    new Script(ScriptType.STORED, null,
                        this.elasticsearchConfiguration
                            .getScript(ScriptIds.LEVENSTEIN_DISTANCE),
                        params))
                .addSort(
                    SortBuilders.scriptSort(
                        new Script(ScriptType.STORED, null,
                            this.elasticsearchConfiguration.getScript(
                                ScriptIds.LEVENSTEIN_DISTANCE),
                            params),
                        ScriptSortType.NUMBER).order(SortOrder.DESC))
                .setSize(1);
        }
        else {
            LOGGER.error(
                "Build Merchant phone query failed. StoreNr's index info is missing.");
        }
        return null;
    }

    private SearchRequestBuilder getStateQuery(final String state) {
        final Index zipCityIndex = this.elasticsearchConfiguration
            .getIndex(ElasticsearchIndex.NPD_ZIP_CITY);

        if (zipCityIndex != null) {
            final Map<String, Object> params = new HashMap<>();
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                state.toLowerCase());
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                zipCityIndex.getFields().get(NpdPlzOrtFields.STATE));

            QueryBuilder matchStateQuery = QueryBuilders.matchQuery(
                zipCityIndex.getFields().get(NpdPlzOrtFields.STATE),
                state.toLowerCase()).fuzziness(Fuzziness.AUTO);

            return this.client.prepareSearch()
                .setIndices(zipCityIndex.getName())
                .setTypes(
                    zipCityIndex.getTypes().get(ElasticsearchType.ZIP_CITY))
                .setQuery(matchStateQuery).setFetchSource(true)
                .addScriptField(
                    zipCityIndex.getFields().get(NpdPlzOrtFields.STATE),
                    new Script(ScriptType.STORED, null,
                        this.elasticsearchConfiguration
                            .getScript(ScriptIds.LEVENSTEIN_DISTANCE),
                        params))
                .addSort(
                    SortBuilders.scriptSort(
                        new Script(ScriptType.STORED, null,
                            this.elasticsearchConfiguration.getScript(
                                ScriptIds.LEVENSTEIN_DISTANCE),
                            params),
                        ScriptSortType.NUMBER).order(SortOrder.DESC))
                .setSize(1);
        }
        else {
            LOGGER.error(
                "Build State query failed. ZipCity's index info is missing.");
        }
        return null;
    }

    private SearchRequestBuilder getHouseNrQuery(final String houseNr) {
        final Index storeNumberIndex = this.elasticsearchConfiguration
            .getIndex(ElasticsearchIndex.NPD_STORE_NUMBER);

        if (storeNumberIndex != null) {
            final Map<String, Object> params = new HashMap<>();
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                houseNr.toLowerCase());
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                storeNumberIndex.getFields()
                    .get(NpdStoreNumberFields.HOUSE_NUMBER));

            QueryBuilder matchHouseNrQuery = QueryBuilders.matchQuery(
                storeNumberIndex.getFields()
                    .get(NpdStoreNumberFields.HOUSE_NUMBER),
                houseNr.toLowerCase());

            return this.client.prepareSearch()
                .setIndices(storeNumberIndex.getName())
                .setTypes(
                    storeNumberIndex.getTypes()
                        .get(ElasticsearchType.STORE_NUMBER))
                .setQuery(matchHouseNrQuery).setFetchSource(true)
                .addScriptField(
                    storeNumberIndex.getFields()
                        .get(NpdStoreNumberFields.HOUSE_NUMBER),
                    new Script(ScriptType.STORED, null,
                        this.elasticsearchConfiguration
                            .getScript(ScriptIds.LEVENSTEIN_DISTANCE),
                        params))
                .addSort(
                    SortBuilders.scriptSort(
                        new Script(ScriptType.STORED, null,
                            this.elasticsearchConfiguration.getScript(
                                ScriptIds.LEVENSTEIN_DISTANCE),
                            params),
                        ScriptSortType.NUMBER).order(SortOrder.DESC))
                .setSize(1);
        }
        else {
            LOGGER.error(
                "Build HouseNr query failed. StoreNr's index info is missing.");
        }
        return null;
    }

    private SearchRequestBuilder getPaymentMethodDescQuery(
        final String paymentMethod) {
        final Index paymentIndex = this.elasticsearchConfiguration
            .getIndex(ElasticsearchIndex.NPD_PAYMENT_METHOD);
        
        if (paymentIndex != null) {
        
            final Map<String, Object> params = new HashMap<>();
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                paymentMethod.toLowerCase());
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                paymentIndex.getFields()
                    .get(NpdPaymentMethodFields.PAYMENT_METHOD_DESC));
            
            QueryBuilder matchPaymentMethodQuery = QueryBuilders.matchQuery(
                paymentIndex.getFields()
                    .get(NpdPaymentMethodFields.PAYMENT_METHOD_DESC),
                paymentMethod.toLowerCase()).fuzziness(
                    this.elasticsearchValidationConfiguration
                        .getDefaultFuzziness());
            
            return this.client.prepareSearch()
			            .setIndices(paymentIndex.getName())
			            .setTypes(
			                paymentIndex.getTypes()
			                    .get(ElasticsearchType.PAYMENT_METHOD))
			            .setQuery(matchPaymentMethodQuery).setSize(1);
        }
        else {
            LOGGER.error(
                "Build PaymentMethod query failed. PaymentMethod's index info is missing.");
        }

        return null;
    }
    
    private SearchRequestBuilder getPaymentMethodRegexQuery(
            final String paymentMethod) {
    		
            final Index paymentIndex = this.elasticsearchConfiguration
                .getIndex(ElasticsearchIndex.NPD_PAYMENT_METHOD);
            
            if (paymentIndex != null) {
            	
            	QueryBuilder matchPaymentMethodQuery = QueryBuilders.matchQuery(
                        paymentIndex.getFields()
                            .get(NpdPaymentMethodFields.PAYMENT_METHOD_REGEX),
                        paymentMethod.toLowerCase()).fuzziness(
                            this.elasticsearchValidationConfiguration
                                .getDefaultFuzziness());

                final Map<String, Object> params = new HashMap<>();
                params.put(
                    this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                    paymentMethod.toLowerCase());
                params.put(
                    this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                    paymentIndex.getFields()
                        .get(NpdPaymentMethodFields.PAYMENT_METHOD_REGEX));
                
                return this.client.prepareSearch()
    	                .setIndices(paymentIndex.getName())
    	                .setTypes(
    	                    paymentIndex.getTypes()
    	                        .get(ElasticsearchType.PAYMENT_METHOD))
    	                .setQuery(matchPaymentMethodQuery).setFetchSource(true)
    	                .addScriptField(
    	                    paymentIndex.getFields()
    	                        .get(NpdPaymentMethodFields.PAYMENT_METHOD_REGEX),
    	                    new Script(ScriptType.STORED, null,
    	                        this.elasticsearchConfiguration
    	                            .getScript(ScriptIds.LEVENSTEIN_DISTANCE_PAYMENT_METHOD),
    	                        params))
    	                .addSort(
    	                    SortBuilders.scriptSort(
    	                        new Script(ScriptType.STORED, null,
    	                            this.elasticsearchConfiguration.getScript(
    	                                ScriptIds.LEVENSTEIN_DISTANCE_PAYMENT_METHOD),
    	                            params),
    	                        ScriptSortType.NUMBER).order(SortOrder.DESC))
    	                .setSize(1);
            }
            else {
                LOGGER.error(
                    "Build PaymentMethod query failed. PaymentMethod's index info is missing.");
            }

            return null;
        }

    private SearchRequestBuilder getStreetQuery(final String street) {
        final Index streetIndex = this.elasticsearchConfiguration
            .getIndex(ElasticsearchIndex.NPD_STREET);

        if (streetIndex != null) {
            final Map<String, Object> params = new HashMap<>();
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                street.toLowerCase());
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                streetIndex.getFields().get(NpdStrasseFields.STREET));

            QueryBuilder matchStreetNrQuery = QueryBuilders
                .matchQuery(
                    streetIndex.getFields().get(NpdStrasseFields.STREET),
                    street.toLowerCase())
                .fuzziness(
                    this.elasticsearchValidationConfiguration
                        .getDefaultFuzziness())
                .operator(Operator.AND);
            
            return this.client.prepareSearch().setIndices(streetIndex.getName())
                .setTypes(streetIndex.getTypes().get(ElasticsearchType.STREET))
                .setQuery(matchStreetNrQuery).setFetchSource(true)
                .addScriptField(
                    streetIndex.getFields().get(NpdStrasseFields.STREET),
                    new Script(ScriptType.STORED,null,
                        this.elasticsearchConfiguration
                            .getScript(ScriptIds.LEVENSTEIN_DISTANCE),
                        params))
                .addSort(
                    SortBuilders.scriptSort(
                        new Script(ScriptType.STORED,null,
                            this.elasticsearchConfiguration.getScript(
                                ScriptIds.LEVENSTEIN_DISTANCE),
                            params),
                        ScriptSortType.NUMBER).order(SortOrder.DESC))
                .setSize(1);
        }
        else {
            LOGGER.error(
                "Build Street query failed. Street's index info is missing.");
        }

        return null;
    }

    private SearchRequestBuilder getStoreNumberQuery(final String storeNumber) {
        final Index storeNumberIndex = this.elasticsearchConfiguration
            .getIndex(ElasticsearchIndex.NPD_STORE_NUMBER);

        if (storeNumberIndex != null) {

            final Map<String, Object> params = new HashMap<>();
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                storeNumber.toLowerCase());
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                storeNumberIndex.getFields()
                    .get(NpdStoreNumberFields.STORE_NUMBER));

            QueryBuilder matchStoreNrQuery = QueryBuilders.matchQuery(
                storeNumberIndex.getFields()
                    .get(NpdStoreNumberFields.STORE_NUMBER),
                storeNumber.toLowerCase()).fuzziness(
                    this.elasticsearchValidationConfiguration
                        .getDefaultFuzziness());
            											
            return this.client.prepareSearch()
                .setIndices(storeNumberIndex.getName())
                .setTypes(
                    storeNumberIndex.getTypes()
                        .get(ElasticsearchType.STORE_NUMBER))
                .setQuery(matchStoreNrQuery).setFetchSource(true)
                .addScriptField(
                    storeNumberIndex.getFields()
                        .get(NpdStoreNumberFields.STORE_NUMBER),
                    new Script(ScriptType.STORED,null,
                        this.elasticsearchConfiguration
                            .getScript(ScriptIds.LEVENSTEIN_DISTANCE),
                        params))
                .addSort(
                    SortBuilders.scriptSort(
                        new Script(ScriptType.STORED,null,
                            this.elasticsearchConfiguration.getScript(
                                ScriptIds.LEVENSTEIN_DISTANCE),
                            params),
                        ScriptSortType.NUMBER).order(SortOrder.DESC))
                .setSize(1);
        }
        else {
            LOGGER.info(
                "Build StoreNumber query failed. StoreNumber's index info is missing.");
        }
        return null;
    }

    private SearchRequestBuilder getCityQuery(final String city) {
        final Index zipCityIndex = this.elasticsearchConfiguration
            .getIndex(ElasticsearchIndex.NPD_ZIP_CITY);

        if (zipCityIndex != null) {
            QueryBuilder matchCityQuery = QueryBuilders
                .matchQuery(
                    zipCityIndex.getFields().get(NpdPlzOrtFields.CITY),
                    city.toLowerCase())
                .fuzziness(
                    this.elasticsearchValidationConfiguration
                        .getDefaultFuzziness())
                .operator(Operator.AND);

            final Map<String, Object> cityParams = new HashMap<>();
            cityParams.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                city.toLowerCase());
            cityParams.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                zipCityIndex.getFields().get(NpdPlzOrtFields.CITY));
            
            return this.client.prepareSearch()
                .setIndices(zipCityIndex.getName())
                .setTypes(
                    zipCityIndex.getTypes().get(ElasticsearchType.ZIP_CITY))
                .setQuery(matchCityQuery).setFetchSource(true)
                .addScriptField(
                    zipCityIndex.getFields().get(NpdPlzOrtFields.CITY),
                    new Script(ScriptType.STORED,null,
                        this.elasticsearchConfiguration.getScript(
                            ScriptIds.LEVENSTEIN_DISTANCE),
                        cityParams))
                .addSort(
                    SortBuilders.scriptSort(
                        new Script(ScriptType.STORED,null,
                            this.elasticsearchConfiguration.getScript(
                                ScriptIds.LEVENSTEIN_DISTANCE),
                            cityParams),
                        ScriptSortType.NUMBER).order(SortOrder.DESC))
                .setSize(1);
        }
        else {
            LOGGER.info(
                "Build City query failed. ZipCity's index info is missing.");
        }
        return null;
    }

	private void buildItemQuery(String merchantName, Entry<String, RelationsCorrectionEntity> itemMap, MultiSearchRequestBuilder multiRequestBuilder) {

		BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
		List<QueryBuilder> queries = new ArrayList<>();
		RelationsCorrectionEntity item = itemMap.getValue();
		Index itemIndex = this.elasticsearchConfiguration.getIndex(ElasticsearchIndex.NPD_ITEM);

		//If have merchant name, then add it in query.
		if (!StringUtil.isNullOrEmpty(merchantName)) {
			//queries.add(QueryBuilders.matchQuery(itemIndex.getFields().get(ItemNumberDescFields.ITEM_MERCHANT), merchantName.toLowerCase()));
			boolQuery.must().add(QueryBuilders.matchQuery(itemIndex.getFields().get(ItemNumberDescFields.ITEM_MERCHANT), merchantName.toLowerCase()));
		}

		String fuzzyValue = "";
		
		if (!StringUtil.isNullOrEmpty(item.getItemName())) {
			fuzzyValue = CollectionUtils.isEmpty(item.getSubItems()) ? item.getItemName().toLowerCase()
					: StringUtil.formatMerchant(item.getQuantity(), item.getItemName(), item.getSubItems()).toLowerCase();
			
			queries.add(QueryBuilders.matchQuery(itemIndex.getFields().get(ItemNumberDescFields.ITEM_NAME), fuzzyValue)
					.fuzziness(Fuzziness.build(this.elasticsearchValidationConfiguration.getDefaultFuzziness())));
		}

		if (!StringUtil.isNullOrEmpty(item.getItemId())) {
			queries.add(QueryBuilders.matchQuery(itemIndex.getFields().get(ItemNumberDescFields.ITEM_ID), item.getItemId().toLowerCase())
					.fuzziness(Fuzziness.build(this.elasticsearchValidationConfiguration.getDefaultFuzziness())));
		}
		boolQuery.should().addAll(queries);

		final Index itemNumberDescIndex = this.elasticsearchConfiguration.getIndex(ElasticsearchIndex.NPD_ITEM);

		if (itemNumberDescIndex == null) {
			LOGGER.info("Build item query failed. itemNumberQuery's index info is missing.");
			return;
		}

		Map<String, Object> itemParams = new HashMap<>();
		String scriptFieldName = "";
		Map<String, Object> storeParams = new HashMap<>();
		storeParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.KEY), itemMap.getKey());
		
		//If have both item id and item name, then build 2 queries.
		if (!StringUtil.isNullOrEmpty(item.getItemId()) && !StringUtil.isNullOrEmpty(item.getItemName())) {

			// Item id
			Map<String, Object> itemIdParams = new HashMap<>();
			itemIdParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
					item.getItemId().toLowerCase());
			itemIdParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
					itemNumberDescIndex.getFields().get(ItemNumberDescFields.ITEM_ID));
			multiRequestBuilder.add(buildSearchRequestBuilder(itemIdParams, storeParams, boolQuery, itemNumberDescIndex,
					itemNumberDescIndex.getFields().get(ItemNumberDescFields.ITEM_ID)));

			// Item name
			Map<String, Object> itemNameParams = new HashMap<>();
			itemNameParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.VALUE), fuzzyValue);
			itemNameParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
					itemNumberDescIndex.getFields().get(ItemNumberDescFields.ITEM_NAME));
			multiRequestBuilder.add(buildSearchRequestBuilder(itemNameParams, storeParams, boolQuery,
					itemNumberDescIndex, itemNumberDescIndex.getFields().get(ItemNumberDescFields.ITEM_NAME)));
			return;
		}
		
		//If have item id, then use it to fuzzy, if don't have item id, then use item name
		if (!StringUtil.isNullOrEmpty(item.getItemId())) {
			scriptFieldName = itemNumberDescIndex.getFields().get(ItemNumberDescFields.ITEM_ID);
			itemParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.VALUE), 
					item.getItemId().toLowerCase());
			itemParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
					itemNumberDescIndex.getFields().get(ItemNumberDescFields.ITEM_ID));
			
		} else if (!StringUtil.isNullOrEmpty(item.getItemName())) {
			scriptFieldName = itemNumberDescIndex.getFields().get(ItemNumberDescFields.ITEM_NAME);
			itemParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.VALUE), 
					fuzzyValue);
			itemParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
					itemNumberDescIndex.getFields().get(ItemNumberDescFields.ITEM_NAME));
		}
		
		multiRequestBuilder.add(buildSearchRequestBuilder(itemParams, storeParams, boolQuery,
				itemNumberDescIndex, scriptFieldName));
	}
	
	private SearchRequestBuilder buildSearchRequestBuilder(Map<String, Object> itemParams,
			Map<String, Object> storeParams, BoolQueryBuilder boolQuery, Index itemNumberDescIndex,
			String scriptFieldName) {
		SearchRequestBuilder builder = this.client.prepareSearch().setIndices(itemNumberDescIndex.getName())
				.setTypes(itemNumberDescIndex.getTypes().get(ElasticsearchType.ITEM)).setQuery(boolQuery)
				.setFetchSource(true)
				.addScriptField(scriptFieldName,
						new Script(ScriptType.STORED, null,
								this.elasticsearchConfiguration.getScript(ScriptIds.LEVENSTEIN_DISTANCE), itemParams))
				.addScriptField(this.elasticsearchConfiguration.getParam(ScriptParams.KEY),
						new Script(ScriptType.STORED, null,
								this.elasticsearchConfiguration.getScript(ScriptIds.KEY_STORE), storeParams))
				.addSort(
						SortBuilders
								.scriptSort(
										new Script(ScriptType.STORED, null,
												this.elasticsearchConfiguration
														.getScript(ScriptIds.LEVENSTEIN_DISTANCE),
												itemParams),
										ScriptSortType.NUMBER)
								.order(SortOrder.DESC))
				.setSize(1);
		return builder;
	}
	
	private SearchRequestBuilder buildItemTypeQuery(String key, String itemType) {

		final Index itemTypeIndex = this.elasticsearchConfiguration.getIndex(ElasticsearchIndex.NPD_ITEM_TYPE);

		if (itemTypeIndex != null) {

			Map<String, Object> storeParams = new HashMap<>();
			storeParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.KEY), key);

			QueryBuilder matchItemTypeQuery = QueryBuilders.matchQuery(
					itemTypeIndex.getFields().get(NpdItemTypeFields.RECEIPTITEM_KEY_DESC),
					StringUtil.isNullOrEmpty(itemType) ? NpdItemTypeFields.DEFAULT_ITEM_TYPE_VALUE : itemType.toLowerCase());

			SearchRequestBuilder builder = this.client.prepareSearch().setIndices(itemTypeIndex.getName())
					.setTypes(itemTypeIndex.getTypes().get(ElasticsearchType.TYPDES_ITEM)).setQuery(matchItemTypeQuery)
					.setFetchSource(true)
					.addScriptField(this.elasticsearchConfiguration.getParam(ScriptParams.KEY),
							new Script(ScriptType.STORED, null,
									this.elasticsearchConfiguration.getScript(ScriptIds.KEY_STORE), storeParams))
					.setSize(1);
			return builder;
		} else {
			LOGGER.error("Build ItemType query failed. ItemType's index info is missing.");
		}
		return null;
	}
	
	private SearchRequestBuilder buildItemUnitQuery(String key, String itemType) {

		final Index itemUnitIndex = this.elasticsearchConfiguration.getIndex(ElasticsearchIndex.NPD_ITEM_UNIT);

		if (itemUnitIndex != null) {

			Map<String, Object> storeParams = new HashMap<>();
			storeParams.put(this.elasticsearchConfiguration.getParam(ScriptParams.KEY), key);

			QueryBuilder matchItemTypeQuery = QueryBuilders.matchQuery(
					itemUnitIndex.getFields().get(NpdItemUnitFields.UNIT_DESC),
					StringUtil.isNullOrEmpty(itemType) ? NpdItemUnitFields.DEFAULT_ITEM_UNIT_VALUE : itemType.toLowerCase());

			return this.client.prepareSearch().setIndices(itemUnitIndex.getName())
					.setTypes(itemUnitIndex.getTypes().get(ElasticsearchType.TYPDES_UNIT)).setQuery(matchItemTypeQuery)
					.setFetchSource(true)
					.addScriptField(this.elasticsearchConfiguration.getParam(ScriptParams.KEY),
							new Script(ScriptType.STORED, null,
									this.elasticsearchConfiguration.getScript(ScriptIds.KEY_STORE), storeParams))
					.setSize(1);
		} else {
			LOGGER.error("Build ItemUnit query failed. ItemUnit's index info is missing.");
		}
		return null;
	}

    @SuppressWarnings("unused")
    private SearchRequestBuilder getZipOrtQuery(
        final String zip,
        final String city) {

        final Index zipCityIndex = this.elasticsearchConfiguration
            .getIndex(ElasticsearchIndex.NPD_ZIP_CITY);

        if (zipCityIndex != null) {

            final BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
            boolQuery.must().add(
                QueryBuilders.matchQuery(
                    zipCityIndex.getFields().get(NpdPlzOrtFields.ZIP),
                    zip.toLowerCase()).fuzziness(Fuzziness.AUTO));
            boolQuery.must().add(
                QueryBuilders
                    .matchQuery(
                        zipCityIndex.getFields().get(NpdPlzOrtFields.CITY),
                        city.toLowerCase())
                    .fuzziness(
                        this.elasticsearchValidationConfiguration
                            .getDefaultFuzziness())
                    .operator(Operator.AND));

            final Map<String, Object> zipParams = new HashMap<>();
            zipParams.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                zip.toLowerCase());
            zipParams.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                zipCityIndex.getFields().get(NpdPlzOrtFields.ZIP));

            final Map<String, Object> cityParams = new HashMap<>();
            cityParams.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                city.toLowerCase());
            cityParams.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                zipCityIndex.getFields().get(NpdPlzOrtFields.CITY));

            return this.client.prepareSearch()
                .setIndices(zipCityIndex.getName())
                .setTypes(
                    zipCityIndex.getTypes().get(ElasticsearchType.ZIP_CITY))
                .setQuery(boolQuery).setFetchSource(true)
                .addScriptField(
                    zipCityIndex.getFields().get(NpdPlzOrtFields.ZIP),
                    new Script(ScriptType.STORED,null,
                        this.elasticsearchConfiguration.getScript(
                            ScriptIds.LEVENSTEIN_DISTANCE),
                        zipParams))
                .addScriptField(
                    zipCityIndex.getFields().get(NpdPlzOrtFields.CITY),
                    new Script(ScriptType.STORED,null,
                        this.elasticsearchConfiguration.getScript(
                            ScriptIds.LEVENSTEIN_DISTANCE),
                        cityParams))
                .setSize(1);
        }
        else {
            LOGGER.info(
                "Build Zip, City query failed. ZipCity's index info is missing.");
        }

        return null;
    }

    private SearchRequestBuilder getMerchantQuery(final String merchant) {
        final List<String> lstMerchantNameToken = Arrays
            .asList(StringUtils.splitPreserveAllTokens(merchant.toLowerCase()));

        final BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();

        final Index merchantIndex = this.elasticsearchConfiguration
            .getIndex(ElasticsearchIndex.NPD_MERCHANT_NAME);
        if (merchantIndex != null) {

            lstMerchantNameToken.forEach(i -> {
                boolQuery.should()
                    .add(
                        QueryBuilders
                            .fuzzyQuery(
                                merchantIndex.getFields()
                                    .get(MerchantFields.MERCHANT_NAME),
                                i)
                            .fuzziness(
                                Fuzziness.build(
                                    this.elasticsearchValidationConfiguration
                                        .getDefaultFuzziness())));
            });

            final Map<String, Object> params = new HashMap<>();
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.VALUE),
                merchant.toLowerCase());
            params.put(
                this.elasticsearchConfiguration.getParam(ScriptParams.NAME),
                merchantIndex.getFields().get(MerchantFields.MERCHANT_NAME));
            
            return this.client.prepareSearch()
                .setIndices(merchantIndex.getName())
                .setTypes(
                    merchantIndex.getTypes().get(ElasticsearchType.MERCHANT))
                .setQuery(boolQuery).setFetchSource(true)
                .addScriptField(
                    merchantIndex.getFields().get(MerchantFields.MERCHANT_NAME),
                    new Script(ScriptType.STORED, null,
                        this.elasticsearchConfiguration
                            .getScript(ScriptIds.LEVENSTEIN_DISTANCE),
                        params))
                .addSort(
                    SortBuilders.scriptSort(
                        new Script(ScriptType.STORED, null,
                            this.elasticsearchConfiguration.getScript(
                                ScriptIds.LEVENSTEIN_DISTANCE),
                            params),
                        ScriptSortType.NUMBER).order(SortOrder.DESC))
                .setSize(1);
        }
        else {
            LOGGER.info(
                "Build merchant query failed. Merchant's index info is missing.");
        }

        return null;
    }
    
	private MultiSearchRequestBuilder buildMultiQuery(String receiptId, EntitiesCorrectionEntity entity, Map<String, RelationsCorrectionEntity> itemEntities) {
		// Build multi search query, execute search and update context.
		final MultiSearchRequestBuilder multiRequestBuilder = this.client.prepareMultiSearch();

		// Build search request for Zip.
		if (!StringUtil.isNullOrEmpty(entity.getZip())) {
			SearchRequestBuilder zipSearchBuilder = this.getZipQuery(entity.getZip());
			if (zipSearchBuilder != null) {
				multiRequestBuilder.add(zipSearchBuilder);
			}
		} else {
			LOGGER.warn("Zip of receipt {} is empty.", receiptId);
		}

		// Build search request for City.
		if (!StringUtil.isNullOrEmpty(entity.getCity())) {
			SearchRequestBuilder citySearchBuilder = this.getCityQuery(entity.getCity());
			if (citySearchBuilder != null) {
				multiRequestBuilder.add(citySearchBuilder);
			}
		} else {
			LOGGER.warn("City of receipt {} is empty.", receiptId);
		}

		// Build search query for Store Number.
		if (!StringUtil.isNullOrEmpty(entity.getStoreNumber())) {
			SearchRequestBuilder storeNumberSearchBuilder = this.getStoreNumberQuery(entity.getStoreNumber());
			if (storeNumberSearchBuilder != null) {
				multiRequestBuilder.add(storeNumberSearchBuilder);
			}
		} else {
			LOGGER.warn("StoreNr of receipt {} is empty.", receiptId);
		}

		// Build search query for Street.
		if (!StringUtil.isNullOrEmpty(entity.getStreetAddress())) {
			SearchRequestBuilder streetSearchBuilder = this.getStreetQuery(entity.getStreetAddress());
			if (streetSearchBuilder != null) {
				multiRequestBuilder.add(streetSearchBuilder);
			}
		} else {
			LOGGER.warn("Street of receipt {} is empty.", receiptId);
		}

		// Build search query for House Nr.
		if (!StringUtil.isNullOrEmpty(entity.getHouseNumber())) {
			SearchRequestBuilder houseNrSearchBuilder = this.getHouseNrQuery(entity.getHouseNumber());
			if (houseNrSearchBuilder != null) {
				multiRequestBuilder.add(houseNrSearchBuilder);
			}
		} else {
			LOGGER.warn("HouseNr of receipt {} is empty.", receiptId);
		}

		// Build search query for State.
		if (!StringUtil.isNullOrEmpty(entity.getState())) {
			SearchRequestBuilder stateSearchBuilder = this.getStateQuery(entity.getState());
			if (stateSearchBuilder != null) {
				multiRequestBuilder.add(stateSearchBuilder);
			}
		} else {
			LOGGER.warn("State of receipt {} is empty.", receiptId);
		}

		// Build search query for Payment Method
		if (!CollectionUtils.isEmpty(entity.getExtractPaymentMethods())) {
			for (String pay : entity.getExtractPaymentMethods()) {
				if (!StringUtil.isNullOrEmpty(pay)) {
					SearchRequestBuilder paymentMethodSearchBuilder = this
							.getPaymentMethodRegexQuery(pay.toLowerCase());
					if (paymentMethodSearchBuilder != null) {
						multiRequestBuilder.add(paymentMethodSearchBuilder);
					}
				} else {
					LOGGER.warn("Payment Method of receipt {} is empty.", receiptId);
				}
			}
		}
		
		//Build Item query
		if (!CollectionUtils.isEmpty(itemEntities))
			buildItemMultiQuery(multiRequestBuilder, receiptId, itemEntities, entity.getMerchant());
		return multiRequestBuilder;
	}
    
    private class PaymentMethodES {
    	private String id;
    	private String description;
    	private String confident;
    	
		public PaymentMethodES(String id, String description, String confident) {
			this.id = id;
			this.description = description;
			this.confident = confident;
		}

		@SuppressWarnings("unused")
		public String getId() {
			return id;
		}

		@SuppressWarnings("unused")
		public void setId(String id) {
			this.id = id;
		}

		public String getDescription() {
			return description;
		}

		@SuppressWarnings("unused")
		public void setDescription(String description) {
			this.description = description;
		}

		public String getConfident() {
			return confident;
		}

		@SuppressWarnings("unused")
		public void setConfident(String confident) {
			this.confident = confident;
		}
    }
}
