package vn.sps.ss.extraction.watson.application.iterator.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import vn.sps.ss.extraction.watson.application.iterator.Iterator;
import vn.sps.ss.extraction.watson.application.iterator.interceptor.Interceptor;

abstract class AbstractIterator implements Iterator<Interceptor> {
	
	protected final List<Interceptor> interceptors = new ArrayList<>();
	
	@Override
	public boolean hasNext() {
		return this.interceptors.iterator().hasNext();
	}

	@Override
	public Interceptor next() {
		return this.interceptors.iterator().next();
	}

	/**
	 * Add all available interceptors
	 */
	protected void addInterceptor() {
		this.getConfiguration().forEach(c -> {
			this.addInterceptor(this.getAllInterceptors().get(c));
		});
		
	}
	
	private void addInterceptor(Interceptor interceptor) {
		if (interceptor != null) {
			this.interceptors.add(interceptor);
		}
	}
	
	/**
	 * Load interceptor configuration
	 */
	protected abstract ArrayList<String> getConfiguration();
	
	/**
	 * Load all interceptors  
	 */
	protected abstract Map<String, Interceptor> getAllInterceptors();
	
	
}
