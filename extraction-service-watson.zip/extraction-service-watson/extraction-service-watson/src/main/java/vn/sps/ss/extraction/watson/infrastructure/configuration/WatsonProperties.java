package vn.sps.ss.extraction.watson.infrastructure.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "http.client.watson")
public class WatsonProperties {

    private String username;

    private String password;

    private String version;

    private Long readTimeout;

    private Long connectTimeout;

    private Long writeTimeout;

    private Long keepAliveDuration;

    private Integer maxIdleConnections;

    private Map<String, String> headers;

    private String name;

    private boolean jmxEnabled;

    private long sleepForRetry;

    private boolean enableConcepts;

    private Concepts concepts = new Concepts();

    private boolean enableEntities;

    private Entities entities = new Entities();

    private boolean enableKeywords;

    private Keywords keywords = new Keywords();

    private boolean enableEmotion;

    private Emotion emotion = new Emotion();

    private boolean enableRelations;

    private Relations relations = new Relations();

    private boolean enableSemanticRoles;

    private SemanticRoles semanticRoles = new SemanticRoles();

    private boolean enableSentiment;

    private Sentiment sentiment = new Sentiment();

    private boolean enableAnalyze;

    private Analyze analyze = new Analyze();

    public class Concepts {

        private Long limit;

        public Long getLimit() {
            return limit;
        }

        public void setLimit(Long limit) {
            this.limit = limit;
        }

    }

    public class Entities {

        private Long limit;

        private String model;

        private Boolean sentiment;

        private Boolean emotion;

        public Long getLimit() {
            return limit;
        }

        public void setLimit(Long limit) {
            this.limit = limit;
        }

        public String getModel() {
            return model;
        }

        public void setModel(String model) {
            this.model = model;
        }

        public Boolean getSentiment() {
            return sentiment;
        }

        public void setSentiment(Boolean sentiment) {
            this.sentiment = sentiment;
        }

        public Boolean getEmotion() {
            return emotion;
        }

        public void setEmotion(Boolean emotion) {
            this.emotion = emotion;
        }

    }

    public class Keywords {

        private Long limit;

        private Boolean sentiment;

        private Boolean emotion;

        public Long getLimit() {
            return limit;
        }

        public void setLimit(Long limit) {
            this.limit = limit;
        }

        public Boolean getSentiment() {
            return sentiment;
        }

        public void setSentiment(Boolean sentiment) {
            this.sentiment = sentiment;
        }

        public Boolean getEmotion() {
            return emotion;
        }

        public void setEmotion(Boolean emotion) {
            this.emotion = emotion;
        }

    }

    public class Emotion {

        private Boolean document;

        private List<String> targets;

        public Boolean getDocument() {
            return document;
        }

        public void setDocument(Boolean document) {
            this.document = document;
        }

        public List<String> getTargets() {
            return targets;
        }

        public void setTargets(List<String> targets) {
            this.targets = targets;
        }

    }

    public class Relations {

        private String model;

        public String getModel() {
            return model;
        }

        public void setModel(String model) {
            this.model = model;
        }
    }

    public class SemanticRoles {

        private Long limit;

        private Boolean keywords;

        private Boolean entities;

        public Long getLimit() {
            return limit;
        }

        public void setLimit(Long limit) {
            this.limit = limit;
        }

        public Boolean getKeywords() {
            return keywords;
        }

        public void setKeywords(Boolean keywords) {
            this.keywords = keywords;
        }

        public Boolean getEntities() {
            return entities;
        }

        public void setEntities(Boolean entities) {
            this.entities = entities;
        }

    }

    public class Sentiment {

        private Boolean document;

        private List<String> targets;

        public Boolean getDocument() {
            return document;
        }

        public void setDocument(Boolean document) {
            this.document = document;
        }

        public List<String> getTargets() {
            return targets;
        }

        public void setTargets(List<String> targets) {
            this.targets = targets;
        }

    }

    public class Analyze {

        private String xpath;

        private Boolean returnAnalyzedText;

        private String language;

        private String html;

        private String text;

        private Long limitTextCharacters;

        private Boolean clean;

        private String url;

        private Boolean fallbackToRaw;

        public String getXpath() {
            return xpath;
        }

        public void setXpath(String xpath) {
            this.xpath = xpath;
        }

        public Boolean getReturnAnalyzedText() {
            return returnAnalyzedText;
        }

        public void setReturnAnalyzedText(Boolean returnAnalyzedText) {
            this.returnAnalyzedText = returnAnalyzedText;
        }

        public String getLanguage() {
            return language;
        }

        public void setLanguage(String language) {
            this.language = language;
        }

        public String getHtml() {
            return html;
        }

        public void setHtml(String html) {
            this.html = html;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public Long getLimitTextCharacters() {
            return limitTextCharacters;
        }

        public void setLimitTextCharacters(Long limitTextCharacters) {
            this.limitTextCharacters = limitTextCharacters;
        }

        public Boolean getClean() {
            return clean;
        }

        public void setClean(Boolean clean) {
            this.clean = clean;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public Boolean getFallbackToRaw() {
            return fallbackToRaw;
        }

        public void setFallbackToRaw(Boolean fallbackToRaw) {
            this.fallbackToRaw = fallbackToRaw;
        }

    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public Concepts getConcepts() {
        return concepts;
    }

    public void setConcepts(Concepts concepts) {
        this.concepts = concepts;
    }

    public Entities getEntities() {
        return entities;
    }

    public void setEntities(Entities entities) {
        this.entities = entities;
    }

    public Keywords getKeywords() {
        return keywords;
    }

    public void setKeywords(Keywords keywords) {
        this.keywords = keywords;
    }

    public Emotion getEmotion() {
        return emotion;
    }

    public void setEmotion(Emotion emotion) {
        this.emotion = emotion;
    }

    public Relations getRelations() {
        return relations;
    }

    public void setRelations(Relations relations) {
        this.relations = relations;
    }

    public SemanticRoles getSemanticRoles() {
        return semanticRoles;
    }

    public void setSemanticRoles(SemanticRoles semanticRoles) {
        this.semanticRoles = semanticRoles;
    }

    public Sentiment getSentiment() {
        return sentiment;
    }

    public void setSentiment(Sentiment sentiment) {
        this.sentiment = sentiment;
    }

    public Analyze getAnalyze() {
        return analyze;
    }

    public void setAnalyze(Analyze analyze) {
        this.analyze = analyze;
    }

    public Long getReadTimeout() {
        return readTimeout;
    }

    public void setReadTimeout(Long readTimeout) {
        this.readTimeout = readTimeout;
    }

    public Long getConnectTimeout() {
        return connectTimeout;
    }

    public void setConnectTimeout(Long connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public Long getKeepAliveDuration() {
        return keepAliveDuration;
    }

    public void setKeepAliveDuration(Long keepAliveDuration) {
        this.keepAliveDuration = keepAliveDuration;
    }

    public Integer getMaxIdleConnections() {
        return maxIdleConnections;
    }

    public void setMaxIdleConnections(Integer maxIdleConnections) {
        this.maxIdleConnections = maxIdleConnections;
    }

    public Long getWriteTimeout() {
        return writeTimeout;
    }

    public void setWriteTimeout(Long writeTimeout) {
        this.writeTimeout = writeTimeout;
    }

    public long getSleepForRetry() {
        return sleepForRetry;
    }

    public void setSleepForRetry(long sleepForRetry) {
        this.sleepForRetry = sleepForRetry;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isJmxEnabled() {
        return jmxEnabled;
    }

    public void setJmxEnabled(boolean jmxEnabled) {
        this.jmxEnabled = jmxEnabled;
    }

    public boolean isEnableConcepts() {
        return enableConcepts;
    }

    public void setEnableConcepts(boolean enableConcepts) {
        this.enableConcepts = enableConcepts;
    }

    public boolean isEnableEntities() {
        return enableEntities;
    }

    public void setEnableEntities(boolean enableEntities) {
        this.enableEntities = enableEntities;
    }

    public boolean isEnableKeywords() {
        return enableKeywords;
    }

    public void setEnableKeywords(boolean enableKeywords) {
        this.enableKeywords = enableKeywords;
    }

    public boolean isEnableEmotion() {
        return enableEmotion;
    }

    public void setEnableEmotion(boolean enableEmotion) {
        this.enableEmotion = enableEmotion;
    }

    public boolean isEnableRelations() {
        return enableRelations;
    }

    public void setEnableRelations(boolean enableRelations) {
        this.enableRelations = enableRelations;
    }

    public boolean isEnableSemanticRoles() {
        return enableSemanticRoles;
    }

    public void setEnableSemanticRoles(boolean enableSemanticRoles) {
        this.enableSemanticRoles = enableSemanticRoles;
    }

    public boolean isEnableSentiment() {
        return enableSentiment;
    }

    public void setEnableSentiment(boolean enableSentiment) {
        this.enableSentiment = enableSentiment;
    }

    public boolean isEnableAnalyze() {
        return enableAnalyze;
    }

    public void setEnableAnalyze(boolean enableAnalyze) {
        this.enableAnalyze = enableAnalyze;
    }
}
