package vn.sps.ss.extraction.watson.application.service.ocr.impl;

import javax.activation.UnsupportedDataTypeException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import vn.sps.ss.extraction.watson.application.common.util.Constant.MediaType;
import vn.sps.ss.extraction.watson.application.service.ocr.OCRService;
import vn.sps.ss.extraction.watson.domain.OCRRequest;
import vn.sps.ss.extraction.watson.domain.OCRResponse;

@Service
@Primary
@ConditionalOnProperty(name = "ocr.service-class", havingValue = "vn.sps.ss.extraction.watson.application.service.ocr.impl.OCRServiceImpl")
public class OCRServiceImpl implements OCRService {

    @Autowired
    private ImageService imageOCRService;

    @Autowired
    private PdfOCRService pdfOCRService;

    @Override
    public OCRResponse doOCR(final OCRRequest request)
            throws UnsupportedDataTypeException {
        if (MediaType.APPLICATION_PDF.equals(request.getFileType())) {
            return this.pdfOCRService.doOCR(request);
        }
        else if (MediaType.IMAGE_JPEG.equals(request.getFileType())) {
            return this.imageOCRService.doOCR(request);
        }
        else {
            throw new UnsupportedDataTypeException(
                "Unsupported media type " + request.getFileType());
        }
    }

}
