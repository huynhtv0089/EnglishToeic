/*
 * Class: WatsonResponse
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.domain;

import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalysisResults;

/**
 * The Class WatsonResponse.
 */
public class WatsonResponse {

    /** The content. */
    private AnalysisResults content;

    /** The raw extract. */
    private String rawExtract;

    /** The watson error. */
    private boolean watsonError;

    /**
     * Gets the content.
     *
     * @return the content
     */
    public AnalysisResults getContent() {
        return this.content;
    }

    /**
     * Gets the raw extract.
     *
     * @return the raw extract
     */
    public String getRawExtract() {
        return this.rawExtract;
    }

    /**
     * Checks if is watson error.
     *
     * @return true, if is watson error
     */
    public boolean isWatsonError() {
        return this.watsonError;
    }

    /**
     * Sets the content.
     *
     * @param content the new content
     */
    public void setContent(final AnalysisResults content) {
        this.content = content;
    }

    /**
     * Sets the raw extract.
     *
     * @param rawExtract the new raw extract
     */
    public void setRawExtract(final String rawExtract) {
        this.rawExtract = rawExtract;
    }

    /**
     * Sets the watson error.
     *
     * @param watsonError the new watson error
     */
    public void setWatsonError(final boolean watsonError) {
        this.watsonError = watsonError;
    }
}
