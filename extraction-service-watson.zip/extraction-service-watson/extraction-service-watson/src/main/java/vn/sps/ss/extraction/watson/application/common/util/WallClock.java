/*
 * Class: DiscoWallClock
 *
 * Created on Sep 18, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.common.util;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import vn.sps.ss.extraction.watson.infrastructure.configuration.CommonConfiguration;

/**
 * The Class DiscoWallClock.
 */
@Component
@Configuration
public class WallClock {

    /** The clock. */
    private static Clock clock;

    /**
     * Milli.
     *
     * @return the long
     */
    public static long milli() {
        return clock.millis();
    }

    /**
     * Now.
     *
     * @return the local date time
     */
    public static LocalDateTime now() {
        return LocalDateTime.now(zone());
    }

    /**
     * Of instant.
     *
     * @param epochMilli the epoch milli
     * @return the local date time
     */
    public static LocalDateTime ofInstant(final long epochMilli) {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(epochMilli), zone());
    }
    
    /**
     * Today.
     *
     * @return the local date
     */
    public static LocalDate today() {
        return LocalDate.now(zone());
    }

    /**
     * Zone.
     *
     * @return the zone id
     */
    public static ZoneId zone() {
        return clock.getZone();
    }

    /** The common configuration. */
    @Autowired
    private CommonConfiguration commonConfiguration;

    /**
     * Initialzie.
     */
    @PostConstruct
    protected synchronized void initialzie() {
        clock = Clock.system(this.commonConfiguration.getZoneId());
    }
}
