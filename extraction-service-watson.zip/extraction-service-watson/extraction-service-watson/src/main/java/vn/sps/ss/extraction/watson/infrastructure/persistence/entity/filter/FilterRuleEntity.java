package vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class FilterRuleEntity implements Serializable {

    private static final long serialVersionUID = -61846666394275L;

    @SerializedName(value = "merchant_name")
    private String merchantName;
    
    @SerializedName(value = "merchant_id")
    private String merchantId;
    
    @SerializedName(value = "merchant_id_int")
    private String merchantIdInt;
    
    @SerializedName(value = "merchant_best_valid")
    private String merchantBestValid;
    
    @SerializedName(value = "transaction_type")
    private String transactionType;
    
    @SerializedName(value = "loyalty_status")
    private String loyaltyStatus;
    
    @SerializedName(value = "loyalty_program_name")
    private String loyaltyProgramName;
    
    @SerializedName(value = "create_time")
    private String createTime;
    
    @SerializedName(value = "driverthru_inclusion")
    private String driverthruInclusion;
    
    @SerializedName(value = "address_inclusion")
    private String addressInclusion;
    
    @SerializedName(value = "ordernumber")
    private String orderNumber;
    
    @SerializedName(value = "merchant_name_1")
    private String merchantName1;
    
    @SerializedName(value = "merchantid1")
    private String merchantid1;
    
    @SerializedName(value = "cash_inclusion")
    private String cashInclusion;
    
    @SerializedName(value = "loyalty_number_inclusion")
    private String loyaltyNumberInclusion;
    
    @SerializedName(value = "store_number_inclusion")
    private String storeNumberInclusion;
    
    @SerializedName(value = "merchant_name-suggest")
    private FilterRuleSuggest merchantNameSuggest;
    
    @SerializedName(value = "merchant_id-suggest")
    private FilterRuleSuggest merchantIdSuggest;
    
    @SerializedName(value = "loyalty_status-suggest")
    private FilterRuleSuggest loyaltyStatusSuggest;
    
    @SerializedName(value = "merchant_name_best_valid-suggest")
    private FilterRuleSuggest merchantNameBestValidSuggest;
    
	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantIdInt() {
		return merchantIdInt;
	}

	public void setMerchantIdInt(String merchantIdInt) {
		this.merchantIdInt = merchantIdInt;
	}

	public String getMerchantBestValid() {
		return merchantBestValid;
	}

	public void setMerchantBestValid(String merchantBestValid) {
		this.merchantBestValid = merchantBestValid;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getLoyaltyStatus() {
		return loyaltyStatus;
	}

	public void setLoyaltyStatus(String loyaltyStatus) {
		this.loyaltyStatus = loyaltyStatus;
	}

	public String getLoyaltyProgramName() {
		return loyaltyProgramName;
	}

	public void setLoyaltyProgramName(String loyaltyProgramName) {
		this.loyaltyProgramName = loyaltyProgramName;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getDriverthruInclusion() {
		return driverthruInclusion;
	}

	public void setDriverthruInclusion(String driverthruInclusion) {
		this.driverthruInclusion = driverthruInclusion;
	}

	public String getAddressInclusion() {
		return addressInclusion;
	}

	public void setAddressInclusion(String addressInclusion) {
		this.addressInclusion = addressInclusion;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getMerchantName1() {
		return merchantName1;
	}

	public void setMerchantName1(String merchantName1) {
		this.merchantName1 = merchantName1;
	}

	public String getMerchantId1() {
		return merchantid1;
	}

	public void setMerchantId1(String merchantid1) {
		this.merchantid1 = merchantid1;
	}

	public String getCashInclusion() {
		return cashInclusion;
	}

	public void setCashInclusion(String cashInclusion) {
		this.cashInclusion = cashInclusion;
	}

	public String getLoyaltyNumberInclusion() {
		return loyaltyNumberInclusion;
	}

	public void setLoyaltyNumberInclusion(String loyaltyNumberInclusion) {
		this.loyaltyNumberInclusion = loyaltyNumberInclusion;
	}

	public String getStoreNumberInclusion() {
		return storeNumberInclusion;
	}

	public void setStoreNumberInclusion(String storeNumberInclusion) {
		this.storeNumberInclusion = storeNumberInclusion;
	}

	public FilterRuleSuggest getMerchantNameSuggest() {
		return merchantNameSuggest;
	}

	public void setMerchantNameSuggest(FilterRuleSuggest merchantNameSuggest) {
		this.merchantNameSuggest = merchantNameSuggest;
	}

	public FilterRuleSuggest getMerchantIdSuggest() {
		return merchantIdSuggest;
	}

	public void setMerchantIdSuggest(FilterRuleSuggest merchantIdSuggest) {
		this.merchantIdSuggest = merchantIdSuggest;
	}

	public FilterRuleSuggest getLoyaltyStatusSuggest() {
		return loyaltyStatusSuggest;
	}

	public void setLoyaltyStatusSuggest(FilterRuleSuggest loyaltyStatusSuggest) {
		this.loyaltyStatusSuggest = loyaltyStatusSuggest;
	}

	public FilterRuleSuggest getMerchantNameBestValidSuggest() {
		return merchantNameBestValidSuggest;
	}

	public void setMerchantNameBestValidSuggest(FilterRuleSuggest merchantNameBestValidSuggest) {
		this.merchantNameBestValidSuggest = merchantNameBestValidSuggest;
	}
}
