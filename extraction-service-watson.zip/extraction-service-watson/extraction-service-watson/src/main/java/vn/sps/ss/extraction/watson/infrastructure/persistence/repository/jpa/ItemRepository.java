package vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesEntity;

@Repository
@Transactional
public  interface ItemRepository extends CrudRepository<EntitiesEntity, Long> {

}
