package vn.sps.ss.extraction.watson.application.business.interceptor.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.common.util.Enumerations.EntityType;
import vn.sps.ss.extraction.watson.application.common.util.StringUtil;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;

@Service
class EntitiesPreCorrectionInterceptor extends AbstractInterceptor {

	private static final String ENTITIES_PRE_CORRECTION = "entitiesprecorrection";
	
	private static final Logger LOG = LoggerFactory.getLogger(EntitiesPreCorrectionInterceptor.class);
	
	private static final EntitiesPreCorrectionInterceptor INSTANCE = new EntitiesPreCorrectionInterceptor();
	
	private EntitiesPreCorrectionInterceptor() {
		super(ENTITIES_PRE_CORRECTION);
	}
	
	public static EntitiesPreCorrectionInterceptor getInstance() {
		return INSTANCE;
	}
	
	@Override
	public ProcessingContext process(ProcessingContext context) {
		LOG.info("Start process interceptor {} for request {}.", ENTITIES_PRE_CORRECTION, context.getId());
		ManagementEntity management = context.getManagementEntity();
		if (!CollectionUtils.isEmpty(management.getItem())) {
			this.preProcessCorrect(management, management.getItem());
		} else {
			LOG.warn("Entities Pre-Correction of request {} has been not process because list item is empty", context.getId());
		}
		LOG.info("End process interceptor {} for request {}.", ENTITIES_PRE_CORRECTION, context.getId());
		return context;
	}
	
	private void preProcessCorrect(final ManagementEntity management, final List<EntitiesEntity> items) {
    	final EntitiesCorrectionEntity correctionEntity = management.getCorrect();
        items.forEach(field -> {
            switch (EntityType.valueOf(field.getType())) {
            case A_MERCHANT:
                if (StringUtil.isNullOrEmpty(correctionEntity.getMerchant())) {
                    correctionEntity.setMerchant(field.getTextExtract());
                }
                break;
            case B_STORE_NUMBER:
                if (StringUtil.isNullOrEmpty(correctionEntity.getStoreNumber())) {
                    correctionEntity.setStoreNumber(field.getTextExtract());
                }
                break;
            case C_HOUSE_NUMBER:
                if (StringUtil.isNullOrEmpty(correctionEntity.getHouseNumber())) {
                    correctionEntity.setHouseNumber(field.getTextExtract());
                }
                break;
            case D_ADDRESS:
                if (StringUtil.isNullOrEmpty(correctionEntity.getStreetAddress())) {
                    correctionEntity.setStreetAddress(field.getTextExtract());
                }
                break;
            case D_ZIP:
                if (StringUtil.isNullOrEmpty(correctionEntity.getZip())) {
                    correctionEntity.setZip(field.getTextExtract());
                }
                break;
            case F_CITY:
                if (StringUtil.isNullOrEmpty(correctionEntity.getCity())) {
                    correctionEntity.setCity(field.getTextExtract());
                }
                break;
            case F_STATE:
                if (StringUtil.isNullOrEmpty(correctionEntity.getState())) {
                    correctionEntity.setState(field.getTextExtract());
                }
                break;
            case G_PHONE:
                if (StringUtil.isNullOrEmpty(correctionEntity.getMerchantPhone())) {
                    correctionEntity.setMerchantPhone(field.getTextExtract());
                }
                break;
            case H_PURCHASE_DATE:
                if (StringUtil
                    .isNullOrEmpty(correctionEntity.getPurchaseDate())) {
                    correctionEntity.setPurchaseDate(field.getTextExtract());
                }
                break;
            case I_PURCHASE_TIME:
                if (StringUtil.isNullOrEmpty(correctionEntity.getPurchaseTime())) {
                    correctionEntity.setPurchaseTime(field.getTextExtract());
                }
                break;
            case J_TOTAL_PAID:
                if (StringUtil.isNullOrEmpty(correctionEntity.getTotalPaid())) {
                    correctionEntity.setTotalPaid(field.getTextExtract());
                }
                break;
            case K_PAYMENT_METHOD:
                correctionEntity.getExtractPaymentMethods().add(field.getTextExtract());
                break;
            case M_LOYALTY_CARD:
                if (StringUtil.isNullOrEmpty(correctionEntity.getLoyalty())) {
                    correctionEntity.setLoyalty(field.getTextExtract());
                }
                break;
            case N_ORDER_NUMBER:
                if (StringUtil
                    .isNullOrEmpty(correctionEntity.getOrderNumber())) {
                    correctionEntity.setOrderNumber(field.getTextExtract());
                }
                break;
            case O_SERVICE_TYPE:
                if (StringUtil.isNullOrEmpty(correctionEntity.getServiceType())) {
                    correctionEntity.setServiceType(field.getTextExtract());
                }
                break;
            case P_RECEIPT_TYPE:
                if (StringUtil.isNullOrEmpty(correctionEntity.getReceiptType())) {
                    correctionEntity.setReceiptType(field.getTextExtract());
                }
                break;
            case Q_DRIVE_THRU:
                if (StringUtil.isNullOrEmpty(correctionEntity.getDriveThru())) {
                    correctionEntity.setDriveThru(field.getTextExtract());
                }
                break;
            case R_COUNTER:
                if (StringUtil.isNullOrEmpty(correctionEntity.getCounter())) {
                    correctionEntity.setCounter(field.getTextExtract());
                }
                break;
            default:
                break;
            }
        });
    }
}
