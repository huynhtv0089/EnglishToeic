package vn.sps.ss.extraction.watson.application.service.ocr.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.google.cloud.vision.v1.AnnotateImageRequest;
import com.google.cloud.vision.v1.AnnotateImageResponse;
import com.google.cloud.vision.v1.BatchAnnotateImagesResponse;
import com.google.cloud.vision.v1.Feature;
import com.google.cloud.vision.v1.Feature.Type;
import com.google.cloud.vision.v1.Image;
import com.google.cloud.vision.v1.ImageAnnotatorClient;
import com.google.protobuf.ByteString;

import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.domain.OCRRequest;
import vn.sps.ss.extraction.watson.domain.OCRResponse;

@Service
@Primary
@ConditionalOnProperty(name = "ocr.image.service-class", havingValue = "vn.sps.ss.extraction.watson.application.service.ocr.impl.ImageGoogleServiceImpl")
class ImageGoogleServiceImpl implements ImageService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ImageGoogleServiceImpl.class);
	
	@PostConstruct
	private void info() {
		LOGGER.info("Initialize Bean ImageGoogleServiceImpl: vn.sps.ss.extraction.watson.application.service.ocr.impl.ImageGoogleServiceImpl");
	}

	@Override
	public OCRResponse doOCR(OCRRequest request) {
		final Map<String, Object> result = new HashMap<>();
		final OCRResponse ocrResponse = new OCRResponse();
		ocrResponse.setResult(result);
		
		try (ImageAnnotatorClient vision = ImageAnnotatorClient.create(/*settings*/)) {

			// Reads the image file into memory
			byte[] data = request.getInput();
			ByteString imgBytes = ByteString.copyFrom(data);

			// Builds the image annotation request
			List<AnnotateImageRequest> requests = new ArrayList<>();
			Image img = Image.newBuilder().setContent(imgBytes).build();
			Feature textFeature = Feature.newBuilder().setType(Type.TEXT_DETECTION).build();
			AnnotateImageRequest imageRequest = AnnotateImageRequest.newBuilder().addFeatures(textFeature).setImage(img)
					.build();
			requests.add(imageRequest);

			// Performs label detection on the image file
			final BatchAnnotateImagesResponse response = vision.batchAnnotateImages(requests);
			final List<AnnotateImageResponse> responses = response.getResponsesList();
			final List<String> rawMetaData = new ArrayList<>();
			LOGGER.info("Response of Google at {}.", WallClock.milli());

			for (AnnotateImageResponse imageResponse : responses) {
				if (imageResponse.hasError()) {
					LOGGER.error("Google OCR Error: Error while OCR image. Detail: {}", imageResponse.getError().getMessage());
				} else {
					rawMetaData.add(imageResponse.toString());
					result.put("result", imageResponse.getFullTextAnnotation().getText());
				}
			}
			result.put("chars", rawMetaData);
			
		} catch (Exception e) {
			result.put("result","");
			result.put("chars","");
			LOGGER.error("Error when doing OCR", e);
		} 
		return ocrResponse;

	}

}
