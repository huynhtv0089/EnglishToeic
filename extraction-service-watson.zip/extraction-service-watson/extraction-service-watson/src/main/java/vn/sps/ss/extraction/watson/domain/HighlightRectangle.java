package vn.sps.ss.extraction.watson.domain;

import java.util.List;

public class HighlightRectangle {
	
	private List<Vertice> vertices;

	public HighlightRectangle(List<Vertice> vertices) {
		this.vertices = vertices;
	}

	public List<Vertice> getVertices() {
		return vertices;
	}

	public void setVertices(List<Vertice> vertices) {
		this.vertices = vertices;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((vertices == null) ? 0 : vertices.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HighlightRectangle other = (HighlightRectangle) obj;
		if (vertices == null) {
			if (other.vertices != null)
				return false;
		} else if (vertices.size() != other.getVertices().size())
			return false;
		
		for (int i = 0; i < vertices.size(); i++) {
			if (!vertices.get(i).equals(other.getVertices().get(i)))
				return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "HighlightRectangle [vertices=" + vertices + "]";
	}

	public int compareTo(HighlightRectangle finalRectangle) {
		if (this.getVertices().get(0).getY() > finalRectangle.getVertices().get(0).getY())
			return -1;
		return 1;
	}
}
