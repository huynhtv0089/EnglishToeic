/*
 * Class: WatsonService
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.service.extraction;

import vn.sps.ss.extraction.watson.domain.WatsonRequest;
import vn.sps.ss.extraction.watson.domain.WatsonResponse;

public interface WatsonService {

    /**
     * Extract.
     *
     * @param request the request
     * @return the watson response
     */
    WatsonResponse extract(WatsonRequest request);
}
