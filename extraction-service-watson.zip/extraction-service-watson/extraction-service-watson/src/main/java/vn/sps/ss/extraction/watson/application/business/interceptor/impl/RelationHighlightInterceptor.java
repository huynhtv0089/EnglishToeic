package vn.sps.ss.extraction.watson.application.business.interceptor.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.google.gson.Gson;

import vn.sps.ss.extraction.model.item.ExtractItemCoordinate;
import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.common.util.Constant.Field;
import vn.sps.ss.extraction.watson.application.common.util.HighlightUtil;
import vn.sps.ss.extraction.watson.domain.BoundaryResult;
import vn.sps.ss.extraction.watson.domain.TextAnnotation;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsCorrectionEntity;

@Service
class RelationHighlightInterceptor extends AbstractInterceptor {

	private static final String RELATION_HIGHLIGHT = "relationhighlight";

	private static final Logger LOG = LoggerFactory.getLogger(RelationHighlightInterceptor.class);

	private static final RelationHighlightInterceptor INSTANCE = new RelationHighlightInterceptor();
	
	private RelationHighlightInterceptor() {
		super(RELATION_HIGHLIGHT);
	}

	public static RelationHighlightInterceptor getInstance() {
		return INSTANCE;
	}

	@Override
	public ProcessingContext process(ProcessingContext context) {

		final long begin = System.currentTimeMillis();
		LOG.info("Start process interceptor {} for request {}.", RELATION_HIGHLIGHT, context.getId());
		if (!CollectionUtils.isEmpty(context.getManagementEntity().getItemCorrect())) {
			context.getManagementEntity()
					.setItemCorrect(this.processHighlight(context.getManagementEntity(), context.getId()));
		} else {
			LOG.warn("Item hightlight process of request {} has been not processed because RelationsCorrectionEntity is null",
					context.getId());
		}
		LOG.info("End process interceptor {} for request {} took {}", RELATION_HIGHLIGHT, context.getId(),
				System.currentTimeMillis() - begin);
		return context;
	}

	private Map<String, RelationsCorrectionEntity> processHighlight(ManagementEntity management, String requestId) {
		Map<String, List<BoundaryResult>> readyBoundary = new HashMap<>();
		Map<String, RelationsCorrectionEntity> rlation = management.getItemCorrect();
		for (Entry<String, RelationsCorrectionEntity> t : rlation.entrySet()) {
			Map<String, List<BoundaryResult>> mapResult = new HashMap<>();
			mapResult.put(Field.ITEM_ID, boundary(t.getValue().getItemId(), management.getTextAnnotations()));
			
			mapResult.put(Field.ITEM_NAME, boundary(t.getValue().getItemName(), management.getTextAnnotations()));

			mapResult.put(Field.ITEM_PRICE, boundary(t.getValue().getItemPrice(), management.getTextAnnotations()));

			mapResult.put(Field.QUANTITY, boundary(t.getValue().getQuantity(), management.getTextAnnotations()));

			mapResult.put(Field.TYPE, boundary(t.getValue().getItemType(), management.getTextAnnotations()));

			if (!CollectionUtils.isEmpty(t.getValue().getSubItems())) {
				t.getValue().getSubItems().forEach(z -> {
					if (mapResult.get(Field.SUB_ITEM) == null) {
						mapResult.put(Field.SUB_ITEM, boundary(z, management.getTextAnnotations()));
					} else {
						mapResult.get(Field.SUB_ITEM).addAll(boundary(z, management.getTextAnnotations()));
					}
				});
			}
			
			HighlightUtil.removeIfFound(mapResult, readyBoundary);
			
			Map<String, List<BoundaryResult>> mapResultAfterclean = HighlightUtil.checkItemLine(mapResult);
			
			mapResultAfterclean.entrySet().stream().forEach(itemElement -> {
				if (readyBoundary.containsKey(itemElement.getKey())) {
					readyBoundary.get(itemElement.getKey()).addAll(new ArrayList<>(itemElement.getValue()));
				} else {
					readyBoundary.put(itemElement.getKey(), new ArrayList<>(itemElement.getValue()));
				}
			});
			
			// Remove overload
			for (Entry<String, List<BoundaryResult>> entry : mapResultAfterclean.entrySet()) {
				HighlightUtil.overload(entry.getKey(), entry.getValue(), mapResultAfterclean);
			}
			
			//Set boundary
			setBoundatyForItemLine(rlation.get(t.getKey()), mapResultAfterclean);
		}
		
		Map<String, RelationsCorrectionEntity> orderedRelation = rlation.entrySet().stream().sorted((o1, o2) -> {
			return o2.getValue().compareTo(o1.getValue());
		}).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
				(oldValue, newValue) -> oldValue, LinkedHashMap::new));
		return orderedRelation;
	}

	private void setBoundatyForItemLine(RelationsCorrectionEntity correctionEntity,
			Map<String, List<BoundaryResult>> mapResultAfterclean) {
		Gson gson = new Gson();
		correctionEntity.setItemIdBoundary(convertJson(gson, mapResultAfterclean.get(Field.ITEM_ID)));
		correctionEntity.setListItemIdBoundary(mapResultAfterclean.get(Field.ITEM_ID));
		correctionEntity.setItemPriceBoundary(convertJson(gson, mapResultAfterclean.get(Field.ITEM_PRICE)));
		correctionEntity.setListItemPriceBoundary(mapResultAfterclean.get(Field.ITEM_PRICE));
		correctionEntity.setItemQuantityBoundary(convertJson(gson, mapResultAfterclean.get(Field.QUANTITY)));
		correctionEntity.setListItemQuantityBoundary(mapResultAfterclean.get(Field.QUANTITY));
		correctionEntity.setItemTypeBoundary(convertJson(gson, mapResultAfterclean.get(Field.TYPE)));
		correctionEntity.setListItemTypeBoundary(mapResultAfterclean.get(Field.TYPE));

		correctionEntity.setListItemNameBoundary(mapResultAfterclean.get(Field.ITEM_NAME));
		correctionEntity.setListSubItemsBoundary(mapResultAfterclean.get(Field.SUB_ITEM));

		// Item Name
		if (mapResultAfterclean.containsKey(Field.ITEM_NAME)) {
			if (mapResultAfterclean.containsKey(Field.SUB_ITEM)) {
				mapResultAfterclean.get(Field.ITEM_NAME).addAll(mapResultAfterclean.get(Field.SUB_ITEM));
			}
			correctionEntity.setItemNameBoundary(convertJson(gson, mapResultAfterclean.get(Field.ITEM_NAME)));
		}
	}

	private String convertJson(Gson gson, List<BoundaryResult> list) {
		if (CollectionUtils.isEmpty(list))
			return "";
		return gson.toJson(list.stream().map(i -> new ExtractItemCoordinate(
				i.getFinalRectangle().getVertices().get(0).getX(), i.getFinalRectangle().getVertices().get(0).getY(),
				i.getFinalRectangle().getVertices().get(1).getX(), i.getFinalRectangle().getVertices().get(1).getY(),
				i.getFinalRectangle().getVertices().get(2).getX(), i.getFinalRectangle().getVertices().get(2).getY(),
				i.getFinalRectangle().getVertices().get(3).getX(), i.getFinalRectangle().getVertices().get(3).getY()))
				.collect(Collectors.toList()));
	}

	private List<BoundaryResult> boundary(String field, List<TextAnnotation> textAnnotations) {
		List<BoundaryResult> listBoundary = HighlightUtil.getBoundary(field, textAnnotations);

		// remove duplicate
		if (!CollectionUtils.isEmpty(listBoundary) && listBoundary.size() > 1) {
			HighlightUtil.duplicate(listBoundary);
		}
		return listBoundary;
	}
}
