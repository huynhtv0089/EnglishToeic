package vn.sps.ss.extraction.watson.domain;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class GoogleResponse implements Serializable {

	private static final long serialVersionUID = 4307217700018538858L;
	
	@JsonProperty("fullTextAnnotation")
	private FullTextAnnotation fullTextAnnotation;
	
	@JsonProperty("textAnnotations")
	private List<TextAnnotation> textAnnotations;

	public List<TextAnnotation> getTextAnnotations() {
		return textAnnotations;
	}

	public void setTextAnnotations(List<TextAnnotation> textAnnotations) {
		this.textAnnotations = textAnnotations;
	}

	public FullTextAnnotation getFullTextAnnotation() {
		return fullTextAnnotation;
	}

	public void setFullTextAnnotation(FullTextAnnotation fullTextAnnotation) {
		this.fullTextAnnotation = fullTextAnnotation;
	}

	@JsonIgnoreProperties(ignoreUnknown=true)
	public class FullTextAnnotation implements Serializable {
		
		private static final long serialVersionUID = 6864485064683158968L;
		
		@JsonProperty("text")
		private String text;

		public String getText() {
			return text;
		}

		public void setText(String text) {
			this.text = text;
		}

	}
}
