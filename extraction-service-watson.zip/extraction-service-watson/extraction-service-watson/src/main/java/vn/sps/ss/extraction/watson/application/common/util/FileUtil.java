package vn.sps.ss.extraction.watson.application.common.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.tika.config.TikaConfig;
import org.apache.tika.detect.Detector;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;

import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfReaderContentParser;

@SuppressWarnings({"unchecked", "rawtypes"})
public final class FileUtil {
    private FileUtil() {}
    public static String getType(InputStream inputStream) throws IOException {
        TikaConfig config = TikaConfig.getDefaultConfig();
        Detector detector = config.getDetector();

        TikaInputStream stream = TikaInputStream.get(inputStream);

        Metadata metadata = new Metadata();
        MediaType mediaType = detector.detect(stream, metadata);
        return mediaType.toString();
    }
    
    public static String getType(byte[] input) throws IOException {
        TikaConfig config = TikaConfig.getDefaultConfig();
        Detector detector = config.getDetector();

        TikaInputStream stream = TikaInputStream.get(input);

        Metadata metadata = new Metadata();
        MediaType mediaType = detector.detect(stream, metadata);
        return mediaType.toString();
    }
    
    public static Map<String, Object> extractTextPdf(byte[] input) throws IOException {
        StringBuilder output = new StringBuilder();
        List chars = new ArrayList();
        PdfReader reader = new PdfReader(input);
        PdfReaderContentParser parser = new PdfReaderContentParser(reader);
        PdfRender renderResult;
        for (int i = 1; i <= reader.getNumberOfPages(); i++) {
        	Rectangle pageSize = reader.getPageSizeWithRotation(i);
            renderResult = parser.processContent(i, new PdfRender(pageSize));
            output.append(renderResult.getResult());
            chars.addAll(renderResult.getChars());
        }
        Map resultMap = new LinkedHashMap();
        resultMap.put("result", output.toString());
        resultMap.put("chars", chars);
        return resultMap;
    }

    public static Map<String, Object> byteArray2Text(final byte[] input) {
        final Map<String, Object> resultMap = new LinkedHashMap();
        {
            final String content = new String(input);
            resultMap.put("result", content);
            // The chars is null
        }
        return resultMap;
    }
}