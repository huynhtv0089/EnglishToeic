package vn.sps.ss.extraction.watson.application.service.ocr.impl;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import vn.sps.ss.extraction.watson.application.common.util.Constant.MediaType;
import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.domain.OCRRequest;
import vn.sps.ss.extraction.watson.domain.OCRResponse;
import vn.sps.ss.extraction.watson.infrastructure.configuration.OcrProperties;

@Service
@Primary
@ConditionalOnProperty(name = "ocr.image.service-class", havingValue = "vn.sps.ss.extraction.watson.application.service.ocr.impl.ImageOCRServiceImpl")
class ImageOCRServiceImpl implements ImageService {

    private static final Logger LOGGER = LoggerFactory
        .getLogger(ImageOCRServiceImpl.class);
    
    private String basicAuthorization;

    @Autowired
    @Qualifier("ocrRestTemplate")
    private RestTemplate client;

    @Autowired
    private OcrProperties ocrProperties;

    @Override
    public OCRResponse doOCR(final OCRRequest request) {
        return this
            .doOCR(request, Base64.encodeBase64String(request.getInput()));
    }

    @SuppressWarnings("unchecked")
    private OCRResponse doOCR(final OCRRequest request, final String base64) {

        final OCRResponse ocrResponse = new OCRResponse();

        try {
            final HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", this.basicAuthorization);
            headers.add("Content-Type", MediaType.APPLICATION_JSON);

            final Map<String, Object> payload = new LinkedHashMap<>();
            payload.put("image", base64);
            payload.putAll(this.ocrProperties.getPayload());

            final List<Map<String, Object>> body = new ArrayList<>();
            body.add(payload);
            final HttpEntity<List<Map<String, Object>>> entity = new HttpEntity<>(
                body, headers);

            request.setBegin(WallClock.milli());
            final List<?> result = this.client.postForObject(
                this.ocrProperties.getUrl(),
                entity,
                ArrayList.class);
            request.setEnd(WallClock.milli());
            LOGGER.info("Do OCR done in {} ms", request.duration());

            if ((result == null) || result.isEmpty()) {
                LOGGER.info("OCR Center returns null or empty result");
            }
            else {
                ocrResponse.setResult((Map<String, Object>) result.get(0));
            }
        }
        catch (Exception e) {
            LOGGER.error("Error when doing OCR", e);
        }

        return ocrResponse;

    }

    @PostConstruct
    protected void initialize() {
    	LOGGER.info("Initialize Bean ImageOCRServiceImpl: vn.sps.ss.extraction.watson.application.service.ocr.impl.ImageOCRServiceImpl");
        final String auth = this.ocrProperties.getUsername() + ":"
                + this.ocrProperties.getPassword();
        final byte[] encodedAuth = Base64
            .encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
        this.basicAuthorization = "Basic " + new String(encodedAuth);
        LOGGER.debug(
            "OCR client initialized with authorization {}",
            this.basicAuthorization);
    }

}
