package vn.sps.ss.extraction.watson.application.business.interceptor.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.SerializationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.common.util.Constant.Field;
import vn.sps.ss.extraction.watson.application.common.util.Enumerations.EntityType;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsEntity;

@Service
class RelationsPreCorrectionInterceptor extends AbstractInterceptor {

	private static final String RELATIONS_PRECORRECTION = "relationsprecorrection";
	
	private static final Logger LOG = LoggerFactory.getLogger(RelationsPreCorrectionInterceptor.class);
	
	private static final RelationsPreCorrectionInterceptor INSTANCE = new RelationsPreCorrectionInterceptor();
	
	private static final String DISCOUNT = "discount";
	
	private static final String SHIPPING = "shipping";
	
	private static final String RETURN = "return";
	
	private RelationsPreCorrectionInterceptor() {
		super(RELATIONS_PRECORRECTION);
	}
	
	public static RelationsPreCorrectionInterceptor getInstance() {
		return INSTANCE;
	}
	
	@Override
	public ProcessingContext process(ProcessingContext context) {
		LOG.info("Start process interceptor {} for request {}.", RELATIONS_PRECORRECTION, context.getId());
		ManagementEntity management = context.getManagementEntity();
		if (!CollectionUtils.isEmpty(management.getRelation())) {
			this.preProcessCorrect(management, management.getItem());
        	this.preProcessItemCorrect(management, management.getRelation());
        	this.createObjectLine(management);
		} else {
			LOG.warn("Relations Pre-Correction of request {} has been not processed because list relation is empty", context.getId());
		}
		LOG.info("End process interceptor {} for request {}.", RELATIONS_PRECORRECTION, context.getId());
		return context;
	}
	
	private void preProcessCorrect(final ManagementEntity management, final List<EntitiesEntity> items) {
		items.forEach(field -> {
			switch (EntityType.valueOf(field.getType())) {
			case J_ITEM_NAME:
				Map<String, RelationsCorrectionEntity> itemCorrect = management.getItemCorrect();
				RelationsCorrectionEntity itemCorrection = new RelationsCorrectionEntity(management);
				itemCorrection.setItemName(field.getTextExtract());
				itemCorrection.setCount(1);

				if (!CollectionUtils.isEmpty(itemCorrect)) {
					if (itemCorrect.get(field.getTextExtract()) != null) {
						int countCurrent = itemCorrect.get(field.getTextExtract()).getCount();
						itemCorrect.get(field.getTextExtract()).setCount(countCurrent + 1);
					} else {
						itemCorrect.put(field.getTextExtract(), itemCorrection);
					}
				} else {
					itemCorrect.put(field.getTextExtract(), itemCorrection);
				}
				break;
			default:
				break;
			}
		});
	}
	
	public void preProcessItemCorrect(final ManagementEntity management, final List<RelationsEntity> relation) {
    	Map<String, RelationsCorrectionEntity> itemCorrect = management.getItemCorrect();
    	
    	relation.forEach(field -> {
    		String mainTextExtract = field.getMainTextExtract();  		
    		String mainType = field.getMainType();						
    		String secondTextExtract = field.getSecondTextExtract();	
    		String secondType = field.getSecondType();
    		Double score = field.getScore();
    		
			setDataItemCorrect(mainType, 0.0, mainTextExtract, itemCorrect.get(mainTextExtract));
			setTypeData(secondType, score, secondTextExtract, itemCorrect.get(mainTextExtract));
			itemCorrect.put(mainTextExtract, itemCorrect.get(mainTextExtract));
        });
    }
    
    public void setDataItemCorrect(String name, Double score, String value, RelationsCorrectionEntity enity) {
		if(Field.ITEM_ID.equals(name)) {
			enity.setListItemId(score, value);
		} else if(Field.ITEM_NAME.equals(name)) {
			enity.setItemName(value);
		} else if(Field.QUANTITY.equals(name)) {
			enity.setQuantity(value);
		} else if(Field.ITEM_PRICE.equals(name)) {
			enity.setListItemPrice(score, value);
		} else if(Field.TYPE.equals(name)) {
			if(Field.DISCOUNT_TYPE.equals(value)) {
				value = DISCOUNT;
			} else if (Field.SHIPPING_TYPE.equals(value)) {
				value = SHIPPING;
			} else if (Field.RETURN_TYPE.equals(value)) {
				value = RETURN;
			}
			enity.setItemType(value);
		} else if(Field.SUB_ITEM.equals(name)) {
			enity.setSubItems(value);
			if(enity.getQuantity() == null) {
				enity.setQuantity(String.valueOf(1));
			}
		}
    }
    
	private void setTypeData(String type, Double score, String TextExtract, RelationsCorrectionEntity entity) {
		if (Field.DISCOUNT_TYPE.equals(type) || Field.SHIPPING_TYPE.equals(type) || Field.RETURN_TYPE.equals(type)) {
			setDataItemCorrect(Field.TYPE, 0.0, type, entity);
		} else {
			if (Field.ITEM_PRICE.equals(type)) {
				if (entity.getListItemPrice().size() < entity.getCount()) {
					setDataItemCorrect(type, score, TextExtract, entity);
				} else {
					setDataItemCorrect(type, score, TextExtract, entity);
					entity.getListItemPrice().remove(entity.getListItemPrice().firstKey());
				}
			} else if (Field.ITEM_ID.equals(type)) {
				setDataItemCorrect(type, score, TextExtract, entity);
			} else {
				setDataItemCorrect(type, 0.0, TextExtract, entity);
			}
		}
	}
    
	private void createObjectLine(final ManagementEntity management) {
		Map<String, RelationsCorrectionEntity> itemCorrect = management.getItemCorrect();
		Map<String, RelationsCorrectionEntity> itemCorrectResult = new LinkedHashMap<String, RelationsCorrectionEntity>();

		itemCorrect.forEach((k, v) -> {
			v.setItemId(CollectionUtils.isEmpty(v.getListItemId()) ? ""
					: String.valueOf(v.getListItemId().lastEntry()).split("=")[1]);
			if (v.getCount() > 1) {
				v.setQuantity("");
				int i = 1;
				for (Map.Entry<Double, String> entry : v.getListItemPrice().entrySet()) {
					RelationsCorrectionEntity entity = (RelationsCorrectionEntity) SerializationUtils.clone(v);
					entity.setItemPrice(String.valueOf(entry.getValue()));
					itemCorrectResult.put(k + " [Duplicate-" + i + "]", entity);
					i++;
				}
				itemCorrect.remove(String.valueOf(v));
			} else {
				v.setItemPrice(CollectionUtils.isEmpty(v.getListItemPrice()) ? ""
						: String.valueOf(v.getListItemPrice().firstEntry()).split("=")[1]);
				itemCorrectResult.put(k, v);
			}
		});

		management.setItemCorrect(itemCorrectResult);
	}
}
