/*
 * Class: Enumerations
 *
 * Created on Oct 16, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.common.util;

public class Enumerations {

    public enum EntityType {
        A_MERCHANT,
        B_STORE_NUMBER,
        C_HOUSE_NUMBER,
        D_ADDRESS,
        D_ZIP,
        F_CITY,
        F_STATE,
        G_PHONE,
        H_PURCHASE_DATE,
        I_PURCHASE_TIME,
        K_PAYMENT_METHOD,
        J_TOTAL_PAID,
        M_LOYALTY_CARD,
        N_ORDER_NUMBER,
        O_SERVICE_TYPE,
        P_RECEIPT_TYPE,
        Q_DRIVE_THRU,
        R_COUNTER,
        J_ITEM_PRICE,
        J_ITEM_NAME,
        J_QUANTITY,
        J_ITEM_ID,
        J_SUB_ITEM,
        K_DISCOUNT_TYPE,
        K_GENERAL_TYPE,
        K_SHIPPING_TYPE,
        K_RETURN_TYPE,
        S_RECEIPT_NUMBER,
        S_CASH_REGISTER_CODE,
        S_LOYALTY_CARD_NO,
        S_CASHIER_CODE;
    }
}
