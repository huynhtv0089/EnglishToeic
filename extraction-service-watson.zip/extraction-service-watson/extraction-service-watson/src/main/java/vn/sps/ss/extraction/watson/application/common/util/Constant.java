package vn.sps.ss.extraction.watson.application.common.util;

public final class Constant {
	
	public final class Field {
		private Field() {}
		
		public static final String A_MERCHANT = "A_MERCHANT";
		public static final String B_STORE_NUMBER = "B_STORE_NUMBER";
		public static final String C_HOUSE_NUMBER = "C_HOUSE_NUMBER";
		public static final String D_ADDRESS = "D_ADDRESS";
		public static final String D_ZIP = "D_ZIP";
		public static final String F_CITY = "F_CITY";
		public static final String F_STATE = "F_STATE";
		public static final String G_PHONE = "G_PHONE";
		public static final String H_PURCHASE_DATE = "H_PURCHASE_DATE";
		public static final String I_PURCHASE_TIME = "I_PURCHASE_TIME";
		public static final String K_PAYMENT_METHOD = "K_PAYMENT_METHOD";
		public static final String J_TOTAL_PAID = "J_TOTAL_PAID";
		public static final String M_LOYALTY_CARD = "M_LOYALTY_CARD";
		public static final String N_ORDER_NUMBER = "N_ORDER_NUMBER";
		public static final String O_SERVICE_TYPE = "O_SERVICE_TYPE";
		public static final String P_RECEIPT_TYPE = "P_RECEIPT_TYPE";
		
		public static final String ITEM_ID = "J_ITEM_ID";
		
		public static final String ITEM_NAME = "J_ITEM_NAME";
		
		public static final String QUANTITY = "J_QUANTITY";
		
		public static final String ITEM_PRICE = "J_ITEM_PRICE";
		
		public static final String DISCOUNT_TYPE = "K_DISCOUNT_TYPE";
		
		public static final String SHIPPING_TYPE = "K_SHIPPING_TYPE";
		
		public static final String RETURN_TYPE = "K_RETURN_TYPE";
		
		public static final String SUB_ITEM = "J_SUB_ITEM";
		
		public static final String TYPE = "TYPE";
	}
	
	public final class RelationType {
		private RelationType() {}
		
		public static final String COST = "cost";
		
		public static final String HAS = "has";
		
		public static final String INCLUDE_IN = "includeIn";
		
		public static final String IDENTIFIED_BY = "identifiedBy";
		
		public static final String DISCOUNT = "is";
	}

    public final class MediaType {
    	
    	private MediaType() {}
    	
        public static final String IMAGE_JPEG = "image/jpeg";

        public static final String APPLICATION_PDF = "application/pdf";

        public static final String APPLICATION_JSON = "application/json";
    }

    /**
     * Instantiates a new enumerations.
     */
    private Constant() {
    }

    public final class ElasticsearchType {
    	
    	private ElasticsearchType() {}
    	
        public static final String MERCHANT = "t_merchant";

        public static final String ZIP_CITY = "t_zip_city";
        
        public static final String STORE_NUMBER = "t_store_number";
        
        public static final String STREET = "t_street";
        
        public static final String PAYMENT_METHOD = "t_payment_method";
        
        public static final String ITEM = "t_item";
        
        public static final String TYPDES_ITEM = "t_typdes_item";
        
        public static final String TYPDES_UNIT = "t_units";
    }

    public final class ElasticsearchIndex {
    	
    	private ElasticsearchIndex() {}
    	
        public static final String NPD_MERCHANT_NAME = "merchant";

        public static final String NPD_ZIP_CITY = "zipCity";
        
        public static final String NPD_PAYMENT_METHOD = "paymentMethod";
        
        public static final String NPD_STORE_NUMBER = "storeNumber";
        
        public static final String NPD_STREET = "street";
        
        public static final String NPD_ITEM = "item";
        
        public static final String NPD_ITEM_TYPE = "itemType";
        
        public static final String NPD_ITEM_UNIT = "itemUnit";
    }

    public final class MerchantFields {
    	
    	private MerchantFields() {}
    	
        public static final String MERCHANT_NAME = "f_merchant";
    }

    public final class NpdPlzOrtFields {
    	
    	private NpdPlzOrtFields() {}
    	
        public static final String CITY = "f_city";
        public static final String ZIP = "f_zip";
        public static final String STATE = "f_state";
    }
    
    public final class NpdStrasseFields {
    	
    	private NpdStrasseFields() {}
    	
        public static final String STREET = "f_street";
    }
    
    public final class NpdStoreNumberFields {
    	
    	private NpdStoreNumberFields() {}
    	
        public static final String EXT_MERCHANTNAME = "f_ext_merchant";
        public static final String STORE_NUMBER = "f_store_number";
        public static final String HOUSE_NUMBER = "f_house_number";
    }
    
    public final class NpdPaymentMethodFields {
    	
    	private NpdPaymentMethodFields() {}
    	
        public static final String PAYMENT_METHOD_DESC = "f_payment_method_desc";
        public static final String PAYMENT_METHOD_REGEX = "f_payment_method_regex";
    }

    public final class ScriptParams {
    	
    	private ScriptParams() {}
    	
        public static final String NAME = "p_field_name";
        public static final String VALUE = "p_field_value";
        public static final String KEY = "p_key";
    }

    public final class ScriptLangs {
    	
    	private ScriptLangs() {}
    	
        public static final String PAINLESS = "painless";
    }
    
    public final class ScriptIds {
    	
    	private ScriptIds() {}
    	
        public static final String LEVENSTEIN_DISTANCE = "levensteinDistance";
        public static final String LEVENSTEIN_DISTANCE_PAYMENT_METHOD = "levensteinDistanceForPaymentMethod";
        public static final String KEY_STORE = "storeKey";
    }
    
    public final class RegexValidtionFields {
    	
    	private RegexValidtionFields() {}
    	
        public static final String ORDER_NUMBER = "f_order_nr";
        public static final String PURCHASE_DATE = "f_purchase_date";
        public static final String PURCHASE_TIME = "f_purchase_time";
        public static final String SERVICE_TYPE_COUNTER = "f_service_type_counter";
        public static final String SERVICE_TYPE_DRIVETHRU = "f_service_type_drivethru";
        public static final String SERVICE_TYPE_SPECIAL = "f_service_type_special";
        public static final String TOTAL_PAID = "f_total_paid";
        public static final String MERCHANT_PHONE = "f_merchant_phone";
        public static final String PAYMENT_METHOD_CASH = "f_payment_method_cash";
        public static final String PAYMENT_METHOD_CREDIT = "f_payment_method_credit";
        public static final String PAYMENT_METHOD_DEBIT = "f_payment_method_debit";
        public static final String PAYMENT_METHOD_GIFTCARD = "f_payment_method_giftcard";
        public static final String PAYMENT_METHOD_EBT = "f_payment_method_ebt";
        public static final String PAYMENT_METHOD_CHECK = "f_payment_method_check";
        public static final String PAYMENT_METHOD_STORECREDIT = "f_payment_method_storecredit";
        public static final String PAYMENT_METHOD_PAYPAL = "f_payment_method_paypal";
        public static final String PAYMENT_METHOD_OTHER = "f_payment_method_other";
        public static final String ITEM_PRICE = "f_item_price";
    }
    
    public final class FilterRuleFields {
    	
    	private FilterRuleFields() {}
    	
        public static final String MERCHANT_NAME = "merchant_name";
        public static final String SEARCH = "_search";
        public static final String SEPARATOR = "/";
        public static final String HITS = "hits";
        public static final String SPACE = "";
        public static final String HTTP = "http://";
    }
    
    public final class ItemNumberDescFields {
    	
    	private ItemNumberDescFields() {}
    	
        public static final String ITEM_MERCHANT = "f_merchant";
        public static final String ITEM_NAME = "f_item_name";
        public static final String ITEM_ID = "f_item_id";
    }
    
    public final class NpdItemTypeFields {
    	
    	private NpdItemTypeFields() {}
    	
        public static final String RECEIPTITEM_KEY_DESC = "f_receiptitem_key_desc";
        
        public static final String DEFAULT_ITEM_TYPE_VALUE = "general";
    }
    
    public final class NpdItemUnitFields {
    	
    	private NpdItemUnitFields() {}
    	
        public static final String UNIT_DESC = "f_unit_desc";
        
        public static final String DEFAULT_ITEM_UNIT_VALUE = "Unit";
    }
}
