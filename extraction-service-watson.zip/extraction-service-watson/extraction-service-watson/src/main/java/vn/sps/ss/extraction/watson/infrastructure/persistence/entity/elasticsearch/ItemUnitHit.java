package vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ItemUnitEntity;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemUnitHit extends AbstractHit implements Serializable {

	private static final long serialVersionUID = -1615945965187852862L;
	
	@JsonProperty(value = "sourceAsMap")
    private ItemUnitEntity _source;

    public ItemUnitEntity get_source() {
        return _source;
    }

    public void set_source(ItemUnitEntity _source) {
        this._source = _source;
    }
}
