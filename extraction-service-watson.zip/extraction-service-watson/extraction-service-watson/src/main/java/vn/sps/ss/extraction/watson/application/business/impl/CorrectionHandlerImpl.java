/*
 * Class: OCRWorker
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.business.impl;

import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import vn.sps.ss.extraction.watson.application.business.CorrectionHandler;
import vn.sps.ss.extraction.watson.application.business.interceptor.Interceptor;
import vn.sps.ss.extraction.watson.application.business.interceptor.InterceptorFactory;
import vn.sps.ss.extraction.watson.application.common.util.StringUtil;
import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.application.service.correction.CorrectionService;
import vn.sps.ss.extraction.watson.domain.CorrectionRequest;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ElasticsearchValidationConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.ifa.impl.AbstractAsyncWorker;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa.ManagementRepository;

/**
 * The Class CorrectionHandlerImpl.
 */
@Component
public class CorrectionHandlerImpl extends
        AbstractAsyncWorker<ProcessingContext> implements CorrectionHandler {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory
        .getLogger(CorrectionHandlerImpl.class);

    /** The correction service. */
    @Autowired
    private CorrectionService correctionService;

    /** The correction task executor. */
    @Autowired
    private AsyncTaskExecutor correctionTaskExecutor;

    /** The management repository. */
    @Autowired
    private ManagementRepository managementRepository;
    
    @Autowired
    private ElasticsearchValidationConfiguration esValidationConfiguration;
    
    @Autowired
    private InterceptorFactory<ProcessingContext> interceptorFactory;
    
    private List<Interceptor> interceptors;
    
    @PostConstruct
    private void setup() {
    	this.interceptors = this.interceptorFactory.getInterceptors(this);
	}
    
    /**
     * {@inheritDoc}
     *
     * @see vn.sps.ss.extraction.watson.infrastructure.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected AsyncTaskExecutor getExecutor() {
        return this.correctionTaskExecutor;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.ss.extraction.watson.infrastructure.ifa.impl.AbstractAsyncWorker#handle(java.lang.Object)
     */
    @Override
    protected void handle(final ProcessingContext context) {

        final String requestId = context.getId();

        try {
            final long begin = WallClock.milli();
            LOG.info("Process Correction for request {}", requestId);

            final ManagementEntity management = context.getManagementEntity();
            
            // Process interceptors
//            if (!CollectionUtils.isEmpty(this.interceptors)) {
//            	this.interceptors.forEach(i -> i.process(context));
//            }
            
            final CorrectionRequest correctionRequest = context.getCorrectionRequest();
            this.correctionService.correct(correctionRequest);

            this.cleanUncorrectedEntitiesData(
                correctionRequest,
                this.esValidationConfiguration.getMinConfidence(),
                this.esValidationConfiguration.getHouseNrConfidence());
            
			this.cleanUncorrectedRelationData(correctionRequest, this.esValidationConfiguration.getMinConfidence());

            //store request id in correction
            correctionRequest.getManagement().getCorrect().setRequestId(management.getRequestId());
			correctionRequest.getManagement().getItemCorrect().entrySet().stream()
					.forEach(item -> item.getValue().setRequestId(management.getRequestId()));
            
            final long end = WallClock.milli();
            LOG.info(
                "Process Correction for request {} took {} milis.",
                requestId,
                end - begin);

            management.setBeginCorrect(begin);
            management.setEndCorrect(end);
            //Don't save again
            management.setItem(null);
            management.setRelation(null);
            this.managementRepository.save(management);
            LOG.info(
                "Store Correction for request {} to DB took {} milis.",
                requestId,
                WallClock.milli() - end);
        }
        catch (final Exception e) {
            LOG.info(
                "Failed to process Correction with request {}.",
                requestId,
                e);
        }
    }

    

	private void cleanUncorrectedEntitiesData(
        CorrectionRequest correctionRequest,
        int minConfidence,
			int minHouseNrConfidence) {
		EntitiesCorrectionEntity correctionEntity = correctionRequest.getManagement().getCorrect();

		String merchantConfidence = correctionEntity.getMerchantConfidence();
		if (StringUtil.isNullOrEmpty(merchantConfidence) || Integer.parseInt(merchantConfidence) < minConfidence) {
			correctionEntity.setMerchant("");
			correctionEntity.setMerchantConfidence("");
			correctionEntity.setMerchantId("");
			correctionEntity.setMerchantBoundary("");
		}

		String zipConfidence = correctionEntity.getZipConfidence();
		if (StringUtil.isNullOrEmpty(zipConfidence) || Integer.parseInt(zipConfidence) < minConfidence) {
			correctionEntity.setZip("");
			correctionEntity.setZipConfidence("");
			correctionEntity.setZipBoundary("");
		}

		String cityConfidence = correctionEntity.getCityConfidence();
		if (StringUtil.isNullOrEmpty(cityConfidence) || Integer.parseInt(cityConfidence) < minConfidence) {
			correctionEntity.setCity("");
			correctionEntity.setCityConfidence("");
			correctionEntity.setCityBoundary("");
		}

		String storeNrConfidence = correctionEntity.getStoreNumberConfidence();
		if (StringUtil.isNullOrEmpty(storeNrConfidence) || Integer.parseInt(storeNrConfidence) < minConfidence) {
			correctionEntity.setStoreNumber("");
			correctionEntity.setStoreNumberConfidence("");
			correctionEntity.setStoreNumberBoundary("");
		}

		String streetConfidence = correctionEntity.getStreetAddressConfidence();
		if (StringUtil.isNullOrEmpty(streetConfidence) || Integer.parseInt(streetConfidence) < minConfidence) {
			correctionEntity.setStreetAddress("");
			correctionEntity.setStreetAddressConfidence("");
			correctionEntity.setStreetAddressBoundary("");
		}

		String stateConfidence = correctionEntity.getStateConfidence();
		if (StringUtil.isNullOrEmpty(stateConfidence) || Integer.parseInt(stateConfidence) < minConfidence) {
			correctionEntity.setState("");
			correctionEntity.setStateConfidence("");
			correctionEntity.setStateBoundary("");
		}

		String houseNrConfidence = correctionEntity.getHouseNumberConfidence();
		if (StringUtil.isNullOrEmpty(houseNrConfidence) || Integer.parseInt(houseNrConfidence) < minHouseNrConfidence) {
			correctionEntity.setHouseNumber("");
			correctionEntity.setHouseNumberConfidence("");
			correctionEntity.setHouseNumberBoundary("");
		}
		
		cleanUncorrectedEntitiesBoundary(correctionEntity);
	}
	
	private void cleanUncorrectedEntitiesBoundary(EntitiesCorrectionEntity correctionEntity) {
		if (StringUtil.isNullOrEmpty(correctionEntity.getMerchantPhone())) {
			correctionEntity.setMerchantPhoneBoundary("");
		}

		if (StringUtil.isNullOrEmpty(correctionEntity.getPurchaseDate())) {
			correctionEntity.setPurchaseDateBoundary("");
		}

		if (StringUtil.isNullOrEmpty(correctionEntity.getPurchaseTime())) {
			correctionEntity.setPurchaseTimeBoundary("");
		}

		if (StringUtil.isNullOrEmpty(correctionEntity.getPaymentMethod())) {
			correctionEntity.setPaymentMethodBoundary("");
		}

		if (StringUtil.isNullOrEmpty(correctionEntity.getTotalPaid())) {
			correctionEntity.setTotalPaidBoundary("");
		}

		if (StringUtil.isNullOrEmpty(correctionEntity.getLoyalty())) {
			correctionEntity.setLoyaltyBoundary("");
		}

		if (StringUtil.isNullOrEmpty(correctionEntity.getOrderNumber())) {
			correctionEntity.setOrderNumberBoundary("");
		}

		if (StringUtil.isNullOrEmpty(correctionEntity.getServiceType())) {
			correctionEntity.setServiceTypeBoundary("");
		}
	}
	
	private void cleanUncorrectedRelationData(CorrectionRequest correctionRequest, int minConfidence) {
		correctionRequest.getManagement().getItemCorrect().entrySet().stream().forEach(item -> {
			String itemIdConfidence = item.getValue().getItemIdConfidence();
			if (StringUtil.isNullOrEmpty(itemIdConfidence) || Integer.parseInt(itemIdConfidence) < minConfidence) {
				item.getValue().setItemId("");
				item.getValue().setItemIdConfidence("");
			}

			String itemNameConfidence = item.getValue().getItemNameConfidence();
			if (StringUtil.isNullOrEmpty(itemNameConfidence) || Integer.parseInt(itemNameConfidence) < minConfidence) {
				item.getValue().setItemName("");
				item.getValue().setItemNameConfidence("");
			}

			String itemTypeConfidence = item.getValue().getItemTypeConfidence();
			if (StringUtil.isNullOrEmpty(itemTypeConfidence) || Integer.parseInt(itemTypeConfidence) < minConfidence) {
				item.getValue().setItemType("");
				item.getValue().setItemTypeConfidence("");
				item.getValue().setItemTypeId("");
			}

			String itemUnitConfidence = item.getValue().getItemUnitConfidence();
			if (StringUtil.isNullOrEmpty(itemUnitConfidence) || Integer.parseInt(itemUnitConfidence) < minConfidence) {
				item.getValue().setItemUnit("");
				item.getValue().setItemUnitConfidence("");
				item.getValue().setItemUnitId("");
			}
			
			if (StringUtil.isNullOrEmpty(item.getValue().getItemName()) && StringUtil.isNullOrEmpty(item.getValue().getItemId())) {
				item.getValue().setItemPrice("");
				item.getValue().setQuantity("");
				return;
			}
		});
		correctionRequest.getManagement().getItemCorrect().entrySet().removeIf(
				f -> StringUtils.isEmpty(f.getValue().getItemId()) && StringUtils.isEmpty(f.getValue().getItemName()));
	}
}
