package vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter;

public class FilterRule {

	private boolean merchant;

	private boolean storeNumber;

	private boolean houseNumber;

	private boolean streetAddress;

	private boolean zip;

	private boolean city;

	private boolean state;

	private boolean merchantPhone;

	private boolean purchaseDate;

	private boolean purchaseTime;

	private boolean totalPaid;

	private boolean paymentMethod;

	private boolean loyalty;

	private boolean orderNumber;

	private boolean serviceType;

	private boolean receiptType;
	
	private String rule;

	public boolean isMerchant() {
		return merchant;
	}

	public void setMerchant(boolean merchant) {
		this.merchant = merchant;
	}

	public boolean isStoreNumber() {
		return storeNumber;
	}

	public void setStoreNumber(boolean storeNumber) {
		this.storeNumber = storeNumber;
	}

	public boolean isHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(boolean houseNumber) {
		this.houseNumber = houseNumber;
	}

	public boolean isStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(boolean streetAddress) {
		this.streetAddress = streetAddress;
	}

	public boolean isZip() {
		return zip;
	}

	public void setZip(boolean zip) {
		this.zip = zip;
	}

	public boolean isCity() {
		return city;
	}

	public void setCity(boolean city) {
		this.city = city;
	}

	public boolean isState() {
		return state;
	}

	public void setState(boolean state) {
		this.state = state;
	}

	public boolean isMerchantPhone() {
		return merchantPhone;
	}

	public void setMerchantPhone(boolean merchantPhone) {
		this.merchantPhone = merchantPhone;
	}

	public boolean isPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(boolean purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public boolean isPurchaseTime() {
		return purchaseTime;
	}

	public void setPurchaseTime(boolean purchaseTime) {
		this.purchaseTime = purchaseTime;
	}

	public boolean isTotalPaid() {
		return totalPaid;
	}

	public void setTotalPaid(boolean totalPaid) {
		this.totalPaid = totalPaid;
	}

	public boolean isPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(boolean paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public boolean isLoyalty() {
		return loyalty;
	}

	public void setLoyalty(boolean loyalty) {
		this.loyalty = loyalty;
	}

	public boolean isOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(boolean orderNumber) {
		this.orderNumber = orderNumber;
	}

	public boolean isServiceType() {
		return serviceType;
	}

	public void setServiceType(boolean serviceType) {
		this.serviceType = serviceType;
	}

	public boolean isReceiptType() {
		return receiptType;
	}

	public void setReceiptType(boolean receiptType) {
		this.receiptType = receiptType;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}
}
