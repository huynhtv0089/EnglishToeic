package vn.sps.ss.extraction.watson.application.common.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import vn.sps.ss.extraction.watson.application.common.util.Constant.Field;
import vn.sps.ss.extraction.watson.domain.BoundaryResult;
import vn.sps.ss.extraction.watson.domain.HighlightRectangle;
import vn.sps.ss.extraction.watson.domain.TextAnnotation;
import vn.sps.ss.extraction.watson.domain.Vertice;

public final class HighlightUtil {
	
	private static int MAX_ANGLE_TRIP = 5;
	
	private static int MAX_ANGLE_ITEM = 3;

	public static List<List<Object>> combine(List<List<Object>> containers) {
		return combineInternal(0, containers);
	}

	private static List<List<Object>> combineInternal(int currentIndex, List<List<Object>> containers) {
		if (currentIndex == containers.size()) {
			// Skip the items for the last container
			List<List<Object>> combinations = new ArrayList<>();
			combinations.add(Collections.emptyList());
			return combinations;
		}

		List<List<Object>> combinations = new ArrayList<>();
		List<Object> containerItemList = containers.get(currentIndex);
		// Get combination from next index
		List<List<Object>> suffixList = combineInternal(currentIndex + 1, containers);

		int size = containerItemList.size();
		for (int i = 0; i < size; i++) {
			Object containerItem = containerItemList.get(i);
			if (suffixList != null) {
				for (List<Object> suffix : suffixList) {
					List<Object> nextCombination = new ArrayList<>();
					nextCombination.add(containerItem);
					nextCombination.addAll(suffix);
					combinations.add(nextCombination);
				}
			}
		}
		return combinations;
	}

	public static Vertice newVertice(Vertice original, Vertice target, double angle, double currentAngle) {
		// Find distance
		double distance = Math.hypot(original.getX() - target.getX(), original.getY() - target.getY());

		// find next point
		double ab = Math.cos(Math.toRadians(angle)) * distance;

		Vertice newVertice = new Vertice();
		newVertice.setX(original.getX() + (int) (Math.cos(Math.toRadians(currentAngle)) * ab));
		newVertice.setY(original.getY() + (int) (Math.sin(Math.toRadians(currentAngle)) * ab));
		return newVertice;
	}

	public static double getAngle(Vertice original, Vertice target) {
		return Math.toDegrees(Math.atan2(target.getY() - original.getY(), target.getX() - original.getX()));
	}
	
	public static double getAbsAngle(Vertice original, Vertice target) {
		return Math.toDegrees(Math.atan2(Math.abs(target.getY() - original.getY()), Math.abs(target.getX() - original.getX())));
	}

	public static double area(List<Vertice> vertices) {
		double sum = 0;
		for (int i = 0; i < vertices.size(); i++) {
			if (i == 0) {
				sum += vertices.get(i).getX() * (vertices.get(i + 1).getY() - vertices.get(vertices.size() - 1).getY());
			} else if (i == vertices.size() - 1) {
				sum += vertices.get(i).getX() * (vertices.get(0).getY() - vertices.get(i - 1).getY());
			} else {
				sum += vertices.get(i).getX() * (vertices.get(i + 1).getY() - vertices.get(i - 1).getY());
			}
		}

		return 0.5 * Math.abs(sum);
	}

	public static List<BoundaryResult> getBoundary(String field, List<TextAnnotation> textAnnotations) {
		 if (StringUtils.isEmpty(field) || CollectionUtils.isEmpty(textAnnotations)) {
			 return new ArrayList<>();
		 }
		 return getBoundary(new ArrayList<>(Arrays.asList(field.split("\\s+|(?=\\p{Punct})|(?<=\\p{Punct})"))), textAnnotations);
	}
	
	public static List<BoundaryResult> getBoundary(List<String> lstItemName, List<TextAnnotation> textAnnotations) {

		// If cannot parse to TextAnnotation then return.
		if (!(textAnnotations.get(0) instanceof TextAnnotation)) {
			return new ArrayList<>();
		}
		
		lstItemName.removeIf(t -> StringUtils.isEmpty(t));
		List<List<Object>> listField = new ArrayList<>();
		for (String item : lstItemName) {
			List<Object> list = new ArrayList<>();
			for (TextAnnotation textAnnotation : textAnnotations) {
				if (item.equals(textAnnotation.getDescription())) {
					list.add(textAnnotation);
				}
			}
			listField.add(list);
		}
		List<BoundaryResult> result = new ArrayList<>();

		List<List<Object>> list = HighlightUtil.combine(listField);
		boolean isFound = false;
		for (int i = 0; i < list.size(); i++) {
			Vertice verticeA = new Vertice();
			Vertice verticeB = new Vertice();
			Vertice verticeC = new Vertice();
			Vertice verticeD = new Vertice();
			List<HighlightRectangle> elements = new ArrayList<>();
			double currentAngle = 0;
			for (int j = 0; j < list.get(i).size(); j++) {
				if (j == 0) {
					TextAnnotation firstText = (TextAnnotation) list.get(i).get(j);
					verticeA = new Vertice(firstText.getBoundingPoly().getVertices().get(0));
					verticeB = new Vertice(firstText.getBoundingPoly().getVertices().get(1));
					verticeC = new Vertice(firstText.getBoundingPoly().getVertices().get(2));
					verticeD = new Vertice(firstText.getBoundingPoly().getVertices().get(3));

					currentAngle = HighlightUtil.getAngle(verticeA, verticeB);
					elements.add(new HighlightRectangle(firstText.getBoundingPoly().getVertices()));
					isFound = true;
					continue;
				}
				List<Vertice> subVer = ((TextAnnotation) list.get(i).get(j)).getBoundingPoly().getVertices();
				// if angle > MAX_ANGLE_TRIP degrees then not allow
				double topAngle = HighlightUtil.getAngle(verticeA, subVer.get(1));
				double botAngle = HighlightUtil.getAngle(verticeD, subVer.get(2));
				if (Math.abs(currentAngle - topAngle) <= MAX_ANGLE_TRIP || Math.abs(currentAngle - botAngle) <= MAX_ANGLE_TRIP) {
					Vertice verticeNewB = HighlightUtil.newVertice(verticeA, subVer.get(1),
							Math.abs(currentAngle - topAngle), currentAngle);
					Vertice verticeNewC = HighlightUtil.newVertice(verticeD, subVer.get(2),
							Math.abs(currentAngle - botAngle), currentAngle);

					List<Vertice> tmp = new ArrayList<>();
					tmp.add(verticeA);
					tmp.add(verticeNewB);
					tmp.add(verticeNewC);
					tmp.add(verticeD);
					verticeB = new Vertice(verticeNewB);
					verticeC = new Vertice(verticeNewC);
					elements.add(new HighlightRectangle(subVer));
					isFound = true;
				} else {
					isFound = false;
					break;
				}
			}

			if (isFound) {
				List<Vertice> listTmp = new ArrayList<>();
				listTmp.add(verticeA);
				listTmp.add(verticeB);
				listTmp.add(verticeC);
				listTmp.add(verticeD);
				BoundaryResult boundaryResult = new BoundaryResult();
				boundaryResult.setFinalRectangle(new HighlightRectangle(listTmp));
				boundaryResult.setElements(elements);
				result.add(boundaryResult);
				isFound = false;
			}

		}
		return result;
	}

	public static void duplicate(List<BoundaryResult> listBoundary) {

		List<BoundaryResult> copy = new ArrayList<>();
		copy.addAll(listBoundary);
		Iterator<BoundaryResult> it = listBoundary.iterator();
		while (it.hasNext()) {
			BoundaryResult f = it.next();
			if (shouldGetRemovedIfDuplicate(f, copy)) {
				it.remove();
			}
		}
		HashSet<BoundaryResult> tmp = new HashSet<>();
		listBoundary.removeIf(e -> !tmp.add(e));
	}
	
	private static boolean shouldGetRemovedIfDuplicate(BoundaryResult f, List<BoundaryResult> destinationList) {
		for (BoundaryResult br : destinationList) {
			// If target is greater then remove and kill check for vertices
			if (f.isDuplicate(br)
					&& (area(f.getFinalRectangle().getVertices()) > area(br.getFinalRectangle().getVertices()))) {
				return true;
			}
		}
		return false;
	}
	
	private static boolean shouldGetRemovedIfOverload(String key, BoundaryResult f,
			Map<String, List<BoundaryResult>> destination) {
		
		for (Entry<String, List<BoundaryResult>> entry : destination.entrySet()) {
			if (CollectionUtils.isEmpty(entry.getValue()))
				continue;
			if (entry.getKey().equals(key))
				continue;
			for (BoundaryResult brCompare : entry.getValue()) {
				for (HighlightRectangle hrCompare : brCompare.getElements()) {
					if (f.getFinalRectangle().equals(hrCompare)) {
						return true;
					}
				}
			}
		}
		return false;
	}

	public static void overload(String key, List<BoundaryResult> neededCompare,
			Map<String, List<BoundaryResult>> result) {
		if (CollectionUtils.isEmpty(neededCompare))
			return;

		Iterator<BoundaryResult> it = neededCompare.iterator();
		while (it.hasNext()) {
			BoundaryResult brNeeded = it.next();
			if (shouldGetRemovedIfOverload(key, brNeeded, result)) {
				it.remove();
			}
		}
	}
	
	public static Map<String, List<BoundaryResult>> checkItemLine(Map<String, List<BoundaryResult>> itemLine) {
		
		//Clear all boundary if does not have item name and item id
		if (CollectionUtils.isEmpty(itemLine.get(Field.ITEM_NAME))
				&& CollectionUtils.isEmpty(itemLine.get(Field.ITEM_ID))) {
			return new HashMap<>();
		}
		
		// If just have one boundary for item name.
		// use this to find boundary for remaining fields
		if (!CollectionUtils.isEmpty(itemLine.get(Field.ITEM_NAME)) && itemLine.get(Field.ITEM_NAME).size() == 1) {
			return processCleanBoundary(itemLine, Field.ITEM_NAME);
		}
		
		//Check multi name
		// Id
		if (!CollectionUtils.isEmpty(itemLine.get(Field.ITEM_ID)) && itemLine.get(Field.ITEM_ID).size() == 1) {
			return processCleanBoundary(itemLine, Field.ITEM_ID);
		}
		
		// price
		if (!CollectionUtils.isEmpty(itemLine.get(Field.ITEM_PRICE)) && itemLine.get(Field.ITEM_PRICE).size() == 1) {
			return processCleanBoundary(itemLine, Field.ITEM_PRICE);
		}
		
		// if have all many
		if (!CollectionUtils.isEmpty(itemLine.get(Field.ITEM_NAME)))
			return processCleanBoundary(itemLine, Field.ITEM_NAME);
		if (!CollectionUtils.isEmpty(itemLine.get(Field.ITEM_ID)))
			return processCleanBoundary(itemLine, Field.ITEM_ID);
		if (!CollectionUtils.isEmpty(itemLine.get(Field.ITEM_PRICE)))
			return processCleanBoundary(itemLine, Field.ITEM_PRICE);
		
		return new HashMap<>();
	}
	
	public static void removeIfFound(Map<String, List<BoundaryResult>> itemLine,
			Map<String, List<BoundaryResult>> readyBoundary) {
		
		for (Map.Entry<String, List<BoundaryResult>> itemField : itemLine.entrySet()) {
			if (!CollectionUtils.isEmpty(readyBoundary.get(itemField.getKey()))) {
				Iterator<BoundaryResult> it = itemField.getValue().iterator();
				while (it.hasNext()) {
					BoundaryResult f = it.next();
					if (readyBoundary.get(itemField.getKey()).stream().anyMatch(found -> found.getFinalRectangle().equals(f.getFinalRectangle()))) {
						it.remove();
					}
				}
			}
		}
		
	}

	public static Map<String, List<BoundaryResult>> processCleanBoundary(Map<String, List<BoundaryResult>> itemLine, String field) {
		List<Vertice> verItem = itemLine.get(field).get(0).getFinalRectangle().getVertices();
		Map<String, List<BoundaryResult>> newLine = new HashMap<>();
		double currentAngle = HighlightUtil.getAbsAngle(verItem.get(0), verItem.get(1));
		itemLine.entrySet().stream().filter(f -> !f.getKey().equals(field) && !f.getKey().equals(Field.SUB_ITEM)).forEach(itemElement -> {
			if (!CollectionUtils.isEmpty(itemElement.getValue())) {
				
				// Check item same line
				int sameLine = checkItemSameLine(verItem, itemElement.getValue(), currentAngle);
				if (sameLine == -1) {
					int nearLine = checkItemNearLine(verItem, itemElement.getValue(), currentAngle);
					if (nearLine == -1) {
						newLine.put(itemElement.getKey(), new ArrayList<>());
					} else {
						setNewValue(itemElement.getValue().get(nearLine), itemElement.getKey(), newLine);
					}
				} else {
					setNewValue(itemElement.getValue().get(sameLine), itemElement.getKey(), newLine);
				}
			}
		});
		
		// store this field
		setNewValue(itemLine.get(field).get(0), field, newLine);
		return newLine;
	}
	
	private static void setNewValue(BoundaryResult boundaryResult, String field, Map<String, List<BoundaryResult>> newLine) {
		BoundaryResult tmp = new BoundaryResult(boundaryResult);
		List<BoundaryResult> neededReplaceVertice = new ArrayList<>();
		neededReplaceVertice.add(tmp);
		newLine.put(field, neededReplaceVertice);
	}
	
	public static int checkItemSameLine(List<Vertice> itemOriginalVertice,
			List<BoundaryResult> neededCheckVertice, double currentAngle) {
		double minAngle = Integer.MAX_VALUE;
		int minIndex = -1;
		for (int i = 0; i < neededCheckVertice.size(); i++) {
			List<Vertice> verItemId = neededCheckVertice.get(i).getFinalRectangle().getVertices();
			double topAngle = HighlightUtil.getAbsAngle(itemOriginalVertice.get(0), verItemId.get(1));
			if (Math.abs(currentAngle - topAngle) <= MAX_ANGLE_ITEM && Math.abs(topAngle) < Math.abs(minAngle)) {
				minAngle = topAngle;
				minIndex = i;
			}
		}
		return minIndex;
	}
	
	public static int checkItemNearLine(List<Vertice> itemOriginalVertice,
			List<BoundaryResult> neededCheckVertice, double currentAngle) {
		double minDistance = Integer.MAX_VALUE;
		int minIndex = -1;
		int middleX = (itemOriginalVertice.get(0).getX() + itemOriginalVertice.get(3).getX()) / 2;
		int middleY = (itemOriginalVertice.get(0).getY() + itemOriginalVertice.get(3).getY()) / 2;
		for (int i = 0; i < neededCheckVertice.size(); i++) {
			
			List<Vertice> verItemId = neededCheckVertice.get(i).getFinalRectangle().getVertices();
			int newMiddleX = (verItemId.get(0).getX() + verItemId.get(3).getX()) / 2;
			int newMiddleY = (verItemId.get(0).getY() + verItemId.get(3).getY()) / 2;
			double distance = Math.hypot(middleX - newMiddleX, middleY - newMiddleY);
			
			if (distance < minDistance) {
				minDistance = distance;
				minIndex = i;
			}
		}
		return minIndex;
	}
}
