/*
 * Class: ElasticsearchConfiguration
 *
 * Created on Oct 17, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.configuration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "spring.data.elasticsearch")
public class ElasticsearchConfiguration {
    /**
     * Elasticsearch cluster name.
     */
    private String clusterName = "elasticsearch";

    /**
     * Comma-separated list of cluster node addresses. If not specified, starts a client
     * node.
     */
    private String clusterNodes;

    /**
     * Additional properties used to configure the client.
     */
    private Map<String, String> properties = new HashMap<String, String>();

    /**
     * Indexs configuration.
     */
    private Map<String, Index> indexs = new HashMap<>();

    /**
     * Scripts configuration.
     */
    private Map<String, String> scripts = new HashMap<>();

    /**
     * Langs configuration.
     */
    private Map<String, String> langs = new HashMap<>();

    /**
     * Params configuration.
     */
    private Map<String, String> params = new HashMap<>();
    
    public ElasticsearchConfiguration() {
        // TODO Auto-generated constructor stub
    }
    
    public String getClusterName() {
        return this.clusterName;
    }

    public void setClusterName(String clusterName) {
        this.clusterName = clusterName;
    }

    protected String getClusterNodes() {
        return this.clusterNodes;
    }

    public void setClusterNodes(String clusterNodes) {
        this.clusterNodes = clusterNodes;
    }

    public Map<String, String> getProperties() {
        return this.properties;
    }

    protected void setProperties(Map<String, String> properties) {
        this.properties = properties;
    }

    public Map<String, Index> getIndexs() {
        return indexs;
    }

    protected void setIndexs(Map<String, Index> indexs) {
        this.indexs = indexs;
    }

    public Map<String, String> getScripts() {
        return scripts;
    }

    protected void setScripts(Map<String, String> scripts) {
        this.scripts = scripts;
    }

    public Map<String, String> getLangs() {
        return langs;
    }

    protected void setLangs(Map<String, String> langs) {
        this.langs = langs;
    }

    public Map<String, String> getParams() {
        return params;
    }

    void setParams(Map<String, String> params) {
        this.params = params;
    }

    public Index getIndex(final String indexKey) {
        return this.indexs.get(indexKey);
    }

    public String getIndexKeyByName(final String indexName) {
        List<String> keys = this.indexs.entrySet().stream()
            .filter(e -> indexName.equalsIgnoreCase(e.getValue().getName()))
            .map(e -> e.getKey()).collect(Collectors.toList());

        if (keys.size() > 0) {
            return keys.get(0);
        }
        return "";
    }
    
    public String getScript(final String key) {
        return this.scripts.get(key);
    }
    
    public String getLang(final String key) {
        return this.langs.get(key);
    }
    
    public String getParam(final String key) {
        return this.params.get(key);
    }


    public static class Index {

        private String name;

        private Map<String, String> types = new HashMap<>();

        private Map<String, String> fields = new HashMap<>();

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Map<String, String> getTypes() {
            return types;
        }

        public void setTypes(Map<String, String> types) {
            this.types = types;
        }

        public Map<String, String> getFields() {
            return fields;
        }

        public void setFields(Map<String, String> fields) {
            this.fields = fields;
        }

    }

    public static class Script {

        private String id;

        private String lang;

        private List<String> params = new ArrayList<>();

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getLang() {
            return lang;
        }

        public void setLang(String lang) {
            this.lang = lang;
        }

        public List<String> getParams() {
            return params;
        }

        public void setParams(List<String> params) {
            this.params = params;
        }
    }
}
