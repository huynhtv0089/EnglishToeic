package vn.sps.ss.extraction.watson.application.service.receipt;

import java.util.List;
import java.util.Map;

import vn.sps.ss.extraction.model.ItemExtract;
import vn.sps.ss.extraction.model.ReceiptRequest;
import vn.sps.ss.extraction.model.extract.Trip;
import vn.sps.ss.extraction.model.item.Item;

public interface ReceiptService {

    Map<String, List<ItemExtract>> byId(String requestId);
    
    Trip findById(String requestId);
    
    Item findItemById(ReceiptRequest request);
}
