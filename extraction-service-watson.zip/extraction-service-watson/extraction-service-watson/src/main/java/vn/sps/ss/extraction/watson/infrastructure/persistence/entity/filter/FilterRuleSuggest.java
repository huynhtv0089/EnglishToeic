package vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class FilterRuleSuggest implements Serializable {

    private static final long serialVersionUID = 5544151276467447682L;

    @SerializedName(value = "input")
    private String input;

    @SerializedName(value = "output")
    private String output;

    @SerializedName(value = "weight")
    private String weight;

    @SerializedName(value = "payload")
    private Payload payload;

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public Payload getPayload() {
		return payload;
	}

	public void setPayload(Payload payload) {
		this.payload = payload;
	}
}
