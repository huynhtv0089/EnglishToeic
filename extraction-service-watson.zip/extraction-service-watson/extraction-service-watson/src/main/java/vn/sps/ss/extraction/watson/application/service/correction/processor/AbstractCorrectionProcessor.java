/*
 * Class: AbstractCorrectionHanlder
 *
 * Created on Oct 16, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.service.correction.processor;

import vn.sps.ss.extraction.watson.domain.CorrectionContext;

/**
 * The Class AbstractCorrectionProcessor.
 */
public abstract class AbstractCorrectionProcessor {

    /** The name. */
    protected final String name;

    /** The next handler. */
    private final CorrectionProcessor nextHandler;

    /**
     * Instantiates a new abstract correction processor.
     *
     * @param name the name
     * @param nextHandler the next handler
     */
    public AbstractCorrectionProcessor(final String name,
            final CorrectionProcessor nextHandler) {
        this.name = name;
        this.nextHandler = nextHandler;
    }

    /**
     * Filter.
     *
     * @param context the context
     */
    protected abstract void filter(CorrectionContext context);

    /**
     * Handle.
     *
     * @param context the context
     */
    public void handle(final CorrectionContext context) {
        this.filter(context);
        this.process(context);
        if (this.nextHandler != null) {
            this.nextHandler.handle(context);
        }
    }

    /**
     * Process.
     *
     * @param context the context
     */
    protected abstract void process(CorrectionContext context);
}