package vn.sps.ss.extraction.watson.domain.http;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import vn.sps.ss.extraction.watson.domain.GoogleResponse;

@JsonIgnoreProperties(ignoreUnknown=true)
public class GoogleMessage implements Serializable {
	
	private static final long serialVersionUID = -2644702664465327466L;
	
	@JsonProperty("responses")
	private List<GoogleResponse> responses;

	public List<GoogleResponse> getResponses() {
		return responses;
	}

	public void setResponses(List<GoogleResponse> responses) {
		this.responses = responses;
	}
	
	
}
