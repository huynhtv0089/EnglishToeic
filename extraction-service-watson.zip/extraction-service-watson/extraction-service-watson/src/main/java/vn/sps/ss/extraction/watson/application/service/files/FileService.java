package vn.sps.ss.extraction.watson.application.service.files;

public interface FileService {
    byte[] get(String file);
}
