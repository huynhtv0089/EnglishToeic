package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemTypeEntity implements Serializable {

	private static final long serialVersionUID = 7401497516557898315L;

	@JsonProperty(value = "receiptitem_type_id")
    private String receiptItemTypeId;
    
    @JsonProperty(value = "receiptitem_key_desc")
    private String receiptItemKeyDesc;
    
    @JsonProperty(value = "receiptitem_type_desc")
    private String receiptItemTypeDesc;

	public String getReceiptItemTypeId() {
		return receiptItemTypeId;
	}

	public void setReceiptItemTypeId(String receiptItemTypeId) {
		this.receiptItemTypeId = receiptItemTypeId;
	}

	public String getReceiptItemKeyDesc() {
		return receiptItemKeyDesc;
	}

	public void setReceiptItemKeyDesc(String receiptItemKeyDesc) {
		this.receiptItemKeyDesc = receiptItemKeyDesc;
	}

	public String getReceiptItemTypeDesc() {
		return receiptItemTypeDesc;
	}

	public void setReceiptItemTypeDesc(String receiptItemTypeDesc) {
		this.receiptItemTypeDesc = receiptItemTypeDesc;
	}
}
