package vn.sps.ss.extraction.watson.infrastructure.configuration;

import java.util.ArrayList;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix="interceptors.matrix")
public class InterceptorConfiguration {
	
	private ArrayList<String> correctionConfig;
	
	private ArrayList<String> extractionConfig;

	public ArrayList<String> getCorrectionConfig() {
		return correctionConfig;
	}

	public void setCorrectionConfig(ArrayList<String> correctionConfig) {
		this.correctionConfig = correctionConfig;
	}

	public ArrayList<String> getExtractionConfig() {
		return extractionConfig;
	}

	public void setExtractionConfig(ArrayList<String> extractionConfig) {
		this.extractionConfig = extractionConfig;
	}
	
}
