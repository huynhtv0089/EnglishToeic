/*
 * Class: StringUtil
 *
 * Created on Oct 17, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.common.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * The Class StringUtil.
 */
public final class StringUtil {

    /**
     * Instantiates a new string util.
     */
    private StringUtil() {
    }

    /**
     * Checks if is null or empty.
     *
     * @param value the value
     * @return true, if is null or empty
     */
    public static boolean isNullOrEmpty(String value) {
        return value == null || value.isEmpty();
    }

    public static String format(final float number, final String format) {
        return String.format(format, number);
    }

    public static String format(final Date date, final String format) {
        SimpleDateFormat simpleFormat = new SimpleDateFormat(format);
        return simpleFormat.format(date);
    }
    
    public static String formatMerchant(String quantity, String parentMerchant, List<String> subMerchants) {
    	StringBuilder sb = new StringBuilder();
    	if (!isNullOrEmpty(quantity)) {
    		sb.append(quantity);
    		sb.append(" ");
    	}
    	sb.append(parentMerchant);
    	for (int i = 0; i < subMerchants.size() - 1; i++) {
    		if (!isNullOrEmpty(subMerchants.get(i))) {
    			sb.append(", ");
    			sb.append(subMerchants.get(i));
    		}
    	}
    	
    	if (!isNullOrEmpty(subMerchants.get(subMerchants.size() - 1))) {
    		sb.append(", ");
        	sb.append(subMerchants.get(subMerchants.size() - 1));
    	}
    	return sb.toString();
    }
}
