/*
 * Class: OCRWorker
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.business.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import vn.sps.ss.extraction.watson.application.business.OCRHandler;
import vn.sps.ss.extraction.watson.application.business.WatsonExtractionHandler;
import vn.sps.ss.extraction.watson.application.common.util.FileUtil;
import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.application.service.files.FileService;
import vn.sps.ss.extraction.watson.application.service.ocr.OCRService;
import vn.sps.ss.extraction.watson.domain.OCRRequest;
import vn.sps.ss.extraction.watson.domain.OCRResponse;
import vn.sps.ss.extraction.watson.domain.TextAnnotation;
import vn.sps.ss.extraction.watson.domain.WatsonRequest;
import vn.sps.ss.extraction.watson.infrastructure.configuration.OcrProperties;
import vn.sps.ss.extraction.watson.infrastructure.ifa.impl.AbstractAsyncWorker;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RawDataEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa.ManagementRepository;

/**
 * The Class OCRHandlerImpl.
 */
@Component
public class OCRHandlerImpl extends AbstractAsyncWorker<ProcessingContext>
        implements OCRHandler {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory
        .getLogger(OCRHandlerImpl.class);

    /** The file service. */
    @Autowired
    private FileService fileService;

    /** The management repository. */
    @Autowired
    private ManagementRepository managementRepository;
    
    /** The mapper. */
    @Autowired
    private ObjectMapper mapper;

    /** The ocrservice. */
    @Autowired
    private OCRService ocrservice;

    /** The ocr task executor. */
    @Autowired
    private AsyncTaskExecutor ocrTaskExecutor;

    /** The orc properites. */
    @Autowired
    private OcrProperties orcProperites;

    /** The watson. */
    @Autowired
    private WatsonExtractionHandler watson;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.ss.extraction.watson.infrastructure.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected AsyncTaskExecutor getExecutor() {
        return this.ocrTaskExecutor;
    }

    /**
     * {@inheritDoc}
     *
     * @see AbstractAsyncWorker#handle(Object)
     */
    @Override
    protected void handle(final ProcessingContext context) {
        try {
        	boolean isNotExist = this.managementRepository.findByRequestId(context.getId()).isEmpty();
        	if (isNotExist) {
        		 final long startTime = WallClock.milli();

                 final String requestId = context.getId();
                 LOG.info("Begin process OCR for request {} at {}. ", requestId, WallClock.milli());

                 final String filePath = context.getRequest().getFilePath();
                 
                 LOG.info("Begin get file: {} of request {}.", filePath, requestId);
                 final long beginGetFile = WallClock.milli();
                 final byte[] fileData = this.fileService.get(filePath);
                 LOG.info(
                     "End get file: {} of request {}. Took {} milis.",
                     filePath,
                     requestId,
                     WallClock.milli() - beginGetFile);

                 LOG.info("Begin do OCR request {}.", requestId);
                 final long beginDoOcr = WallClock.milli();
                 final OCRRequest request = new OCRRequest();
                 {
                     request.setInput(fileData);
                     request.setFileType(FileUtil.getType(fileData));
                 }
                 final OCRResponse result = this.ocrservice.doOCR(request);

                 final long endDoOcr = WallClock.milli();

                 
                 LOG.info(
                     "End do OCR request {}. Took {} milis.",
                     requestId,
                     endDoOcr - beginDoOcr);

                 final ManagementEntity management = new ManagementEntity();
                 {
                     management.setRequestId(requestId);
                     management.setImagePath(filePath);
                     management.setBeginOcr(beginDoOcr);
                     management.setEndOcr(endDoOcr);
                     management.setReceiveTime(context.getReceiveTime());
                 }

                 final Map<String, Object> ret = result.getResult();
                 if ((ret != null) && !ret.isEmpty()) {
                     LOG.info(
                         "Begin parse data and store DB for request {}.",
                         requestId);

                     String textData = (String) ret.get("result");

                     //PostgreSQL doesn't support storing NULL (\0x00) characters in text fields
                     if (textData != null) {
                         textData = textData.replaceAll("\u0000","");
                     }
                     management.setTextAnnotations((List<TextAnnotation>) ret.get("chars"));
                     final String metaData = this.mapper
                         .writeValueAsString(ret.get("chars"));
                     {
                         management.setRaw(new RawDataEntity(management));
                         management.getRaw().setRawTextOrc(textData);
                         management.getRaw().setRawMetaOrc(metaData);
                         context.setManagementEntity(management);
                     }
                     this.managementRepository.save(management);

                     LOG.info(
                         "End Store DB for request {}. Took {} milis.",
                         requestId,
                         WallClock.milli() - endDoOcr);

                     //Replace all some text
                     for (int i = 0; i < this.orcProperites.getTransform()
                         .getReplaceFrom().size(); i++) {
                     	if (textData != null) {
     	                    textData = textData.replaceAll(
     	                        this.orcProperites.getTransform().getReplaceFrom()
     	                            .get(i),
     	                        this.orcProperites.getTransform().getReplaceTo()
     	                            .get(i));
                     	}
                     }

                     if (!StringUtils.isEmpty(textData)) {
                         final WatsonRequest watsonRequest = new WatsonRequest();
                         {
                             watsonRequest.setRequestId(requestId);
                             watsonRequest.setContent(textData);
                         }
                         context.setWatsonRequest(watsonRequest);

                         LOG.info(
                             "Forward request {} to Watson Extraction at {}.",
                             requestId, WallClock.milli());
                         this.watson.submitItem(requestId, context);
                     }
                     else {
                         LOG.info("Result OCR of request {} is empty.", requestId);
                     }
                 }
                 else {
                     LOG.warn(
                         "Result OCR of receipt {} is null or empty.",
                         requestId);
                     this.managementRepository.save(management);
                 }

                 LOG.info(
                     "End process OCR for request {}. Took {} milis.",
                     requestId,
                     WallClock.milli() - startTime);
			} else {
				LOG.info("Receipt {} has been rejected because it existed!", context.getId());
			}
           
        }
        catch (final Exception e) {
            LOG.info(
                "Failed to process OCR with request {}. Detail: ",
                context.getRequest().getId(),
                e);
        }
    }

}
