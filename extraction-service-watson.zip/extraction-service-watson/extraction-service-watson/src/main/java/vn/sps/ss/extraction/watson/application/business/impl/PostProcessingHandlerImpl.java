/*
 * Class: OCRWorker
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.business.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.stereotype.Component;

import vn.sps.ss.extraction.watson.application.business.PostProcessingHandler;
import vn.sps.ss.extraction.watson.infrastructure.ifa.impl.AbstractAsyncWorker;

/**
 * The Class PostProcessingHandlerImpl.
 */
@Component
public class PostProcessingHandlerImpl
        extends AbstractAsyncWorker<ProcessingContext>
        implements PostProcessingHandler {

    /** The postprocessing task executor. */
    @Autowired
    private AsyncTaskExecutor postprocessingTaskExecutor;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.ss.extraction.watson.infrastructure.ifa.impl.AbstractAsyncWorker#getExecutor()
     */
    @Override
    protected AsyncTaskExecutor getExecutor() {
        return this.postprocessingTaskExecutor;
    }

    @Override
    protected void handle(final ProcessingContext obj) {
        // TODO Auto-generated method stub

    }

}
