package vn.sps.ss.extraction.watson.application.service.ocr.impl;

import vn.sps.ss.extraction.watson.domain.OCRRequest;
import vn.sps.ss.extraction.watson.domain.OCRResponse;

interface ImageService {
	
	OCRResponse doOCR(OCRRequest request);
}
