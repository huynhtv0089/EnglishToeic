package vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
@Repository
@Transactional
public interface CorrectionRepository extends CrudRepository<EntitiesCorrectionEntity, Long> {
	
	@Query("SELECT c FROM EntitiesCorrectionEntity c WHERE c.requestId = :requestId")
	public List<EntitiesCorrectionEntity> findCorrectionByRequestId(@Param("requestId") String requestId);
}
