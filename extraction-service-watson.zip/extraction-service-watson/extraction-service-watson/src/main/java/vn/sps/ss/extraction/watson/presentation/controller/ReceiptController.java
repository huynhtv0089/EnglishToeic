package vn.sps.ss.extraction.watson.presentation.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import vn.sps.ss.extraction.model.ReceiptRequest;
import vn.sps.ss.extraction.model.extract.Trip;
import vn.sps.ss.extraction.model.item.Item;
import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.application.service.receipt.impl.ReceiptServiceImpl;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;

@RestController
public class ReceiptController {
	
	private static final Logger LOG = LoggerFactory.getLogger(ReceiptController.class);
	
    @Autowired
    private ReceiptServiceImpl receiptService;
    
    @PostMapping(value = "/receipt/trip")
    public ResponseEntity<Trip> loadTrip(@RequestBody ReceiptRequest request) {
    	Trip body = null;
    	final long beginProcess = WallClock.milli();
    	LOG.info("Begin return trip part of card {} ", request.getRequestId());
    	
    	final long beginQuery = WallClock.milli();
		body = this.receiptService.findById(request.getRequestId());
		LOG.info("Fetching card {} from database has taken {} milisecond", request.getRequestId(), WallClock.milli() - beginQuery);
    	
    	if (body != null) {
    		LOG.info("Processing return trip part of card {} has taken {} milisecond", request.getRequestId(), WallClock.milli() - beginProcess);
    		return new ResponseEntity<>(body, HttpStatus.OK);
    	} else {
    		LOG.info("Processing return trip part of card {} has taken {} milisecond", request.getRequestId(), WallClock.milli() - beginProcess);
    		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    	}
    }
    
    @PostMapping(value = "/receipt/item")
    public ResponseEntity<Item> loadItem(@RequestBody ReceiptRequest request) {
    	Item body = null;
    	final long beginProcess = WallClock.milli();
    	LOG.info("Begin return item part of card {} ", request.getRequestId());
    	
    	final long beginQuery = WallClock.milli();
		body = this.receiptService.findItemById(request);
		LOG.info("Fetching card {} from database has taken {} milisecond", request.getRequestId(), WallClock.milli() - beginQuery);
    	
    	if (body != null) {
    		LOG.info("Processing return item part of card {} has taken {} milisecond", request.getRequestId(), WallClock.milli() - beginProcess);
    		return new ResponseEntity<>(body, HttpStatus.OK);
    	} else {
    		LOG.info("Processing return item part of card {} has taken {} milisecond", request.getRequestId(), WallClock.milli() - beginProcess);
    		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    	}
    }
    
    @PostMapping(value = "/list/receipt/{requestId}")
    public ResponseEntity<List<EntitiesCorrectionEntity>> list(@PathVariable("requestId") String requestId) {
    	return new ResponseEntity<>(this.receiptService.list(requestId), HttpStatus.OK);
    }
}
