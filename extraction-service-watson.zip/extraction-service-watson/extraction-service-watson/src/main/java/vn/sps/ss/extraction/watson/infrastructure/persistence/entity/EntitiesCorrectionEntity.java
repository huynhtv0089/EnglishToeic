package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "entities_correction", indexes = { @Index(name = "index_entities_correction", columnList = "requestId") })
public class EntitiesCorrectionEntity implements Serializable {

	private static final long serialVersionUID = -6352797773115994427L;

	@Id
	private Long id;

	@Column(length = 30, nullable = true)
	private String requestId;

	@Column(length = 255, nullable = true)
	private String merchant;

	@Column(length = 10, nullable = true)
	private String merchantConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String merchantBoundary;

	@Column(length = 255, nullable = true)
	private String storeNumber;

	@Column(length = 10, nullable = true)
	private String storeNumberConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String storeNumberBoundary;

	@Column(length = 255, nullable = true)
	private String houseNumber;

	@Column(length = 10, nullable = true)
	private String houseNumberConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String houseNumberBoundary;

	@Column(length = 255, nullable = true)
	private String streetAddress;

	@Column(length = 10, nullable = true)
	private String streetAddressConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String streetAddressBoundary;

	@Column(length = 255, nullable = true)
	private String zip;

	@Column(length = 10, nullable = true)
	private String zipConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String zipBoundary;

	@Column(length = 255, nullable = true)
	private String city;

	@Column(length = 10, nullable = true)
	private String cityConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String cityBoundary;

	@Column(length = 255, nullable = true)
	private String state;

	@Column(length = 10, nullable = true)
	private String stateConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String stateBoundary;

	@Column(length = 255, nullable = true)
	private String merchantPhone;

	@Column(length = 10, nullable = true)
	private String merchantPhoneConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String merchantPhoneBoundary;

	@Column(length = 255, nullable = true)
	private String purchaseDate;

	@Column(length = 10, nullable = true)
	private String purchaseDateConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String purchaseDateBoundary;

	@Column(length = 255, nullable = true)
	private String purchaseTime;

	@Column(length = 10, nullable = true)
	private String purchaseTimeConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String purchaseTimeBoundary;

	@Column(length = 255, nullable = true)
	private String totalPaid;

	@Column(length = 10, nullable = true)
	private String totalPaidConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String totalPaidBoundary;

	@Column(length = 255, nullable = true)
	private String paymentMethod;

	@Column(length = 10, nullable = true)
	private String paymentMethodConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String paymentMethodBoundary;

	@Column(length = 255, nullable = true)
	private String loyalty;

	@Column(length = 10, nullable = true)
	private String loyaltyConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String loyaltyBoundary;

	@Column(length = 255, nullable = true)
	private String orderNumber;

	@Column(length = 10, nullable = true)
	private String orderNumberConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String orderNumberBoundary;

	@Column(length = 255, nullable = true)
	private String serviceType;

	@Column(length = 10, nullable = true)
	private String serviceTypeConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String serviceTypeBoundary;

	@Column(length = 255, nullable = true)
	private String receiptType;

	@Column(length = 10, nullable = true)
	private String receiptTypeConfidence;
	
	@Column(columnDefinition = "TEXT")
	private String receiptTypeBoundary;

	@Column(length = 255, nullable = true)
	private String merchantId;

	@Column(length = 255, nullable = true)
	private String paymentMethodId;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getPaymentMethodId() {
		return paymentMethodId;
	}

	public void setPaymentMethodId(String paymentMethodId) {
		this.paymentMethodId = paymentMethodId;
	}

	public String getMerchantRule() {
		return merchantRule;
	}

	public void setMerchantRule(String merchantRule) {
		this.merchantRule = merchantRule;
	}

	@Column(columnDefinition = "TEXT")
	private String merchantRule;

	@Transient
	private String driveThru;

	@Transient
	private String counter;

	@Transient
	private List<String> extractPaymentMethods = new ArrayList<>();

	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "id")
	@MapsId
	private ManagementEntity management;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMerchant() {
		return merchant;
	}

	public void setMerchant(String merchant) {
		this.merchant = merchant;
	}

	public String getMerchantConfidence() {
		return merchantConfidence;
	}

	public void setMerchantConfidence(String merchantConfidence) {
		this.merchantConfidence = merchantConfidence;
	}

	public String getStoreNumber() {
		return storeNumber;
	}

	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}

	public String getStoreNumberConfidence() {
		return storeNumberConfidence;
	}

	public void setStoreNumberConfidence(String storeNumberConfidence) {
		this.storeNumberConfidence = storeNumberConfidence;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getHouseNumberConfidence() {
		return houseNumberConfidence;
	}

	public void setHouseNumberConfidence(String houseNumberConfidence) {
		this.houseNumberConfidence = houseNumberConfidence;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getStreetAddressConfidence() {
		return streetAddressConfidence;
	}

	public void setStreetAddressConfidence(String streetAddressConfidence) {
		this.streetAddressConfidence = streetAddressConfidence;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getZipConfidence() {
		return zipConfidence;
	}

	public void setZipConfidence(String zipConfidence) {
		this.zipConfidence = zipConfidence;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCityConfidence() {
		return cityConfidence;
	}

	public void setCityConfidence(String cityConfidence) {
		this.cityConfidence = cityConfidence;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStateConfidence() {
		return stateConfidence;
	}

	public void setStateConfidence(String stateConfidence) {
		this.stateConfidence = stateConfidence;
	}

	public String getMerchantPhone() {
		return merchantPhone;
	}

	public void setMerchantPhone(String merchantPhone) {
		this.merchantPhone = merchantPhone;
	}

	public String getMerchantPhoneConfidence() {
		return merchantPhoneConfidence;
	}

	public void setMerchantPhoneConfidence(String merchantPhoneConfidence) {
		this.merchantPhoneConfidence = merchantPhoneConfidence;
	}

	public String getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getPurchaseDateConfidence() {
		return purchaseDateConfidence;
	}

	public void setPurchaseDateConfidence(String purchaseDateConfidence) {
		this.purchaseDateConfidence = purchaseDateConfidence;
	}

	public String getPurchaseTime() {
		return purchaseTime;
	}

	public void setPurchaseTime(String purchaseTime) {
		this.purchaseTime = purchaseTime;
	}

	public String getPurchaseTimeConfidence() {
		return purchaseTimeConfidence;
	}

	public void setPurchaseTimeConfidence(String purchaseTimeConfidence) {
		this.purchaseTimeConfidence = purchaseTimeConfidence;
	}

	public String getTotalPaid() {
		return totalPaid;
	}

	public void setTotalPaid(String totalPaid) {
		this.totalPaid = totalPaid;
	}

	public String getTotalPaidConfidence() {
		return totalPaidConfidence;
	}

	public void setTotalPaidConfidence(String totalPaidConfidence) {
		this.totalPaidConfidence = totalPaidConfidence;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getPaymentMethodConfidence() {
		return paymentMethodConfidence;
	}

	public void setPaymentMethodConfidence(String paymentMethodConfidence) {
		this.paymentMethodConfidence = paymentMethodConfidence;
	}

	public String getLoyalty() {
		return loyalty;
	}

	public void setLoyalty(String loyalty) {
		this.loyalty = loyalty;
	}

	public String getLoyaltyConfidence() {
		return loyaltyConfidence;
	}

	public void setLoyaltyConfidence(String loyaltyConfidence) {
		this.loyaltyConfidence = loyaltyConfidence;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getOrderNumberConfidence() {
		return orderNumberConfidence;
	}

	public void setOrderNumberConfidence(String orderNumberConfidence) {
		this.orderNumberConfidence = orderNumberConfidence;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getServiceTypeConfidence() {
		return serviceTypeConfidence;
	}

	public void setServiceTypeConfidence(String serviceTypeConfidence) {
		this.serviceTypeConfidence = serviceTypeConfidence;
	}

	public String getReceiptType() {
		return receiptType;
	}

	public void setReceiptType(String receiptType) {
		this.receiptType = receiptType;
	}

	public String getReceiptTypeConfidence() {
		return receiptTypeConfidence;
	}

	public void setReceiptTypeConfidence(String receiptTypeConfidence) {
		this.receiptTypeConfidence = receiptTypeConfidence;
	}

	public ManagementEntity getManagement() {
		return management;
	}

	public void setManagement(ManagementEntity management) {
		this.management = management;
	}

	public String getDriveThru() {
		return driveThru;
	}

	public void setDriveThru(String driveThru) {
		this.driveThru = driveThru;
	}

	public String getCounter() {
		return counter;
	}

	public void setCounter(String counter) {
		this.counter = counter;
	}

	public List<String> getExtractPaymentMethods() {
		return extractPaymentMethods;
	}

	public String getMerchantBoundary() {
		return merchantBoundary;
	}

	public void setMerchantBoundary(String merchantBoundary) {
		this.merchantBoundary = merchantBoundary;
	}

	public String getStoreNumberBoundary() {
		return storeNumberBoundary;
	}

	public void setStoreNumberBoundary(String storeNumberBoundary) {
		this.storeNumberBoundary = storeNumberBoundary;
	}

	public String getHouseNumberBoundary() {
		return houseNumberBoundary;
	}

	public void setHouseNumberBoundary(String houseNumberBoundary) {
		this.houseNumberBoundary = houseNumberBoundary;
	}

	public String getStreetAddressBoundary() {
		return streetAddressBoundary;
	}

	public void setStreetAddressBoundary(String streetAddressBoundary) {
		this.streetAddressBoundary = streetAddressBoundary;
	}

	public String getZipBoundary() {
		return zipBoundary;
	}

	public void setZipBoundary(String zipBoundary) {
		this.zipBoundary = zipBoundary;
	}

	public String getCityBoundary() {
		return cityBoundary;
	}

	public void setCityBoundary(String cityBoundary) {
		this.cityBoundary = cityBoundary;
	}

	public String getStateBoundary() {
		return stateBoundary;
	}

	public void setStateBoundary(String stateBoundary) {
		this.stateBoundary = stateBoundary;
	}

	public String getMerchantPhoneBoundary() {
		return merchantPhoneBoundary;
	}

	public void setMerchantPhoneBoundary(String merchantPhoneBoundary) {
		this.merchantPhoneBoundary = merchantPhoneBoundary;
	}

	public String getPurchaseDateBoundary() {
		return purchaseDateBoundary;
	}

	public void setPurchaseDateBoundary(String purchaseDateBoundary) {
		this.purchaseDateBoundary = purchaseDateBoundary;
	}

	public String getPurchaseTimeBoundary() {
		return purchaseTimeBoundary;
	}

	public void setPurchaseTimeBoundary(String purchaseTimeBoundary) {
		this.purchaseTimeBoundary = purchaseTimeBoundary;
	}

	public String getTotalPaidBoundary() {
		return totalPaidBoundary;
	}

	public void setTotalPaidBoundary(String totalPaidBoundary) {
		this.totalPaidBoundary = totalPaidBoundary;
	}

	public String getPaymentMethodBoundary() {
		return paymentMethodBoundary;
	}

	public void setPaymentMethodBoundary(String paymentMethodBoundary) {
		this.paymentMethodBoundary = paymentMethodBoundary;
	}

	public String getLoyaltyBoundary() {
		return loyaltyBoundary;
	}

	public void setLoyaltyBoundary(String loyaltyBoundary) {
		this.loyaltyBoundary = loyaltyBoundary;
	}

	public String getOrderNumberBoundary() {
		return orderNumberBoundary;
	}

	public void setOrderNumberBoundary(String orderNumberBoundary) {
		this.orderNumberBoundary = orderNumberBoundary;
	}

	public String getServiceTypeBoundary() {
		return serviceTypeBoundary;
	}

	public void setServiceTypeBoundary(String serviceTypeBoundary) {
		this.serviceTypeBoundary = serviceTypeBoundary;
	}

	public String getReceiptTypeBoundary() {
		return receiptTypeBoundary;
	}

	public void setReceiptTypeBoundary(String receiptTypeBoundary) {
		this.receiptTypeBoundary = receiptTypeBoundary;
	}

	public void setExtractPaymentMethods(List<String> extractPaymentMethods) {
		this.extractPaymentMethods = extractPaymentMethods;
	}
}
