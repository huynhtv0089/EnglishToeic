package vn.sps.ss.extraction.watson.application.service.receipt.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import vn.sps.ss.extraction.model.ItemExtract;
import vn.sps.ss.extraction.model.ReceiptRequest;
import vn.sps.ss.extraction.model.extract.Trip;
import vn.sps.ss.extraction.model.item.Item;
import vn.sps.ss.extraction.watson.application.service.receipt.ReceiptService;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ReceiptCredential;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa.CorrectionRepository;
import vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa.ManagementRepository;
import vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa.RelationCorrectionRepository;

@Service
public class ReceiptServiceImpl implements ReceiptService {
	
	/** The Correction repository. */
	@Autowired
	private ManagementRepository repository;
	
	@Autowired
	private CorrectionRepository correctionRepository;
	
	@Autowired
	private RelationCorrectionRepository relationCorrectionRepository;
	
	@Autowired
	private ReceiptCredential credential;
	

	@Override
	public Map<String, List<ItemExtract>> byId(String requestId) {
		final Map<String, List<ItemExtract>> result = new HashMap<>();
		// Move business to WSO2
		return result;
	}

	@Override
	public Trip findById(String requestId) {
		List<EntitiesCorrectionEntity> results = this.correctionRepository.findCorrectionByRequestId(requestId);
		return ReceiptTransfer.transferFrom(this.credential, results, requestId);
	}

	public List<EntitiesCorrectionEntity> list(String requestId) {
		return  this.repository.findCorrectionByRequestId(requestId);
	}

	@Override
	public Item findItemById(ReceiptRequest request) {
		List<RelationsCorrectionEntity> result = this.relationCorrectionRepository.findItemCorrectionByRequestId(request.getRequestId());
		List<List<RelationsCorrectionEntity>> results = new ArrayList<>();
		results.add(result);
		return ReceiptTransfer.transferFrom(results);
	}
}
