package vn.sps.ss.extraction.watson.application.iterator.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.iterator.WatsonExtractionIterator;
import vn.sps.ss.extraction.watson.application.iterator.interceptor.Interceptor;
import vn.sps.ss.extraction.watson.application.iterator.interceptor.extraction.MatchingBoundaryInterceptor;
import vn.sps.ss.extraction.watson.infrastructure.configuration.InterceptorConfiguration;

@Component
public class WatsonExtractionIteratorImpl extends AbstractIterator implements WatsonExtractionIterator {

	@Autowired
	private InterceptorConfiguration configuration;
	
	private final Map<String, Interceptor> allInterceptors = new HashMap<>();

	@PostConstruct
	private void setup() {
		this.loadAllInterceptors();
		this.addInterceptor();
	}

	private void loadAllInterceptors() {
		this.allInterceptors.put(MatchingBoundaryInterceptor.getInstance().getName(), MatchingBoundaryInterceptor.getInstance());
	}

	@Override
	protected ArrayList<String> getConfiguration() {
		return this.configuration.getExtractionConfig();
	}

	@Override
	protected Map<String, Interceptor> getAllInterceptors() {
		return this.allInterceptors;
	}

	@Override
	public ProcessingContext apply(ProcessingContext context) {
		while (this.hasNext()) {
			context = this.next().process(context);
		}
		return context;
	}

}
