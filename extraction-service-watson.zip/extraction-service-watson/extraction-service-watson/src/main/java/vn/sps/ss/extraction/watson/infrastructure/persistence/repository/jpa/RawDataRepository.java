package vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa;

import org.springframework.data.repository.CrudRepository;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RawDataEntity;

public interface RawDataRepository extends CrudRepository<RawDataEntity, Long>  {
}
