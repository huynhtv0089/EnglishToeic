/*
 * Class: ResultHandler
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.business;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.infrastructure.ifa.ExternalSubmitter;

/**
 * The Interface PostProcessingHandler.
 */
public interface PostProcessingHandler
        extends ExternalSubmitter<ProcessingContext> {

}
