package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemNumberDescEntity implements Serializable {

	private static final long serialVersionUID = -2409505615234980993L;

	@JsonProperty(value = "ext_merchantname")
    private String merchantName;
    
    @JsonProperty(value = "quantity")
    private String quantity;
    
    @JsonProperty(value = "desc_item")
    private String itemName;
    
    @JsonProperty(value = "itemnumber_item")
    private String itemId;

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
}
