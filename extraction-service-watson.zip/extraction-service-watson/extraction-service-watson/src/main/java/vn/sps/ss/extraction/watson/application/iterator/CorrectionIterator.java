package vn.sps.ss.extraction.watson.application.iterator;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;

public interface CorrectionIterator {
	
	/**
	 * Apply business processing each interceptor
	 */
	ProcessingContext apply(ProcessingContext context);
}
