package vn.sps.ss.extraction.watson.application.common.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.parser.ImageRenderInfo;
import com.itextpdf.text.pdf.parser.LineSegment;
import com.itextpdf.text.pdf.parser.RenderListener;
import com.itextpdf.text.pdf.parser.TextRenderInfo;
import com.itextpdf.text.pdf.parser.Vector;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class PdfRender implements RenderListener {
    private StringBuilder result = new StringBuilder();

    private List<Map> chars = new ArrayList<>();

    private TextLocation lastLocation = null;

    private String lastChar = null;

    private Rectangle pageSize;
    
    private static final String VALUE = "value";
    
    private static final String WIDTH = "width";
    
    private static final String HEIGHT = "height";
    
    private static final String CONFIDENCE = "confidence";

    public PdfRender(Rectangle pageSize) {
        this.pageSize = pageSize;
    }

    public String getResult() {
        return result.toString();
    }

    public List getChars() {
        return chars;
    }

    @Override
    public void beginTextBlock() {
        // Do nothing

    }

    @Override
    public void renderText(TextRenderInfo renderInfo) {
        List<TextRenderInfo> renderInfos = renderInfo.getCharacterRenderInfos();
        for (TextRenderInfo item : renderInfos) {
            String text = item.getText().replace((char) 160, ' ')
                .replace('￿', ' ');
            if (" ".equals(text) && (lastChar == null || " ".equals(lastChar))) {
                    continue;
            }

            LineSegment line = item.getBaseline();
            TextLocation location = new TextLocation(line.getStartPoint(),
                line.getEndPoint(), line.getLength());

            if (lastLocation == null) {
                result.append(text);
                Map charInfo = new LinkedHashMap();
                charInfo.put(VALUE, text);
                charInfo.put("x", Math.round(location.startLocation.get(0)));
                charInfo.put(
                    "y",
                    Math.round(
                        pageSize.getHeight() - location.startLocation.get(1)));
                charInfo
                    .put(WIDTH, 2 * Math.round(location.charSpaceWidth()));
                charInfo.put(HEIGHT, 20);
                charInfo.put(CONFIDENCE, 1.0);
                chars.add(charInfo);
            }
            else {
            	lastLocation(location, item, text);
            }
            lastChar = text;
            lastLocation = location;
        }
    }
    
    private void lastLocation(TextLocation location, TextRenderInfo item, String text) {

        if (!location.sameLine(lastLocation)) {
            if (" ".equals(lastChar)) {
                result.deleteCharAt(result.length() - 1);
                chars.remove(chars.size() - 1);
            }
            result.append("\n");
            Map charInfo = new LinkedHashMap();
            charInfo.put(VALUE, "\n");
            charInfo.put("x", 0);
            charInfo.put("y", 0);
            charInfo.put(WIDTH, 0);
            charInfo.put(HEIGHT, 0);
            charInfo.put(CONFIDENCE, 0);
            chars.add(charInfo);
        }
        result.append(text);
        Map charInfo = new LinkedHashMap();
        charInfo.put(VALUE, item.getText());
        if (" ".equals(item.getText())) {
            charInfo.put("x", 0);
            charInfo.put("y", 0);
            charInfo.put(WIDTH, 0);
            charInfo.put(HEIGHT, 0);
            charInfo.put(CONFIDENCE, 0);
        }
        else {
            charInfo.put(
                "x",
                Math.round(location.startLocation.get(0)) + 23);
            charInfo.put(
                "y",
                Math.round(
                    pageSize.getHeight() - location.startLocation.get(1)
                            + 29));
            charInfo
                .put(WIDTH, Math.round(location.charSpaceWidth()));
            charInfo.put(HEIGHT, 16);
            charInfo.put(CONFIDENCE, 1.0);
        }
        chars.add(charInfo);
    }

    @Override
    public void endTextBlock() {
        // Do nothing
    }

    @Override
    public void renderImage(ImageRenderInfo renderInfo) {
        // Do nothing
    }

    @SuppressWarnings("unused")
    private class TextLocation {
        private final Vector startLocation;

        private final Vector orientationVector;

        private final int orientationMagnitude;

        private final int distPerpendicular;

        private final float distParallelStart;

        private final float distParallelEnd;

        private final float charSpaceWidth;

        public TextLocation(Vector startLocation, Vector endLocation,
                float charSpaceWidth) {
            this.startLocation = startLocation;
            this.charSpaceWidth = charSpaceWidth;
            Vector oVector = endLocation.subtract(startLocation);
            if (oVector.length() == 0) {
                oVector = new Vector(1, 0, 0);
            }
            orientationVector = oVector.normalize();
            orientationMagnitude = (int) (Math.atan2(
                orientationVector.get(Vector.I2),
                orientationVector.get(Vector.I1)) * 1000);
            Vector origin = new Vector(0, 0, 1);
            distPerpendicular = (int) (startLocation.subtract(origin))
                .cross(orientationVector).get(Vector.I3);
            distParallelStart = orientationVector.dot(startLocation);
            distParallelEnd = orientationVector.dot(endLocation);
        }

        public Boolean sameLine(TextLocation target) {
            return orientationMagnitude() == target.orientationMagnitude()
                    && distPerpendicular() == target.distPerpendicular();
        }

        public int orientationMagnitude() {
            return orientationMagnitude;
        }

        public int distPerpendicular() {
            return distPerpendicular;
        }

        public float distParallelStart() {
            return distParallelStart;
        }

        public float distParallelEnd() {
            return distParallelEnd;
        }

        public float charSpaceWidth() {
            return charSpaceWidth;
        }
    }
}
