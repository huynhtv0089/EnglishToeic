/*
 * Class: CleanableBean
 *
 * Created on Nov 1, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.ifa;

/**
 * The Interface CleanableBean.
 */
public interface ImmortalCollector {

    /**
     * Clean finished tasks.
     *
     * @param force the force
     * @return the number of finished task was removed.
     */
    int cleanFinishedTasks(boolean force);

    /**
     * Empty queue.
     *
     * @param interuptted the interuptted
     * @param key the key
     * @return the int
     */
    int emptyQueue(String key);

}
