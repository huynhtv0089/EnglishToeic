package vn.sps.ss.extraction.watson.application.iterator.interceptor;

public abstract class AbstractInterceptor implements Interceptor {
	
	private String name;

	protected AbstractInterceptor(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
}
