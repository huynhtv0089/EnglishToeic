/*
 * Class: ProcessingContext
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.business.impl;

import vn.sps.ss.extraction.model.ExtractionRequest;
import vn.sps.ss.extraction.model.ExtractionResponse;
import vn.sps.ss.extraction.watson.domain.CorrectionRequest;
import vn.sps.ss.extraction.watson.domain.CorrectionResponse;
import vn.sps.ss.extraction.watson.domain.WatsonRequest;
import vn.sps.ss.extraction.watson.domain.WatsonResponse;
import vn.sps.ss.extraction.watson.infrastructure.configuration.TypeProperties;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;

public class ProcessingContext {

    private CorrectionRequest correctionRequest;

    private CorrectionResponse correctionResponse;

    private String id;

    private ManagementEntity managementEntity;

    private final ExtractionRequest request;

    private final ExtractionResponse response;

    private TypeProperties typeProperties;

    private WatsonRequest watsonRequest;

    private WatsonResponse watsonResponse;
    
    private Long receiveTime;

    public ProcessingContext(final ExtractionRequest request,
            final ExtractionResponse response) {
        super();
        this.id = request.getId();
        this.request = request;
        this.response = response;
    }

    public CorrectionRequest getCorrectionRequest() {
        return this.correctionRequest;
    }

    public CorrectionResponse getCorrectionResponse() {
        return this.correctionResponse;
    }

    public String getId() {
        return this.id;
    }

    public ManagementEntity getManagementEntity() {
        return this.managementEntity;
    }

    public ExtractionRequest getRequest() {
        return this.request;
    }

    public ExtractionResponse getResponse() {
        return this.response;
    }

    public TypeProperties getTypeProperties() {
        return this.typeProperties;
    }

    public WatsonRequest getWatsonRequest() {
        return this.watsonRequest;
    }

    public WatsonResponse getWatsonResponse() {
        return this.watsonResponse;
    }

    public void setCorrectionRequest(
        final CorrectionRequest correctionRequest) {
        this.correctionRequest = correctionRequest;
    }

    public void setCorrectionResponse(
        final CorrectionResponse correctionResponse) {
        this.correctionResponse = correctionResponse;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public void setManagementEntity(final ManagementEntity managementEntity) {
        this.managementEntity = managementEntity;
    }

    public void setTypeProperties(final TypeProperties typeProperties) {
        this.typeProperties = typeProperties;
    }

    public void setWatsonRequest(final WatsonRequest watsonRequest) {
        this.watsonRequest = watsonRequest;
    }

    public void setWatsonResponse(final WatsonResponse watsonResponse) {
        this.watsonResponse = watsonResponse;
    }

	public Long getReceiveTime() {
		return receiveTime;
	}

	public void setReceiveTime(Long receiveTime) {
		this.receiveTime = receiveTime;
	}

}
