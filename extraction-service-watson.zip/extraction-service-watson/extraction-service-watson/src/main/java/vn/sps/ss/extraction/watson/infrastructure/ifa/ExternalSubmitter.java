/*
 * Class: IExternalTransfer
 *
 * Created on Oct 18, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.ifa;

import java.util.concurrent.Future;

/**
 * The Interface IExternalSender.
 *
 * @param <T> the generic type
 * @param <R> the generic type
 */
public interface ExternalSubmitter<T> {

    /**
     * Submit item.<br>
     * The submitted worker must not be null
     *
     * @param key the key
     * @param obj the obj
     * @return the future of added task or the existing one
     */
    Future<T> submitItem(String key, T obj);
    
}
