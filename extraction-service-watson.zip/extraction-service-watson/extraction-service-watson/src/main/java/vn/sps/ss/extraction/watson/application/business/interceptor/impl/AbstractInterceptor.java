package vn.sps.ss.extraction.watson.application.business.interceptor.impl;

import vn.sps.ss.extraction.watson.application.business.interceptor.Interceptor;

abstract class AbstractInterceptor implements Interceptor {
	
	private String name;

	protected AbstractInterceptor(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	
}
