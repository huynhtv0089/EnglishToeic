package vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;

@Repository
@Transactional
public interface ManagementRepository extends CrudRepository<ManagementEntity, Long> {
	
	@Query("SELECT id FROM ManagementEntity WHERE requestId = :requestId")
	public List<ManagementEntity> findByRequestId(@Param("requestId") String requestId);
	
	@Query("SELECT m.correct FROM ManagementEntity m WHERE m.requestId = :requestId")
	public List<EntitiesCorrectionEntity> findCorrectionByRequestId(@Param("requestId") String requestId);
	
	@Query("SELECT m.item FROM ManagementEntity m WHERE m.id = :id")
	public List<EntitiesEntity> findItem(@Param("id") long id);
}
