/*
 * Class: WatsonServiceImpl
 *
 * Created on Oct 17, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.service.extraction.impl;

import com.ibm.watson.developer_cloud.service.exception.ServiceResponseException;
import com.ibm.watson.developer_cloud.service.exception.TooManyRequestsException;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.NaturalLanguageUnderstanding;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalysisResults;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalyzeOptions;

import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.application.service.extraction.WatsonService;
import vn.sps.ss.extraction.watson.domain.WatsonRequest;
import vn.sps.ss.extraction.watson.domain.WatsonResponse;
import vn.sps.ss.extraction.watson.infrastructure.configuration.WatsonProperties;

/**
 * The Class WatsonServiceImpl.
 */
@Service
@ConditionalOnProperty(name = "watson.service-class", havingValue = "vn.sps.ss.extraction.watson.application.service.extraction.impl.WatsonDelayServiceImpl")
public class WatsonDelayServiceImpl implements WatsonService {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory
        .getLogger(WatsonDelayServiceImpl.class);

    /** The analyze options. */
    @Autowired
    private AnalyzeOptions analyzeOptions;

    /** The mapper. */
    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private WatsonProperties properties;

    /** The service. */
    @Autowired
    private NaturalLanguageUnderstanding service;

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.ss.extraction.watson.application.service.extraction.WatsonService#extract(vn.sps.ss.extraction.watson.domain.WatsonRequest)
     */
    @Override
    public WatsonResponse extract(final WatsonRequest request) {

        WatsonResponse res = null;
        final String requestId = request.getRequestId();
        try {
            final AnalyzeOptions parameters = new AnalyzeOptions.Builder()
                .text(request.getContent()).clean(this.analyzeOptions.clean())
                .fallbackToRaw(this.analyzeOptions.fallbackToRaw())
                .features(this.analyzeOptions.features())
                .html(this.analyzeOptions.html())
                .language(this.analyzeOptions.language())
                .returnAnalyzedText(this.analyzeOptions.returnAnalyzedText())
                .text(request.getContent()).url(this.analyzeOptions.url())
                .xpath(this.analyzeOptions.xpath()).build();

            request.setBegin(WallClock.milli());
            final AnalysisResults response = this.service.analyze(parameters)
                .execute();
            request.setEnd(WallClock.milli());

            res = new WatsonResponse();
            {
                final String rawData = this.mapper.writeValueAsString(response);
                res.setRawExtract(rawData);
                res.setContent(response);
            }
        }
        catch (final TooManyRequestsException e) {
            final long delayTime = this.properties.getSleepForRetry();
            try {
                LOG.info(
                    "Too many request to Watson Service when processing request {}. This will retry after {} milis",
                    requestId,
                    delayTime);

                LOG.debug(
                    "Received exception from Watson Service when processing request {}",
                    requestId,
                    e);

                TimeUnit.MILLISECONDS.sleep(delayTime);
                this.extract(request);
            }
            catch (final InterruptedException ex) {
                LOG.debug(
                    "Error when sleep thread for request {}",
                    requestId,
                    ex);
                Thread.currentThread().interrupt();
            }
        }
        catch (final ServiceResponseException e) {
            LOG.error(
                "Failed to processing extraction for request {}",
                requestId,
                e);
            res = new WatsonResponse();
            res.setWatsonError(true);
        }
        catch (final Exception e) {
            LOG.error(
                "Unexpected error happens when process extraction for request {}",
                requestId,
                e);
        }

        return res;
    }

}
