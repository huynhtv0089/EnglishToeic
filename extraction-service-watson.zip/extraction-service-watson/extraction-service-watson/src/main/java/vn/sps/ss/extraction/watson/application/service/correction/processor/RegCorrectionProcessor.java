/*
 * Class: RegCorrectionHandler
 *
 * Created on Oct 16, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.service.correction.processor;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.sps.ss.extraction.watson.application.common.util.Constant.RegexValidtionFields;
import vn.sps.ss.extraction.watson.application.common.util.DateTimeUtil;
import vn.sps.ss.extraction.watson.application.common.util.RegularExpressionUtils;
import vn.sps.ss.extraction.watson.application.common.util.StringUtil;
import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.domain.CorrectionContext;
import vn.sps.ss.extraction.watson.infrastructure.configuration.RegexValidationConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.configuration.RegexValidationConfiguration.Replacement;
import vn.sps.ss.extraction.watson.infrastructure.configuration.RegexValidationConfiguration.Validation;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsCorrectionEntity;

public class RegCorrectionProcessor extends AbstractCorrectionProcessor
        implements CorrectionProcessor {

    private static final Logger LOGGER = LoggerFactory
        .getLogger(RegCorrectionProcessor.class);

    final RegexValidationConfiguration regexValidationConfiguration;

    public RegCorrectionProcessor(final CorrectionProcessor nextHandler,
            final RegexValidationConfiguration regexValidationConfiguration) {
        super("REG", nextHandler);
        this.regexValidationConfiguration = regexValidationConfiguration;
    }

    @Override
    protected void filter(final CorrectionContext context) {
        // do nothing

    }

    @Override
	protected void process(final CorrectionContext context) {
		EntitiesCorrectionEntity entity = context.getRequest().getManagement().getCorrect();
		final Map<String, RelationsCorrectionEntity> itemEntities = context.getRequest().getManagement().getItemCorrect();

		final String requestId = context.getRequest().getReceiptId();
		final long beginTime = WallClock.milli();

		try {

			LOGGER.info("Begin correct using Regex for receipt {}.", requestId);

			// Correct Merchant phone
			correctMerchantPhone(requestId, entity);

			// Correct Loyalty.
			correctLoyalty(requestId, entity);

			// Correct OrderNr.
			correctOrderNumber(requestId, entity);

			// Correct Purchase date.
			correctPurchaseDate(requestId, entity);

			// Correct Purchase time.
			correctPurchaseTime(requestId, entity);

			// Correct Total paid.
			correctTotalPaid(requestId, entity);

			// Correct Service type.
			correctServiceType(requestId, entity);
			
			// Correct item (item price, item quantity, item type, item unit)
			correctItem(requestId, itemEntities);

			LOGGER.info("End correct using Regex for receipt {}. Took {} milis.", requestId,
					WallClock.milli() - beginTime);
		} catch (Exception e) {
			LOGGER.error("Error while correct receipt {} with Regex. Took {} milis. Detail: ", requestId,
					WallClock.milli() - beginTime, e);
		}
	}

	private void correctServiceType(String requestId, EntitiesCorrectionEntity entity) {

		String serviceType = entity.getServiceType() != null ? entity.getServiceType() : "";

		String counter = entity.getCounter() != null ? entity.getCounter() : "";

		String driveThru = entity.getDriveThru() != null ? entity.getDriveThru() : "";

		if (!StringUtil.isNullOrEmpty(counter)) {
			entity.setServiceType("Counter");
			LOGGER.info("Service type of receipt [{}] is Counter.");
		} else {
			if (!StringUtil.isNullOrEmpty(driveThru)) {
				entity.setServiceType("Drive Thru");
				LOGGER.info("Service type of receipt [{}] is Drive Thru.");
			} else {
				if (!StringUtil.isNullOrEmpty(serviceType)) {
					boolean isValid = false;
					// Counter
					{
						Validation serviceTypeValidation = this.regexValidationConfiguration
								.getRule(RegexValidtionFields.SERVICE_TYPE_COUNTER);

						if (serviceTypeValidation != null) {
							String tmpServiceType = serviceType.toLowerCase();
							// Remove all unnecessary words with regular expression in configuration.
							List<Replacement> replaces = serviceTypeValidation.getReplaces();
							for (Replacement replace : replaces) {
								tmpServiceType = tmpServiceType.replaceAll(replace.getReplacePattern(),
										replace.getReplaceValue());
							}

							// Validate payment method with pattern.
							if (RegularExpressionUtils.match(serviceTypeValidation.getValidatePattern(),
									tmpServiceType)) {

								entity.setServiceType("Counter");
								isValid = true;
								LOGGER.info("Service type [{}] is match with Counter regex [{}].", tmpServiceType,
										serviceTypeValidation.getValidatePattern());
							}
						} else {
							LOGGER.warn("Validation rule of Service type has not been set.");
						}
					}
					// Drive thru
					{
						Validation serviceTypeValidation = this.regexValidationConfiguration
								.getRule(RegexValidtionFields.SERVICE_TYPE_DRIVETHRU);

						if (serviceTypeValidation != null) {
							String tmpServiceType = serviceType.toLowerCase();
							// Remove all unnecessary words with regular expression in configuration.
							List<Replacement> replaces = serviceTypeValidation.getReplaces();
							for (Replacement replace : replaces) {
								tmpServiceType = tmpServiceType.replaceAll(replace.getReplacePattern(),
										replace.getReplaceValue());
							}

							// Validate payment method with pattern.
							if (RegularExpressionUtils.match(serviceTypeValidation.getValidatePattern(),
									tmpServiceType)) {

								entity.setServiceType("Drive Thru");
								isValid = true;
								LOGGER.info("Service type [{}] is match with Drive Thru regex [{}].", tmpServiceType,
										serviceTypeValidation.getValidatePattern());
							}
						}
					}
					// Special case: Take out total
					{
						Validation serviceTypeValidation = this.regexValidationConfiguration
								.getRule(RegexValidtionFields.SERVICE_TYPE_SPECIAL);
						if (serviceTypeValidation != null) {
							String tmpServiceType = serviceType.toLowerCase();
							// Remove all unnecessary words with regular expression in configuration.
							List<Replacement> replaces = serviceTypeValidation.getReplaces();
							for (Replacement replace : replaces) {
								tmpServiceType = tmpServiceType.replaceAll(replace.getReplacePattern(),
										replace.getReplaceValue());
							}

							// Validate payment method with pattern.
							if (RegularExpressionUtils.match(serviceTypeValidation.getValidatePattern(),
									tmpServiceType)) {

								isValid = true;

								entity.setServiceType("Drive Thru");
								LOGGER.info("Service type [{}] is match with Drive Thru regex [{}] and without couter.",
										tmpServiceType, serviceTypeValidation.getValidatePattern());

							}
						}
					}
					if (!isValid) {
						entity.setServiceType("");
						LOGGER.warn("Service type [{}] is invalid.", serviceType);
					}
				} else {
					entity.setServiceType("");
					LOGGER.warn("Service type of receipt {} is empty.", requestId);
				}
			}
		}
	}

	private void correctTotalPaid(String requestId, EntitiesCorrectionEntity entity) {

		String totalPaid = entity.getTotalPaid() != null ? entity.getTotalPaid() : "";

		if (!StringUtil.isNullOrEmpty(totalPaid)) {

			final Validation totalPaidValidation = this.regexValidationConfiguration
					.getRule(RegexValidtionFields.TOTAL_PAID);

			if (totalPaidValidation != null) {
				// Pre validate total paid with pattern.
				if (RegularExpressionUtils.match(totalPaidValidation.getPreValidatePattern(), totalPaid)) {
					// Remove all unnecessary words with regular expression in configuration.
					List<Replacement> replaces = totalPaidValidation.getReplaces();
					for (Replacement replace : replaces) {
						totalPaid = totalPaid.replaceAll(replace.getReplacePattern(), replace.getReplaceValue());
					}

					try {
						float fTotalPaid = Float.parseFloat(totalPaid);
						totalPaid = StringUtil.format(fTotalPaid, totalPaidValidation.getConvertTo());

						if (!RegularExpressionUtils.match(totalPaidValidation.getValidatePattern(), totalPaid)) {

							entity.setTotalPaid("");
							LOGGER.warn("Total paid [{}] is not valid with regex [{}].", totalPaid,
									totalPaidValidation.getValidatePattern());
						} else {
							entity.setTotalPaid(totalPaid);
							LOGGER.info("Total paid [{}] is valid with regex [{}].", totalPaid,
									totalPaidValidation.getValidatePattern());
						}
					} catch (Exception e) {
						entity.setTotalPaid("");
						LOGGER.warn("Total paid [{}] is not valid.", totalPaid, e);
					}
				} else {
					entity.setTotalPaid("");
					LOGGER.warn("Total paid [{}] is not valid.", totalPaid);
				}
			} else {
				entity.setTotalPaid("");
				LOGGER.warn("Validation rule of Total paid has not been set.");
			}
		} else {
			entity.setTotalPaid("");
			LOGGER.warn("Total paid of receipt {} is empty.", requestId);
		}
	}

	private void correctPurchaseTime(String requestId, EntitiesCorrectionEntity entity) {

		String purchaseTime = entity.getPurchaseTime() != null ? entity.getPurchaseTime() : "";

		purchaseTime = purchaseTime.toLowerCase();

		if (!StringUtil.isNullOrEmpty(purchaseTime)) {
			final Validation purchaseTimeValidation = this.regexValidationConfiguration
					.getRule(RegexValidtionFields.PURCHASE_TIME);

			if (purchaseTimeValidation != null) {
				// Pre validate purchase time with pattern.
				if (RegularExpressionUtils.match(purchaseTimeValidation.getPreValidatePattern(), purchaseTime)) {
					// Remove all unnecessary words with regular expression in configuration.
					String tmpPurchaseTime = purchaseTime;
					List<Replacement> replaces = purchaseTimeValidation.getReplaces();
					for (Replacement replace : replaces) {
						tmpPurchaseTime = tmpPurchaseTime.replaceAll(replace.getReplacePattern(),
								replace.getReplaceValue());
					}

					// Try to convert purchase time with all format in configuration.
					List<String> correctFormats = purchaseTimeValidation.getCorrectFormats();
					Date date = DateTimeUtil.getDateWithFormat(tmpPurchaseTime, correctFormats);
					if (date != null) {
						tmpPurchaseTime = StringUtil.format(date, purchaseTimeValidation.getConvertTo());

						int hour = DateTimeUtil.getHour(date);

						if ((purchaseTime.contains("pm") || purchaseTime.contains("p"))
								&& !tmpPurchaseTime.contains("+")) {
							tmpPurchaseTime = tmpPurchaseTime + "+";
						}

						if ((purchaseTime.contains("am") || purchaseTime.contains("a")) && hour == 12) {
							tmpPurchaseTime = tmpPurchaseTime + "-";
						}

						purchaseTime = tmpPurchaseTime;
					}

					// Validate purchase time with pattern.
					if (!RegularExpressionUtils.match(purchaseTimeValidation.getValidatePattern(), purchaseTime)) {

						entity.setPurchaseTime("");
						LOGGER.warn("Purchase time [{}] is not valid with regex [{}].", purchaseTime,
								purchaseTimeValidation.getValidatePattern());
					} else {
						entity.setPurchaseTime(purchaseTime);
						LOGGER.info("Purchase time [{}] is valid with regex [{}].", purchaseTime,
								purchaseTimeValidation.getValidatePattern());
					}
				} else {
					entity.setPurchaseTime("");
					LOGGER.info("Purchase time [{}] is invalid.", purchaseTime);
				}
			} else {
				entity.setPurchaseTime("");
				LOGGER.warn("Validation rule of Purchase time has not been set.");
			}
		} else {
			LOGGER.warn("Purchase time of receipt {} is empty.", requestId);
		}
	}

	private void correctPurchaseDate(String requestId, EntitiesCorrectionEntity entity) {

		String purchaseDate = entity.getPurchaseDate() != null ? entity.getPurchaseDate() : "";

		if (!StringUtil.isNullOrEmpty(purchaseDate)) {
			final Validation purchaseDateValidation = this.regexValidationConfiguration
					.getRule(RegexValidtionFields.PURCHASE_DATE);

			if (purchaseDateValidation != null) {
				// Remove all unnecessary words with regular expression in configuration.
				List<Replacement> replaces = purchaseDateValidation.getReplaces();
				for (Replacement replace : replaces) {
					purchaseDate = purchaseDate.replaceAll(replace.getReplacePattern(), replace.getReplaceValue());
				}

				// Try to convert purchase date with all format in configuration.
				List<String> correctFormats = purchaseDateValidation.getCorrectFormats();
				Date date = DateTimeUtil.getDateWithFormat(purchaseDate, correctFormats);
				if (date != null) {
					purchaseDate = StringUtil.format(date, purchaseDateValidation.getConvertTo());
				}

				// Validate Purchase date with pattern.
				if (!RegularExpressionUtils.match(purchaseDateValidation.getValidatePattern(), purchaseDate)) {

					entity.setPurchaseDate("");
					LOGGER.warn("Purchase date [{}] is not valid with regex [{}].", purchaseDate,
							purchaseDateValidation.getValidatePattern());
				} else {
					entity.setPurchaseDate(purchaseDate);
					LOGGER.info("Purchase date [{}] is valid with regex [{}].", purchaseDate,
							purchaseDateValidation.getValidatePattern());
				}
			} else {
				entity.setPurchaseDate("");
				LOGGER.warn("Validation rule of Purchase date has not been set.");
			}
		} else {
			LOGGER.warn("Purchase date of receipt {} is empty.", requestId);
		}
	}

	private void correctOrderNumber(String requestId, EntitiesCorrectionEntity entity) {

		String orderNr = entity.getOrderNumber() != null ? entity.getOrderNumber() : "";

		if (!StringUtil.isNullOrEmpty(orderNr)) {

			final Validation orderNrValidation = this.regexValidationConfiguration
					.getRule(RegexValidtionFields.ORDER_NUMBER);

			if (orderNrValidation != null) {
				// Remove all unnecessary words with regular expression in configuration.
				List<Replacement> replaces = orderNrValidation.getReplaces();
				for (Replacement replace : replaces) {
					orderNr = orderNr.replaceAll(replace.getReplacePattern(), replace.getReplaceValue());
				}

				// Validate ordernr with pattern.
				if (!RegularExpressionUtils.match(orderNrValidation.getValidatePattern(), orderNr)) {

					entity.setOrderNumber("");
					LOGGER.warn("OrderNr [{}] is not valid with regex [{}].", orderNr,
							orderNrValidation.getValidatePattern());
				} else {
					entity.setOrderNumber(orderNr);
					LOGGER.info("OrderNr [{}] is valid with regex [{}].", orderNr,
							orderNrValidation.getValidatePattern());
				}
			} else {
				entity.setOrderNumber("");
				LOGGER.warn("Validation rule of Order Nr has not been set.");
			}
		} else {
			LOGGER.warn("OrderNr of receipt {} is empty.", requestId);
		}
	}

	private void correctLoyalty(String requestId, EntitiesCorrectionEntity entity) {

		String loyalty = entity.getLoyalty() != null ? entity.getLoyalty() : "";

		if (!StringUtil.isNullOrEmpty(loyalty)) {
			entity.setLoyalty("1");
			LOGGER.info("Loyalty: {}", loyalty);
		} else {
			entity.setLoyalty("");
			LOGGER.warn("Loyalty of receipt {} is empty.", requestId);
		}
	}

	private void correctMerchantPhone(String requestId, EntitiesCorrectionEntity entity) {

		String merchantPhone = entity.getMerchantPhone() != null ? entity.getMerchantPhone() : "";

		if (!StringUtil.isNullOrEmpty(merchantPhone)) {

			final Validation merchantPhoneValidation = this.regexValidationConfiguration
					.getRule(RegexValidtionFields.MERCHANT_PHONE);

			if (merchantPhoneValidation != null) {
				// Remove all unnecessary words with regular expression in configuration.
				List<Replacement> replaces = merchantPhoneValidation.getReplaces();
				for (Replacement replace : replaces) {
					merchantPhone = merchantPhone.replaceAll(replace.getReplacePattern(), replace.getReplaceValue());
				}

				// Validate Merchant phone with pattern.
				if (!RegularExpressionUtils.match(merchantPhoneValidation.getValidatePattern(), merchantPhone)) {

					entity.setMerchantPhone("");
					LOGGER.warn("Merchant phone [{}] is not valid with regex [{}].", merchantPhone,
							merchantPhoneValidation.getValidatePattern());
				} else {
					entity.setMerchantPhone(merchantPhone);
					LOGGER.info("Merchant phone [{}] is valid with regex [{}].", merchantPhone,
							merchantPhoneValidation.getValidatePattern());
				}
			} else {
				entity.setMerchantPhone("");
				LOGGER.warn("Validation rule of Merchant phone has not been set.");
			}
		} else {
			LOGGER.warn("Merchant phone of receipt {} is empty.", requestId);
		}
	}
	
	private void correctItem(String requestId, Map<String, RelationsCorrectionEntity> itemEntities) {
		itemEntities.entrySet().stream().filter(Objects::nonNull).forEach(item -> {
			// Item price
			correctItemPrice(requestId, item.getValue());
			// Item quantity
			correctItemQuantity(requestId, item.getValue());
		});
	}
	
	private void correctItemQuantity(String requestId, RelationsCorrectionEntity item) {
		if (NumberUtils.isDigits(item.getQuantity())) {
			LOGGER.info("({} - {}) Item quantity [{}] of receipt {} is valid.", item.getItemName(), item.getItemId(),
					item.getQuantity(), requestId);
		} else {
			LOGGER.debug("({} - {}) Item quantity [{}] of receipt {} is not valid.", item.getItemName(),
					item.getItemId(), item.getQuantity(), requestId);
			item.setQuantity("");
		}
	}

	private void correctItemPrice(String requestId, RelationsCorrectionEntity item) {

		String itemPrice = item.getItemPrice() == null ? "" : item.getItemPrice();

		// If item price is null or empty, then set it as space and return.
		if (StringUtil.isNullOrEmpty(itemPrice)) {
			item.setItemPrice("");
			LOGGER.warn("({} - {}) Item price of receipt {} is empty.", item.getItemName(), item.getItemId(),
					requestId);
			return;
		}
		
		//If item name and item id are empty, then set is as space and return
		if (StringUtil.isNullOrEmpty(item.getItemName()) && StringUtil.isNullOrEmpty(item.getItemId())) {
			item.setItemPrice("");
			LOGGER.warn("({} - {}) Item price of receipt {} is empty.", item.getItemName(), item.getItemId(),
					requestId);
			return;
		}

		final Validation itemPriceValidation = this.regexValidationConfiguration
				.getRule(RegexValidtionFields.ITEM_PRICE);

		// If validation rule of item price has not been set, then set it as space and return.
		if (itemPriceValidation == null) {
			LOGGER.warn("Validation rule of Item price has not been set.");
			item.setItemPrice("");
			return;
		}

		// Pre validate total paid with pattern.
		if (!RegularExpressionUtils.match(itemPriceValidation.getPreValidatePattern(), itemPrice)) {
			LOGGER.warn("({} - {}) Item price [{}] of receipt {} is not valid.", item.getItemName(), item.getItemId(),
					itemPrice, requestId);
			item.setItemPrice("");
			return;
		}

		// Remove all unnecessary words with regular expression in configuration.
		List<Replacement> replaces = itemPriceValidation.getReplaces();
		for (Replacement replace : replaces) {
			itemPrice = itemPrice.replaceAll(replace.getReplacePattern(), replace.getReplaceValue());
		}

		try {
			float fitemPrice = Float.parseFloat(itemPrice);
			itemPrice = StringUtil.format(fitemPrice, itemPriceValidation.getConvertTo());

			if (!RegularExpressionUtils.match(itemPriceValidation.getValidatePattern(), itemPrice)) {
				LOGGER.warn("({} - {}) Item price [{}] of receipt {} is not valid with regex [{}].", item.getItemName(),
						item.getItemId(), itemPrice, requestId, itemPriceValidation.getValidatePattern());
				item.setItemPrice("");
			} else {
				item.setItemPrice(itemPrice);
				LOGGER.info("({} - {}) Item price [{}] of receipt {} is valid with regex [{}].", item.getItemName(),
						item.getItemId(), itemPrice, requestId, itemPriceValidation.getValidatePattern());
			}
		} catch (Exception e) {
			LOGGER.warn("({} - {}) Item price [{}] of receipt {} is not valid.", itemPrice, item.getItemName(),
					item.getItemId(), requestId, e);
			item.setItemPrice("");
		}

	}
}
