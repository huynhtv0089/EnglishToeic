package vn.sps.ss.extraction.watson.application.business.interceptor.impl;

import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalysisResults;

import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;

/**
 * Read watson entity interceptor
 * @author nttung_3
 */
@Service
class ReadingEntityInterceptor extends AbstractInterceptor {
	
	private static final Logger LOG = LoggerFactory.getLogger(ReadingEntityInterceptor.class);
	
	private static final String READING_ENTITY = "readingEntity";
	
	private static final ReadingEntityInterceptor INSTANCE = new ReadingEntityInterceptor();
	
	private ReadingEntityInterceptor() {
		super(READING_ENTITY);
	}
	
	public static ReadingEntityInterceptor getInstance() {
		return INSTANCE;
	}

	@Override
	public ProcessingContext process(ProcessingContext context) {
		final long begin = System.currentTimeMillis();
		LOG.info("Start process {} interceptor for receipt {}", READING_ENTITY, context.getId());
		final AnalysisResults analysisContent = context.getWatsonResponse().getContent();
		final ManagementEntity management = context.getManagementEntity();
		if (analysisContent != null && !CollectionUtils.isEmpty(analysisContent.getEntities())) {
			management.setItem(analysisContent.getEntities().stream()
					.map(i -> new EntitiesEntity(i.getText(), i.getType(), management))
					.collect(Collectors.toList()));
			 final EntitiesCorrectionEntity correction = new EntitiesCorrectionEntity();
             correction.setManagement(management);
             management.setCorrect(correction);
             
		} else {
			LOG.warn("Watson service return response Entities is empty or receipt {} have error", context.getId());
		}
		LOG.info("End process {} interceptor for receipt {} took {} milisecond", READING_ENTITY, context.getId(), System.currentTimeMillis() - begin);
		
		return context;
	}
	
	
}
