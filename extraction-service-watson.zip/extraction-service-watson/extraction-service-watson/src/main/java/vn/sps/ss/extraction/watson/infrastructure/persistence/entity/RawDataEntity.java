package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "raw_data")
public class RawDataEntity implements Serializable {
    private static final long serialVersionUID = -1957681405907588120L;

    @Id
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String rawTextOrc;

    @Column(columnDefinition = "TEXT")
    private String rawMetaOrc;

    @Column(columnDefinition = "TEXT")
    private String rawExtract;

    @Column(columnDefinition = "TEXT")
    private String rawCorrect;

    @OneToOne
    @JoinColumn(name = "id")
    @MapsId
    private ManagementEntity management;

    public RawDataEntity() {
    }

    public RawDataEntity(ManagementEntity management) {
        this.management = management;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRawTextOrc() {
        return rawTextOrc;
    }

    public void setRawTextOrc(String rawTextOrc) {
        this.rawTextOrc = rawTextOrc;
    }

    public String getRawMetaOrc() {
        return rawMetaOrc;
    }

    public void setRawMetaOrc(String rawMetaOrc) {
        this.rawMetaOrc = rawMetaOrc;
    }

    public String getRawExtract() {
        return rawExtract;
    }

    public void setRawExtract(String rawExtract) {
        this.rawExtract = rawExtract;
    }

    public String getRawCorrect() {
        return rawCorrect;
    }

    public void setRawCorrect(String rawCorrect) {
        this.rawCorrect = rawCorrect;
    }

    public ManagementEntity getManagement() {
        return management;
    }

    public void setManagement(ManagementEntity management) {
        this.management = management;
    }
}
