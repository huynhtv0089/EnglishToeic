/*
 * Class: AbstractExternalSender
 *
 * Created on Nov 2, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.ifa.impl;

import java.util.concurrent.Future;

import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import vn.sps.ss.extraction.watson.infrastructure.ifa.ExternalSubmitter;
import vn.sps.ss.extraction.watson.infrastructure.ifa.ImmortalCollector;
import vn.sps.ss.extraction.watson.presentation.jmx.AsyncWorkerInfo;

/**
 * The Class AbstractAsyncWorker.
 *
 * @param <T> the generic type
 * @param <R> the generic type
 */
public abstract class AbstractAsyncWorker<T>
        implements AsyncWorkerInfo, ImmortalCollector, ExternalSubmitter<T> {

    /** The watcher. */
    protected final TaskWatcherImpl watcher = new TaskWatcherImpl();
    
    /**
     * {@inheritDoc}
     *
     * @see vn.sps.npd.npdcanada.jmx.AsyncWorkerInfo#changePoolConfig(int, int)
     */
    @Override
    public void changePoolConfig(final int corePoolSize) {
        this.getInternalExecutor().setCorePoolSize(corePoolSize);
        this.getInternalExecutor().setMaxPoolSize(corePoolSize);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.ImmortalCollector#cleanFinishedTasks()
     */
    @Override
    public int cleanFinishedTasks(final boolean force) {
        return this.watcher.cleanFinishedTasks(force);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.npd.npdcanada.jmx.AsyncWorkerInfo#countWatcherSize()
     */
    @Override
    public int countWatcherSize() {
        return this.watcher.size();
    }
    
	/**
     * {@inheritDoc}
     *
     * @see vn.sps.npd.npdcanada.jmx.AsyncWorkerInfo#emptyQueue(java.lang.String)
     */
    @Override
    public int emptyQueue(final String key) {
        final int ret = this.watcher.emptyQueue(key);
        this.getInternalExecutor().getThreadPoolExecutor().getQueue().clear();
        return ret;
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.npd.npdcanada.jmx.AsyncWorkerInfo#getActiveCount()
     */
    @Override
    public int getActiveCount() {
        return this.getInternalExecutor().getActiveCount();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.npd.npdcanada.jmx.AsyncWorkerInfo#getCorePoolSize()
     */
    @Override
    public int getCorePoolSize() {
        return this.getInternalExecutor().getCorePoolSize();
    }

    /**
     * Gets the executor.
     *
     * @return the executor
     */
    protected abstract AsyncTaskExecutor getExecutor();

    /**
     * Gets the internal executor.
     *
     * @return the internal executor
     */
    private ThreadPoolTaskExecutor getInternalExecutor() {
        return ((ThreadPoolTaskExecutor) this.getExecutor());
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.npd.npdcanada.jmx.AsyncWorkerInfo#getMaxPoolSize()
     */
    @Override
    public int getMaxPoolSize() {
        return this.getInternalExecutor().getMaxPoolSize();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.aba.dds.common.ifa.ImmortalCollector#getNumberWatchingTask()
     */
    @Override
    public int getNumberWatchingTask() {
        return this.watcher.getNumberWatchingTask();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.npd.npdcanada.jmx.AsyncWorkerInfo#getQueingCount()
     */
    @Override
    public int getQueingCount() {
        return this.getInternalExecutor().getThreadPoolExecutor().getQueue()
            .size();
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.npd.npdcanada.jmx.AsyncWorkerInfo#getQueueCapacity()
     */
    @Override
    public int getQueueCapacity() {
        // Cannot retrieve the capacity of underline queue
        return -1;
    }

    /**
     * Gets the task.
     *
     * @param key the key
     * @return the task
     */
    @SuppressWarnings("rawtypes")
    public Future getTask(final String key) {
        return this.watcher.unWatch(key);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.npd.npdcanada.jmx.AsyncWorkerInfo#getThreadName()
     */
    @Override
    public String getThreadName() {
        return this.getInternalExecutor().getThreadNamePrefix();
    }

    /**
     * Handle.
     *
     * @param obj the obj
     * @return the object
     */
    protected abstract void handle(T obj);

    /**
     * Checks if is done.
     *
     * @param key the key
     * @return true, if is done
     */
    public boolean isDone(final String key) {
        return this.watcher.isDone(key);
    }

    /**
     * {@inheritDoc}
     *
     * @see vn.sps.ss.extraction.watson.infrastructure.ifa.ExternalSubmitter#submitItem(java.lang.String, java.lang.Object)
     */
    @Override
    public Future<T> submitItem(final String key, final T obj) {

        // TODO check null object
        final Future<T> ret = this.watcher.unWatch(key);

        final ListenableFuture<T> submitListenable = this.getInternalExecutor().submitListenable(() -> {
                this.handle(obj);
                return null;
        });
        
        {
            submitListenable.addCallback(new ListenableFutureCallback<T>() {

                @Override
                public void onFailure(final Throwable ex) {
                    AbstractAsyncWorker.this.watcher.unWatch(key);
                }

                @Override
                public void onSuccess(final T result) {
                    AbstractAsyncWorker.this.watcher.unWatch(key);
                }
            });
        }
        this.watcher.watch(key, submitListenable);

        return ret != null ? ret : submitListenable;
    }

}