/*
 * Class: HttpCPInfo
 *
 * Created on Dec 23, 2016
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.presentation.jmx;

/**
 * The Interface HttpCPInfo.
 */
public interface HttpCPInfoMXBean {

    /**
     * Gets the conn time to live.
     *
     * @return the conn time to live
     */
    long getConnTimeToLive();

    /**
     * Gets the default connect time out.
     *
     * @return the default connect time out
     */
    long getDefaultConnectTimeOut();

    /**
     * Gets the default read time out.
     *
     * @return the default read time out
     */
    long getDefaultReadTimeOut();

    /**
     * Gets the connection pool info.
     * <p>
     * Retrieve the CP info just as string will save the requests to the CP Manager which lock the threads
     * </p>
     *
     * @return the connection pool info
     */
    String getConnectionPoolInfo();

    /**
     * Sets the max per route.
     *
     * @param max the new max per route
     */
    void changeMaxPerRoute(int max);

    /**
     * Sets the max total.
     *
     * @param max the new max total
     */
    void changeMaxTotal(int max);
}
