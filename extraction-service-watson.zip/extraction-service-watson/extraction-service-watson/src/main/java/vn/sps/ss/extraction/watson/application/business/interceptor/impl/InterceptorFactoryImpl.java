package vn.sps.ss.extraction.watson.application.business.interceptor.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import vn.sps.ss.extraction.watson.application.business.CorrectionHandler;
import vn.sps.ss.extraction.watson.application.business.OCRHandler;
import vn.sps.ss.extraction.watson.application.business.WatsonExtractionHandler;
import vn.sps.ss.extraction.watson.application.business.impl.ProcessingContext;
import vn.sps.ss.extraction.watson.application.business.interceptor.Interceptor;
import vn.sps.ss.extraction.watson.application.business.interceptor.InterceptorFactory;
import vn.sps.ss.extraction.watson.infrastructure.configuration.InterceptorConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.ifa.ExternalSubmitter;

@Component
class InterceptorFactoryImpl implements InterceptorFactory<ProcessingContext> {
	
	private static final Logger LOGG = LoggerFactory.getLogger(InterceptorFactoryImpl.class);
	
	@Autowired
	private InterceptorConfiguration configuration;
	
	private final Map<String, Interceptor> allInterceptors = new HashMap<>();
	
	@Autowired
	private InterceptorFactoryImpl(List<Interceptor> interceptor) {
		this.registerInterceptors(interceptor);
	}
	
	private void registerInterceptors(List<Interceptor> interceptor) {
		LOGG.info("Total available interceptors {}", interceptor.size());
		interceptor.parallelStream().forEach(i -> {
			if (!this.allInterceptors.containsKey(i.getName())) {
				LOGG.info("Load {} interceptor to list available interceptors", i.getName());
				this.allInterceptors.put(i.getName(), i);
			} else {
				try {
					throw new InstantiationException(String.format("Interceptor that has name %s is duplicated. Please rename!", i.getName()));
				} catch (InstantiationException e) {
					LOGG.error("Error while registering interceptor", e);
				}
			}
		});
	}
	
	@Override
	public List<Interceptor> getInterceptors(ExternalSubmitter<ProcessingContext> handler) {
		if (handler instanceof OCRHandler) {
			// OCR handler have not been set up any interceptors yet
			return new ArrayList<>();
		} else if (handler instanceof WatsonExtractionHandler) {
			return this.getInterceptors(this.configuration.getExtractionConfig());
		} else if (handler instanceof CorrectionHandler) {
			return this.getInterceptors(this.configuration.getCorrectionConfig());
		} else {
			// not match any instance of handler => return empty list interceptor
			return new ArrayList<>();
		}
		
	}

	private List<Interceptor> getInterceptors(List<String> interceptorKeys) {
		List<Interceptor> interceptors = new ArrayList<>();
		for (String key : interceptorKeys) {
			Interceptor interceptor = this.allInterceptors.get(key);
			if (interceptor != null) {
				interceptors.add(interceptor);
			} else  {
				LOGG.error("Interceptor has key {} is null", key, new NullPointerException());
				throw new NullPointerException();
			}
		}
		
		return interceptors;
		
	}
	
}
