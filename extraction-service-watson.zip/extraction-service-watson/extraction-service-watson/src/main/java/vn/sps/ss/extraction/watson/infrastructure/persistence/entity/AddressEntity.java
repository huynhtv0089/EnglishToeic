/*
 * Class: AddressEntity
 *
 * Created on Oct 14, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressEntity implements Serializable {

    private static final long serialVersionUID = -618466284935394275L;

    @JsonProperty(value = "ort")
    private String ort;
    
    @JsonProperty(value = "gleiort")
    private String gleiort;
    
    @JsonProperty(value = "sub_ort")
    private String sub_ort;
    
    @JsonProperty(value = "state")
    private String state;
    
    @JsonProperty(value = "plz")
    private String plz;
    
    public String getOrt() {
        return ort;
    }

    public void setOrt(String ort) {
        this.ort = ort;
    }

    public String getGleiort() {
        return gleiort;
    }

    public void setGleiort(String gleiort) {
        this.gleiort = gleiort;
    }

    public String getSub_ort() {
        return sub_ort;
    }

    public void setSub_ort(String sub_ort) {
        this.sub_ort = sub_ort;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPlz() {
        return plz;
    }

    public void setPlz(String plz) {
        this.plz = plz;
    }
    
}
