package vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ItemNumberDescEntity;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemHit extends AbstractHit implements Serializable {

	private static final long serialVersionUID = -6223265760013827359L;
	
	@JsonProperty(value = "sourceAsMap")
    private ItemNumberDescEntity _source;

    public ItemNumberDescEntity get_source() {
        return _source;
    }

    public void set_source(ItemNumberDescEntity _source) {
        this._source = _source;
    }
}
