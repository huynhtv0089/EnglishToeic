/*
 * Class: StoreNumberEntity
 *
 * Created on Oct 17, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.persistence.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class StoreNumberEntity implements Serializable {

    private static final long serialVersionUID = 1137342245184047432L;

    @JsonProperty(value = "zip")
    private String zip;
    
    @JsonProperty(value = "ext_merchantname")
    private String extMerchantname;
    
    @JsonProperty(value = "quantity")
    private String quantity;
    
    @JsonProperty(value = "city")
    private String city;
    
    @JsonProperty(value = "housenumber")
    private String housenumber;
    
    @JsonProperty(value = "store_number")
    private String storeNumber;
    
    @JsonProperty(value = "streetaddress")
    private String streetAddress;
    
    @JsonProperty(value = "state")
    private String state;
    
    @JsonProperty(value = "merchantphone")
    private String merchantPhone;
    
    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getExtMerchantname() {
        return extMerchantname;
    }

    public void setExtMerchantname(String extMerchantname) {
        this.extMerchantname = extMerchantname;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getHousenumber() {
        return housenumber;
    }

    public void setHousenumber(String housenumber) {
        this.housenumber = housenumber;
    }

    public String getStoreNumber() {
        return storeNumber;
    }

    public void setStoreNumber(String storeNumber) {
        this.storeNumber = storeNumber;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getMerchantPhone() {
        return merchantPhone;
    }

    public void setMerchantPhone(String merchantPhone) {
        this.merchantPhone = merchantPhone;
    }
}
