/*
 * Class: HttpConfiguration
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.configuration;

import java.lang.management.ManagementFactory;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.net.ssl.SSLContext;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.pool.ConnPoolControl;
import org.apache.http.pool.PoolStats;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import vn.sps.ss.extraction.watson.presentation.jmx.HttpCPInfoMXBean;

@Configuration
public class HttpConfiguration {

    private static final Logger LOG = LoggerFactory.getLogger(HttpConfiguration.class);

    private MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
    
    private PoolingHttpClientConnectionManager connManager;

    @Bean
    protected RestTemplate ocrRestTemplate() {
        return buildRestTemplate(ocrHttpClientProperties());
    }

    @Bean
    protected RestTemplate esRestTemplate() {
        return buildRestTemplate(esHttpClientProperties());
    }
    
    @Bean
    protected RestTemplate esFilterRestTemplate() {
		return buildRestTemplate(esHttpAuthenticationClientProperties());
	}

    @Bean
    protected RestTemplate fileRestTemplate() {
        return buildRestTemplate(fileHttpClientProperties());
    }
    @Bean
    protected RestTemplate googleRestTemplate() {
        return buildRestTemplate(googleHttpClientProperties());
    }

	private RestTemplate buildRestTemplate(HttpClientProperties properties) {
		
		this.connManager = connManager(properties.getMaxConnTotal(), properties.getMaxConnPerRoute());
		
		if (properties.isJmxEnabled()) {
			createMBean(connManager, properties);
		}
		
		final RequestConfig requestConfig = requestConfig(properties.getConnectTimeout(), properties.getReadTimeout(),
				properties.getConnectionRequestTimeout());

		return restTemplate(requestConfig, this.connManager, properties.toString());
	}
	
	private RestTemplate restTemplate(RequestConfig requestConfig, PoolingHttpClientConnectionManager connManager, String property) {
		final RestTemplate restTemplate = new RestTemplate();
		final HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
		SSLContext sslContext = sslContext();
		
		final CloseableHttpClient httpClientBuilder = httpClientBuilder(requestConfig, connManager, sslContext);

		clientHttpRequestFactory.setHttpClient(httpClientBuilder);

		restTemplate.setRequestFactory(clientHttpRequestFactory);
		LOG.info("Initialized rest template with connection pool $s ", property);
		
		return restTemplate;
	}
    
    private RestTemplate buildRestTemplate(HttpAuthenticationClientProperties properties) {
    	if (properties.isJmxEnabled()) {
			createMBean(connManager, properties);
		}
		
		final RequestConfig requestConfig = requestConfig(properties.getConnectTimeout(), properties.getReadTimeout(),
				properties.getConnectionRequestTimeout());

		this.connManager = connManager(properties.getMaxConnTotal(), properties.getMaxConnPerRoute());
		
		return restTemplate(requestConfig, this.connManager, properties.toString());
    }
    
    private CloseableHttpClient httpClientBuilder(RequestConfig requestConfig, PoolingHttpClientConnectionManager connManager, SSLContext sslContext) {
    	return HttpClients.custom().setDefaultRequestConfig(requestConfig)
				.setConnectionManager(connManager).setSSLContext(sslContext)
				.setSSLHostnameVerifier(new NoopHostnameVerifier()).build();
    }
    
    private PoolingHttpClientConnectionManager connManager(int maxConnTotal, int maxConnPerRoute) {
    	PoolingHttpClientConnectionManager connectManager = new PoolingHttpClientConnectionManager();
    	connectManager.setMaxTotal(maxConnTotal);
    	connectManager.setDefaultMaxPerRoute(maxConnPerRoute);
		return connectManager;
    }
    
    private RequestConfig requestConfig(int connectTimeout, int readTimeout, int connectionRequestTimeout) {
    	return RequestConfig.custom()
                .setConnectTimeout(connectTimeout)
                .setSocketTimeout(readTimeout)
                .setConnectionRequestTimeout(connectionRequestTimeout)
                .build();
    }
    
    private SSLContext sslContext() {
    	try {
			return new SSLContextBuilder().loadTrustMaterial(null, (certificate, authType) -> true).build();
		} catch (Exception ex) {
			LOG.error("{}", ex);
			return null;
		}
    }

    private HttpCPInfo createMBean(
            PoolingHttpClientConnectionManager connManager,
            HttpClientProperties properties) {
        HttpCPInfo httpCPInfo = new HttpCPInfo(connManager, properties);
        try {
            ObjectName name = new ObjectName(
                    "vn.sps.ss.extraction.watson.infrastructure.config:type=CP"
                            + properties.getName());
            mbs.registerMBean(httpCPInfo, name);
        } catch (Exception e) {
            LOG.error("Error when create MBean {}", e);
        }

        return httpCPInfo;
    }

    @Bean
    @ConfigurationProperties(prefix = "http.client.ocr")
    protected HttpClientProperties ocrHttpClientProperties() {
        return new HttpClientProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "http.client.es")
    protected HttpClientProperties esHttpClientProperties() {
        return new HttpClientProperties();
    }
    
    @Bean
    @ConfigurationProperties(prefix = "http.client.es.filter")
    protected HttpAuthenticationClientProperties esHttpAuthenticationClientProperties() {
		return new HttpAuthenticationClientProperties();
	}

    @Bean
    @ConfigurationProperties(prefix = "http.client.file")
    protected HttpClientProperties fileHttpClientProperties() {
        return new HttpClientProperties();
    }
    @Bean
    @ConfigurationProperties(prefix = "http.client.google")
    protected HttpClientProperties googleHttpClientProperties() {
        return new HttpClientProperties();
    }

    public class HttpCPInfo implements HttpCPInfoMXBean {

        private final ConnPoolControl<HttpRoute> cpControl;

        private final HttpClientProperties props;

        public HttpCPInfo(ConnPoolControl<HttpRoute> cpControl,
                          HttpClientProperties props) {
            super();
            this.cpControl = cpControl;
            this.props = props;
        }

        @Override
        public long getConnTimeToLive() {
            return -1;
        }

        @Override
        public long getDefaultConnectTimeOut() {
            return this.props.getConnectTimeout();
        }

        @Override
        public long getDefaultReadTimeOut() {
            return this.props.getReadTimeout();
        }

        @Override
        public String getConnectionPoolInfo() {
            final String pattern = "Max = %d ; On Going = %d ; Pending = %d ; Available = %d";
            if (this.cpControl != null) {
                final PoolStats poolStats = this.cpControl.getTotalStats();
                return String.format(pattern, poolStats.getMax(), poolStats.getLeased(), poolStats.getPending(), poolStats.getAvailable());
            }
            return "The connection pool is not configured";
        }

        @Override
        public void changeMaxPerRoute(int max) {
            this.cpControl.setDefaultMaxPerRoute(max);

        }

        @Override
        public void changeMaxTotal(int max) {
            this.cpControl.setMaxTotal(max);
        }

    }
}
