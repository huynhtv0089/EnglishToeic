/*
 * Class: WatsonConfiguration
 *
 * Created on Oct 18, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.configuration;

import java.lang.management.ManagementFactory;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ibm.watson.developer_cloud.natural_language_understanding.v1.NaturalLanguageUnderstanding;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.AnalyzeOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.ConceptsOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.EmotionOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.EntitiesOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.Features;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.KeywordsOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.RelationsOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.SemanticRolesOptions;
import com.ibm.watson.developer_cloud.natural_language_understanding.v1.model.SentimentOptions;

import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import vn.sps.ss.extraction.watson.presentation.jmx.HttpCPInfoMXBean;

/**
 * The Class WatsonConfiguration.
 */
@Configuration
public class WatsonConfiguration {

    /** The Constant LOG. */
    private static final Logger LOG = LoggerFactory
        .getLogger(WatsonConfiguration.class);

    /** The watson properties. */
    private final WatsonProperties watsonProperties;

    private final MBeanServer mbs;

    @Autowired
    public WatsonConfiguration(WatsonProperties watsonProperties) {
        this.watsonProperties = watsonProperties;
        mbs = ManagementFactory.getPlatformMBeanServer();
    }

    /**
     * Concepts options.
     *
     * @return the concepts options
     */
    @Bean
    public ConceptsOptions conceptsOptions() {
        ConceptsOptions.Builder builder = new ConceptsOptions.Builder();

        if (this.watsonProperties.getConcepts().getLimit() != null) {
            builder.limit(this.watsonProperties.getConcepts().getLimit());

        }
        return builder.build();
    }

    /**
     * Entities options.
     *
     * @return the entities options
     */
    @Bean
    public EntitiesOptions entitiesOptions() {
        EntitiesOptions.Builder builder = new EntitiesOptions.Builder();
        if (this.watsonProperties.getEntities().getLimit() != null) {
            builder.limit(this.watsonProperties.getEntities().getLimit());
        }
        if (this.watsonProperties.getEntities().getModel() != null) {
            builder.model(this.watsonProperties.getEntities().getModel());
        }
        if (this.watsonProperties.getEntities().getSentiment() != null) {
            builder
                .sentiment(this.watsonProperties.getEntities().getSentiment());
        }
        if (this.watsonProperties.getEntities().getEmotion() != null) {
            builder.emotion(this.watsonProperties.getEntities().getEmotion());
        }
        return builder.build();
    }

    /**
     * Keywords options.
     *
     * @return the keywords options
     */
    @Bean
    public KeywordsOptions keywordsOptions() {
        KeywordsOptions.Builder builder = new KeywordsOptions.Builder();
        if (this.watsonProperties.getKeywords().getLimit() != null) {
            builder.limit(this.watsonProperties.getKeywords().getLimit());
        }
        if (this.watsonProperties.getKeywords().getSentiment() != null) {
            builder
                .sentiment(this.watsonProperties.getKeywords().getSentiment());
        }
        if (this.watsonProperties.getKeywords().getEmotion() != null) {
            builder.emotion(this.watsonProperties.getKeywords().getEmotion());
        }
        return builder.build();
    }

    /**
     * Emotion options.
     *
     * @return the emotion options
     */
    @Bean
    public EmotionOptions emotionOptions() {
        EmotionOptions.Builder builder = new EmotionOptions.Builder();
        if (this.watsonProperties.getEmotion().getDocument() != null) {
            builder.document(this.watsonProperties.getEmotion().getDocument());
        }
        if (this.watsonProperties.getEmotion().getTargets() != null
                && !this.watsonProperties.getEmotion().getTargets().isEmpty()) {
            this.watsonProperties.getEmotion().getTargets().forEach(target -> {
                builder.addTargets(target);
            });
        }
        return builder.build();
    }

    /**
     * Relations options.
     *
     * @return the relations options
     */
    @Bean
    public RelationsOptions relationsOptions() {
        RelationsOptions.Builder builder = new RelationsOptions.Builder();
        if (this.watsonProperties.getRelations().getModel() != null) {
            builder.model(this.watsonProperties.getRelations().getModel());
        }
        return builder.build();
    }

    /**
     * Semantic roles options.
     *
     * @return the semantic roles options
     */
    @Bean
    public SemanticRolesOptions semanticRolesOptions() {
        SemanticRolesOptions.Builder builder = new SemanticRolesOptions.Builder();
        if (this.watsonProperties.getSemanticRoles().getLimit() != null) {
            builder.limit(this.watsonProperties.getSemanticRoles().getLimit());
        }

        if (this.watsonProperties.getSemanticRoles().getKeywords() != null) {
            builder.keywords(
                this.watsonProperties.getSemanticRoles().getKeywords());
        }

        if (this.watsonProperties.getSemanticRoles().getEntities() != null) {
            builder.entities(
                this.watsonProperties.getSemanticRoles().getEntities());
        }
        return builder.build();
    }

    /**
     * Sentiment options.
     *
     * @return the sentiment options
     */
    @Bean
    public SentimentOptions sentimentOptions() {
        SentimentOptions.Builder builder = new SentimentOptions.Builder();
        if (this.watsonProperties.getSentiment().getDocument() != null) {
            builder
                .document(this.watsonProperties.getSentiment().getDocument());
        }

        if (this.watsonProperties.getSentiment().getTargets() != null
                && !this.watsonProperties.getSentiment().getTargets()
                    .isEmpty()) {
            this.watsonProperties.getSentiment().getTargets()
                .forEach(target -> {
                    builder.addTargets(target);
                });
        }
        return builder.build();
    }

    /**
     * Features.
     *
     * @return the features
     */
    @Bean
    public Features features() {

        Features.Builder builder = new Features.Builder();

        if (this.watsonProperties.isEnableConcepts()) {
            builder = builder.concepts(this.conceptsOptions());
        }
        if (this.watsonProperties.isEnableEntities()) {

            builder = builder.entities(this.entitiesOptions());
        }
        if (this.watsonProperties.isEnableKeywords()) {
            builder = builder.keywords(this.keywordsOptions());
        }
        if (this.watsonProperties.isEnableEmotion()) {
            builder = builder.emotion(this.emotionOptions());
        }
        if (this.watsonProperties.isEnableRelations()) {
            builder = builder.relations(this.relationsOptions());
        }
        if (this.watsonProperties.isEnableSemanticRoles()) {
            builder = builder.semanticRoles(this.semanticRolesOptions());
        }
        if (this.watsonProperties.isEnableSentiment()) {
            builder = builder.sentiment(this.sentimentOptions());
        }

        return builder.build();
    }

    /**
     * Analyze options.
     *
     * @return the analyze options
     */
    @Bean
    public AnalyzeOptions analyzeOptions() {
        AnalyzeOptions.Builder builder = new AnalyzeOptions.Builder()
            .features(this.features());
        if (this.watsonProperties.getAnalyze().getXpath() != null) {
            builder.xpath(this.watsonProperties.getAnalyze().getXpath());
        }
        if (this.watsonProperties.getAnalyze()
            .getReturnAnalyzedText() != null) {
            builder.returnAnalyzedText(
                this.watsonProperties.getAnalyze().getReturnAnalyzedText());
        }
        if (this.watsonProperties.getAnalyze().getLanguage() != null) {
            builder.language(this.watsonProperties.getAnalyze().getLanguage());
        }
        if (this.watsonProperties.getAnalyze().getHtml() != null) {
            builder.html(this.watsonProperties.getAnalyze().getHtml());
        }
        if (this.watsonProperties.getAnalyze()
            .getLimitTextCharacters() != null) {
            builder.limitTextCharacters(
                this.watsonProperties.getAnalyze().getLimitTextCharacters());
        }
        if (this.watsonProperties.getAnalyze().getClean() != null) {
            builder.clean(this.watsonProperties.getAnalyze().getClean());
        }
        if (this.watsonProperties.getAnalyze().getUrl() != null) {
            builder.url(this.watsonProperties.getAnalyze().getUrl());
        }
        if (this.watsonProperties.getAnalyze().getFallbackToRaw() != null) {
            builder.fallbackToRaw(
                this.watsonProperties.getAnalyze().getFallbackToRaw());
        }

        return builder.build();
    }

    /**
     * Natural language understanding.
     *
     * @return the natural language understanding
     * @throws Exception the exception
     */
    @Bean
    public NaturalLanguageUnderstanding naturalLanguageUnderstanding()
            throws Exception {

        final String PROTOCOL = "SSL";
        SSLContext sslContext = SSLContext.getInstance(PROTOCOL);
        KeyManager[] keyManagers = null;
        SecureRandom secureRandom = new SecureRandom();
        sslContext.init(keyManagers, trustManagers, secureRandom);
        SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

        final NaturalLanguageUnderstanding nlu = new NaturalLanguageUnderstanding(
            this.watsonProperties.getVersion(),
            this.watsonProperties.getUsername(),
            this.watsonProperties.getPassword()) {
            @Override
            protected OkHttpClient configureHttpClient() {
                ConnectionPool pool = new ConnectionPool(
                    watsonProperties.getMaxIdleConnections(),
                    watsonProperties.getKeepAliveDuration(),
                    TimeUnit.MILLISECONDS);

                if (watsonProperties.isJmxEnabled()) {
                    createMBean(pool, watsonProperties);
                }

                return super.configureHttpClient().newBuilder()
                    .sslSocketFactory(sslSocketFactory, x509TrustManager)
                    .hostnameVerifier(hostnameVerifier)
                    .readTimeout(
                        watsonProperties.getReadTimeout(),
                        TimeUnit.MILLISECONDS)
                    .connectTimeout(
                        watsonProperties.getConnectTimeout(),
                        TimeUnit.MILLISECONDS)
                    .writeTimeout(
                        watsonProperties.getWriteTimeout(),
                        TimeUnit.MILLISECONDS)
                    .connectionPool(pool).build();
            }

        };
        nlu.setDefaultHeaders(this.watsonProperties.getHeaders());
        return nlu;
    }

    /** Trust All Certificates. */
    private TrustManager[] trustManagers = new TrustManager[] {
        new X509TrustManager() {
            @Override
            public X509Certificate[] getAcceptedIssuers() {
                X509Certificate[] x509Certificates = new X509Certificate[0];
                return x509Certificates;
            }

            @Override
            public void checkServerTrusted(
                final X509Certificate[] chain,
                final String authType) throws CertificateException {
                LOG.debug(
                    "Watson Https: checkServerTrusted : authType: {}",
                    String.valueOf(authType));
            }

            @Override
            public void checkClientTrusted(
                final X509Certificate[] chain,
                final String authType) throws CertificateException {
                LOG.debug(
                    "Watson Https: checkClientTrusted : authType: {}",
                    String.valueOf(authType));
            }
        } };

    /** The x 509 trust manager. */
    private X509TrustManager x509TrustManager = new X509TrustManager() {
        @Override
        public X509Certificate[] getAcceptedIssuers() {
            X509Certificate[] x509Certificates = new X509Certificate[0];
            return x509Certificates;
        }

        @Override
        public void checkServerTrusted(
            final X509Certificate[] chain,
            final String authType) throws CertificateException {
            LOG.debug(
                "Watson Https: checkServerTrusted : authType: {}",
                String.valueOf(authType));
        }

        @Override
        public void checkClientTrusted(
            final X509Certificate[] chain,
            final String authType) throws CertificateException {
            LOG.info(
                "Watson Https: checkClientTrusted : authType: {}",
                String.valueOf(authType));
        }
    };

    /** Accept all host. */
    private HostnameVerifier hostnameVerifier = (hostname, session) -> {
        LOG.debug(
            "Watson Https: hostnameVerifier : hostname: {}",
            String.valueOf(hostname));
        return true;
    };

    private HttpCPInfo createMBean(
            ConnectionPool pool,
            WatsonProperties properties) {
        HttpCPInfo httpCPInfo = new HttpCPInfo(pool, properties);
        try {
            ObjectName name = new ObjectName(
                    "vn.sps.ss.extraction.watson.infrastructure.config:type=CP"
                            + properties.getName());
            mbs.registerMBean(httpCPInfo, name);
        } catch (Exception e) {
            LOG.error("Error when create MBean {}", e);
        }

        return httpCPInfo;
    }


    public class HttpCPInfo implements HttpCPInfoMXBean {

        private final ConnectionPool pool;

        private final WatsonProperties props;

        public HttpCPInfo(ConnectionPool pool, WatsonProperties props) {
            this.pool = pool;
            this.props = props;
        }

        @Override
        public long getConnTimeToLive() {
            return props.getKeepAliveDuration();
        }

        @Override
        public long getDefaultConnectTimeOut() {
            return this.props.getConnectTimeout();
        }

        @Override
        public long getDefaultReadTimeOut() {
            return this.props.getReadTimeout();
        }

        @Override
        public String getConnectionPoolInfo() {
            final String pattern = "Count = %d ; Idle = %d ";
            if (this.pool != null) {
                return String.format(pattern, this.pool.connectionCount(), this.pool.idleConnectionCount());
            }
            return "The connection pool is not configured";
        }

        @Override
        public void changeMaxPerRoute(int max) {
        	//do nothing
        }

        @Override
        public void changeMaxTotal(int max) {
        	//do nothing
        }

    }

}
