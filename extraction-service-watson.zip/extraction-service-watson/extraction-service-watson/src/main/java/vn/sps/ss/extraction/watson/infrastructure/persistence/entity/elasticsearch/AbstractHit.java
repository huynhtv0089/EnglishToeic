/*
 * Class: AbstractHit
 *
 * Created on Oct 14, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch;

import org.elasticsearch.common.document.DocumentField;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public abstract class AbstractHit {

    @JsonProperty(value = "index")
    private String _index;

    @JsonProperty(value = "type")
    private String _type;

    @JsonProperty(value = "id")
    private String _id;

    @JsonProperty(value = "score")
    private Double _score;
    
    @JsonIgnore
    private DocumentField field;

    public String get_index() {
        return _index;
    }

    public void set_index(String _index) {
        this._index = _index;
    }

    public String get_type() {
        return _type;
    }

    public void set_type(String _type) {
        this._type = _type;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public Double get_score() {
        return _score;
    }

    public void set_score(Double _score) {
        this._score = _score;
    }

    public DocumentField getField() {
        return field;
    }

    public void setField(DocumentField field) {
        this.field = field;
    }
    
}
