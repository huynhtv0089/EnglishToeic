/*
 * Class: OCRResponse
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.domain;

import java.util.Map;

/**
 * The Class OCRResponse.
 */
public class OCRResponse {

    /** The result. */
    private Map<String, Object> result;

    /**
     * Gets the result.This might be null in case:<br>
     * <ul>
     * <li>Has just been created</li>
     * <li>No processing result was set</li>
     * </ul>
     *
     * @return the result
     */
    public Map<String, Object> getResult() {
        return result;
    }

    /**
     * Sets the result.
     *
     * @param result the result
     */
    public void setResult(Map<String, Object> result) {
        this.result = result;
    }

}
