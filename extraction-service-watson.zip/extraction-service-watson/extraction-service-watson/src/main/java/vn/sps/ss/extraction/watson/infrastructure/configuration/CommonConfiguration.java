/*
 * Class: CommonConfiguration
 *
 * Created on Jul 3, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.infrastructure.configuration;

import java.time.ZoneId;

import org.apache.commons.lang.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * The Class CommonConfiguration.
 */
@Configuration
@ConfigurationProperties(prefix = "common")
public class CommonConfiguration {

    /**
     * The Constant LOG.
     */
    private static final Logger LOG = LoggerFactory.getLogger(CommonConfiguration.class);

    /**
     * The prefix linux.
     */
    private String prefixLinux;

    /**
     * The prefix windows.
     */
    private String prefixWindows;

    /**
     * The zone id.
     */
    private ZoneId zoneId;

    /**
     * Gets the image dir prefix.
     *
     * @return the image dir prefix
     */
    public String getDirPrefix() {
        return this.isWindows() ? this.getPrefixWindows() : this.getPrefixLinux();
    }

    /**
     * Gets the prefix linux.
     *
     * @return the prefix linux
     */
    private String getPrefixLinux() {
        return this.prefixLinux;
    }

    /**
     * Gets the prefix windows.
     *
     * @return the prefix windows
     */
    private String getPrefixWindows() {
        return this.prefixWindows;
    }

    /**
     * Gets the zone id.
     *
     * @return the zone id
     */
    public ZoneId getZoneId() {
        return this.zoneId;
    }

    /**
     * Checks if is windows.
     *
     * @return true, if is windows
     */
    private boolean isWindows() {
        return SystemUtils.IS_OS_WINDOWS;
    }

    /**
     * Sets the prefix linux.
     *
     * @param prefixLinux the new prefix linux
     */
    public void setPrefixLinux(final String prefixLinux) {
        this.prefixLinux = prefixLinux;
    }

    /**
     * Sets the prefix windows.
     *
     * @param prefixWindows the new prefix windows
     */
    public void setPrefixWindows(final String prefixWindows) {
        this.prefixWindows = prefixWindows;
    }

    /**
     * Sets the zone id.
     *
     * @param zoneId the new zone id
     */
    public void setZoneId(final String zoneId) {
        try {
            this.zoneId = ZoneId.of(zoneId);
        } catch (final Exception e) {
            this.zoneId = ZoneId.systemDefault();
            LOG.warn("Error when initialize the timezone. Use the default system timezone istead", e);
        }
    }
}
