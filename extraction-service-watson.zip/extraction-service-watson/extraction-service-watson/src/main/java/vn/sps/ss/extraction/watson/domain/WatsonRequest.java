/*
 * Class: WatsonRequest
 *
 * Created on Sep 29, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.domain;

public class WatsonRequest extends MeasurableModel {

    private String content;

    private String requestId;

    public WatsonRequest() {
    }

    public WatsonRequest(final String content) {
        this.content = content;
    }

    public String getContent() {
        return this.content;
    }

    public String getRequestId() {
        return this.requestId;
    }

    public void setContent(final String content) {
        this.content = content;
    }

    public void setRequestId(final String requestId) {
        this.requestId = requestId;
    }

}
