/*
 * Class: MeasurableModel
 *
 * Created on Oct 17, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.domain;

/**
 * The Class MeasurableModel.
 */
public abstract class MeasurableModel {

    /** The begin. */
    private long begin;

    /** The end. */
    private long end;

    /**
     * Duration.
     *
     * @return the long
     */
    public long duration() {
        return this.end - this.begin;
    }

    /**
     * Gets the begin.
     *
     * @return the begin
     */
    public long getBegin() {
        return this.begin;
    }

    /**
     * Gets the end.
     *
     * @return the end
     */
    public long getEnd() {
        return this.end;
    }

    /**
     * Sets the begin.
     *
     * @param begin the new begin
     */
    public void setBegin(final long begin) {
        this.begin = begin;
    }

    /**
     * Sets the end.
     *
     * @param end the new end
     */
    public void setEnd(final long end) {
        this.end = end;
    }
}
