/*
 * Class: PdfOCRService
 *
 * Created on Oct 15, 2017
 *
 * (c) Copyright Swiss Post Solution, unpublished work
 * All use, disclosure, and/or reproduction of this material is prohibited
 * unless authorized in writing.  All Rights Reserved.
 * Rights in this program belong to:
 * Swiss Post Solution.
 * Floor 4-5-8, ICT Tower, Quang Trung Software City
 */
package vn.sps.ss.extraction.watson.application.service.ocr.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import vn.sps.ss.extraction.watson.application.common.util.FileUtil;
import vn.sps.ss.extraction.watson.application.common.util.WallClock;
import vn.sps.ss.extraction.watson.domain.OCRRequest;
import vn.sps.ss.extraction.watson.domain.OCRResponse;

/**
 * The Class PdfOCRService.
 */
@Service
public class PdfOCRService {

    /** The Constant LOGGER. */
    private static final Logger LOGGER = LoggerFactory
        .getLogger(PdfOCRService.class);

    /**
     * Do OCR.
     *
     * @param request the request
     * @return the OCR response
     */
    OCRResponse doOCR(final OCRRequest request) {

        final OCRResponse pdfResponse = new OCRResponse();

        try {
            request.setBegin(WallClock.milli());
            final Map<String, Object> result = FileUtil
                .extractTextPdf(request.getInput());
            request.setEnd(WallClock.milli());
            LOGGER.info("Do OCR done in {} ms", request.duration());
            pdfResponse.setResult(result);
        }
        catch (Exception e) {
            LOGGER.error("Error when doing OCR", e);
        }

        return pdfResponse;
    }

}
