package vn.sps.ss.extraction.watson.application.service.correction.filter.impl;

import java.util.HashMap;
import java.util.Map;

import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;

import vn.sps.ss.extraction.watson.application.common.util.Constant.FilterRuleFields;
import vn.sps.ss.extraction.watson.application.service.correction.filter.FilterRuleProvider;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ElasticsearchFilterRuleConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.elasticsearch.FilterRuleHit;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter.FilterRule;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter.Payload;

/**
 * 
 * @author vctoan
 *	This service is used for Elasticsearch 1.4.4
 */

@Service
@Primary
@ConditionalOnProperty(name = "filter.service-class", havingValue = "vn.sps.ss.extraction.watson.application.service.correction.filter.impl.RestFilterImpl")
public class RestFilterImpl implements FilterRuleProvider {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RestFilterImpl.class);
	
	private static final String ONE = "1";
	
	private Map<String, FilterRule> listRule = new HashMap<>();

	@Autowired
	private ElasticsearchFilterRuleConfiguration filterRuleConfiguration;
	
	@Autowired
	@Qualifier("esFilterRestTemplate")
    private RestTemplate restTemplate;

	@Override
	public FilterRule getRule(String merchant) {

		//Check if this rule already existed then return the rule
		if (this.listRule.containsKey(merchant)) {
			return this.listRule.get(merchant);
		}
		
		FilterRule filterRule = null;
		String query = "{\"query\": {\"match\": {\""+ FilterRuleFields.MERCHANT_NAME +"\": {\"query\": \"" + merchant + "\"}}}}";
		//SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		//searchSourceBuilder.query(QueryBuilders.matchQuery(FilterRuleFields.MERCHANT_NAME, merchant));

		// Call elasticsearch with query
		StringBuilder urlBuilder = new StringBuilder(FilterRuleFields.HTTP)
				.append(this.filterRuleConfiguration.getServer())
				.append(FilterRuleFields.SEPARATOR)
				.append(this.filterRuleConfiguration.getIndex())
				.append(FilterRuleFields.SEPARATOR)
				.append(FilterRuleFields.SEARCH);
		
		HttpEntity<String> queryRequest = new HttpEntity<>(query);
		String response = restTemplate.postForObject(urlBuilder.toString(), queryRequest, String.class);

		FilterRuleHit filterRuleHit = null;
		if (!StringUtils.isEmpty(response)) {
			// Convert Json result to java object
			filterRuleHit = convertToObject(response);
		}
		// process merchant rule
		if (filterRuleHit != null) {
			filterRule = processRule(filterRuleHit);
			if (filterRule != null) {
				this.listRule.put(merchant, filterRule);
			}
		}
		return filterRule;
	}
	
	private FilterRuleHit convertToObject(String response) {
		JSONObject jsonObject = null;
		try {
			jsonObject = new JSONObject(response);
			Gson gson = new Gson();
			return gson.fromJson(
					jsonObject.getJSONObject(FilterRuleFields.HITS).getJSONArray(FilterRuleFields.HITS).getJSONObject(0).toString(),
					FilterRuleHit.class);
		} catch (JSONException e) {
			LOGGER.info("Error when convert to Json: ", e);
			return null;
		}
	}
	
	private FilterRule processRule(FilterRuleHit filterRuleHit) {

		final Payload payload = filterRuleHit.getSource().getMerchantNameSuggest().getPayload();

		if (payload == null) {
			return null;
		}

		final FilterRule filterRule = new FilterRule();

		//store rule to track the history
		Gson gson = new Gson();
		filterRule.setRule(gson.toJson(payload));
		// Common
		filterRule.setZip(true);
		filterRule.setMerchantPhone(true);
		filterRule.setPurchaseDate(true);
		filterRule.setPurchaseTime(true);
		filterRule.setTotalPaid(true);
		filterRule.setMerchant(true);
		filterRule.setPaymentMethod(true);
		filterRule.setReceiptType(true);

		// loyalty status
		if (!StringUtils.isEmpty(payload.getLoyaltyStatus()) && ONE.equalsIgnoreCase(payload.getLoyaltyStatus())) {
			filterRule.setLoyalty(true);
		}

		// driverthru
		if (!StringUtils.isEmpty(payload.getDriverthruInclusion()) && ONE.equalsIgnoreCase(payload.getDriverthruInclusion())) {
			filterRule.setServiceType(true);
		}

		// address
		if (!StringUtils.isEmpty(payload.getAddressInclusion()) && ONE.equalsIgnoreCase(payload.getAddressInclusion())) {
			filterRule.setStoreNumber(true);
			filterRule.setCity(true);
			filterRule.setState(true);
			filterRule.setStreetAddress(true);
			filterRule.setHouseNumber(true);
		}

		// order number
		if (!StringUtils.isEmpty(payload.getOrderNumber()) && ONE.equalsIgnoreCase(payload.getOrderNumber())) {
			filterRule.setOrderNumber(true);
		}
		
		return filterRule;
	}
}
