package vn.sps.ss.extraction.watson.application.business.impl;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import vn.sps.ss.extraction.model.ExtractionRequest;
import vn.sps.ss.extraction.model.ExtractionResponse;
import vn.sps.ss.extraction.watson.application.business.OCRHandler;
import vn.sps.ss.extraction.watson.application.business.WatsonExtractionHandler;
import vn.sps.ss.extraction.watson.application.service.files.FileService;
import vn.sps.ss.extraction.watson.application.service.ocr.OCRService;
import vn.sps.ss.extraction.watson.infrastructure.configuration.CommonConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.configuration.FileServiceProperties;
import vn.sps.ss.extraction.watson.infrastructure.configuration.OcrProperties;
import vn.sps.ss.extraction.watson.infrastructure.configuration.TypeProperties;
import vn.sps.ss.extraction.watson.infrastructure.persistence.repository.jpa.ManagementRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OCRHandlerImplTest {

	/*@MockBean
    private OCRHandler ocrHandler;
	
	@MockBean
    private TypeProperties typeProperties;
	
	@MockBean
    private CommonConfiguration configuration;

    *//** The file service. *//*
    @MockBean
    private FileService fileService;

    *//** The file service properties. *//*
    @MockBean
    private FileServiceProperties fileServiceProperties;

    *//** The management repository. *//*
    @MockBean
    private ManagementRepository managementRepository;

    *//** The mapper. *//*
    @MockBean
    private ObjectMapper mapper;

    *//** The ocrservice. *//*
    @MockBean
    private OCRService ocrservice;

    *//** The ocr task executor. *//*
    @MockBean
    private AsyncTaskExecutor ocrTaskExecutor;

    *//** The orc properites. *//*
    @MockBean
    private OcrProperties orcProperites;

    *//** The watson. *//*
    @MockBean
    private WatsonExtractionHandler watson;*/
	
	@Test
	public void testHandleProcessingContext() {
		
		Assert.assertTrue(true);
		/*ExtractionRequest request = new ExtractionRequest();
		request.setId("55507");
		request.setFilePath("/test/extraction/New_trip_level_2017_05_31_16_12_01/70658481.jpg");
		
		ExtractionResponse response = new ExtractionResponse();
		
		ProcessingContext context = new ProcessingContext(request, response);
        context.setTypeProperties(typeProperties);
		String requestId = "55507";
		OCRHandlerImpl ac = new OCRHandlerImpl();
		ac.handle(context);*/
		//ocrHandler.submitItem(requestId, context);
	}

}
