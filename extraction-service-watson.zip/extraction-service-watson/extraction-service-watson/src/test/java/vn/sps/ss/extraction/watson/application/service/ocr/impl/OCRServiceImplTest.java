package vn.sps.ss.extraction.watson.application.service.ocr.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.activation.UnsupportedDataTypeException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import vn.sps.ss.extraction.watson.application.common.util.Constant.MediaType;
import vn.sps.ss.extraction.watson.application.service.ocr.OCRService;
import vn.sps.ss.extraction.watson.domain.OCRRequest;
import vn.sps.ss.extraction.watson.domain.OCRResponse;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource("classpath:application-OCRServiceImpl.properties")
public class OCRServiceImplTest {

	@MockBean
    private ImageService imageOCRService;

	@MockBean
    private PdfOCRService pdfOCRService;
	
	@Autowired
	private OCRService ocrService;
	
	private OCRResponse ocrResponse;
	
	private byte[] fileData = new byte[12];
    
	@Before
	public void setUp() {
		Map<String, Object> result = new HashMap<>();
		result.put("123", new Object());
		ocrResponse = new OCRResponse();
		ocrResponse.setResult(result);
	}
	
	@Test
	public void testDoOcrPdf() {
		OCRRequest request = new OCRRequest();
		request.setInput(fileData);
		try {
			request.setFileType(MediaType.APPLICATION_PDF);
			Mockito.when(pdfOCRService.doOCR(request)).thenReturn(ocrResponse);
			Assert.assertTrue(!CollectionUtils.isEmpty(ocrService.doOCR(request).getResult()));
		} catch (IOException e) {
			e.printStackTrace();
			Assert.fail();
		}
	}
	
	@Test
	public void testDoOcrImg() {
		OCRRequest request = new OCRRequest();
		request.setInput(fileData);
		try {
			request.setFileType(MediaType.IMAGE_JPEG);
			Mockito.when(imageOCRService.doOCR(request)).thenReturn(ocrResponse);
			Assert.assertTrue(!CollectionUtils.isEmpty(ocrService.doOCR(request).getResult()));
		} catch (IOException e) {
			e.printStackTrace();
			Assert.fail();
		}
	}
	
	@Test (expected=UnsupportedDataTypeException.class)
	public void testUnsupportedDataTypeException() throws UnsupportedDataTypeException {
		byte[] fileData = new byte[12];
		OCRRequest request = new OCRRequest();
		request.setInput(fileData);
		request.setFileType("");
		ocrService.doOCR(request);
	}
}
