package vn.sps.ss.extraction.watson.application.service.correction.filter.impl;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import vn.sps.ss.extraction.watson.application.service.correction.filter.FilterRuleProvider;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter.FilterRule;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource("classpath:application-RestFilterImpl.properties")
public class RestFilterImplTest {

	@Autowired
	private FilterRuleProvider filterRuleProvider;

	private FilterRule expect;

	@Before
	public void before() {
		// Aldi rule
		this.expect = new FilterRule();
		this.expect.setZip(true);
		this.expect.setMerchantPhone(true);
		this.expect.setPurchaseDate(true);
		this.expect.setPurchaseTime(true);
		this.expect.setTotalPaid(true);
		this.expect.setMerchant(true);
		this.expect.setPaymentMethod(true);
		this.expect.setReceiptType(true);

		this.expect.setLoyalty(false);
		this.expect.setServiceType(false);
		this.expect.setStoreNumber(false);
		this.expect.setCity(false);
		this.expect.setState(false);
		this.expect.setStreetAddress(false);
		this.expect.setHouseNumber(false);
		this.expect.setOrderNumber(false);
	}

	@Test
	public void testExistenceRule() {
		FilterRule filterRule = filterRuleProvider.getRule("Walmart");

		Assert.assertTrue(filterRule != null);
	}

	@Test
	public void testQualityRule() {
		FilterRule aldiRule = filterRuleProvider.getRule("aldi");
		
		Assert.assertTrue("Status Zip wrong", aldiRule.isZip() == this.expect.isZip());
		Assert.assertTrue("Status Merchant Phone wrong", aldiRule.isMerchantPhone() == this.expect.isMerchantPhone());
		Assert.assertTrue("Status Purchase Date wrong", aldiRule.isPurchaseDate() == this.expect.isPurchaseDate());
		Assert.assertTrue("Status Purchase Time wrong", aldiRule.isPurchaseTime() == this.expect.isPurchaseTime());
		Assert.assertTrue("Status Total Paid wrong", aldiRule.isTotalPaid() == this.expect.isTotalPaid());
		Assert.assertTrue("Status Merchant wrong", aldiRule.isMerchant() == this.expect.isMerchant());
		Assert.assertTrue("Status Payment Method wrong", aldiRule.isPaymentMethod() == this.expect.isPaymentMethod());
		Assert.assertTrue("Status Receipt Type wrong", aldiRule.isReceiptType() == this.expect.isReceiptType());
		Assert.assertTrue("Status Loyayty Card wrong", aldiRule.isLoyalty() == this.expect.isLoyalty());
		Assert.assertTrue("Status Service Type wrong", aldiRule.isServiceType() == this.expect.isServiceType());
		Assert.assertTrue("Status Store Number wrong", aldiRule.isStoreNumber() == this.expect.isStoreNumber());
		Assert.assertTrue("Status City wrong", aldiRule.isCity() == this.expect.isCity());
		Assert.assertTrue("Status State wrong", aldiRule.isState() == this.expect.isState());
		Assert.assertTrue("Status Street Address wrong", aldiRule.isStreetAddress() == this.expect.isStreetAddress());
		Assert.assertTrue(String.format("Status House Number wrong. Expected: %s - Actual: %s", this.expect.isHouseNumber(), aldiRule.isHouseNumber()), aldiRule.isHouseNumber() == this.expect.isHouseNumber());
		Assert.assertTrue(String.format("Status Order Number wrong. Expected: %s - Actual: %s", this.expect.isOrderNumber(), aldiRule.isOrderNumber()), aldiRule.isOrderNumber() == this.expect.isOrderNumber());
	}

}
