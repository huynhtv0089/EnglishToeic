package vn.sps.ss.extraction.watson.application.service.ocr.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import vn.sps.ss.extraction.watson.application.common.util.Constant.MediaType;
import vn.sps.ss.extraction.watson.domain.OCRRequest;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PdfOCRServiceTest {
	
	@Autowired
	private PdfOCRService pdfOCRService;

	@Test
	public void testPdfOCRServiceSuccess() throws IOException {
		
		Path path = Paths.get("Y:", "/test/extraction/New_trip_level_2017_05_31_16_12_01/55565.pdf");
		
		OCRRequest request = new OCRRequest();
		request.setInput(Files.readAllBytes(path));
		request.setFileType(MediaType.APPLICATION_PDF);
		Assert.assertTrue(!CollectionUtils.isEmpty(pdfOCRService.doOCR(request).getResult()));
	}
	
	@Test
	public void testPdfOCRServiceFail() {
		
		OCRRequest request = new OCRRequest();
		request.setInput(new byte[12]);
		request.setFileType(MediaType.APPLICATION_PDF);
		Assert.assertTrue(CollectionUtils.isEmpty(pdfOCRService.doOCR(request).getResult()));
	}
}
