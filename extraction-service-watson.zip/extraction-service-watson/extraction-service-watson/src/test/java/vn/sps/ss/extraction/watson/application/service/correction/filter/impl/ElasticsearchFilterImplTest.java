package vn.sps.ss.extraction.watson.application.service.correction.filter.impl;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import vn.sps.ss.extraction.watson.application.service.correction.filter.FilterRuleProvider;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.filter.FilterRule;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource("classpath:application-ElasticsearchFilterImpl.properties")
public class ElasticsearchFilterImplTest {

	@Autowired
	private FilterRuleProvider filterRuleProvider;

	@Test
	public void testGetRule() {
		FilterRule filterRule = filterRuleProvider.getRule("Walmart");
		
		Assert.assertTrue(filterRule != null);
	}

}
