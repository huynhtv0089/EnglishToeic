package vn.sps.ss.extraction.watson.application.service.ocr.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import vn.sps.ss.extraction.watson.application.common.util.Constant.MediaType;
import vn.sps.ss.extraction.watson.domain.OCRRequest;

@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource("classpath:application-ImageOCRServiceImpl.properties")
public class ImageOCRServiceImplTest {
	
	@Autowired
    private ImageService imageOCRService;

	@Test
	public void testDoOCR() throws IOException {
		Path path = Paths.get("Y:", "/test/extraction/New_trip_level_2017_05_31_16_12_01/55559.jpg");
		
		OCRRequest request = new OCRRequest();
		request.setInput(Files.readAllBytes(path));
		request.setFileType(MediaType.IMAGE_JPEG);
		Assert.assertTrue(!CollectionUtils.isEmpty(imageOCRService.doOCR(request).getResult()));
	}

}
