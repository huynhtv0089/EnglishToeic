package vn.sps.ss.extraction.watson.application.service.correction.processor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.elasticsearch.client.Client;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import vn.sps.ss.extraction.watson.application.service.correction.filter.FilterRuleProvider;
import vn.sps.ss.extraction.watson.domain.CorrectionContext;
import vn.sps.ss.extraction.watson.domain.CorrectionRequest;
import vn.sps.ss.extraction.watson.domain.CorrectionResponse;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ElasticsearchConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.configuration.ElasticsearchValidationConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.configuration.RegexValidationConfiguration;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.EntitiesCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.RelationsCorrectionEntity;
import vn.sps.ss.extraction.watson.infrastructure.persistence.entity.ManagementEntity;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ElasticsearchCorrectionProcessorTest {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ElasticsearchCorrectionProcessorTest.class);

	@Autowired
	private Client client;

	@Autowired
	private ElasticsearchConfiguration configuration;

	@Autowired
	private ElasticsearchValidationConfiguration esValidationConfiguration;

	@Autowired
	private RegexValidationConfiguration regexValidation;

	@MockBean
	private FilterRuleProvider filterRuleProvider;

	private CorrectionProcessor processor;
	
	private ManagementEntity managementEntity;
	
	@Before
	public void setUp() {
		processor = new ElasticsearchCorrectionProcessor(
				new RegCorrectionProcessor(null, this.regexValidation), this.client,
				this.configuration, this.esValidationConfiguration, this.filterRuleProvider);

		managementEntity = new ManagementEntity();

		EntitiesCorrectionEntity correctionEntity = new EntitiesCorrectionEntity();

		correctionEntity.setMerchant("Aldi");

		correctionEntity.setStoreNumber("101");

		correctionEntity.setHouseNumber("1031");

		correctionEntity.setStreetAddress("Volunteer Pzwy");

		correctionEntity.setZip("376q0");

		correctionEntity.setCity("Brzstol");

		correctionEntity.setState("TN");

		correctionEntity.setMerchantPhone("(718) 576 3584");

		correctionEntity.setPurchaseDate("09/17/17");

		correctionEntity.setPurchaseTime("17:37:27");

		correctionEntity.setTotalPaid("123.23");

		correctionEntity.setPaymentMethod("Credit");
		
		correctionEntity.getExtractPaymentMethods().add("US Debit");
		
		correctionEntity.getExtractPaymentMethods().add("Credit");
		
		correctionEntity.setLoyalty("2");
		
		correctionEntity.setOrderNumber("4242423");
		
		RelationsCorrectionEntity itemCorrectionEntity1 = new RelationsCorrectionEntity();
		itemCorrectionEntity1.setItemId("");
		itemCorrectionEntity1.setItemName("3 Pc Pizza Stone");
		
		Map<String, RelationsCorrectionEntity> itemCorrect = new HashMap<>();
		
		itemCorrect.put(itemCorrectionEntity1.getItemId() + itemCorrectionEntity1.getItemName(), itemCorrectionEntity1);
		managementEntity.setItemCorrect(itemCorrect);
		managementEntity.setCorrect(correctionEntity);
	}

	@Test
	public void testCorrection() {

		CorrectionRequest request = new CorrectionRequest("55507", managementEntity);

		CorrectionResponse response = new CorrectionResponse();

		CorrectionContext correct = new CorrectionContext(request, response);

		Mockito.when(filterRuleProvider.getRule(request.getManagement().getCorrect().getMerchant())).thenReturn(null);
		processor.handle(correct);

		EntitiesCorrectionEntity result = correct.getRequest().getManagement().getCorrect();

		// Merchant
		Assert.assertTrue(
				checkFuzzy("Walmart", result.getMerchant(), result.getMerchantConfidence(), result.getMerchantId()));

		// Zip
		Assert.assertTrue(checkFuzzy("37620", result.getZip(), result.getZipConfidence()));

		// City
		Assert.assertTrue(checkFuzzy("Bristol", result.getCity(), result.getCityConfidence()));

		// Store number
		Assert.assertTrue(checkFuzzy("101", result.getStoreNumber(), result.getStoreNumberConfidence()));

		// Street address
		Assert.assertTrue(checkFuzzy("Volunteer Pkwy", result.getStreetAddress(), result.getStreetAddressConfidence()));

		// house number
		Assert.assertTrue(checkFuzzy("1031", result.getHouseNumber(), result.getHouseNumberConfidence()));

		// State
		Assert.assertTrue(checkFuzzy("TN", result.getState(), result.getStateConfidence()));
		
		//Merchant phone
		Assert.assertTrue(checkRegex("7185763584", result.getMerchantPhone()));
		
		//Purchase Date
		Assert.assertTrue(checkRegex("09172017", result.getPurchaseDate()));
		
		//Purchase Time
		Assert.assertTrue(checkRegex("17:37:27", result.getPurchaseTime()));
		
		//Loyalty
		Assert.assertTrue(checkRegex("1", result.getLoyalty()));
		
		//Order number
		Assert.assertTrue(checkRegex("4242423", result.getOrderNumber()));
		
		//Total paid
		Assert.assertTrue(checkRegex("123.23", result.getTotalPaid()));
	}

	private boolean checkFuzzy(String expect, String actual, String actualConfidence) {
		if (!expect.equalsIgnoreCase(actual))
			return false;
		if (levenshteinDistance(expect, actual) > 2)
			return false;
		if (Integer.parseInt(actualConfidence) < this.esValidationConfiguration.getMinConfidence())
			return false;
		return true;
	}
	
	private boolean checkFuzzy(String expect, String actual, String actualConfidence, String actualId) {
		if (actualId == null)
			return false;
		return checkFuzzy(expect, actual, actualConfidence);
	}
	
	private boolean checkRegex(String expect, String actual) {
		if (!expect.equalsIgnoreCase(actual))
			return false;
		return true;
	}
	
	public static int levenshteinDistance(String x, String y) {
	    int[][] dp = new int[x.length() + 1][y.length() + 1];
	 
	    for (int i = 0; i <= x.length(); i++) {
	        for (int j = 0; j <= y.length(); j++) {
	            if (i == 0) {
	                dp[i][j] = j;
	            }
	            else if (j == 0) {
	                dp[i][j] = i;
	            }
	            else {
	                dp[i][j] = min(dp[i - 1][j - 1] 
	                 + costOfSubstitution(x.charAt(i - 1), y.charAt(j - 1)), 
	                  dp[i - 1][j] + 1, 
	                  dp[i][j - 1] + 1);
	            }
	        }
	    }
	 
	    return dp[x.length()][y.length()];
	}
	
	public static int costOfSubstitution(char a, char b) {
        return a == b ? 0 : 1;
    }
 
    public static int min(int... numbers) {
        return Arrays.stream(numbers)
          .min().orElse(Integer.MAX_VALUE);
    }
}
