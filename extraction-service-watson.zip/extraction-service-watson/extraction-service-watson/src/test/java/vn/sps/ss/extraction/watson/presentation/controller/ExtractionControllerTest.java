package vn.sps.ss.extraction.watson.presentation.controller;

import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import vn.sps.ss.extraction.watson.application.business.OCRHandler;
import vn.sps.ss.extraction.watson.infrastructure.configuration.TypeProperties;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ExtractionControllerTest {

    private MockMvc mockMvc;
	
	@MockBean
    private OCRHandler ocrHandler;
	
	@MockBean
    private TypeProperties typeProperties;

	private String successMsg;
	
	private String requestId;
	
	@Autowired
	private ExtractionController extractionControllerTest;
	
	@Before
	public void setUp() {
		this.requestId = "55507";
		this.successMsg = "The request " + this.requestId + " has been queued for later processing.";
		mockMvc = standaloneSetup(extractionControllerTest).build();
	}
	
	@Test
	public void testExtract() {
		
		String example = "{\r\n" + 
				"	\"id\" : \"55507\",\r\n" + 
				"	\"filePath\" : \"/test/extraction/New_trip_level_2017_05_31_16_12_01/70658481.jpg\"\r\n" + 
				"\r\n" + 
				"}";
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/extract")
				.accept(MediaType.APPLICATION_JSON).content(example)
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result;
		try {
			result = mockMvc.perform(requestBuilder).andReturn();
			
			MockHttpServletResponse response = result.getResponse();

			//Check status
			Assert.assertEquals(HttpStatus.OK.value(), response.getStatus());
			
			//Check message
			//Assert.assertEquals(this.successMsg, response.getContentAsString());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
