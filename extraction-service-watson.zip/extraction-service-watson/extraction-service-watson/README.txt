-- Start App in eclipse:
- Program arguments: --spring.config.location=classpath:config/cache-config.properties
- VM arguments: -Dcom.sun.management.jmxremote 
				-Dcom.sun.management.jmxremote.authenticate=false 
				-Dcom.sun.management.jmxremote.local.only=false
				-Dcom.sun.management.jmxremote.ssl=false 
				-Dcom.sun.management.jmxremote.port=5000
				-Djava.rmi.server.hostname=YOUR_IP


-- Prepare ES:
- Run 2 script in script folder: levenshtein distance for array.txt and levenshtein distance for field.txt
- Add config: script.painless.regex.enabled = true in elasticsearch.yaml