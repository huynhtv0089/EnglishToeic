package vn.sps.ss.extraction.model.item;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ 
	"itemName", 
	"itemId", 
	"itemPrice", 
	"itemQuantity", 
	"itemType", 
	"itemTypeId", 
	"itemUnit",
	"itemUnitId" 
})
public class ExtractItemBoundaryDetails {

	@JsonProperty("itemName")
	private ExtractItemCoordinate[] itemName;

	@JsonProperty("itemId")
	private ExtractItemCoordinate[] itemId;

	@JsonProperty("itemPrice")
	private ExtractItemCoordinate[] itemPrice;

	@JsonProperty("itemQuantity")
	private ExtractItemCoordinate[] itemQuantity;

	@JsonProperty("itemType")
	private ExtractItemCoordinate[] itemType;

	@JsonProperty("itemUnit")
	private ExtractItemCoordinate[] itemUnit;

	public ExtractItemCoordinate[] getItemName() {
		return itemName;
	}

	public void setItemName(ExtractItemCoordinate[] itemName) {
		this.itemName = itemName;
	}

	public ExtractItemCoordinate[] getItemId() {
		return itemId;
	}

	public void setItemId(ExtractItemCoordinate[] itemId) {
		this.itemId = itemId;
	}

	public ExtractItemCoordinate[] getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(ExtractItemCoordinate[] itemPrice) {
		this.itemPrice = itemPrice;
	}

	public ExtractItemCoordinate[] getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(ExtractItemCoordinate[] itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public ExtractItemCoordinate[] getItemType() {
		return itemType;
	}

	public void setItemType(ExtractItemCoordinate[] itemType) {
		this.itemType = itemType;
	}

	public ExtractItemCoordinate[] getItemUnit() {
		return itemUnit;
	}

	public void setItemUnit(ExtractItemCoordinate[] itemUnit) {
		this.itemUnit = itemUnit;
	}
}
