package vn.sps.ss.extraction.model.extract;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "boundary"
})
public class ExtractTripAsset {

    @JsonProperty("boundary")
    private ExtractTripBoundaryDetails boundary;

	public ExtractTripBoundaryDetails getBoundary() {
		return boundary;
	}

	public void setBoundary(ExtractTripBoundaryDetails boundary) {
		this.boundary = boundary;
	}
}
