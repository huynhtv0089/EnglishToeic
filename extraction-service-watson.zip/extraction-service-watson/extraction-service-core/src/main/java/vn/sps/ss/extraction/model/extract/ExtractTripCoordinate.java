package vn.sps.ss.extraction.model.extract;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "x",
        "y",
        "x1",
        "y1",
        "x2",
        "y2",
        "x3",
        "y3"
})
public class ExtractTripCoordinate {
	
	@JsonProperty("x")
    private int x;

    @JsonProperty("y")
    private int y;

    @JsonProperty("x1")
    private int x1;

    @JsonProperty("y1")
    private int y1;

    @JsonProperty("x2")
    private int x2;

    @JsonProperty("y2")
    private int y2;

    @JsonProperty("x3")
    private int x3;

    @JsonProperty("y3")
    private int y3;

	public ExtractTripCoordinate() {
		
	}

	public ExtractTripCoordinate(int x, int y, int x1, int y1, int x2, int y2, int x3, int y3) {
		this.x = x;
		this.y = y;
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.x3 = x3;
		this.y3 = y3;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getX1() {
		return x1;
	}

	public void setX1(int x1) {
		this.x1 = x1;
	}

	public int getY1() {
		return y1;
	}

	public void setY1(int y1) {
		this.y1 = y1;
	}

	public int getX2() {
		return x2;
	}

	public void setX2(int x2) {
		this.x2 = x2;
	}

	public int getY2() {
		return y2;
	}

	public void setY2(int y2) {
		this.y2 = y2;
	}

	public int getX3() {
		return x3;
	}

	public void setX3(int x3) {
		this.x3 = x3;
	}

	public int getY3() {
		return y3;
	}

	public void setY3(int y3) {
		this.y3 = y3;
	}

	@Override
	public String toString() {
		return "ExtractTripBoundary [x=" + x + ", y=" + y + ", x1=" + x1 + ", y1=" + y1 + ", x2=" + x2 + ", y2=" + y2
				+ ", x3=" + x3 + ", y3=" + y3 + "]";
	}
}