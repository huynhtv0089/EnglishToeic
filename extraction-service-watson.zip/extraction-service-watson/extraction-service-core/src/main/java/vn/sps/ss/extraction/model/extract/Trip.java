package vn.sps.ss.extraction.model.extract;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "entries"
})
public class Trip {
    @JsonProperty("entries")
    private ExtractTripEntries entries;

    @JsonProperty("entries")
    public ExtractTripEntries getEntries() {
        return entries;
    }

    @JsonProperty("entries")
    public void setEntries(ExtractTripEntries entries) {
        this.entries = entries;
    }
}
