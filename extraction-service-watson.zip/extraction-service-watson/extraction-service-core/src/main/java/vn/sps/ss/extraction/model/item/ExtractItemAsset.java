package vn.sps.ss.extraction.model.item;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "boundary"
})
public class ExtractItemAsset {

    @JsonProperty("boundary")
    private ExtractItemBoundaryDetails boundary;

	public ExtractItemBoundaryDetails getBoundary() {
		return boundary;
	}

	public void setBoundary(ExtractItemBoundaryDetails boundary) {
		this.boundary = boundary;
	}
}
