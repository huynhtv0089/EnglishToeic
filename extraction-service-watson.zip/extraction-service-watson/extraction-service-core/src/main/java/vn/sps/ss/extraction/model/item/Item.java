package vn.sps.ss.extraction.model.item;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "entries"
})
public class Item {
    @JsonProperty("entries")
    private ExtractItemEntries items;

    @JsonProperty("entries")
    public ExtractItemEntries getItems() {
        return items;
    }

    @JsonProperty("entries")
    public void setItems(ExtractItemEntries items) {
        this.items = items;
    }
}
