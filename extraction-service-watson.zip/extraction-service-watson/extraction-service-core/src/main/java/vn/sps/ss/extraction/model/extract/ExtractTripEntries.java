package vn.sps.ss.extraction.model.extract;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "data",
        "asset"
})
public class ExtractTripEntries {


    @JsonProperty("data")
    private ExtractTripData[] data;
    
    @JsonProperty("asset")
    private ExtractTripAsset[] asset;

    @JsonProperty("data")
    public ExtractTripData[] getData() {
        return data;
    }

    @JsonProperty("data")
    public void setData(ExtractTripData[] data) {
        this.data = data;
    }

	public ExtractTripAsset[] getAsset() {
		return asset;
	}

	public void setAsset(ExtractTripAsset[] asset) {
		this.asset = asset;
	}
}
