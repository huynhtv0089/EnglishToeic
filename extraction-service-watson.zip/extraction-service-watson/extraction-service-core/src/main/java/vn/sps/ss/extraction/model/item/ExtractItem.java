package vn.sps.ss.extraction.model.item;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ 
	"data", 
	"asset"
	})
public class ExtractItem {

	@JsonProperty("data")
	private ExtractItemData[] data;

	@JsonProperty("asset")
	private ExtractItemAsset[] asset;

	@JsonProperty("data")
	public ExtractItemData[] getData() {
		return data;
	}

	@JsonProperty("data")
	public void setData(ExtractItemData[] data) {
		this.data = data;
	}

	public ExtractItemAsset[] getAsset() {
		return asset;
	}

	public void setAsset(ExtractItemAsset[] asset) {
		this.asset = asset;
	}
}
