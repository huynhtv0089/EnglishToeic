package vn.sps.ss.extraction.model.item;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "items"
})
public class ExtractItemEntries {


    @JsonProperty("items")
    private ExtractItem[] items;


    @JsonProperty("items")
    public ExtractItem[] getItems() {
        return items;
    }


    @JsonProperty("items")
    public void setItems(ExtractItem[] items) {
        this.items = items;
    }
}
