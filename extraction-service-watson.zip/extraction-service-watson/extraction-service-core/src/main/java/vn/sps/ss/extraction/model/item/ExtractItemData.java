package vn.sps.ss.extraction.model.item;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "itemName",
        "itemId",
        "itemPrice",
        "itemQuantity",
        "itemType",
        "itemTypeId",
        "itemUnit",
        "itemUnitId"
})
public class ExtractItemData {

	@JsonProperty("itemName")
	private String itemName;

	@JsonProperty("itemId")
	private String itemId;

	@JsonProperty("itemPrice")
	private String itemPrice;

	@JsonProperty("itemQuantity")
	private String itemQuantity;

	@JsonProperty("itemType")
	private String itemType;
	
	@JsonProperty("itemTypeId")
	private String itemTypeId;

	@JsonProperty("itemUnit")
	private String itemUnit;
	
	@JsonProperty("itemUnitId")
	private String itemUnitId;

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(String itemPrice) {
		this.itemPrice = itemPrice;
	}

	public String getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(String itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public String getItemUnit() {
		return itemUnit;
	}

	public void setItemUnit(String itemUnit) {
		this.itemUnit = itemUnit;
	}

	public String getItemTypeId() {
		return itemTypeId;
	}

	public void setItemTypeId(String itemTypeId) {
		this.itemTypeId = itemTypeId;
	}

	public String getItemUnitId() {
		return itemUnitId;
	}

	public void setItemUnitId(String itemUnitId) {
		this.itemUnitId = itemUnitId;
	}

	@Override
	public String toString() {
		return "ExtractItem [itemName=" + itemName + ", itemId=" + itemId + ", itemPrice=" + itemPrice
				+ ", itemQuantity=" + itemQuantity + ", itemType=" + itemType + ", itemTypeId=" + itemTypeId
				+ ", itemUnit=" + itemUnit + ", itemUnitId=" + itemUnitId + "]";
	}
}
