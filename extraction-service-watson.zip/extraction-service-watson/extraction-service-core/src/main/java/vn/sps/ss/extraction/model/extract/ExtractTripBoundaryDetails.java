package vn.sps.ss.extraction.model.extract;


import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "zip",
        "ext_merchantname",
        "city",
        "loyalty",
        "storenumber",
        "paymentmethoddesc",
        "purchasetime",
        "receiptypedesc",
        "servicetype",
        "totalpaid",
        "purchasedate",
        "housenumber",
        "ordernumber",
        "streetaddress",
        "state",
        "merchantphone"
})
public class ExtractTripBoundaryDetails {

    @JsonProperty("address")
    private ExtractTripCoordinate[] address;

    @JsonProperty("city")
    private ExtractTripCoordinate[] city;

    @JsonProperty("housenumber")
    private ExtractTripCoordinate[] housenumber;

    @JsonProperty("loyalty")
    private ExtractTripCoordinate[] loyalty;

    @JsonProperty("ext_merchantname")
    private ExtractTripCoordinate[] merchantname;

    @JsonProperty("merchantphone")
    private ExtractTripCoordinate[] merchantphone;

    @JsonProperty("ordernumber")
    private ExtractTripCoordinate[] ordernumber;

    @JsonProperty("paymentmethoddesc")
    private ExtractTripCoordinate[] paymentmethoddesc;

    @JsonProperty("purchasedate")
    private ExtractTripCoordinate[] purchasedate;

    @JsonProperty("purchasetime")
    private ExtractTripCoordinate[] purchasetime;

    @JsonProperty("receiptypedesc")
    private ExtractTripCoordinate[] receiptypedesc;

    @JsonProperty("servicetype")
    private ExtractTripCoordinate[] servicetype;

    @JsonProperty("state")
    private ExtractTripCoordinate[] state;

    @JsonProperty("storenumber")
    private ExtractTripCoordinate[] storenumber;

    @JsonProperty("totalpaid")
    private ExtractTripCoordinate[] totalpaid;

    @JsonProperty("zip")
    private ExtractTripCoordinate[] zip;

	public ExtractTripCoordinate[] getAddress() {
		return address;
	}

	public void setAddress(ExtractTripCoordinate[] address) {
		this.address = address;
	}

	public ExtractTripCoordinate[] getCity() {
		return city;
	}

	public void setCity(ExtractTripCoordinate[] city) {
		this.city = city;
	}

	public ExtractTripCoordinate[] getHousenumber() {
		return housenumber;
	}

	public void setHousenumber(ExtractTripCoordinate[] housenumber) {
		this.housenumber = housenumber;
	}

	public ExtractTripCoordinate[] getLoyalty() {
		return loyalty;
	}

	public void setLoyalty(ExtractTripCoordinate[] loyalty) {
		this.loyalty = loyalty;
	}

	public ExtractTripCoordinate[] getMerchantname() {
		return merchantname;
	}

	public void setMerchantname(ExtractTripCoordinate[] merchantname) {
		this.merchantname = merchantname;
	}

	public ExtractTripCoordinate[] getMerchantphone() {
		return merchantphone;
	}

	public void setMerchantphone(ExtractTripCoordinate[] merchantphone) {
		this.merchantphone = merchantphone;
	}

	public ExtractTripCoordinate[] getOrdernumber() {
		return ordernumber;
	}

	public void setOrdernumber(ExtractTripCoordinate[] ordernumber) {
		this.ordernumber = ordernumber;
	}

	public ExtractTripCoordinate[] getPaymentmethoddesc() {
		return paymentmethoddesc;
	}

	public void setPaymentmethoddesc(ExtractTripCoordinate[] paymentmethoddesc) {
		this.paymentmethoddesc = paymentmethoddesc;
	}

	public ExtractTripCoordinate[] getPurchasedate() {
		return purchasedate;
	}

	public void setPurchasedate(ExtractTripCoordinate[] purchasedate) {
		this.purchasedate = purchasedate;
	}

	public ExtractTripCoordinate[] getPurchasetime() {
		return purchasetime;
	}

	public void setPurchasetime(ExtractTripCoordinate[] purchasetime) {
		this.purchasetime = purchasetime;
	}

	public ExtractTripCoordinate[] getReceiptypedesc() {
		return receiptypedesc;
	}

	public void setReceiptypedesc(ExtractTripCoordinate[] receiptypedesc) {
		this.receiptypedesc = receiptypedesc;
	}

	public ExtractTripCoordinate[] getServicetype() {
		return servicetype;
	}

	public void setServicetype(ExtractTripCoordinate[] servicetype) {
		this.servicetype = servicetype;
	}

	public ExtractTripCoordinate[] getState() {
		return state;
	}

	public void setState(ExtractTripCoordinate[] state) {
		this.state = state;
	}

	public ExtractTripCoordinate[] getStorenumber() {
		return storenumber;
	}

	public void setStorenumber(ExtractTripCoordinate[] storenumber) {
		this.storenumber = storenumber;
	}

	public ExtractTripCoordinate[] getTotalpaid() {
		return totalpaid;
	}

	public void setTotalpaid(ExtractTripCoordinate[] totalpaid) {
		this.totalpaid = totalpaid;
	}

	public ExtractTripCoordinate[] getZip() {
		return zip;
	}

	public void setZip(ExtractTripCoordinate[] zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "ExtractTripBoundaryDetails [address=" + Arrays.toString(address) + ", city=" + Arrays.toString(city)
				+ ", housenumber=" + Arrays.toString(housenumber) + ", loyalty=" + Arrays.toString(loyalty)
				+ ", merchantname=" + Arrays.toString(merchantname) + ", merchantphone="
				+ Arrays.toString(merchantphone) + ", ordernumber=" + Arrays.toString(ordernumber)
				+ ", paymentmethoddesc=" + Arrays.toString(paymentmethoddesc) + ", purchasedate="
				+ Arrays.toString(purchasedate) + ", purchasetime=" + Arrays.toString(purchasetime)
				+ ", receiptypedesc=" + Arrays.toString(receiptypedesc) + ", servicetype="
				+ Arrays.toString(servicetype) + ", state=" + Arrays.toString(state) + ", storenumber="
				+ Arrays.toString(storenumber) + ", totalpaid=" + Arrays.toString(totalpaid) + ", zip="
				+ Arrays.toString(zip) + "]";
	}
}
