package vn.sps.ss.extraction.model;

public class ItemExtract {

    private String text;

    private String confidence;

    public ItemExtract() {
    }

    public ItemExtract(String text, String confidence) {
        this.text = text;
        this.confidence = confidence;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getConfidence() {
        return confidence;
    }

    public void setConfidence(String confidence) {
        this.confidence = confidence;
    }

}
