package vn.sps.ss.extraction.model.extract;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "zip",
        "ext_merchantname",
        "city",
        "loyalty",
        "storenumber",
        "paymentmethoddesc",
        "purchasetime",
        "receiptypedesc",
        "servicetype",
        "totalpaid",
        "purchasedate",
        "housenumber",
        "ordernumber",
        "streetaddress",
        "state",
        "merchantphone",
        "merchantId",
        "paymentMethodId"
})
public class ExtractTripData {

    @JsonProperty("streetaddress")
    private String address;

    @JsonProperty("city")
    private String city;

    @JsonProperty("housenumber")
    private String houseNumber;

    @JsonProperty("loyalty")
    private String loyaltyCard;

    @JsonProperty("ext_merchantname")
    private String merchant;

    @JsonProperty("merchantphone")
    private String merchantPhone;

    @JsonProperty("ordernumber")
    private String orderNumber;

    @JsonProperty("paymentmethoddesc")
    private String paymentMethod;

    @JsonProperty("purchasedate")
    private String purchaseDate;

    @JsonProperty("purchasetime")
    private String purchaseTime;

    @JsonProperty("receiptypedesc")
    private String receiptType;

    @JsonProperty("servicetype")
    private String serviceType;

    @JsonProperty("state")
    private String state;

    @JsonProperty("storenumber")
    private String storeNumber;

    @JsonProperty("totalpaid")
    private String totalPaid; 

    @JsonProperty("zip")
    private String zip;
    
    @JsonProperty("merchantId")
    private String merchantId;
    
    @JsonProperty("paymentMethodId")
    private String paymentMethodId;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getLoyaltyCard() {
        return loyaltyCard;
    }

    public void setLoyaltyCard(String loyaltyCard) {
        this.loyaltyCard = loyaltyCard;
    }

    public String getMerchant() {
        return merchant;
    }

    public void setMerchant(String merchant) {
        this.merchant = merchant;
    }

    public String getMerchantPhone() {
        return merchantPhone;
    }

    public void setMerchantPhone(String merchantPhone) {
        this.merchantPhone = merchantPhone;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getPurchaseTime() {
        return purchaseTime;
    }

    public void setPurchaseTime(String purchaseTime) {
        this.purchaseTime = purchaseTime;
    }

    public String getReceiptType() {
        return receiptType;
    }

    public void setReceiptType(String receiptType) {
        this.receiptType = receiptType;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getStoreNumber() {
        return storeNumber;
    }

    public void setStoreNumber(String storeNumber) {
        this.storeNumber = storeNumber;
    }

    public String getTotalPaid() {
        return totalPaid;
    }

    public void setTotalPaid(String totalPaid) {
        this.totalPaid = totalPaid;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }
    
    public String getMerchantId() {
    	return merchantId;
    }
    
    public void setMerchantId(String merchantId) {
    	this.merchantId = merchantId;
    }
    
    public String getPaymentMethodId() {
    	return paymentMethodId;
    }
    
    public void setPaymentMethodId(String paymentMethodId) {
    	this.paymentMethodId = paymentMethodId;
    }
    
    @Override
    public String toString() {
        return "ExtractData{" +
                "address='" + address + '\'' +
                ", city='" + city + '\'' +
                ", houseNumber='" + houseNumber + '\'' +
                ", loyaltyCard='" + loyaltyCard + '\'' +
                ", merchant='" + merchant + '\'' +
                ", merchantPhone='" + merchantPhone + '\'' +
                ", orderNumber='" + orderNumber + '\'' +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", purchaseDate='" + purchaseDate + '\'' +
                ", purchaseTime='" + purchaseTime + '\'' +
                ", receiptType='" + receiptType + '\'' +
                ", serviceType='" + serviceType + '\'' +
                ", state='" + state + '\'' +
                ", storeNumber='" + storeNumber + '\'' +
                ", totalPaid='" + totalPaid + '\'' +
                ", merchantId='" + merchantId + '\'' +
                ", paymentMethodId='" + paymentMethodId + '\'' +
                '}';
    }
}
