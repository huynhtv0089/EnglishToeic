package vn.sps.ss.extraction.model;

public class ReceiptRequest {

	private String requestId;
	
	public ReceiptRequest() {
	}
	
	public ReceiptRequest(String requestId) {
		this.requestId = requestId;
	}

	public String getRequestId() {
		return requestId;
	}

}
