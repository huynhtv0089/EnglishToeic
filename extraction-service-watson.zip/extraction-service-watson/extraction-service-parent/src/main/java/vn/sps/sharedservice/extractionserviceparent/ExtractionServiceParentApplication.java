package vn.sps.sharedservice.extractionserviceparent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExtractionServiceParentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExtractionServiceParentApplication.class, args);
	}
}
