import { Component, OnInit } from '@angular/core';
import { Hero } from './hero';
import { HeroService } from './hero.service';

@Component({
    selector: 'dashboard',
    template:   `
                    <h3>Top Heros</h3>
                    <div class="grid grid-pad">
                        <a class="col-1-4" *ngFor="let hero of topHeros">
                            <div class="module hero">  
                                <h4>{{ hero.name }}</h4>
                            </div>
                        </a>
                    </div>
                    <!--<search-hero [hero]="topHeros"></search-hero>-->
                `,
    styleUrls: ['./dashboard.component.css']  
})
export class DashboardComponent {
    topHeros: Hero[];
    constructor(private heroService: HeroService){}

    ngOnInit() {
        this.heroService.getHeros().subscribe(data => this.topHeros = data.slice(1,5));
    }


}