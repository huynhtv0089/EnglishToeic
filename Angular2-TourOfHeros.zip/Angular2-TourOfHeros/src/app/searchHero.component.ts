import { Component, Input } from '@angular/core';
import { Hero } from './hero'

@Component({
    selector: 'search-hero',
    template:   `
                    <h3>Hero Search</h3>
                    <form>
                        <input type="text" [(ngModel)]="hero.name" name="hero">
                    </form>
                `
})
export class SearchHeroComponent {
    @Input() hero: Hero[];
}