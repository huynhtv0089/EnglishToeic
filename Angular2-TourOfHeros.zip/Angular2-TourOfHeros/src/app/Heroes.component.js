"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var hero_service_1 = require("./hero.service");
var HeroesComponent = (function () {
    function HeroesComponent(heroService, router) {
        this.heroService = heroService;
        this.router = router;
    }
    HeroesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.heroService.getHeros().subscribe(function (data) { return _this.heroes = data; });
    };
    HeroesComponent.prototype.selectHero = function (hero) {
        this.selectedHero = hero;
    };
    HeroesComponent.prototype.redirectToHero = function (id) {
        this.router.navigate(['/heros', id]);
    };
    return HeroesComponent;
}());
HeroesComponent = __decorate([
    core_1.Component({
        selector: 'heroes',
        template: "\n                    <h2>My Herors</h2>\n                    <div>\n                        <label>Hero name: </label> <input type=\"text\" >\n                        <button>Add</button>\n                    </div>\n                    <ul class=\"heroes\">\n                        <li *ngFor=\"let hero of heroes\" (click)=\"selectHero(hero)\">\n                            <span class=\"badge\">{{ hero.id }}</span>\n                            <span>{{ hero.name }}</span>\n                            <button class=\"delete\">x</button>\n                        </li>\n                    </ul>\n\n                    <div *ngIf=\"selectedHero\">\n                        <h2>{{selectedHero.name}} is my hero</h2>\n                        <button (click)=\"redirectToHero(selectedHero.id)\">View Details</button>\n                    </div>\n                ",
        styleUrls: ['./Heroes.component.css']
    }),
    __metadata("design:paramtypes", [hero_service_1.HeroService, router_1.Router])
], HeroesComponent);
exports.HeroesComponent = HeroesComponent;
//# sourceMappingURL=heroes.component.js.map