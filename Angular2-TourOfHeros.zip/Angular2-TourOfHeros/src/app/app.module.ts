import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';

import { routes } from './app.route'

import { AppComponent }  from './app.component';
import { DashboardComponent }  from './dashboard.component';
import { SearchHeroComponent }  from './searchHero.component';
import { HeroesComponent }  from './heroes.component';
import { HeroDetailComponent }  from './hero-detail.component';

@NgModule({
  imports:      [ BrowserModule, HttpModule, FormsModule, routes ],
  declarations: [ AppComponent, DashboardComponent, SearchHeroComponent, HeroesComponent, HeroDetailComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
