"use strict";
//# sourceMappingURL=hero.component.js.map