import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { HeroesComponent } from './heroes.component';
import { HeroDetailComponent } from './hero-detail.component';

const route: Routes = [
    {
        path: 'dashboard',
        component: DashboardComponent
    },
    {
        path: 'heros',
        component: HeroesComponent
    },
    {
        path: 'heros/:id',
        component: HeroDetailComponent
    },
    {
        path: '',
        redirectTo: '/dashboard',
        pathMatch: 'full'
    }
];

export const routes = RouterModule.forRoot(route);