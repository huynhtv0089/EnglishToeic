import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute }  from '@angular/router'
import { HeroService } from './hero.service';
import { Hero } from './hero';

@Component({
    selector: 'hero-detail',
    template:   `
                    <div *ngIf="hero">
                        <h2>{{ hero.name }} details!</h2>
                        <div><label>id: </label> {{ hero.id }}</div>
                        <div>
                            <label>name: </label> <input type="text" placeholder="name" [(ngModel)]="hero.name" />
                        </div>
                        <button>Back</button>
                        <button>Save</button>
                    </div> 
                `,
    styleUrls: ['./hero-detail.component.css']
})
export class HeroDetailComponent implements OnInit {
    hero: Hero;
    sub: any;
    constructor(private heroService: HeroService, private router: Router, private activatedRoute: ActivatedRoute) {

    }

    ngOnInit() {
        //this.hero = this.heroService.getHeros();
        this.activatedRoute.params.subscribe(params => {
            //console.log('param: ' + params);
            let id = Number.parseInt(params['id']);
            this.hero = this.heroService.getHero(id);
            console.log('hero: ' + this.hero);
        });
    }
}