import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { Hero } from './hero';
import { HeroService } from './hero.service';

@Component({
    selector: 'heroes',
    template:   `
                    <h2>My Herors</h2>
                    <div>
                        <label>Hero name: </label> <input type="text" >
                        <button>Add</button>
                    </div>
                    <ul class="heroes">
                        <li *ngFor="let hero of heroes" (click)="selectHero(hero)">
                            <span class="badge">{{ hero.id }}</span>
                            <span>{{ hero.name }}</span>
                            <button class="delete">x</button>
                        </li>
                    </ul>

                    <div *ngIf="selectedHero">
                        <h2>{{selectedHero.name}} is my hero</h2>
                        <button (click)="redirectToHero(selectedHero.id)">View Details</button>
                    </div>
                `,
    styleUrls: ['./Heroes.component.css']
})
export class HeroesComponent {
    heroes: Hero[];
    selectedHero: Hero;

    constructor(private heroService: HeroService, private router: Router) {}

    ngOnInit() {
        this.heroService.getHeros().subscribe(data => this.heroes = data);
    }

    selectHero(hero: Hero) {
        this.selectedHero = hero; 
    }

    redirectToHero(id: number) {
        this.router.navigate(['/heros', id]);
    }
}