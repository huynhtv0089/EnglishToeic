shopApp.service('AppService', [function(){
	this.dataProduction = function() {
		return  [
			{
				'image' : 'product12.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product11.jpg',
				'price' : 57,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product10.jpg',
				'price' : 58,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product9.jpg',
				'price' : 59,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product8.jpg',
				'price' : 55,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product7.jpg',
				'price' : 54,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product6.jpg',
				'price' : 53,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product5.jpg',
				'price' : 52,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product4.jpg',
				'price' : 51,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product3.jpg',
				'price' : 60,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product2.jpg',
				'price' : 61,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product1.jpg',
				'price' : 62,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			}		
		]; 
	}

	this.dataFeaturesItems = function() {
		return [
			{
				'image' : 'product1.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
				'newProduct' : ''
			},
			{
				'image' : 'product2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
				'newProduct' : ''
			},
			{
				'image' : 'product3.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#'
			},
			{
				'image' : 'product4.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
				'newProduct' : 'new.png'
			},
			{
				'image' : 'product5.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
				'newProduct' : ''
			},
			{
				'image' : 'product6.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
				'newProduct' : ''
			}
		];
	}

	this.dataTShirt = function() {
		return [
			{
				'image' : 'gallery1.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery1.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataBlazers = function() {
		return [
			{
				'image' : 'gallery4.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery1.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataSunglass = function() {
		return [
			{
				'image' : 'gallery3.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery1.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataKids = function() {
		return [
			{
				'image' : 'gallery1.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery1.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataPoloShirt = function() {
		return [
			{
				'image' : 'gallery2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery3.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery1.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'gallery4.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataRecommendedItems = function() {
		return [
			{
				'image' : 'recommend1.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'recommend2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'recommend3.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			},
			{
				'image' : 'recommend2.jpg',
				'price' : 56,
				'nameProduct' : 'Easy Polo Black Edition',
				'urlProduct' : '#',
			}
		];
	}

	this.dataCategory = function() {
		return [
			{'name': 'Sportswear', 'url': '#'},
			{'name': 'Men', 'url': '#'},
			{'name': 'Kids', 'url': '#'},
			{'name': 'Fashion', 'url': '#'},
			{'name': 'Households', 'url': '#'},
			{'name': 'Interiors', 'url': '#'},
			{'name': 'Clothing', 'url': '#'},
			{'name': 'Bags', 'url': '#'},
			{'name': 'Shoes', 'url': '#'}
		];
	}

	this.dataBrands = function() {
		return [
			{'name': 'Acne', 'quantity': 50, 'url': '#'},
			{'name': 'Grüne Erde', 'quantity': 56, 'url': '#'},
			{'name': 'Albiro', 'quantity': 27, 'url': '#'},
			{'name': 'Ronhill', 'quantity': 32, 'url': '#'},
			{'name': 'Oddmolly', 'quantity': 5, 'url': '#'},
			{'name': 'Boudestijn', 'quantity': 9, 'url': '#'},
			{'name': 'Rösch creative culture', 'quantity': 4, 'url': '#'}
		];
	}

	this.imageViewProduct = function() {
		return '1.jpg';
	}

	this.dataCart = function() {
		return [
			{'name': 'Colorblock Scuba', 'price': 59, 'quantity': 1, 'total': 59, 'image': 'one.png'},
			{'name': 'Colorblock Scuba', 'price': 59, 'quantity': 2, 'total': 59, 'image': 'two.png'},
			{'name': 'Colorblock Scuba', 'price': 59, 'quantity': 3, 'total': 59, 'image': 'three.png'},
		];
	}

}]);