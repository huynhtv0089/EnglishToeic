'use restrict';
var shopApp = angular.module('ShopApp', ['ngMessages', 'ngRoute']);
	
shopApp.directive('mySidebar', function() {
	return {
		templateUrl : '../static/apps/pages/sidebar.html'
	};
});

shopApp.config(['$routeProvider', function($routeProvider) {
	$routeProvider
		.when('/', {
			templateUrl : '../static/apps/pages/home.html'
		})
		.when('/products', {
			templateUrl : '../static/apps/pages/products.html'
		})
		.when('/product-details', {
			templateUrl : '../static/apps/pages/product-details.html'
		})
		.when('/checkout', {
			templateUrl : '../static/apps/pages/checkout.html'
		})
		.when('/cart', {
			templateUrl : '../static/apps/pages/cart.html'
		})
		.when('/login', {
			templateUrl : '../static/apps/pages/login.html'
		})
		.when('/blog', {
			templateUrl : '../static/apps/pages/blog.html'
		})
		.when('/blog-single', {
			templateUrl : '../static/apps/pages/blog-single.html'
		})
		.otherwise({
			redirectTo: '/'
		});
}]);

shopApp.controller('indexController', ['$scope', function($scope) {
	$scope.demo = 'hello angular';
}]);