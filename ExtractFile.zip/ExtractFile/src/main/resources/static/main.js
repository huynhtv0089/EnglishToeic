
'use restrict';
var app = angular.module('RLE-App', []);

app.controller('RLE-Ctrl-Compress', ['$scope', '$http', function($scope, $http) {
	
	$http({
		method: 'GET',
		url: '/DoneHandlerFile'
	}).then(function(success) {
		console.log('1. success compress: ' + JSON.stringify(success));
		
		if (success.data.fileNameCompress === null) {
			$scope.fileNameCompressOrigin = '';
		    $scope.fileSizeCompressOrigin = '';
			$scope.fileNameCompress = '';
			$scope.sizeCompress = '';
		    $scope.showStoreFileCompress = '';
		    
		    $scope.fileNameDecompressOrigin = success.data.fileNameOrigin + '.' + success.data.extensionOrigin;
		    $scope.fileSizeDecompressOrigin = success.data.fileSizeOrigin + ' byte';
		    $scope.fileNameDecompress = success.data.fileNameDecompress;
		    $scope.sizeDecompress = success.data.sizeDecompress + ' byte';
		    $scope.showStoreFileDecompress = success.data.saveURL;
		} else {
			$scope.fileNameCompressOrigin = success.data.fileNameOrigin + '.' + success.data.extensionOrigin;
		    $scope.fileSizeCompressOrigin = success.data.fileSizeOrigin + ' byte';
			$scope.fileNameCompress = success.data.fileNameCompress;
			$scope.sizeCompress = success.data.sizeCompress + ' byte';
		    $scope.showStoreFileCompress = success.data.saveURL;
		    
		    $scope.fileNameDecompressOrigin = '';
	    	$scope.fileSizeDecompressOrigin = '';
	    	$scope.fileNameDecompress = '';
	    	$scope.sizeDecompress = '';
	    	$scope.showStoreFileDecompress = '';
		}
	}, function(error) {
		console.log('Compress File: ' + error);
		error[1]= error;
	});

}]);

app.controller('RLE-Ctrl-Decompress', ['$scope', '$http', function($scope, $http) {
	
	$http({
		method: 'GET',
		url: '/DoneHandlerFile'
	}).then(function(success) {
		if (success.data.fileNameDecompress === null) {
			$scope.fileNameDecompressOrigin = '';
	    	$scope.fileSizeDecompressOrigin = '';
	    	$scope.fileNameDecompress = '';
	    	$scope.sizeDecompress = '';
	    	$scope.showStoreFileDecompress = '';
			
			
	    	$scope.fileNameCompressOrigin = success.data.fileNameOrigin + '.' + success.data.extensionOrigin;
		    $scope.fileSizeCompressOrigin = success.data.fileSizeOrigin + ' byte';
			$scope.fileNameCompress = success.data.fileNameCompress;
			$scope.sizeCompress = success.data.sizeCompress + ' byte';
		    $scope.showStoreFileCompress = success.data.saveURL;
		} else {
			$scope.fileNameDecompressOrigin = success.data.fileNameOrigin + '.' + success.data.extensionOrigin;
		    $scope.fileSizeDecompressOrigin = success.data.fileSizeOrigin + ' byte';
		    $scope.fileNameDecompress = success.data.fileNameDecompress;
		    $scope.sizeDecompress = success.data.sizeDecompress + ' byte';
		    $scope.showStoreFileDecompress = success.data.saveURL;
		    
		    $scope.fileNameCompressOrigin = '';
		    $scope.fileSizeCompressOrigin = '';
			$scope.fileNameCompress = '';
			$scope.sizeCompress = '';
		    $scope.showStoreFileCompress = '';
		}
	}, function(error) {
		console.log('Decompress File: ' + error);
		error[1]= error;
	});
}]);