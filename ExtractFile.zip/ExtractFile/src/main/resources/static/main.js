
'use restrict';
var app = angular.module('RLE-App', []);

app.controller('programController', ['$scope', '$http', function($scope, $http) {
	
	$http({
		method: 'GET',
		url: '/DoneHandlerFile'
	}).then(function(success) {		
		console.log('success compress: ' + JSON.stringify(success));
		$scope.fileNameCompress = success.data.fileNameOrigin;
		$scope.fileNameDecompress = success.data.fileNameOrigin;
		
	    $scope.fileSizeCompress = success.data.fileSizeOrigin + ' byte';
	    $scope.fileSizeDecompress = success.data.fileSizeOrigin + ' byte';
	    
	    $scope.sizeCompress = success.data.sizeCompress + ' byte';
	    $scope.sizeDecompress = success.data.sizeDecompress + ' byte';
	}, function(error) {
		console.log('Compress File: ' + error);
		error[1]= error;
	});
    
}]);

app.controller('RLE-Ctrl-Compress', ['$scope', '$http', 'RLE-Service', function($scope, $http, rleService) {
	
	$http({
		method: 'GET',
		url: '/DoneHandlerFile'
	}).then(function(success) {		
		console.log('success compress: ' + JSON.stringify(success));
		$scope.fileNameCompress = success.data.fileName;
	    $scope.fileSizeCompress = success.data.fileSize + ' byte';
	    $scope.sizeCompress = success.data.sizeCompress + ' byte';
	    console.log('fileNameCompress: ' + $scope.fileNameCompress + ', $scope.fileSizeCompress: ' + $scope.fileSizeCompress + ', $scope.sizeCompress' + $scope.sizeCompress);
	}, function(error) {
		console.log('Compress File: ' + error);
		error[1]= error;
	});
    
}]);

app.controller('RLE-Ctrl-Decompress', ['$scope', '$http', 'RLE-Service', function($scope, $http, rleService) {
	
	$http({
		method: 'GET',
		url: '/DoneHandlerFile'
	}).then(function(success) {
		console.log('success decompress: ' + JSON.stringify(success));
		$scope.fileNameDecompress = success.data.fileName;
	    $scope.fileSizeDecompress = success.data.fileSize + ' byte';
	    $scope.sizeDecompress = success.data.sizeDecompress + ' byte';
	    console.log('fileNameDecompress: ' + $scope.fileNameDecompress + ', $scope.fileSizeDecompress: ' + $scope.fileSizeDecompress + ', $scope.sizeDecompress' + $scope.sizeDecompress);
	}, function(error) {
		console.log('Decompress File: ' + error);
		error[1]= error;
	});
}]);

app.factory('RLE-Service', ['$q', function($q) {
	var services = {};
	
/*	services.getFile = function() {
		// Input upload file
		let inputCompressValue = document.getElementById('uploadFileCompress').value;
		let inputDecompressValue = document.getElementById('uploadFileDecompress').value;
		// Label input
		let labelFileNameCompress = document.getElementById('fileNameCompress');
		let labelFileNameDeCompress = document.getElementById('fileNameDecompress');
		
		
		let arrFileNameCompress = inputCompressValue.split('\\');
		let arrFileNameDeCompress = inputDecompressValue.split('\\');
		
		//var fileName = arrFileName[arrFileName.length - 1];
		if(inputCompressValue === '' && inputDecompressValue !== '') {
			labelFileNameCompress.innerHTML = 'Choose file...';
			$('#compressArea *').prop('disabled',true);
			labelFileNameDeCompress.innerHTML = arrFileNameDeCompress[arrFileNameDeCompress.length - 1];			
		} else {
			labelFileNameDeCompress.innerHTML = 'Choose file...';
			$('#deCompressArea *').prop('disabled',true);
			labelFileNameCompress.innerHTML = arrFileNameCompress[arrFileNameCompress.length - 1];
		}
	}*/
	
	return services;
}]);
