package com.compress.controller;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.compress.domain.MetaDataFile;
import com.compress.service.ExtractFileService;
import com.compress.service.FactoryServices;

@Controller
public class ExtractController {
	
	/* Service Extract */
	ExtractFileService extractFileService;
	
	/* MetaData File */
	MetaDataFile metaData;
	
	public ExtractController() {
		this.metaData = new MetaDataFile();
	}
	
	/**
	 * Function get infomation MultipartFile
	 * @param file
	 * @return
	 */
	public MetaDataFile getInfoFile(MultipartFile file) {
		String[] arrFileName = file.getOriginalFilename().split("\\.");
		String fileName = arrFileName[0];
		String extensionFile = arrFileName[1];
		System.out.println("fileName: " + fileName + ", extensionFile: " + extensionFile + ", file.getSize(): " + file.getSize());

		return new MetaDataFile(fileName, extensionFile, file.getSize());
	}
	
	/** 
	 * Function: compress file
	 * @param file
	 * @param value
	 * @return index.html
	 */
	@PostMapping("/compress")
    public String handlerUploadCompress(@RequestParam("file") MultipartFile file, 
    		@RequestParam(value="storeUrl") String storeUrl,
    		@RequestParam(value="compressRLE", defaultValue="notRLE") List<String> value) {	

    	InputStream imageInFile;
	    OutputStream imageOutFile;
	    metaData = this.getInfoFile(file);
	     
		try {
			imageInFile = new BufferedInputStream(file.getInputStream());
			imageOutFile = new FileOutputStream(storeUrl.replace("\\", "\\\\") + "\\" + metaData.getFileNameCompress());
			
			if(!"notRLE".equals(value.get(0)))
				extractFileService = FactoryServices.getExtractFileSerice("RLE");
			else
				extractFileService = FactoryServices.getExtractFileSerice("Flater");
			this.metaData = extractFileService.compressFile(imageInFile, imageOutFile, metaData);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	    
    	return "redirect:/";
    }

	/**
	 * Function decompress file
	 * @param file
	 * @param value
	 * @return index.html
	 */
	@PostMapping("/deCompress")
    public String handlerUploadDecompress(@RequestParam("file") MultipartFile file,
    		@RequestParam(value="storeUrl") String storeUrl,
    		@RequestParam(value="deCompressRLE", defaultValue="notRLE") List<String> value) {	

    	InputStream imageInFile;
	    OutputStream imageOutFile;
	    metaData = this.getInfoFile(file);
	     
		try {
			imageInFile = new BufferedInputStream(file.getInputStream());
			imageOutFile = new FileOutputStream(storeUrl.replace("\\", "\\\\") + "\\" + metaData.getFileNameOrigin());
			
			if(!"notRLE".equals(value.get(0)))
				extractFileService = FactoryServices.getExtractFileSerice("RLE");
			else
				extractFileService = FactoryServices.getExtractFileSerice("Flater");
			this.metaData = extractFileService.deCompressFile(imageInFile, imageOutFile, metaData);
			
			Path fileDone = Paths.get(storeUrl.replace("\\", "\\\\") + "\\" + metaData.getFileNameOrigin());
			Files.move(fileDone, fileDone.resolveSibling(metaData.getFileNameOrigin() + "." + metaData.getDetectExtension()));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	    
    	return "redirect:/";
    }
	
	/**
	 * Function get infomation as soon as handler file
	 * @return
	 */
	@RequestMapping (value = "/DoneHandlerFile", method = RequestMethod.GET)
	public ResponseEntity<Map<String, String>> getInfoHandlerFile() {	
		Map<String, String> dataFile = new HashMap<>();
		
		dataFile.put("fileNameOrigin", this.metaData.getFileNameOrigin());
		dataFile.put("fileSizeOrigin", String.valueOf(this.metaData.getFileSizeOrigin()));
		dataFile.put("sizeCompress", String.valueOf(this.metaData.getSizeCompress()));
		dataFile.put("sizeDecompress", String.valueOf(this.metaData.getSizeDecompress()));
		
		System.out.println("dataFile: " + dataFile.toString());
		
		ResponseEntity<Map<String, String>> response = new ResponseEntity<Map<String, String>>(dataFile, HttpStatus.OK);
		return response;
	}
}
