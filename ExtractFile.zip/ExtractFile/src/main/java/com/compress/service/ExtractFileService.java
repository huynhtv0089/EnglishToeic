package com.compress.service;

import java.io.InputStream;
import java.io.OutputStream;

import com.compress.domain.MetaDataFile;

public interface ExtractFileService {
	
	public MetaDataFile compressFile(InputStream in, OutputStream out, MetaDataFile metaData);
	public MetaDataFile deCompressFile(InputStream in, OutputStream out, MetaDataFile metaData);
	
}
