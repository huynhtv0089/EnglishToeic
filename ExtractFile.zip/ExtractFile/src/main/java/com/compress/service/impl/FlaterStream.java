package com.compress.service.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

import com.compress.domain.MetaDataFile;
import com.compress.service.ExtractFileService;
import com.compress.utility.Utility;

public class FlaterStream implements ExtractFileService {

	@Override
	public MetaDataFile compressFile(InputStream in, OutputStream out, MetaDataFile metaData) {
		System.out.println("compress file DeflaterOutputStream");
		try{
			DeflaterOutputStream Deflater = new DeflaterOutputStream(out);  
			
			/* Get Extension */
			int[] arrExtension = Utility.parseExtension(metaData.getExtensionOrigin());
			for(int i=0; i<arrExtension.length; i++) {
				Deflater.write(arrExtension[i]);
			}
			Deflater.write(27); // number 27 is detect done check extension, because alphabet have 26 character.
			/* End- Get Extension */
			
			int i;  
			while((i=in.read())!=-1){  
				Deflater.write((byte)i);  
				Deflater.flush();  
			}
			in.close();  
			Deflater.close();  
			return metaData;
		}catch(Exception e){
			System.out.println(e);
		}  
		return metaData;
	}

	@Override
	public MetaDataFile deCompressFile(InputStream in, OutputStream out, MetaDataFile metaData) {
		System.out.println("compress file InflaterInputStream");
		try{
			InflaterInputStream inflater = new InflaterInputStream(in);
			boolean stop = false;
			String extensionFile = "";
			
			/* Get Extension */
			while(!stop) {
				int number = inflater.read();
				if(number == 27) {
					stop = true;
				} else {
					extensionFile += Utility.convertNumToString(number);
				}	
			}
			metaData.setDetectExt(extensionFile);
			/* End- Get Extension */
			
			int i;  
			while((i=inflater.read())!=-1){  
				out.write((byte)i);  
				out.flush();
			}
			in.close();  
			out.close();  
			inflater.close();
			return metaData;
		}catch(Exception e){
			System.out.println(e);
		}   
		return metaData;
	}

}
