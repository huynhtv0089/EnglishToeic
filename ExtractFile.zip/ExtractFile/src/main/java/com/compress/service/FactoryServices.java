package com.compress.service;

import com.compress.service.impl.AlogrithmRLE;
import com.compress.service.impl.FlaterStream;

public class FactoryServices {
	
	public static ExtractFileService getExtractFileSerice(String opt) {
		if("RLE".equals(opt))
			return new AlogrithmRLE();
		else if ("Flater".equals(opt))
			return new FlaterStream();
		
		return null;
	}
}
