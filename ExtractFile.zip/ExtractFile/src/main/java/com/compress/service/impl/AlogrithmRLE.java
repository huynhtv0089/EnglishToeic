package com.compress.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.compress.domain.MetaDataFile;
import com.compress.service.ExtractFileService;
import com.compress.utility.Utility;


public class AlogrithmRLE implements ExtractFileService {
	
	@Override
	public MetaDataFile compressFile(InputStream in, OutputStream out, MetaDataFile metaData) {
		try {
			double lengthSize = 0;
			int perByte = in.read(), count = 1;
			
			/* Get Extension */
			int[] arrExtension = Utility.parseExtension(metaData.getExtensionOrigin());
			for(int i=0; i<arrExtension.length; i++) {
				out.write(arrExtension[i]);
			}
			out.write(27); // number 27 is detect done check extension, because alphabet have 26 character.
			/* End- Get Extension */

			while(perByte != -1) { 
				int nextByte = in.read();
				if (perByte == nextByte && count<255) {
					count++;
				}else {
					out.write(count);
					out.write(perByte);
	                count = 1;
	                lengthSize++;                
				}
				perByte = nextByte; // Convert nextByte to perByte, When perByte is -1 then break loop 
			}

			metaData.setSizeCompress(lengthSize*2);
			out.close();
			return metaData;
		} catch(IOException e){
			e.printStackTrace();
			System.out.println("Fail!");
		}
		return metaData;
	}

	@Override
	public MetaDataFile deCompressFile(InputStream in, OutputStream out, MetaDataFile metaData) {
		try{
			double lengthSize = 0;
			boolean stop = false;
			String extensionFile = "";
			
			/* Get Extension */
			while(!stop) {
				int number = in.read();
				if(number == 27) {
					stop = true;
				} else {
					extensionFile += Utility.convertNumToString(number);
				}	
			}
			metaData.setDetectExt(extensionFile);
			/* End- Get Extension */
			
			int count = in.read();
			while(count!=-1){
				int byteData = in.read();
				for(int i = 0; i < count; i++) {
					out.write(byteData);
					lengthSize++;
				}
				
				count = in.read();
			}
			metaData.setSizeDecompress(lengthSize);
			out.close();
			return metaData;
		}
		catch(IOException e){
			e.printStackTrace();
			System.out.println("Fail!");
		}
		return metaData;
	}

}
