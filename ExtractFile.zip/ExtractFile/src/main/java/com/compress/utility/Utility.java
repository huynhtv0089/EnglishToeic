package com.compress.utility;

public class Utility {
	public static String[] ARR_ALPHA = {"a", "b", "c", "d", "e","f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
	
	public static boolean isNumeric(String str) {
		return str.matches("-?\\d+(\\.\\d+)?");
	}
	
	public static int[] parseExtension(String extension) {
		int[] containExt = new int[extension.length()];
		
		for(int i = 0; i < extension.length(); i++) {
			containExt[i] = convertStringToNum(String.valueOf(extension.charAt(i))); 
		}
		
		return containExt;
	}
	
	public static int convertStringToNum(String str) {
		if(!isNumeric(str)) {
			for(int i=0; i<ARR_ALPHA.length; i++) {
				if(str.equals(ARR_ALPHA[i])) {
					return i;
				}
			}
		}
		return 27;
	}
	
	public static String convertNumToString(int number) {
		if(isNumeric(String.valueOf(number))) {
			return ARR_ALPHA[number];
		}
		return null;
	}
}

