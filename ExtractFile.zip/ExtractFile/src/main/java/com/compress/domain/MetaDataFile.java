package com.compress.domain;


public class MetaDataFile {
	/* Constant Extension*/
	public static final String EXTENSION = ".htv";
	
	private String fileNameOrigin;
	private String extensionOrigin;
	private String fileNameCompress;
	private String fileNameDecompress;
	private double fileSizeOrigin;
	private double sizeCompress;
	private double sizeDecompress;
	private double saveURL;
	private String detectExtension;
	
	public MetaDataFile() {
		
	}
	
	public MetaDataFile(String fileNameOrigin, String extensionOrigin, double fileSizeOrigin) {
		this.fileNameOrigin = fileNameOrigin;
		this.extensionOrigin = extensionOrigin;
		this.fileSizeOrigin = fileSizeOrigin;
		this.fileNameCompress = fileNameOrigin + EXTENSION;
	}
	
	public String getFileNameOrigin() {
		return fileNameOrigin;
	}
	public void setFileNameOrigin(String fileNameOrigin) {
		this.fileNameOrigin = fileNameOrigin;
	}
	public String getExtensionOrigin() {
		return extensionOrigin;
	}

	public void setExtensionOrigin(String extensionOrigin) {
		this.extensionOrigin = extensionOrigin;
	}

	public String getFileNameCompress() {
		return fileNameCompress;
	}

	public void setFileNameCompress(String fileNameCompress) {
		this.fileNameCompress = fileNameCompress;
	}

	public String getFileNameDecompress() {
		return fileNameDecompress;
	}

	public void setFileNameDecompress(String fileNameDecompress) {
		this.fileNameDecompress = fileNameDecompress;
	}
	public double getFileSizeOrigin() {
		return fileSizeOrigin;
	}
	public void setFileSizeOrigin(double fileSizeOrigin) {
		this.fileSizeOrigin = fileSizeOrigin;
	}
	public double getSizeCompress() {
		return sizeCompress;
	}
	public void setSizeCompress(double sizeCompress) {
		this.sizeCompress = sizeCompress;
	}
	public double getSizeDecompress() {
		return sizeDecompress;
	}
	public void setSizeDecompress(double sizeDecompress) {
		this.sizeDecompress = sizeDecompress;
	}
	public double getSaveURL() {
		return saveURL;
	}
	public void setSaveURL(double saveURL) {
		this.saveURL = saveURL;
	}

	public String getDetectExtension() {
		return detectExtension;
	}

	public void setDetectExt(String detectExtension) {
		this.detectExtension = detectExtension;
	}

}
