package com.compress.domain;


public class MetaDataFile {
	private String fileNameOrigin;
	private String extensionOrigin;
	private String fileNameCompress;
	private String fileNameDecompress;
	private double fileSizeOrigin;
	private double sizeCompress;
	private double sizeDecompress;
	private String saveURL;
	private String detectExtension;
	
	public MetaDataFile() {
		
	}
	
	public MetaDataFile(String fileNameOrigin, String extensionOrigin, double fileSizeOrigin) {
		this.fileNameOrigin = fileNameOrigin;
		this.extensionOrigin = extensionOrigin;
		this.fileSizeOrigin = fileSizeOrigin;
	}
	
	public String getFileNameOrigin() {
		return fileNameOrigin;
	}
	public void setFileNameOrigin(String fileNameOrigin) {
		this.fileNameOrigin = fileNameOrigin;
	}
	public String getExtensionOrigin() {
		return extensionOrigin;
	}

	public void setExtensionOrigin(String extensionOrigin) {
		this.extensionOrigin = extensionOrigin;
	}

	public String getFileNameCompress() {
		return fileNameCompress;
	}

	public void setFileNameCompress(String fileNameCompress) {
		this.fileNameCompress = fileNameCompress;
	}

	public String getFileNameDecompress() {
		return fileNameDecompress;
	}

	public void setFileNameDecompress(String fileNameDecompress) {
		this.fileNameDecompress = fileNameDecompress;
	}
	public double getFileSizeOrigin() {
		return fileSizeOrigin;
	}
	public void setFileSizeOrigin(double fileSizeOrigin) {
		this.fileSizeOrigin = fileSizeOrigin;
	}
	public double getSizeCompress() {
		return sizeCompress;
	}
	public void setSizeCompress(double sizeCompress) {
		this.sizeCompress = sizeCompress;
	}
	public double getSizeDecompress() {
		return sizeDecompress;
	}
	public void setSizeDecompress(double sizeDecompress) {
		this.sizeDecompress = sizeDecompress;
	}
	public String getSaveURL() {
		return saveURL;
	}
	public void setSaveURL(String saveURL) {
		this.saveURL = saveURL;
	}

	public String getDetectExtension() {
		return detectExtension;
	}

	public void setDetectExtension(String detectExtension) {
		this.detectExtension = detectExtension;
	}

	@Override
	public String toString() {
		return "MetaDataFile [fileNameOrigin=" + fileNameOrigin + ", extensionOrigin=" + extensionOrigin
				+ ", fileNameCompress=" + fileNameCompress + ", fileNameDecompress=" + fileNameDecompress
				+ ", fileSizeOrigin=" + fileSizeOrigin + ", sizeCompress=" + sizeCompress + ", sizeDecompress="
				+ sizeDecompress + ", saveURL=" + saveURL + ", detectExtension=" + detectExtension + "]";
	}

}
