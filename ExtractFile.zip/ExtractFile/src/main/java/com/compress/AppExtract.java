package com.compress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppExtract {
	public static void main(String[] args) {
		SpringApplication.run(AppExtract.class, args);
	}
}
